"""QSE v149 - pendengar Telegram. Jalan terus di VPS: balas perintah dalam hitungan detik dan
pantau trade kamu (/entry) tiap menit. Pasang sekali dengan: bash pasang_listener.sh"""
import fcntl
import json
import os
import sys
import time
import threading
import requests

try:
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
except Exception:
    pass

STATE_DIR = os.environ.get("QSE_STATE_DIR") or os.path.expanduser("~/qse_state")
ENV = os.path.join(STATE_DIR, ".env")
if os.path.exists(ENV):
    for ln in open(ENV):
        if "=" in ln and not ln.strip().startswith("#"):
            k, v = ln.strip().split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

import qse_perintah as QP           # noqa: E402
import qse_saya as SY               # noqa: E402
import qse_alarm as AL              # noqa: E402
import telegram_notify as TG        # noqa: E402
import qse_menu as QM               # noqa: E402

STATE = os.path.join(STATE_DIR, "state.json")
ALIVE = os.path.join(STATE_DIR, "listener.alive")


def _st(upd=None):
    try:
        with open(STATE) as f:
            st = json.load(f)
    except Exception:
        st = {}
    if upd is not None:
        with open(STATE + ".lock", "a") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX)
            try:
                with open(STATE) as f:
                    st = json.load(f)
            except Exception:
                st = {}
            st.update(upd)
            with open(STATE + ".tmp", "w") as f:
                json.dump(st, f)
            os.replace(STATE + ".tmp", STATE)
    return st


# Momentum 15/30 menit dimatikan. Uji 40 koin paling likuid data 15 menit 2021-2026, aturan robot persis:
# 15 menit PF 0.58, 30 menit PF 0.67. Variasi terbaik (30 menit, MARKET, trailing, volume 4x, searah EMA200 4J) PF 1.06.
# Info momentum di posisi kamu juga tidak membantu: geser SL ke entry saat momentum searah, profit turun 45%.
MOMENTUM_AKTIF = False


def _tugas_berkala():
    """Tiap 15 menit: peringatan dini posisi, BTC berbalik, scan momentum 15/30 menit.
    Tiap jam menit ke-2: jalankan main.py (cadangan jadwal GitHub yang sering telat). Ganda dicegah oleh main.py."""
    now = time.time()
    st = _st()
    if now - st.get("tnews", 0) >= 300:          # news tiap 5 menit (dulu 15 menit) supaya tidak terlalu telat
        _st({"tnews": now})
        try:
            import qse_news as NW
            with open(os.path.join(STATE_DIR, "screening_terbaru.json")) as f:
                simbol = {r["symbol"] for r in json.load(f)}
            nb = NW.cek(simbol)
            if nb:
                TG.send(["📰 <b>QSE v149 | NEWS PENTING</b>\n\n" + "\n\n".join(nb)])
        except Exception as ex:
            print("[WARN] news", ex)
    if now - st.get("t15", 0) >= 900:
        _st({"t15": now})
        try:
            import qse_catat as CT
            hasil = CT.cek()
            if hasil:
                TG.send(["📒 <b>QSE v149 | HASIL SARAN JALUR TAMBAHAN</b>\nDicatat otomatis untuk menilai jalur momentum "
                         "dan news. Ketik /jalur untuk rekap.\n\n" + "\n".join(hasil)])
        except Exception as ex:
            print("[WARN] catat", ex)
        try:
            if not MOMENTUM_AKTIF:
                raise StopIteration
            import qse_momentum as MO
            with open(os.path.join(STATE_DIR, "screening_terbaru.json")) as f:
                lama = json.load(f)
            bias = {r["symbol"]: (r.get("pasar") or {}).get("arah") for r in lama
                    if r.get("tf", "240") == "240" and r["rapor"] in ("A", "B")}
            info = {r["symbol"]: dict(rapor=r["rapor"], tick=r.get("tick")) for r in lama if r.get("tf", "240") == "240"}
            pos = {it["sym"]: it["arah"] for it in SY.lihat()["open"].values() if it["status"] in ("TERISI", "TP1")}
            pesan = MO.scan(list(dict.fromkeys(list(pos) + list(bias))), bias, pos, info)
            if pesan:
                TG.send(["⚡ <b>QSE v149 | MOMENTUM 15/30 MENIT</b>\nHanya momentum yang lolos penilaian semua aspek "
                         "yang jadi saran.\n\n" + "\n\n".join(pesan)])
        except StopIteration:
            pass
        except Exception as ex:
            print("[WARN] momentum", ex)
    t4 = int(now // 14400) * 14400
    if now - t4 >= 150 and st.get("ichi4", 0) < t4:
        # jalur Ichimoku tren: kelola trailing SL dan cari sinyal baru sekali tiap candle 4J tutup
        _st({"ichi4": t4})
        try:
            _btc_ema50()
        except Exception as ex:
            print("[WARN] btc ema50", ex)
        # candle 4J baru: lepas semua pin sinyal jalur dari candle sebelumnya, supaya yang disematkan hanya yang penting
        # sekarang (sinyal candle ini, laporan 4 jam terbaru, SL terbaru, peringatan posisi)
        try:
            import qse_strat as ST0
            stp = _st()
            lepas = {}
            for slot in ["pin_gzh", "pin_strat", "pin_ob", "pin_ichi"] + [f"pin_{k}" for k in ST0.STRAT]:
                if stp.get(slot) and stp.get(slot + "_t", 0) < t4:
                    TG.unpin(stp[slot])
                    lepas[slot] = None
            if lepas:
                _st(lepas)
        except Exception as ex:
            print("[WARN] lepas pin lama", ex)
        # semua jalur dikumpulkan dulu, lalu kartu sinyal baru dikirim urut prioritas (label terbukti dulu, lalu PF jalur):
        # yang paling bagus dikirim pertama, jadi berada paling atas di chat
        import qse_strat as ST
        kumpul = []          # (prioritas, slot pin, judul, kartu)
        try:
            import qse_ichimoku as IC
            pesan = IC.jalankan(baru_ok=True)          # telat (VPS sempat mati) tetap boleh asal harga belum lari, dicek di IC
            lain = [m for m in pesan or [] if "BISA DIIKUTI" not in m]
            if lain:
                TG.send(["📈 <b>QSE v149 | ICHIMOKU TREN 4J</b>\n\n" + "\n\n".join(lain)])
            kumpul += [(ST.prioritas_teks("ichimoku", m), "pin_ichi", "ICHIMOKU", m) for m in pesan or [] if "BISA DIIKUTI" in m]
        except Exception as ex:
            print("[WARN] ichimoku", ex)
        try:
            import qse_ob as OB
            pesan = OB.jalankan(baru_ok=True)          # jalur Order Block + Volume, aturan sama dengan backtest 6 tahun
            lain = [m for m in pesan or [] if "BISA DIIKUTI" not in m]
            if lain:
                TG.send(["⭐ <b>QSE v149 | ORDER BLOCK 4J</b>\n\n" + "\n\n".join(lain)])
            kumpul += [(ST.prioritas_teks("orderblock", m), "pin_ob", "ORDER BLOCK + VOLUME (LONG)", m)
                       for m in pesan or [] if "BISA DIIKUTI" in m]
            sl_v = OB.proses_sl()                      # analisa volume SL setelah candle 4J tempat SL kena sudah tutup
            if sl_v:
                TG.send(["📊 <b>QSE v149 | ANALISA VOLUME SL</b>\n\n" + "\n\n".join(sl_v)])
        except Exception as ex:
            print("[WARN] orderblock", ex)
        try:
            import qse_sektor as SKT
            pesan = SKT.jalankan(baru_ok=True)       # v150: kantong kedua, slot sendiri maks 2, lot 0.5x, tidak memakan slot v149
            if pesan:
                TG.send(["🧩 <b>QSE v150 | SINYAL PELENGKAP SEKTOR 4J</b>\n\n" + "\n\n".join(pesan)])
        except Exception as ex:
            print("[WARN] sektor pelengkap", ex)
        try:
            for k, pesan in ST.jalankan(baru_ok=True).items():
                nama = ST.STRAT[k]["nama"].upper()
                lain = [m for m in pesan if "BISA DIIKUTI" not in m]
                if lain:
                    TG.send([f"📈 <b>QSE v149 | {nama}</b>\n\n" + "\n\n".join(lain)])
                kumpul += [(ST.prioritas_teks(k, m), f"pin_{k}", nama, m) for m in pesan if "BISA DIIKUTI" in m]
        except Exception as ex:
            print("[WARN] strategi", ex)
        try:
            kumpul.sort(key=lambda z: z[0], reverse=True)
            kumpul = [z for z in kumpul if ST.lolos_mode(z[0])]          # mode profit: skor label rendah tidak dikirim
            kirim = []
            try:
                import qse_pagi as PG
                btc_b = PG.baris_btc_sinyal()
            except Exception:
                btc_b = ""
            try:
                import qse_modal as MD
                slot_b = MD.baris_slot() if kumpul else []      # sisa slot 5 posisi dan risiko SL tiap orang
            except Exception as ex:
                print("[WARN] slot posisi", ex)
                slot_b = []
            # v149: semua orang sudah 4 posisi jalan (atau kena rem/jeda): kartu ditahan, satu sinyal terbaik dikirim begitu ada slot
            try:
                import qse_modal as MD
                st_all = MD.status_semua()
                if kumpul and st_all and all(x["sisa"] <= 0 or x["rem"] for _, x in st_all):
                    TG.send([f"⏸ <b>QSE v149 | {len(kumpul)} SINYAL BARU DITAHAN</b>\n"
                             + "\n".join(f"• {nm}: {x['alasan'] or 'slot penuh'}" for nm, x in st_all)
                             + "\nBegitu satu posisi selesai, robot mengirim 1 sinyal terbaik yang masih valid."])
                    kumpul = []
            except Exception as ex:
                print("[WARN] tahan sinyal", ex)
            try:
                import qse_btcmap as BM
                peta_btc = BM.teks(singkat=True)          # v149: komando BTC di kepala tiap kartu
            except Exception as ex:
                print("[WARN] peta btc", ex)
                BM, peta_btc = None, ""
            for no, (pr, slot, nama, m) in enumerate(kumpul, 1):
                lb = ST.label_nama_teks(m)
                try:
                    rk = BM.kartu_ringkas(m, pr, nama) if BM else None          # v149: kartu ringkas dan rapi
                except Exception as ex:
                    print("[WARN] kartu ringkas", ex)
                    rk = None
                if rk:
                    # v149: satu sinyal = satu gelembung (gambar chart + kartu ringkas di caption kalau muat), lalu disematkan
                    if no == 1:
                        jd = SY.baris_jadwal(telat_menit=3)
                        try:
                            import qse_catat as CT
                            if CT.rem7()["aktif"]:
                                jd += "\n🧯 <b>REM 7 HARI AKTIF</b>: hanya NILAI 10 yang dikirim, pakai setengah lot"
                        except Exception:
                            pass
                        TG.send([f"📋 <b>QSE v149 | {len(kumpul)} SINYAL BARU</b>\n{jd}"
                                 + ("\n" + peta_btc if peta_btc else "") + ("\n\n" + "\n".join(slot_b) if slot_b else "")])
                    mid = None
                    try:
                        import qse_gambar as GB
                        lv = BM.level_dari_kartu(rk)
                        cap = BM.caption_sinyal(f"📌 <b>SINYAL {no}/{len(kumpul)}</b>\n" + rk)
                        png = GB.chart_sinyal(*__import__("re").search(r"<b>([A-Z0-9]+USDT) (LONG|SHORT)</b>", rk).groups(),
                                              lv["entry"], lv["sl"], lv["tps"], lv["tp"], lv["sup"], lv["res"]) if cap else None
                        if png:
                            mid = TG.kirim_foto(png, cap)
                    except Exception as ex:
                        print("[WARN] gambar sinyal", ex)
                    ids = [mid] if mid else TG.send([f"📌 <b>SINYAL {no}/{len(kumpul)}</b>\n" + rk])
                    _pin_sinyal(ids)
                    try:
                        cr = BM.cara_dari_kartu(rk)          # v149: langkah pasang lengkap tepat di bawah gambar sinyal
                        if cr:
                            TG.send([cr])
                    except Exception as ex:
                        print("[WARN] cara pasang", ex)
                    continue
                try:
                    tambah = BM.baris_kartu(m, pr) if BM else []          # v149: TF, kategori, S/R, komando BTC, skor, rekam jejak
                except Exception as ex:
                    print("[WARN] baris kartu", ex)
                    tambah = []
                ids = TG.send([f"📌 <b>QSE v149 | DETAIL SINYAL BARU {nama}</b>\n"
                               + (f"<b>{ST.kelas(pr[0])}</b>\n" if ST.kelas(pr[0]) else "")
                               +
                               f"{('⭐ ' + ' + '.join(lb)) if lb else 'tanpa label'}  ·  PF jalur {pr[1]:.2f}  ·  "
                               f"dikirim urut prioritas, urutan lengkap ada di pesan 🎯 SINYAL 4 JAM\n"
                               f"{SY.baris_jadwal(telat_menit=3)}\n" + (btc_b + "\n" if btc_b else "")
                               + (peta_btc + "\n" if peta_btc and no == 1 else "")
                               + ("\n".join(tambah) + "\n" if tambah else "")
                               + ("\n".join(slot_b) + "\n" if slot_b and no == 1 else "") + m])
                kirim.append((slot, ids))
            terbaik = {}
            for slot, ids in kirim:
                terbaik.setdefault(slot, ids)          # tiap slot menyematkan sinyal terbaik jalur itu
            for slot, ids in reversed(list(terbaik.items())):
                _pin_ichi(ids, slot)                   # disematkan terbalik: prioritas 1 jadi pin paling atas
        except Exception as ex:
            print("[WARN] kirim prioritas", ex)
        try:
            teks, tanda = SY.kartu_sl()
            if teks and [list(x) for x in tanda] != _st().get("sl_tanda"):
                _st({"sl_tanda": [list(x) for x in tanda]})
                _pin_ichi(TG.send([teks]), "pin_sl")
        except Exception as ex:
            print("[WARN] kartu SL", ex)
    # info pasar 06:00, 12:00, 18:00 WIB (23, 05, 11 UTC): peluang gerak serentak dan arah hari ini. Sekali per sesi.
    hp = int((now + 3600) // 86400)
    sesi = {23: "pagi", 5: "siang", 11: "malam", 17: "tengah"}.get(time.gmtime(now).tm_hour)
    if sesi and st.get("info_" + sesi, 0) < hp:
        _st({"info_" + sesi: hp})
        try:
            import qse_sesi as SS          # v149: laporan sesi 5 bagian (peta BTC, karakter sesi, rotasi, funding/OI, pantauan)
            TG.send([SS.teks(sesi, now)])
        except Exception as ex:
            print("[WARN] laporan sesi", sesi, ex)
            try:
                import qse_pagi as PG
                m = PG.ramal(sesi, st.get("gerak_t", 0))
                if m:
                    TG.send([m])
            except Exception as ex2:
                print("[WARN] info pasar", sesi, ex2)
    # laporan bulanan tanggal 1 jam 08:00 WIB (01:00 UTC): hasil live tiap teknik, label, dan nilai dibanding uji.
    # Info saja, jalur tidak dimatikan otomatis (uji: 40 trade PF<1 terjadi 31-55% waktu walau jalurnya untung).
    g = time.gmtime(now)
    bln = g.tm_year * 12 + g.tm_mon
    if g.tm_mday == 1 and g.tm_hour >= 1 and st.get("bulanan", 0) < bln:
        _st({"bulanan": bln})
        try:
            import qse_catat as CT
            TG.send(["🗓 <b>QSE v149 | LAPORAN BULANAN</b>\nCek rutin: hasil live robot dibanding uji 2021-2026. "
                     "Kalau ada yang jauh di bawah uji setelah 100 trade, saya uji ulang dengan data terbaru.\n\n" + CT.teks()])
        except Exception as ex:
            print("[WARN] laporan bulanan", ex)
        try:
            import qse_berita as BR
            jb = BR.jadwal_bulan()          # jadwal resmi FOMC, CPI, NFP, ECB, BoJ, BoC 1 bulan ke depan
            if jb:
                TG.send([jb + "\n\n" + BR.LEGENDA])
        except Exception as ex:
            print("[WARN] jadwal bulanan", ex)
    # kalender berita 7 hari: Senin 06:10 WIB (Minggu 23:10 UTC), sesudah ForexFactory berganti minggu.
    # Isi: berita berdampak tinggi, bank sentral, earnings saham besar, token unlock, dengan tanda dampak hasil uji.
    if g.tm_wday == 6 and (g.tm_hour, g.tm_min) >= (23, 10) and st.get("kal_minggu", 0) < int(now // 86400):
        _st({"kal_minggu": int(now // 86400)})
        try:
            import qse_berita as BR
            TG.send([BR.teks_kalender_minggu()])
        except Exception as ex:
            print("[WARN] kalender minggu", ex)
    # laporan mingguan hasil live lawan uji: Senin 06:20 WIB (Minggu 23:20 UTC). Jendela kirim 6.5 jam supaya bot yang mati
    # sebentar tetap mengirim begitu hidup lagi. Satu kali per minggu lewat nomor minggu yang berganti di Minggu 23:20 UTC.
    nomor_mg = int((now + 40 * 60 + 3 * 86400) // (7 * 86400))
    if (now + 40 * 60 + 3 * 86400) % (7 * 86400) < 6.5 * 3600 and st.get("lap_mg", 0) < nomor_mg:
        _st({"lap_mg": nomor_mg})
        try:
            import qse_mingguan as MG
            TG.send([MG.teks(simpan=True)])          # versi terjadwal yang boleh menyalakan atau mematikan penyaring otak
        except Exception as ex:
            print("[WARN] laporan mingguan", ex)
    # jadwal token unlock (DefiLlama): disegarkan tiap 7 hari di thread sendiri, dicek tiap jam
    if now - st.get("unlock_cek", 0) >= 3600:
        _st({"unlock_cek": now})
        try:
            import qse_unlock as UL
            UL.segarkan_latar()
        except Exception as ex:
            print("[WARN] segarkan unlock", ex)
    hari = int(now // 86400) * 86400
    # pengingat DCA spot BTC: Senin 08:00 WIB (Senin 01:00 UTC), Rp100.000 per minggu. Uji 2018-2026: beli rutin
    # mingguan +416%, mengalahkan semua aturan menunggu waktu beli. Hari dan jam beli tidak berpengaruh (beda < 1%),
    # Senin dipilih karena sinyal futures robot paling sepi di hari Senin.
    if (time.gmtime(now).tm_wday == 0 and now - hari >= 3600 and st.get("dca_hari", 0) < hari
            and now - hari <= 6 * 3600):
        _st({"dca_hari": hari, "dca_n": st.get("dca_n", 0) + 1})
        try:
            import bybit_fetch as B
            px = (B.get_tickers().get("BTCUSDT") or {}).get("last") or 0
            n = st.get("dca_n", 0) + 1
            TG.send([f"🪙 <b>QSE v149 | JADWAL DCA BTC</b>\nHari ini jadwal beli BTC spot Rp100.000 (minggu ke-{n}).\n"
                     + (f"Harga BTC sekarang {px:,.0f} USDT.\n" if px else "")
                     + "Beli sekarang dengan jumlah yang sama, jangan menunggu turun dan jangan lewati minggu ini walau harga naik. "
                     "Uji 2018-2026: beli rutin tiap minggu +416%, lebih baik dari semua cara menunggu waktu beli."])
        except Exception as ex:
            print("[WARN] dca", ex)
    # pengingat beli kedua (opsional) maksimal sekali seminggu, Selasa sampai Minggu jam 08:00 WIB: hari pertama BTC
    # tutup harian 5% atau lebih di bawah puncak 7 hari. Kalau tidak ada koreksi sampai Minggu, dikirim hari Minggu.
    # Uji 2018-2026 (beli di open hari berikutnya): hasil sama dengan beli tambahan di hari tetap (2018-21 +392.6% lawan
    # +396.6%, 2022-26 +104.6% lawan +104.7%). Jadi ini untuk kenyamanan, bukan keunggulan.
    wd = time.gmtime(now).tm_wday
    minggu = int((now + 3 * 86400) // (7 * 86400))          # nomor minggu yang mulai Senin
    if (wd != 0 and now - hari >= 3600 and now - hari <= 6 * 3600 and st.get("dca2_hari", 0) < hari
            and st.get("dca2_minggu") != minggu):
        _st({"dca2_hari": hari})
        try:
            import bybit_fetch as B
            Dd = B._raw("BTCUSDT", "D", 10)
            Dd = Dd[Dd.index + 86400000 <= now * 1000]
            c7 = Dd["close"].values.astype(float)[-7:]
            turun = (c7[-1] / c7.max() - 1) * 100 if len(c7) else 0
            if turun <= -5 or wd == 6:
                _st({"dca2_minggu": minggu})
                TG.send([f"🪙 <b>QSE v149 | BELI KEDUA MINGGU INI (OPSIONAL)</b>\n"
                         + (f"BTC sedang koreksi {turun:.1f}% dari puncak 7 hari (tutup {c7[-1]:,.0f}). "
                            if turun <= -5 else "Minggu ini tidak ada koreksi 5%, jadi pengingat dikirim hari Minggu. ")
                         + "Kalau ada dana tambahan, ini waktu beli kedua minggu ini. Jadwal utama tetap Senin.\n"
                         "Jujur dari data: uji 2018-2026, beli tambahan saat koreksi hasilnya sama dengan beli di hari tetap "
                         "(beda kurang dari 1%). Tidak ada waktu yang terbukti lebih murah."])
        except Exception as ex:
            print("[WARN] dca2", ex)
    if now - hari >= 15 * 3600 and st.get("tidur_hari", 0) < hari and now - hari <= 16 * 3600:
        # 22:00 WIB: kartu siap tidur kalau ada posisi jalan
        _st({"tidur_hari": hari})
        try:
            teks, _ = SY.kartu_sl(tidur=True)
            if teks:
                TG.send([teks])
        except Exception as ex:
            print("[WARN] kartu tidur", ex)
    if now - hari >= 900 and st.get("unlock_hari", 0) < hari and now - hari <= 6 * 3600:
        # 07:15 WIB: kabari posisi jalan yang koinnya diperkirakan unlock pasokan dalam 3 hari (thread sendiri, CoinGecko pelan)
        _st({"unlock_hari": hari})
        threading.Thread(target=_cek_unlock, daemon=True).start()
    if (time.gmtime(now).tm_wday == 6 and now - hari >= 22.5 * 3600 and st.get("latih_hari", 0) < hari):
        # Senin 05:30 WIB (Minggu 22:30 UTC), sebelum sesi 06:00 WIB: latih ulang otomatis model arah BTC (qse_latih).
        # Model baru dipakai hanya kalau lolos penjaga kualitas. Thread sendiri supaya pemantauan tidak tertahan.
        _st({"latih_hari": hari})
        threading.Thread(target=_latih_arah, daemon=True).start()
    if now - hari >= 300 and st.get("arah_hari", 0) < hari and now - hari <= 6 * 3600:
        # 07:05 WIB, candle harian baru tutup: kirim arah pasar otomatis (BTC, ETH, posisi kamu, berita hari ini)
        _st({"arah_hari": hari})
        try:
            import qse_arah as AR
            TG.send(["🧭 <b>QSE v149 | ARAH PASAR HARIAN</b>\n\n" + AR.harian()])
        except Exception as ex:
            print("[WARN] arah harian", ex)
    for kv, detik in (("viral_siang", 6 * 3600), ("viral_malam", 13 * 3600)):
        # 13:00 dan 20:00 WIB: berita kripto paling ramai dan berdampak, hanya yang belum pernah dikirim. Tanpa perintah.
        if detik <= now - hari <= detik + 3 * 3600 and st.get(kv, 0) < hari:
            _st({kv: hari})
            try:
                import qse_news as NW
                kunci = []
                tv = NW.viral(jam=14, maks=4, sudah=set(st.get("viral_kirim", [])), skor_min=NW.VIRAL_MIN, kunci_out=kunci)
                if tv:
                    _st({"viral_kirim": (list(st.get("viral_kirim", [])) + kunci)[-60:]})
                    TG.send([tv])
            except Exception as ex:
                print("[WARN] viral otomatis", ex)
    _jaga_main(now)
    try:
        _jadwal_lab(now)
    except Exception as ex:
        print("[WARN] jadwal lab", ex)
    tutup4 = int(now // 14400) * 14400
    if now - tutup4 >= 120 and st.get("scan4", 0) < tutup4 * 1000 and now - st.get("susul_coba", 0) >= 900:
        # laporan 4 jam terakhir belum pernah jadi (bot mati, update, atau gagal): susulkan sekarang
        _st({"susul_coba": now})
        _jalankan_main(now)
    jam = int(now // 3600)
    if time.gmtime(now).tm_min >= 2 and st.get("jam_main") != jam:
        _st({"jam_main": jam})
        _jalankan_main(now)


MAIN = {"p": None, "t": 0.0, "lapor": 0.0}
LOG_MAIN = os.path.join(STATE_DIR, "main.log")
def _latih_arah():
    try:
        import qse_latih as LT
        LT.jalankan(kirim=True)
    except Exception as ex:
        print("[WARN] latih arah", ex)


def _posisi_semua():
    """Posisi jalan semua orang di grup, masing-masing diberi nama pemiliknya."""
    out = []
    for u in SY.daftar_pengguna():
        try:
            nm = SY.nama_pengguna(u)
            out += [dict(v, oleh=nm) for v in SY._baca(SY._path_uid(u))["open"].values() if v.get("status") in ("TERISI", "TP1")]
        except Exception as ex:
            print("[WARN] posisi semua", u, ex)
    return out


def _cek_unlock():
    """Info 07:15 WIB: posisi jalan (semua orang) yang koinnya unlock dalam 3 hari. Jadwal resmi DefiLlama dulu (qse_unlock,
    teruji), perkiraan dari lonjakan pasokan beredar CoinGecko hanya untuk koin yang tidak punya jadwal."""
    try:
        import qse_fundamental as FD
        import qse_unlock as UL
        pos = _posisi_semua()
        jadwal_r, kira, now = [], [], time.time()
        for s in sorted({v["sym"] for v in pos if v["sym"] != "BTCUSDT"})[:12]:
            siapa = ", ".join(sorted({f"{v.get('oleh', '')} {v['arah']}".strip() for v in pos if v["sym"] == s}))
            u = UL.dekat(s, hari=3, min_pct=0.5, now=now)
            if u:
                jadwal_r.append(f"🔓 <b>{s}: unlock {u[0]['pct']:.1f}% pasokan {UL._jam(u[0]['t'])}</b>. Posisi: {siapa}.")
                continue
            if UL._ev().get(s):
                continue          # punya jadwal resmi tapi tidak ada unlock dekat
            try:
                tk = FD.tokenomik(s)
            except Exception as ex:
                print("[WARN] tokenomik", s, ex)
                continue
            t_u = tk.get("unlock_ts")
            if t_u and -86400 <= t_u - now <= 3 * 86400:
                kira.append(f"🔓 {s}: perkiraan unlock +{tk['unlock_pct']:g}% pasokan sekitar {FD._tgl(t_u)} sampai "
                            f"{FD._tgl(t_u + 2 * 86400)}. Posisi: {siapa}.")
            time.sleep(15)
        if jadwal_r or kira:
            bag = ["🔓 <b>QSE v149 | UNLOCK TOKEN 3 HARI KE DEPAN</b>"]
            if jadwal_r:
                bag.append("Jadwal resmi (DefiLlama). Uji 2021-2026: 7 hari sebelum unlock 1% atau lebih, koin rata-rata -3% lawan "
                           "BTC dan LONG di saat itu PF 0.28. Posisi jalan: ikuti SL, jangan tambah LONG.\n" + "\n".join(jadwal_r))
            if kira:
                bag.append("Perkiraan dari pola lonjakan pasokan beredar 1 tahun (CoinGecko), bukan jadwal resmi. Info saja. "
                           "Untuk LONG, pastikan SL terpasang.\n" + "\n".join(kira))
            TG.send(["\n\n".join(bag)])
    except Exception as ex:
        print("[WARN] cek unlock", ex)


LABP = {"p": None, "t": 0.0, "tugas": ""}
LOG_LAB = os.path.join(STATE_DIR, "lab", "lab.log")


def _lab_jalan(tugas, now):
    """Jalankan qse_lab.py di proses terpisah (prioritas rendah) supaya balasan perintah tidak tertahan."""
    import subprocess
    os.makedirs(os.path.dirname(LOG_LAB), exist_ok=True)
    if os.path.exists(LOG_LAB) and os.path.getsize(LOG_LAB) > 2_000_000:
        os.replace(LOG_LAB, LOG_LAB + ".1")
    log = open(LOG_LAB, "a")
    log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} lab {tugas} =====\n")
    log.flush()
    LABP.update(p=subprocess.Popen(["nice", "-n", "10", sys.executable, "-u", "qse_lab.py", tugas],
                                   cwd=os.path.dirname(os.path.abspath(__file__)), env=os.environ.copy(),
                                   stdout=log, stderr=subprocess.STDOUT, start_new_session=True), t=now, tugas=tugas)
    log.close()


def _jadwal_lab(now):
    """QSE LAB: sinyal 7 menit setelah candle 4J tutup, riset harian 02:30 WIB (riset pertama langsung setelah update),
    uji bulanan tanggal 1 (atau saat belum pernah). Satu proses lab sekaligus, dihentikan kalau lebih dari 50 menit."""
    import signal
    p = LABP["p"]
    if p is not None:
        if p.poll() is None:
            if now - LABP["t"] > 50 * 60:
                try:
                    os.killpg(p.pid, signal.SIGKILL)
                except Exception:
                    pass
                print("[WARN] lab", LABP["tugas"], "lebih dari 50 menit, dihentikan")
                LABP["p"] = None
            return
        if p.returncode:
            print("[WARN] lab", LABP["tugas"], "berhenti dengan kode", p.returncode)
        LABP["p"] = None
    st = _st()
    tutup4 = int(now // 14400) * 14400
    if now - tutup4 >= 420 and st.get("lab_sinyal", 0) < tutup4:
        _st({"lab_sinyal": tutup4})
        _lab_jalan("sinyal", now)
        return
    hari = int(now // 86400) * 86400
    buku = os.path.join(STATE_DIR, "lab", "buku.json")
    if not os.path.exists(buku) and not st.get("lab_pertama"):
        _st({"lab_pertama": now})
        _lab_jalan("riset", now)
        return
    if now >= hari + 19 * 3600 + 1800 and st.get("lab_riset", 0) < hari:     # 19:30 UTC = 02:30 WIB
        _st({"lab_riset": hari})
        _lab_jalan("riset", now)
        return
    g = time.gmtime(now)
    bln = g.tm_year * 12 + g.tm_mon
    f = os.path.join(STATE_DIR, "lab", "slsaran_auto.json")
    basi = not os.path.exists(f) or now - os.path.getmtime(f) > 32 * 86400
    if st.get("lab_bulan", 0) < bln and (g.tm_mday == 1 or basi) and now - tutup4 >= 1800:
        _st({"lab_bulan": bln})
        _lab_jalan("bulanan", now)


def _main_terkunci():
    """True bila .main.lock dipegang proses lain (main.py masih jalan atau nyangkut)."""
    import fcntl
    try:
        with open(os.path.join(STATE_DIR, ".main.lock"), "a") as f:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(f, fcntl.LOCK_UN)
        return False
    except OSError:
        return True


def _bunuh_main(alasan):
    import signal
    import subprocess
    p = MAIN["p"]
    try:
        if p is not None and p.poll() is None:
            os.killpg(p.pid, signal.SIGKILL)
    except Exception:
        pass
    subprocess.run(["pkill", "-9", "-f", "main.py$"], check=False)
    MAIN["p"] = None
    print("[WARN] main.py dihentikan:", alasan)
    TG.send([f"🛠️ <b>QSE v149 | PERBAIKAN OTOMATIS</b>\n{TG.e(alasan)}. Proses lama aku hentikan, jadwal jalan lagi."])


def _ekor_log(n=600):
    try:
        with open(LOG_MAIN, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - n))
            return f.read().decode("utf-8", "ignore")
    except Exception:
        return ""


def _jaga_main(now):
    """Cek hasil main.py yang dijalankan listener. Gagal di awal (misal file tidak cocok) langsung dilaporkan."""
    p = MAIN["p"]
    if p is None:
        return
    rc = p.poll()
    if rc is None:
        if now - MAIN["t"] > 55 * 60:
            _bunuh_main("main.py nyangkut lebih dari 55 menit")
        return
    MAIN["p"] = None
    if rc != 0 and now - MAIN["lapor"] > 3 * 3600:
        MAIN["lapor"] = now
        TG.send([f"⚠️ <b>QSE v149 | JADWAL GAGAL</b>\nmain.py berhenti dengan kode {rc}. Potongan log:\n"
                 f"<code>{TG.e(_ekor_log())}</code>"])


def _jalankan_main(now):
    import subprocess
    st = _st()
    jalan = MAIN["p"] is not None and MAIN["p"].poll() is None
    if jalan or _main_terkunci():
        # main_mulai baru ditulis main.py beberapa detik setelah start, jadi untuk proses milik listener
        # pakai MAIN["t"]. Tanpa ini run yang baru 2 detik jalan ikut dibunuh (laporan nyangkut palsu).
        mulai = max(MAIN["t"] if jalan else 0.0, st.get("main_mulai", 0))
        if now - mulai > 55 * 60:
            _bunuh_main("main.py sebelumnya nyangkut dan mengunci jadwal")
        else:
            return
    try:
        if os.path.exists(LOG_MAIN) and os.path.getsize(LOG_MAIN) > 2_000_000:
            os.replace(LOG_MAIN, LOG_MAIN + ".1")
        log = open(LOG_MAIN, "a")
        log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} mulai main.py =====\n")
        log.flush()
        MAIN["p"] = subprocess.Popen([sys.executable, "-u", "main.py"],
                                     cwd=os.path.dirname(os.path.abspath(__file__)), env=os.environ.copy(),
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        MAIN["t"] = now
        log.close()
    except Exception as ex:
        print("[WARN] jadwal main", ex)


HB = {"perintah": time.time(), "kerja": time.time()}
BATAS_PERINTAH = 180      # loop perintah macet lebih dari 3 menit -> restart paksa
BATAS_KERJA = 1500        # tugas berkala macet lebih dari 25 menit -> restart paksa


def _btc_ema50():
    """Info saja: kabari saat arah resmi BTC 4J pindah sisi EMA 50 (batas 0.3% dan 2 candle, sekitar 1.5 kali seminggu). Bukan ramalan,
    uji 2021-2026 arah ini tepat sekitar 49% untuk 4 sampai 72 jam ke depan. Tidak menyaring sinyal."""
    import qse_strat as ST
    df = ST._k4("BTCUSDT", 400)
    if df is None or len(df) < 100:
        return
    c = df["close"].values.astype(float)
    naik = ST.btc_arah_resmi(c, ST._ema(c, 50))
    lama = _st().get("btc50")
    _st({"btc50": naik})
    if lama is None or lama == naik:
        return
    TG.send([f"{'🟢' if naik else '🔴'} <b>QSE v149 | ARAH BTC BERUBAH</b>\n{ST.btc_ema50_teks()}\n"
             f"BTC 4J sudah 2 candle tutup lebih dari {ST.BTC_BAND:g}% {'di atas' if naik else 'di bawah'} EMA 50. "
             f"Batas ini membuang flip palsu: tanpa batas 47% flip balik lagi dalam 12 jam, dengan batas 8%. "
             f"Info saja, sinyal jalur tetap jalan seperti biasa."])


def _pin_ichi(ids, slot="pin_ichi"):
    """Slot pin prioritas sinyal terbukti: pin_ichi untuk Ichimoku, pin_ob untuk Order Block. Pin lama slot yang sama
    dilepas. Pin ini dinaikkan lagi ke paling atas setiap laporan 4 jam disematkan (main._naikkan_pin_ichi), selama 24 jam."""
    if not ids or not ids[0]:
        return
    lama = _st().get(slot)
    if TG.pin(ids[0]) is None:
        if lama and lama != ids[0]:
            TG.unpin(lama)
        _st({slot: ids[0], slot + "_t": time.time()})


def _pin_sinyal(ids, umur_jam=12, maks=12):
    """v149: tiap gelembung sinyal disematkan sendiri, jadi daftar pin = sinyal yang bisa dipilih. Pin sinyal lebih dari 12 jam
    (lewat masa entry kebanyakan jalur) dilepas, maksimal 12 pin sinyal."""
    if not ids or not ids[0]:
        return
    now = time.time()
    daftar = [x for x in (_st().get("pin_sinyal") or []) if x and x[0]]
    tetap = []
    for mid, t in daftar:
        if now - t > umur_jam * 3600:
            TG.unpin(mid)
        else:
            tetap.append([mid, t])
    while len(tetap) >= maks:
        TG.unpin(tetap.pop(0)[0])
    if TG.pin(ids[0]) is None:
        tetap.append([ids[0], now])
    _st({"pin_sinyal": tetap})


def _pin_dini(ids):
    """Slot pin kedua: peringatan dini trade kamu. Pin lama slot ini dilepas, pin laporan 4 jam tidak disentuh."""
    if not ids or not ids[0]:
        return
    lama = _st().get("pin_dini")
    if TG.pin(ids[0]) is None:
        if lama and lama != ids[0]:
            TG.unpin(lama)
        _st({"pin_dini": ids[0]})


_GERAK = []          # snapshot harga tiap menit: (waktu, {simbol: harga}), 40 menit terakhir


def _gerak_serentak():
    """Peringatan cepat dari HARGA, bukan berita: berita kripto biasanya terbit setelah harga bergerak.
    Pemicu (30 menit): BTC bergerak 2% atau lebih, atau 70% dari 40 koin paling likuid bergerak 3% searah.
    Uji data 15 menit 2022-2026: sekitar 6 sampai 9 kali per bulan. Jeda 2 jam antar peringatan.
    Tambahan 23 Okt 2026, gerak lebih pelan (3 jam): BTC 3% atau 70% koin bergerak 5% searah, sekitar 9 kali per bulan. Info saja:
    uji 2021-2026 menutup posisi lebih awal saat pasar bergejolak menurunkan profit, jadi aturan jalur tetap dipakai."""
    import bybit_fetch as B
    now = time.time()
    tk = B.get_tickers()
    top = [s for s, _ in sorted(((s, v["turnover"]) for s, v in tk.items() if s.endswith("USDT") and s != "BTCUSDT"),
                                key=lambda z: -z[1])[:40]]
    snap = {s: tk[s]["last"] for s in top + ["BTCUSDT"] if s in tk and tk[s]["last"] > 0}
    _GERAK.append((now, snap))
    while _GERAK and now - _GERAK[0][0] > 190 * 60:
        _GERAK.pop(0)
    if now - _st().get("gerak_t", 0) < 7200:
        return
    pilih = None
    # tingkat kecil (26 Okt 2026): BTC 1.5% atau 60% koin 2% dalam 30 menit, sekitar 19 kali per bulan (data 15 menit 2022-2026)
    for menit, b_th, a_th, lab, fr in ((28, 2, 3, "30 menit", 0.7), (178, 3, 5, "3 jam", 0.7), (28, 1.5, 2, "30 menit (gerak kecil)", 0.6)):
        lama = next((sn for t, sn in _GERAK if now - t >= menit * 60), None)
        if not lama or now - _GERAK[0][0] < menit * 60:
            continue
        lama = next(sn for t, sn in reversed(_GERAK) if now - t >= menit * 60)
        ch = {s: (snap[s] / lama[s] - 1) * 100 for s in snap if lama.get(s)}
        btc = ch.get("BTCUSDT")
        alt = [v for s, v in ch.items() if s != "BTCUSDT"]
        if btc is None or len(alt) < 20:
            continue
        naik = sum(1 for v in alt if v >= a_th) / len(alt)
        turun = sum(1 for v in alt if v <= -a_th) / len(alt)
        if abs(btc) >= b_th or naik >= fr or turun >= fr:
            pilih = (lab, a_th, btc, alt, naik, turun, (btc > 0) if abs(btc) >= b_th else naik >= fr)
            break
    if not pilih:
        return
    lab, a_th, btc, alt, naik, turun, arah_naik = pilih
    _st({"gerak_t": now})
    rows = [f"{'🚀' if arah_naik else '💥'} <b>QSE v149 | PASAR BERGERAK SERENTAK {'NAIK' if arah_naik else 'TURUN'}</b>",
            f"{lab} terakhir: BTC {btc:+.1f}%, {round(naik * len(alt))} dari {len(alt)} koin utama naik {a_th}%+, "
            f"{round(turun * len(alt))} turun {a_th}%+.",
            "Biasanya berita baru muncul setelah ini, jadi peringatan ini dari harga langsung.",
            ("👉 Jangan kejar SHORT di dasar. Uji 2019-2026: koin yang sudah turun 2 ATR harian atau lebih dalam 3 hari biasanya memantul "
             "(median +1% sampai +5% dalam 24 jam). Tunggu sinyal robot berikutnya." if not arah_naik else
             "👉 Jangan kejar LONG di pucuk. Uji 2019-2026: koin yang naik 6 ATR harian atau lebih dalam 3 hari sering koreksi "
             "(median -2% sampai -6% dalam 24 jam), walau sebagian lanjut terbang. Tunggu sinyal robot berikutnya.")]
    pos = []
    try:
        for it in SY.lihat()["open"].values():
            if it["status"] not in ("TERISI", "TP1"):
                continue
            px = (tk.get(it["sym"]) or {}).get("last")
            fl = SY.floating(it, px) if px else None
            searah = (it["arah"] == "LONG") == arah_naik
            pos.append(f"{'🟢' if searah else '🔴'} {it['sym']} {it['arah']} "
                       + (f"{fl['r']:+.2f}R" if fl else "") + (" (searah gerak)" if searah else " (melawan gerak)")
                       + (f"  ·  👤 {it['oleh']}" if it.get("oleh") else ""))
    except Exception as ex:
        print("[WARN] gerak posisi", ex)
    if pos:
        rows += ["", "👤 Posisi kamu:"] + pos + [
            "↳ Melawan gerak: SL di Bybit yang membatasi rugi, jangan geser SL menjauh dan jangan tambah posisi.",
            "↳ Searah gerak: biarkan Trailing Stop atau TP jalur bekerja.",
            "Uji 2021-2026: tutup lebih awal saat pasar bergejolak menurunkan profit 18 sampai 78%."]
    rows += ["", "Jangan kejar harga di luar sinyal robot. Sinyal baru hanya dari laporan 4J dan /sinyal4j yang masih valid."]
    TG.send(["\n".join(rows)])


def _slot_terbuka():
    """v149: orang yang tadi slotnya penuh (4 posisi jalan) dan sekarang punya slot: kirim 1 sinyal terbaik yang masih valid untuknya."""
    import qse_modal as MD
    out = []
    for u in SY.daftar_pengguna():
        try:
            x = MD.status(u)
        except Exception as ex:
            print("[WARN] status slot", u, ex)
            continue
        kunci = f"penuh_{u}"
        penuh = x["sisa"] <= 0 or bool(x["rem"])
        dulu = _st().get(kunci, False)
        if penuh != dulu:
            _st({kunci: penuh})
        if dulu and not penuh:
            SY.pakai(u)
            try:
                t = SY.sinyal_jalur(jam=True) or ""
            finally:
                SY.pakai(None)
            j = t.find("PRIORITAS 2</b>")
            if j > 0:
                t = t[:t.rfind("\n\n", 0, j)]
            nama = SY.nama_pengguna(u)
            if "PRIORITAS 1</b>" in t:
                out.append(f"🔓 <b>QSE v149 | SLOT TERBUKA · {nama}</b>\nSatu posisi selesai. Ini 1 sinyal terbaik yang masih valid sekarang:\n\n" + t)
            else:
                out.append(f"🔓 <b>QSE v149 | SLOT TERBUKA · {nama}</b>\nBelum ada sinyal valid saat ini. Robot tidak memaksa, tunggu sinyal berikutnya.")
    return out


def _tugas_menit():
    try:
        for m in _slot_terbuka():
            TG.send([m])
    except Exception as ex:
        print("[WARN] slot terbuka", ex)
    try:
        _gerak_serentak()
    except Exception as ex:
        print("[WARN] gerak serentak", ex)
    try:
        ps = SY.posisi_serentak()
        if ps:
            TG.send(["⚠️ <b>QSE v149 | SEMUA POSISI MINUS</b>\n\n" + "\n\n".join(ps)])
    except Exception as ex:
        print("[WARN] posisi serentak", ex)
    try:
        pesan = SY.pantau()
        if pesan:
            TG.send(["👤 <b>QSE v149 | TRADE KAMU</b>\n\n" + "\n".join(pesan)])
    except Exception as ex:
        print("[WARN] pantau", ex)
    try:
        sb = SY.siaga_berita()
        if sb:
            TG.send(["📅 <b>QSE v149 | SIAGA BERITA BESAR</b>\n\n" + "\n\n".join(sb)])
    except Exception as ex:
        print("[WARN] siaga berita", ex)
    try:
        import qse_berita as BR
        ag = BR.pesan_agenda(SY.posisi_berita)          # pengingat H-24 dan H-6, perubahan jadwal: otomatis, tanpa perintah
        if ag:
            TG.send(ag)
    except Exception as ex:
        print("[WARN] agenda berita", ex)
    try:
        pesan = SY.peringatan_dini()
        if pesan:
            _pin_dini(TG.send(["⚠️ <b>QSE v149 | PERINGATAN DINI TRADE KAMU</b>\n\n" + "\n\n".join(pesan)]) or [])
        elif _st().get("pin_dini") and not any(it["status"] in ("TERISI", "TP1") for it in SY.lihat()["open"].values()):
            TG.unpin(_st()["pin_dini"])           # semua posisi sudah tutup: lepas pin peringatan
            _st({"pin_dini": None})
    except Exception as ex:
        print("[WARN] dini", ex)
    try:
        import qse_slsaran as SLS          # saran SL: otomatis nyala hanya kalau uji bulanan lab membuktikan lebih untung
        sp = SY.per_orang(SLS.cek)()
        if sp:
            TG.send(["📶 <b>QSE v149 | SARAN PINDAH SL</b>\n\n" + "\n\n".join(sp)])
    except Exception as ex:
        print("[WARN] saran sl", ex)
    try:
        kp = SY.kabar_profit()
        if kp:
            TG.send(["💰 <b>QSE v149 | PROGRES PROFIT TRADE KAMU</b>\n\n" + "\n\n".join(kp)])
    except Exception as ex:
        print("[WARN] kabar profit", ex)
    try:
        fb = SY.sentuh_fib()
        if fb:
            TG.send(["📐 <b>QSE v149 | GOLDEN ZONE HUNTER (GZH)</b>\nSearah tren dan BTC, keluar dengan SL berjalan.\n\n" + "\n\n".join(fb)])
    except Exception as ex:
        print("[WARN] fib", ex)
    try:
        kena = AL.cek()
        gz = [m for m in kena if "GZH TERKONFIRMASI" in m]
        kena = [m for m in kena if m not in gz]
        if gz:
            ids = TG.send([f"📌 <b>QSE v149 | SINYAL GZH GOLDEN ZONE ({len(gz)})</b>\nJalur terbukti, disematkan.\n\n" + "\n\n".join(gz)])
            _pin_ichi(ids, "pin_gzh")
        if kena:
            TG.send(["🔔 <b>QSE v149 | ALARM</b>\n\n" + "\n\n".join(kena)])
    except Exception as ex:
        print("[WARN] alarm", ex)


def _pekerja():
    """Thread terpisah: pantau trade, alarm, berita, momentum. Kalau macet, balasan perintah tetap jalan."""
    terakhir = 0.0
    while True:
        HB["kerja"] = time.time()
        try:
            if time.time() - terakhir >= 60:
                terakhir = time.time()
                _tugas_menit()
            _tugas_berkala()
        except Exception as ex:
            print("[WARN] pekerja", ex)
        HB["kerja"] = time.time()
        time.sleep(5)


def _penjaga():
    """Bila salah satu loop macet, matikan proses. systemd (Restart=always) menghidupkannya lagi dalam 5 detik."""
    while True:
        time.sleep(30)
        a = time.time() - HB["perintah"]
        b = time.time() - HB["kerja"]
        if a > BATAS_PERINTAH or b > BATAS_KERJA:
            print(f"[FATAL] listener macet (perintah {a:.0f}s, kerja {b:.0f}s), restart paksa")
            os._exit(1)


def main():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat = os.environ.get("TELEGRAM_CHAT_ID")
    if not token or not chat:
        raise SystemExit(f"Isi TELEGRAM_BOT_TOKEN dan TELEGRAM_CHAT_ID di {ENV}")
    os.makedirs(STATE_DIR, exist_ok=True)
    print("QSE listener aktif", flush=True)
    try:
        import qse_saya as _SY
        _SY.hapus_manual_sekali()
        _SY.seed_awal()
    except Exception as ex:
        print("[WARN] hapus manual atau seed", ex, flush=True)
    try:
        QM.pastikan_menu()
    except Exception as ex:
        print("[WARN] menu awal", ex, flush=True)
    threading.Thread(target=_pekerja, daemon=True).start()
    threading.Thread(target=_penjaga, daemon=True).start()
    while True:
        HB["perintah"] = time.time()
        with open(ALIVE, "w") as f:
            f.write(str(time.time()))
        off = _st().get("tg_offset", 0)
        try:
            r = requests.get(f"https://api.telegram.org/bot{token}/getUpdates",
                             params={"offset": off, "timeout": 25, "allowed_updates": '["message","callback_query"]'}, timeout=(10, 40))
            js = r.json()
        except Exception as ex:
            print("[WARN] getUpdates", ex)
            time.sleep(5)
            continue
        if not js.get("ok"):
            # 401 = token salah/dicabut, 409 = ada pemanggil getUpdates lain atau webhook aktif
            print("[WARN] getUpdates ditolak Telegram:", r.status_code, js.get("description"))
            time.sleep(10)
            continue
        data = js.get("result", [])
        cmds = []
        for u in data:
            off = max(off, u["update_id"] + 1)
            cq = u.get("callback_query")
            m = (cq or {}).get("message") or u.get("message") or {}
            if str(m.get("chat", {}).get("id")) != str(chat):
                continue
            fr = (cq or m).get("from") or {}
            nm_ = " ".join(x for x in (fr.get("first_name"), fr.get("last_name")) if x) or fr.get("username") or ""
            try:
                c_ = QM.dari_tombol(cq) if cq else QM.dari_pesan(m.get("text"), fr.get("id"))
            except Exception as ex:
                print("[WARN] menu", ex, flush=True)
                c_ = None
            if c_:
                if c_[0] in ("/menu", "/start"):
                    QM.kirim_menu()
                    continue
                cmds.append((c_[0], c_[1], str(fr.get("id", "")) or None, nm_))
                continue
            txt = (m.get("text") or "").strip()
            if cq or not txt.startswith("/"):
                continue
            parts = txt.split()
            if parts[0].split("@")[0].lower() in ("/menu", "/start"):
                QM.kirim_menu()
                continue
            cmds.append((parts[0].split("@")[0].lower(), parts[1:], str(fr.get("id", "")) or None,
                         " ".join(x for x in (fr.get("first_name"), fr.get("last_name")) if x) or fr.get("username") or ""))
        if data:
            _st({"tg_offset": off})
        if cmds:
            print("perintah:", [c[0] for c in cmds], flush=True)
            try:
                print("dibalas:", QP.proses(cmds), flush=True)
            except Exception as ex:
                print("[WARN] proses perintah", ex)


if __name__ == "__main__":
    main()

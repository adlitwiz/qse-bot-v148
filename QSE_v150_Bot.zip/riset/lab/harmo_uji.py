import os, sys, time, pickle, itertools
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harmo as HM
from wf1 import muat, baca

K = os.path.dirname(os.path.abspath(__file__))
ts = lambda s: int(pd.Timestamp(s, tz="UTC").value // 10 ** 6)
P = [("2017-20", ts("2017-09-01"), ts("2021-01-01")), ("2021-23", ts("2021-01-01"), ts("2024-01-01")), ("2024-26", ts("2024-01-01"), ts("2026-11-01"))]

dfs = muat()                                           # 40 koin lama 2017-2026
for f in sorted(os.listdir(f"{K}/data")):              # koin baru 2020-2026
    if f.endswith("_240.csv") and f[:-8] not in dfs:
        dfs[f[:-8]] = baca(f"{K}/data/{f}")
print("koin", len(dfs))
D = {}
for s, df in dfs.items():
    o, h, l, c = (df[k].values for k in ("open", "high", "low", "close"))
    at = HM.atr(h, l, c)
    e200 = pd.Series(c).ewm(span=200, adjust=False).mean().values
    tren = np.sign(c - e200)
    tren[:200] = 0
    D[s] = dict(o=o, h=h, l=l, c=c, t=df.index.values, at=at, tren=tren)
PIV = {}


def piv(s, th):
    k = (s, th)
    if k not in PIV:
        d = D[s]
        PIV[k] = HM.zigzag(d["h"], d["l"], d["c"], d["at"], th)
    return PIV[k]


def pf(r):
    r = np.asarray(r, float)
    neg = -r[r < 0].sum()
    return r[r > 0].sum() / neg if neg > 0 else (9.99 if len(r) else 0.0)


def uji(th, mode, sl_mode, tp, tren, pola):
    hasil = []
    for s, d in D.items():
        tp_mode = tp if tp in ("ad", "ad618") else "r"
        tp_r = float(tp[1:]) if tp.startswith("r") else 2.0
        st = HM.deteksi(d["o"], d["h"], d["l"], d["c"], d["at"], piv(s, th), pola, mode=mode,
                        tren=d["tren"] if tren else None, sl_mode=sl_mode, tp_mode=tp_mode, tp_r=tp_r)
        if tp == "trail":
            st = [(i, s_, e, sl, None, nm, j) for (i, s_, e, sl, _, nm, j) in st]
            hasil += [(t, R, s_, nm, s) for (t, R, s_, nm) in HM.jalan(d["o"], d["h"], d["l"], d["c"], d["t"], st, H=60, trail=3.0, at=d["at"])]
        else:
            hasil += [(t, R, s_, nm, s) for (t, R, s_, nm) in HM.jalan(d["o"], d["h"], d["l"], d["c"], d["t"], st, H=45)]
    return hasil


def baris(h):
    t = np.array([z[0] for z in h]); r = np.array([z[1] for z in h])
    out = []
    for nm, lo, hi in P:
        m = (t >= lo) & (t < hi)
        out.append((int(m.sum()), round(pf(r[m]), 2), round(float(r[m].mean()) if m.any() else 0, 3)))
    return out


if __name__ == "__main__":
    t0 = time.time()
    semua = list(HM.POLA) + ["cypher"]
    rows = []
    for th, mode, sl_mode, tp, tren in itertools.product((2.0, 3.0, 4.0), ("sentuh", "konfirmasi"), ("zona", "x"), ("ad", "ad618", "r2", "r3", "trail"), (False, True)):
        if mode == "konfirmasi" and sl_mode == "x":
            continue
        h = uji(th, mode, sl_mode, tp, tren, semua)
        b = baris(h)
        rows.append(dict(th=th, mode=mode, sl=sl_mode, tp=tp, tren=tren, p=b, n=len(h)))
        print(f"th {th} {mode:10s} sl {sl_mode:4s} tp {tp:5s} tren {int(tren)} | " + " | ".join(f"{nm} n {x[0]:4d} PF {x[1]:.2f} exp {x[2]:+.3f}" for (nm, _, _), x in zip(P, b)), flush=True)
    pickle.dump(rows, open(f"{K}/harmo_grid.pkl", "wb"))
    print("selesai", round(time.time() - t0), "s")

"""Celah harmonic: pola GAGAL. Harga tutup menembus batas jauh PRZ (pola reversal gagal), masuk searah tembusan."""
import os, sys, time, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harmo as HM
import harmo_uji as U


def gagal(o, h, l, c, at, piv, tren=None):
    out = []
    N = len(c)
    pola = list(HM.POLA) + ["cypher"]
    for (i, s, e, sl, tp, nm, jenis) in HM.deteksi(o, h, l, c, at, piv, pola, mode="sentuh", sl_mode="zona", tp_mode="r", tp_r=2.0):
        # cari close yang menembus SL pola (batas jauh - 0.5 ATR) dalam 12 candle setelah sentuh
        for j in range(i, min(i + 12, N - 1)):
            if (c[j] < sl) if s == 1 else (c[j] > sl):
                if tren is not None and tren[j] != -s:
                    break
                out.append((j + 1, -s, o[j + 1], None, None, nm, "open"))
                break
            if (h[j] >= tp) if s == 1 else (l[j] <= tp):
                break                      # pola berhasil, tidak ada tembusan
    return out


for th, slk, trail, tren in itertools.product((2.0, 3.0), (1.5, 2.0), (3.0, 4.0), (False, True)):
    res = []
    for s, d in U.D.items():
        st = gagal(d["o"], d["h"], d["l"], d["c"], d["at"], U.piv(s, th), d["tren"] if tren else None)
        st2 = []
        for (i, s_, e, _, _, nm, j) in st:
            if i >= len(d["c"]):
                continue
            risk = slk * d["at"][i - 1]
            st2.append((i, s_, e, e - s_ * risk, None, nm, j))
        res += [(t, R, s_, nm, s) for (t, R, s_, nm) in HM.jalan(d["o"], d["h"], d["l"], d["c"], d["t"], st2, H=60, trail=trail, at=d["at"])]
    b = U.baris(res)
    print(f"GAGAL th {th} SL {slk} trail {trail} tren {int(tren)} | " + " | ".join(f"{p[0]} n {x[0]:4d} PF {x[1]:.2f} exp {x[2]:+.3f}" for p, x in zip(U.P, b)), flush=True)

import os, sys, time, pickle, itertools
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harmo as HM
import harmo_uji as U

t0 = time.time()
print("=== per pola ===")
for th, tp, tren in itertools.product((2.0, 3.0), ("r2", "trail"), (False, True)):
    for nm in list(HM.POLA) + ["cypher"]:
        b = U.baris(U.uji(th, "sentuh", "zona", tp, tren, [nm]))
        print(f"th {th} tp {tp:5s} tren {int(tren)} {nm:9s} | " + " | ".join(f"{p[0]} n {x[0]:4d} PF {x[1]:.2f}" for p, x in zip(U.P, b)), flush=True)
for tol in (0.03, 0.08):
    HM.TOL = tol
    b = U.baris(U.uji(2.0, "sentuh", "zona", "trail", False, list(HM.POLA) + ["cypher"]))
    print(f"TOL {tol} semua pola th 2 trail | " + " | ".join(f"{p[0]} n {x[0]:4d} PF {x[1]:.2f}" for p, x in zip(U.P, b)), flush=True)
HM.TOL = 0.05
print()
print("=== zona harmonic sebagai konfluensi sinyal robot ===")
T = pd.read_pickle(os.path.join(U.K, "strat/semua_f.pkl"))
E = pd.read_pickle(os.path.join(U.K, "strat/era17.pkl"))
T = pd.concat([E, T], ignore_index=True)
T["t"] = pd.to_datetime(T.t, utc=True)
T["tm"] = (T.t - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(milliseconds=1)
for th in (2.0, 3.0):
    ev = {}
    for s, d in U.D.items():
        st = HM.deteksi(d["o"], d["h"], d["l"], d["c"], d["at"], U.piv(s, th), list(HM.POLA) + ["cypher"], mode="sentuh", sl_mode="zona", tp_mode="r", tp_r=2.0)
        ev[s] = {1: np.sort([d["t"][i] for (i, s_, *_r) in st if s_ == 1]), -1: np.sort([d["t"][i] for (i, s_, *_r) in st if s_ == -1])}
    hit = []
    for sym, tm, a in zip(T.sym, T.tm, T.arah):
        e = ev.get(sym, {}).get(int(a))
        if e is None or not len(e):
            hit.append(False)
            continue
        k = np.searchsorted(e, tm, side="right") - 1
        hit.append(bool(k >= 0 and tm - e[k] <= 6 * HM.H4))
    T[f"h{int(th)}"] = hit
    for nm, m in (("dekat zona harmonic searah", T[f"h{int(th)}"]), ("tanpa", ~T[f"h{int(th)}"])):
        o = []
        for p, lo, hi in U.P:
            x = T[m & (T.tm >= lo) & (T.tm < hi)].R
            o.append(f"{p} n {len(x):5d} PF {U.pf(x.values):.2f} exp {x.mean():+.3f}")
        print(f"th {th} {nm:28s} " + " | ".join(o), flush=True)
print("selesai", round(time.time() - t0), "s")

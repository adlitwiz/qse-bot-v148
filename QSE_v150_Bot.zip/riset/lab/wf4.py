"""Tahap 4: (a) pengaruh ukuran kolam teknik ke hasil maju, (b) penyaring rezim global yang dipelajari dari data latih."""
import os, sys, pickle
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wf2 as W
import wf3 as W3

ts, pf, potong = W.ts, W.pf, W.potong
tahun = [2021, 2022, 2023, 2024, 2025, 2026]
asli = list(W.TR)
print("(a) ukuran kolam teknik")
for n in (500, 1000, 2000, 4000):
    W.TR = asli[:n] + [np.zeros((0, 5))] * (len(asli) - n)
    semua, per = [], {}
    for y in tahun:
        sel, nc = W.pilih(ts("2017-09-01"), ts(f"{y}-01-01"))
        f = W.gabung(sel, ts(f"{y}-01-01"), ts(f"{y + 1}-01-01"))
        per[y] = pf(f[:, 1]) if len(f) else 0
        if len(f):
            semua.append(f)
    A = np.vstack(semua)
    print(f"  kolam {n:5d}: " + " | ".join(f"{y} PF {per[y]:.2f}" for y in tahun) + f" || n {len(A)} PF {pf(A[:, 1]):.2f} total {A[:, 1].sum():+.0f}R", flush=True)
W.TR = asli
print("(b) penyaring rezim global dari data latih (lewati rezim yang PF latih teknik terpilih di bawah batas)")
E2 = W3.E2
for batas in (1.0, 1.1, 1.2):
    semua, per = [], {}
    for y in tahun:
        lo, hi = ts("2017-09-01"), ts(f"{y}-01-01")
        lat = np.vstack([potong(W.TR[j], lo, hi) for j in E2[y]])
        rz = W.rez_of(lat[:, 0])
        buruk = {k for k in range(8) if (rz == k).sum() >= 100 and pf(lat[rz == k, 1]) < batas}
        f = W.gabung(E2[y], hi, ts(f"{y + 1}-01-01"))
        m = np.array([k not in buruk for k in W.rez_of(f[:, 0])])
        per[y] = (pf(f[m, 1]), sorted(buruk))
        semua.append(f[m])
    A = np.vstack(semua)
    print(f"  batas {batas}: " + " | ".join(f"{y} PF {per[y][0]:.2f} skip{per[y][1]}" for y in tahun) + f" || n {len(A)} PF {pf(A[:, 1]):.2f} total {A[:, 1].sum():+.0f}R", flush=True)

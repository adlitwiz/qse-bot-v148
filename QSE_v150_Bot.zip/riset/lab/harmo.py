"""Uji pola harmonic (XABCD) dan zona PRZ di candle 4J. Kausal: pivot zigzag baru dipakai setelah terkonfirmasi.
Pola: Gartley, Bat, Butterfly, Crab, Deep Crab, Cypher. Bullish dan bearish (cermin)."""
import os, sys, time, pickle, itertools
import numpy as np, pandas as pd

H4 = 4 * 3600 * 1000
BIAYA = 0.0015
TOL = 0.05

# nama: (rentang AB/XA, rentang BC/AB, rasio D terhadap XA dari A, rentang CD/BC)  untuk XABCD standar
POLA = {
    "gartley": ((0.568, 0.668), (0.382, 0.886), 0.786, (1.13, 1.618)),
    "bat": ((0.382, 0.50), (0.382, 0.886), 0.886, (1.618, 2.618)),
    "butterfly": ((0.736, 0.836), (0.382, 0.886), 1.27, (1.618, 2.24)),
    "crab": ((0.382, 0.618), (0.382, 0.886), 1.618, (2.24, 3.618)),
    "deepcrab": ((0.836, 0.936), (0.382, 0.886), 1.618, (2.0, 3.618)),
}


def atr(h, l, c, n=14):
    pc = np.r_[c[0], c[:-1]]
    tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    out = np.empty(len(tr))
    out[0] = tr[0]
    a = 1 / n
    for i in range(1, len(tr)):
        out[i] = out[i - 1] + a * (tr[i] - out[i - 1])
    return out


def zigzag(h, l, c, at, th):
    """Pivot kausal: high/low ekstrem dikonfirmasi saat CLOSE berbalik th*ATR dari ekstrem itu.
    Return list (bar_pivot, harga, tipe +1 high/-1 low, bar_konfirmasi)."""
    piv = []
    arah = 0
    hi_i, hi_p, lo_i, lo_p = 0, h[0], 0, l[0]
    for i in range(1, len(h)):
        if arah == 0:
            if h[i] > hi_p:
                hi_i, hi_p = i, h[i]
            if l[i] < lo_p:
                lo_i, lo_p = i, l[i]
            if hi_i < i and hi_p - c[i] >= th * at[i] and hi_i > lo_i:
                piv.append((hi_i, hi_p, 1, i))
                arah, lo_i, lo_p = -1, i, l[i]
            elif lo_i < i and c[i] - lo_p >= th * at[i] and lo_i > hi_i:
                piv.append((lo_i, lo_p, -1, i))
                arah, hi_i, hi_p = 1, i, h[i]
        elif arah == 1:                      # pivot terakhir low, cari high
            if h[i] > hi_p:
                hi_i, hi_p = i, h[i]
            if hi_p - c[i] >= th * at[i]:
                piv.append((hi_i, hi_p, 1, i))
                arah, lo_i, lo_p = -1, i, l[i]
        else:                                # pivot terakhir high, cari low
            if l[i] < lo_p:
                lo_i, lo_p = i, l[i]
            if c[i] - lo_p >= th * at[i]:
                piv.append((lo_i, lo_p, -1, i))
                arah, hi_i, hi_p = 1, i, h[i]
    return piv


def deteksi(o, h, l, c, at, piv, pola_dipakai, mode="sentuh", tren=None, sl_mode="zona", tp_mode="ad", tp_r=2.0):
    """Cari setup di tiap leg CD. Return list (bar_masuk, arah, entry, sl, tp, nama_pola).
    mode sentuh: limit di batas dekat PRZ. mode konfirmasi: tunggu candle tutup balik keluar zona (maks 3 candle), masuk open berikutnya."""
    out = []
    N = len(c)
    for k in range(3, len(piv)):
        X, A, B, C = piv[k - 3], piv[k - 2], piv[k - 1], piv[k]
        s = 1 if C[2] == 1 else -1          # C high -> D low -> setup LONG (bullish)
        x, a, b, cc = X[1], A[1], B[1], C[1]
        xa = abs(a - x)
        ab = abs(a - b)
        bc = abs(cc - b)
        if xa <= 0 or ab <= 0 or bc <= 0:
            continue
        r_ab, r_bc = ab / xa, bc / ab
        mulai = C[3] + 1                    # leg CD dipantau setelah C terkonfirmasi
        akhir = piv[k + 1][3] if k + 1 < len(piv) else N - 1   # leg berakhir saat pivot D terkonfirmasi
        kand = []
        for nm in pola_dipakai:
            if nm == "cypher":
                xc = abs(cc - x)
                if not (0.382 <= r_ab <= 0.618 and 1.13 <= xc / xa <= 1.414):
                    continue
                d = cc - s * 0.786 * xc
                zona = (d - TOL * xc, d + TOL * xc)
            else:
                (ab1, ab2), (bc1, bc2), dx, (cd1, cd2) = POLA[nm]
                if not (ab1 <= r_ab <= ab2 and bc1 <= r_bc <= bc2):
                    continue
                d = a - s * dx * xa
                zx = (d - TOL * xa, d + TOL * xa)
                p1, p2 = cc - s * cd1 * bc, cc - s * cd2 * bc
                zb = (min(p1, p2), max(p1, p2))
                if zx[1] < zb[0] or zb[1] < zx[0]:
                    continue                # proyeksi BC tidak bertemu level XA: tidak ada konfluensi
                zona = (max(zx[0], zb[0]), min(zx[1], zb[1]))
                if zona[1] - zona[0] < 0.01 * xa:
                    zona = zx
            kand.append((nm, zona))
        if not kand:
            continue
        nm, zona = kand[0]
        dekat = zona[1] if s == 1 else zona[0]      # batas zona yang pertama disentuh
        jauh = zona[0] if s == 1 else zona[1]
        for i in range(mulai, min(akhir + 1, N)):
            if s == 1 and h[i] > cc or s == -1 and l[i] < cc:
                break                               # harga lewat C: pola batal
            sentuh = l[i] <= dekat if s == 1 else h[i] >= dekat
            if not sentuh:
                continue
            if tren is not None and tren[i - 1] != s:
                break
            if mode == "sentuh":
                e = min(o[i], dekat) if s == 1 else max(o[i], dekat)
                if sl_mode == "zona":
                    sl = jauh - s * 0.5 * at[i - 1]
                else:                               # X: di balik X untuk Gartley/Bat, di balik zona untuk yang lain
                    sl = (x - s * 0.25 * at[i - 1]) if nm in ("gartley", "bat") else jauh - s * 0.5 * at[i - 1]
                if (e - sl) * s <= 0:
                    break
                ad = abs(a - e)
                tp = (e + s * 0.382 * ad) if tp_mode == "ad" else (e + s * 0.618 * ad) if tp_mode == "ad618" else (e + s * tp_r * abs(e - sl))
                out.append((i, s, e, sl, tp, nm, "limit"))
            else:
                for j in range(i, min(i + 3, N - 1)):
                    if (l[j] < jauh - s * 0.5 * at[j - 1]) if s == 1 else (h[j] > jauh - s * 0.5 * at[j - 1]):
                        break
                    if (c[j] > dekat) if s == 1 else (c[j] < dekat):
                        e = o[j + 1]
                        ekstrem = l[i:j + 1].min() if s == 1 else h[i:j + 1].max()
                        sl = ekstrem - s * 0.25 * at[j]
                        if (e - sl) * s <= 0:
                            break
                        ad = abs(a - e)
                        tp = (e + s * 0.382 * ad) if tp_mode == "ad" else (e + s * 0.618 * ad) if tp_mode == "ad618" else (e + s * tp_r * abs(e - sl))
                        out.append((j + 1, s, e, sl, tp, nm, "open"))
                        break
            break                                   # satu entry per pola
    return out


def jalan(o, h, l, c, t, setups, H=45, trail=None, at=None):
    """Simulasi trade. limit: masuk di bar i (intrabar, cek SL/TP mulai bar i setelah masuk, konservatif: SL dulu).
    Return list (t_masuk, R, arah)."""
    res = []
    akhir = -1
    N = len(c)
    for (i, s, e, sl, tp, nm, jenis) in sorted(setups):
        if i <= akhir or i >= N:
            continue
        risk = abs(e - sl)
        if risk <= 0 or risk / e < 0.003 or risk / e > 0.15:
            continue
        R = None
        j = i
        best = e
        stop = sl
        while j < min(N, i + H):
            hi, lo = h[j], l[j]
            if (lo <= stop) if s == 1 else (hi >= stop):
                R = (stop - e) * s / risk
                break
            if tp is not None and not (j == i and jenis == "limit") and ((hi >= tp) if s == 1 else (lo <= tp)):
                R = (tp - e) * s / risk
                break
            if trail and at is not None and not (j == i and jenis == "limit"):
                best = max(best, hi) if s == 1 else min(best, lo)
                stop = max(stop, best - trail * at[j]) if s == 1 else min(stop, best + trail * at[j])
            j += 1
        if R is None:
            if i + H >= N:
                continue
            j = i + H - 1
            R = (c[j] - e) * s / risk
        res.append((int(t[i]), R - BIAYA * e / risk, s, nm))
        akhir = j
    return res

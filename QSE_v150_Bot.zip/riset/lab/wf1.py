"""Tahap 1 uji maju proses lab: data 40 koin lama 2017-2026 (Binance spot 2017-2020 disambung Bybit perp),
simulasi N teknik acak sekali di seluruh sejarah, simpan semua trade."""
import os, sys, time, random, pickle
import numpy as np, pandas as pd
os.environ["QSE_STATE_DIR"] = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/labstate"
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot")
import qse_lab as LB

K = os.path.dirname(os.path.abspath(__file__))
N = int(sys.argv[1]) if len(sys.argv) > 1 else 3000


def baca(p):
    df = pd.read_csv(p, index_col=0, parse_dates=True)
    df.index = (df.index - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(milliseconds=1)
    return df[["open", "high", "low", "close", "volume"]].astype(float)


def muat():
    out = {}
    for f in sorted(os.listdir(f"{K}/data17")):
        if not f.endswith("_240.csv"):
            continue
        s = f[:-8]
        a = baca(f"{K}/data17/{f}")
        pb = f"{K}/data/{s}_240.csv"
        if os.path.exists(pb):
            b = baca(pb)
            df = pd.concat([a[a.index < b.index[0]], b])
        else:
            df = a
        out[s] = df[~df.index.duplicated(keep="last")].sort_index()
    return out


if __name__ == "__main__":
    t0 = time.time()
    dfs = muat()
    btc = LB.btc_arah(dfs["BTCUSDT"])
    FS = {s: LB.fitur(df, btc) for s, df in dfs.items()}
    print("muat", len(FS), "koin", round(time.time() - t0), "s", flush=True)
    rng = random.Random(2017)
    specs, seen = [], set()
    while len(specs) < N:
        sp = LB.acak_spec(rng)
        k = LB._id(sp)
        if k in seen or LB._mirip_jalur(sp):
            continue
        seen.add(k)
        specs.append(sp)
    syms = sorted(FS)
    hasil = []
    for j, sp in enumerate(specs):
        per = LB.jalankan(FS, sp)
        rows = [(z[0], z[1], z[2], z[3], ci) for ci, s in enumerate(syms) for z in per[s]]
        a = np.array(rows, dtype=np.float64) if rows else np.zeros((0, 5))
        hasil.append(a)
        if j % 500 == 0:
            print(j, round(time.time() - t0), "s", flush=True)
    pickle.dump(dict(specs=specs, trades=hasil, syms=syms), open(f"{K}/wf_trades.pkl", "wb"))
    print("selesai", round(time.time() - t0), "s")

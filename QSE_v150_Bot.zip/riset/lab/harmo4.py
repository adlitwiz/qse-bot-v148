"""Cek celah harmonic GAGAL lawan masuk acak (arah tren EMA200 sama, jumlah sama per koin, cara keluar sama)."""
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harmo as HM
import harmo_uji as U
from harmo3 import gagal

rng = np.random.default_rng(3)
for th, slk, trail, tren in ((2.0, 2.0, 4.0, True), (2.0, 2.0, 4.0, False), (2.0, 1.5, 4.0, True), (2.0, 2.0, 3.0, True), (2.5, 2.0, 4.0, True), (1.5, 2.0, 4.0, True)):
    res, acak = [], []
    for s, d in U.D.items():
        st = gagal(d["o"], d["h"], d["l"], d["c"], d["at"], U.piv(s, th), d["tren"] if tren else None)
        st2 = [(i, s_, e, e - s_ * slk * d["at"][i - 1], None, nm, j) for (i, s_, e, _, _, nm, j) in st if i < len(d["c"])]
        res += HM.jalan(d["o"], d["h"], d["l"], d["c"], d["t"], st2, H=60, trail=trail, at=d["at"])
        N = len(d["c"])
        for s_ in (1, -1):
            n = sum(1 for z in st2 if z[1] == s_)
            pool = np.nonzero((d["tren"][:-1] == s_) if tren else np.ones(N - 1, bool))[0] + 1
            pool = pool[pool > 250]
            if not n or not len(pool):
                continue
            for _ in range(3):
                pick = rng.choice(pool, size=min(n, len(pool)), replace=False)
                st3 = [(int(i), s_, d["o"][i], d["o"][i] - s_ * slk * d["at"][i - 1], None, "acak", "open") for i in pick]
                acak += HM.jalan(d["o"], d["h"], d["l"], d["c"], d["t"], st3, H=60, trail=trail, at=d["at"])
    b, a = U.baris(res), U.baris(acak)
    print(f"th {th} SL {slk} trail {trail} tren {int(tren)} | " + " | ".join(f"{p[0]} PF {x[1]:.2f} (acak {y[1]:.2f}) n {x[0]}" for p, x, y in zip(U.P, b, a)), flush=True)

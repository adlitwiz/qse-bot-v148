"""Tahap 3: penyaring bentuk pasar (rezim) dan hasil terbaru, diuji maju di atas seleksi tahunan eksperimen 2."""
import os, sys, pickle, time
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wf2 as W

K = W.K
H4, DAY = W.H4, W.DAY
ts = W.ts
E2 = pickle.load(open(f"{K}/wf_e2.pkl", "rb"))["sel2"]
try:
    c = pickle.load(open(f"{K}/wf_cache.pkl", "rb"))
    W.CACHE_N.update(c["CACHE_N"])
    W.CACHE_B.update(c["CACHE_B"])
except Exception:
    pass
pf, potong = W.pf, W.potong
tahun = sorted(E2)


def rez_pf(a, minn=30):
    """PF per rezim dari trade latih a. dict kode -> (n, pf)."""
    out = {}
    if not len(a):
        return out
    rz = W.rez_of(a[:, 0])
    for k in range(8):
        r = a[rz == k, 1]
        out[k] = (len(r), pf(r) if len(r) else 0.0)
    return out


def ringkas(r):
    r = np.asarray(r, float)
    return f"n {len(r):5d} PF {pf(r):.2f} total {r.sum():+7.1f}R" if len(r) else "n 0"


def jalankan(nama, ambil):
    """ambil(y, j, trade_baris, info) -> bool. Gabung semua tahun."""
    semua, per_tahun = [], {}
    for y in tahun:
        lo, hi = ts("2017-09-01"), ts(f"{y}-01-01")
        t_lo, t_hi = hi, ts(f"{y + 1}-01-01")
        r_y = []
        for j in E2[y]:
            a = W.TR[j]
            info = dict(latih=potong(a, lo, hi), semua=a)
            f = potong(a, t_lo, t_hi)
            for row in f:
                if ambil(y, j, row, info):
                    r_y.append(row[1])
        per_tahun[y] = r_y
        semua += r_y
    print(f"{nama:52s} " + " | ".join(f"{y}: PF {pf(per_tahun[y]):.2f}" for y in tahun) + f" || {ringkas(semua)}", flush=True)
    return semua


if __name__ == "__main__":
    RZ = {}

    def rz_info(y, j, info):
        k = (y, j)
        if k not in RZ:
            RZ[k] = rez_pf(info["latih"])
        return RZ[k]

    jalankan("STATIS (semua trade teknik terpilih)", lambda y, j, row, info: True)
    for batas in (1.0, 1.15, 1.3):
        for default in (True, False):
            def f(y, j, row, info, batas=batas, default=default):
                k = W.REZ.get(int(row[0] // DAY), -1)
                n, p = rz_info(y, j, info).get(k, (0, 0))
                return (p >= batas) if n >= 30 else default
            jalankan(f"REZIM PF latih >= {batas} (rezim sepi: {'ambil' if default else 'lewati'})", f)
    # hasil terbaru: PF trade yang sudah selesai dalam 180 / 365 hari terakhir
    for hari, batas in ((180, 1.0), (180, 1.2), (365, 1.0), (365, 1.2), (90, 1.0)):
        def g(y, j, row, info, hari=hari, batas=batas):
            a = info["semua"]
            sel = a[(a[:, 0] + a[:, 2] * H4 < row[0]) & (a[:, 0] + a[:, 2] * H4 >= row[0] - hari * DAY)]
            return pf(sel[:, 1]) >= batas if len(sel) >= 15 else True
        jalankan(f"TERBARU {hari} hari PF >= {batas}", g)
    # gabungan rezim 1.15 (ambil kalau sepi) + terbaru 180 hari PF >= 1.0
    def h(y, j, row, info):
        k = W.REZ.get(int(row[0] // DAY), -1)
        n, p = rz_info(y, j, info).get(k, (0, 0))
        if n >= 30 and p < 1.15:
            return False
        a = info["semua"]
        sel = a[(a[:, 0] + a[:, 2] * H4 < row[0]) & (a[:, 0] + a[:, 2] * H4 >= row[0] - 180 * DAY)]
        return pf(sel[:, 1]) >= 1.0 if len(sel) >= 15 else True
    jalankan("REZIM 1.15 + TERBARU 180 hari 1.0", h)
    # rezim sekarang: sebaran trade per rezim
    print()
    print("Hasil maju statis per rezim (gabung semua tahun):")
    rows = []
    for y in tahun:
        for j in E2[y]:
            f = potong(W.TR[j], ts(f"{y}-01-01"), ts(f"{y + 1}-01-01"))
            if len(f):
                rows.append(np.c_[f[:, :2], W.rez_of(f[:, 0])])
    A = np.vstack(rows)
    for k in range(8):
        r = A[A[:, 2] == k, 1]
        print(f"   {W.NAMA_REZ[k]:40s} {ringkas(r)}")

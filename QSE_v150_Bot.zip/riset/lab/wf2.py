"""Tahap 2 uji maju proses lab. Seleksi teknik hanya dari data latih, lalu nilai hasilnya di tahun berikutnya.
Juga uji penyaring rezim pasar (bentuk pasar) dan penyaring hasil terbaru."""
import os, sys, time, pickle
import numpy as np, pandas as pd
os.environ["QSE_STATE_DIR"] = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/labstate"
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot")
import qse_lab as LB
from wf1 import muat

K = os.path.dirname(os.path.abspath(__file__))
H4 = LB.H4
DAY = 86400000
ts = lambda s: int(pd.Timestamp(s, tz="UTC").value // 10 ** 6)

D = pickle.load(open(f"{K}/wf_trades.pkl", "rb"))
specs, TR, syms = D["specs"], D["trades"], D["syms"]
dfs = muat()
btc = LB.btc_arah(dfs["BTCUSDT"])
FS = {s: LB.fitur(df, btc) for s, df in dfs.items()}
idmap = {LB._id(sp): j for j, sp in enumerate(specs)}


def pf(r):
    r = np.asarray(r, float)
    neg = -r[r < 0].sum()
    return float(r[r > 0].sum() / neg) if neg > 0 else (9.99 if len(r) else 0.0)


# ------------------------------------------------ rezim harian (status hari kemarin dipakai hari ini)
def rezim():
    c4 = pd.Series(dfs["BTCUSDT"]["close"].values, index=pd.to_datetime(dfs["BTCUSDT"].index, unit="ms", utc=True))
    bd = c4.resample("1D").last().dropna()
    tren = (bd > bd.ewm(span=200, adjust=False).mean()).astype(int)
    rv = bd.pct_change().rolling(30).std()
    vol = (rv > rv.rolling(365, min_periods=120).median()).astype(int)
    C = {}
    for s, df in dfs.items():
        x = pd.Series(df["close"].values, index=pd.to_datetime(df.index, unit="ms", utc=True)).resample("1D").last()
        C[s] = x
    C = pd.DataFrame(C)
    r = C.pct_change(fill_method=None)
    b = r.pop("BTCUSDT")
    alt = r.clip(-0.5, 0.5).mean(axis=1)
    rel = (1 + alt.fillna(0)).cumprod() / (1 + b.fillna(0)).cumprod()
    altk = (rel > rel.ewm(span=20, adjust=False).mean()).astype(int)
    R = pd.DataFrame({"tren": tren, "alt": altk, "vol": vol}).shift(1).dropna()
    kode = (R.tren * 4 + R.alt * 2 + R.vol).astype(int)
    return {int(t.value // 10 ** 6 // DAY): int(v) for t, v in kode.items()}


REZ = rezim()
NAMA_REZ = {k: f"{'BTC naik' if k & 4 else 'BTC turun'}, {'alt kuat' if k & 2 else 'alt lemah'}, {'vol tinggi' if k & 1 else 'vol rendah'}"
            for k in range(8)}


def rez_of(t):
    return np.array([REZ.get(int(x // DAY), -1) for x in t])


# ------------------------------------------------ cache simulasi tambahan
CACHE_N, CACHE_B = {}, {}


def trades_spec(sp):
    k = LB._id(sp)
    if k in idmap:
        return TR[idmap[k]]
    if k not in CACHE_N:
        per = LB.jalankan(FS, sp)
        rows = [(z[0], z[1], z[2], z[3], ci) for ci, s in enumerate(syms) for z in per[s]]
        CACHE_N[k] = np.array(rows) if rows else np.zeros((0, 5))
    return CACHE_N[k]


def acak(j):
    if j in CACHE_B:
        return CACHE_B[j]
    sp = specs[j]
    rng = np.random.default_rng(11)
    rows = []
    for ci, s in enumerate(syms):
        F = FS[s]
        for d in LB._arah(sp):
            sig = LB.sinyal_idx(F, sp, d)
            sig = sig[sig >= 250]
            pool = LB.saring_idx(F, sp, d)
            if not len(sig) or not len(pool):
                continue
            for _ in range(3):
                pick = np.sort(rng.choice(pool, size=min(len(sig), len(pool)), replace=False))
                rows += [(z[0], z[1], z[2], z[3], ci) for z in LB.simulasi(F, sp, idx=[(int(i), d) for i in pick])]
    CACHE_B[j] = np.array(rows) if rows else np.zeros((0, 5))
    return CACHE_B[j]


def potong(a, lo, hi):
    return a[(a[:, 0] >= lo) & (a[:, 0] < hi)] if len(a) else a


def tumpang(a, b):
    """Persen trade a yang punya trade b di koin dan arah sama dalam 6 candle."""
    if not len(a) or not len(b):
        return 0.0
    hit = 0
    for (ci, s) in set(zip(a[:, 4].astype(int), a[:, 3].astype(int))):
        ta = a[(a[:, 4] == ci) & (a[:, 3] == s), 0]
        tb = np.sort(b[(b[:, 4] == ci) & (b[:, 3] == s), 0])
        if not len(tb):
            continue
        i = np.searchsorted(tb, ta)
        lo = np.abs(ta - tb[np.clip(i - 1, 0, len(tb) - 1)])
        hi = np.abs(tb[np.clip(i, 0, len(tb) - 1)] - ta)
        hit += int((np.minimum(lo, hi) <= 6 * H4).sum())
    return hit / len(a)


def mirip(a, b):
    return LB._mirip(a, b)


# ------------------------------------------------ seleksi seperti QSE LAB, hanya data [lo, hi)
def pilih(lo, hi, maks=12, ketat=True, nmin=None):
    mid = (lo + hi) // 2
    half_years = (mid - lo) / (365.25 * DAY)
    nmin = nmin or max(80, int(55 * half_years))
    cands = []
    for j, a in enumerate(TR):
        if len(a) < 2 * nmin:
            continue
        a1, a2 = potong(a, lo, mid), potong(a, mid, hi)
        if len(a1) < nmin or len(a2) < nmin:
            continue
        p1, p2 = pf(a1[:, 1]), pf(a2[:, 1])
        if p1 < 1.35 or p2 < 1.30 or a1[:, 1].mean() < 0.10 or a2[:, 1].mean() < 0.10:
            continue
        aw = potong(a, lo, hi)
        th = pd.to_datetime(aw[:, 0], unit="ms", utc=True).year.values
        tahun = [y for y in np.unique(th) if (th == y).sum() >= 20]
        if tahun and sum(aw[th == y, 1].sum() > 0 for y in tahun) / len(tahun) < 0.66:
            continue
        cands.append((min(p1, p2), j))
    cands.sort(reverse=True)
    if not ketat:
        return [j for _, j in cands[:maks]], len(cands)
    sel = []
    for sk, j in cands:
        if len(sel) >= maks:
            break
        sp = specs[j]
        if any(mirip(sp, specs[i]) for i in sel):
            continue
        if sp["arah"] == "S" and sum(specs[i]["arah"] == "S" for i in sel) >= 8:
            continue
        b = acak(j)
        b1, b2 = potong(b, lo, mid), potong(b, mid, hi)
        a = TR[j]
        a1, a2 = potong(a, lo, mid), potong(a, mid, hi)
        if not len(b1) or not len(b2) or pf(a1[:, 1]) - pf(b1[:, 1]) < 0.10 or pf(a2[:, 1]) - pf(b2[:, 1]) < 0.10:
            continue
        aw = potong(a, lo, hi)
        ok = True
        for g in (0, 1):
            r = aw[aw[:, 4] % 2 == g, 1]
            if len(r) < 40 or pf(r) < 1.10:
                ok = False
        if not ok:
            continue
        nb = LB.tetangga(sp)
        lulus = 0
        for s2 in nb:
            t2 = trades_spec(s2)
            if pf(potong(t2, lo, mid)[:, 1]) >= 1.15 and pf(potong(t2, mid, hi)[:, 1]) >= 1.15:
                lulus += 1
        if lulus < max(1, (len(nb) + 1) // 2):
            continue
        if any(tumpang(aw, potong(TR[i], lo, hi)) > 0.40 for i in sel):
            continue
        sel.append(j)
    return sel, len(cands)


def gabung(js, lo, hi):
    a = [potong(TR[j], lo, hi) for j in js]
    a = [x for x in a if len(x)]
    return np.vstack(a) if a else np.zeros((0, 5))


def ringkas(a):
    if not len(a):
        return "n 0"
    return f"n {len(a):5d} PF {pf(a[:, 1]):.2f} total {a[:, 1].sum():+7.1f}R exp {a[:, 1].mean():+.3f}"


if __name__ == "__main__":
    t0 = time.time()
    tahun_uji = [2021, 2022, 2023, 2024, 2025, 2026]
    print("=== EKSPERIMEN 1: latih 2017-09 s/d 2020-12, uji maju 2021-2026 ===")
    lo, hi = ts("2017-09-01"), ts("2021-01-01")
    sel, nc = pilih(lo, hi)
    naif, _ = pilih(lo, hi, ketat=False)
    print("kandidat lolos syarat dasar", nc, "terpilih", len(sel), round(time.time() - t0), "s")
    for j in sel:
        a = TR[j]
        print(f"  {LB.nama(specs[j])[:95]}")
        print(f"     latih {ringkas(potong(a, lo, hi))}  |  maju {ringkas(potong(a, hi, ts('2026-11-01')))}")
    for nm, js in (("TERPILIH (proses lab lengkap)", sel), ("NAIF (top PF latih saja)", naif)):
        print(nm)
        for y in tahun_uji:
            print(f"   {y}: {ringkas(gabung(js, ts(f'{y}-01-01'), ts(f'{y + 1}-01-01')))}")
        print(f"   2021-2026: {ringkas(gabung(js, hi, ts('2026-11-01')))}")
    # pembanding acak: 12 teknik acak yang cukup trade di latih
    rng = np.random.default_rng(5)
    cukup = [j for j, a in enumerate(TR) if len(potong(a, lo, hi)) >= 160]
    pfs = []
    for _ in range(300):
        js = rng.choice(cukup, size=12, replace=False)
        pfs.append(pf(gabung(js, hi, ts("2026-11-01"))[:, 1]))
    pfs = np.array(pfs)
    p_sel = pf(gabung(sel, hi, ts("2026-11-01"))[:, 1])
    print(f"ACAK 12 teknik: PF maju median {np.median(pfs):.2f} (persentil 10-90: {np.percentile(pfs, 10):.2f}-{np.percentile(pfs, 90):.2f}).",
          f"Terpilih PF {p_sel:.2f} = persentil {(pfs < p_sel).mean() * 100:.0f}")
    pickle.dump(dict(sel1=sel, naif1=naif), open(f"{K}/wf_e1.pkl", "wb"))

    print()
    print("=== EKSPERIMEN 2: pilih ulang tiap tahun dari semua data sebelumnya, uji tahun itu ===")
    hasil = {}
    for y in tahun_uji:
        lo, hi = ts("2017-09-01"), ts(f"{y}-01-01")
        sel, nc = pilih(lo, hi)
        hasil[y] = sel
        f = gabung(sel, hi, ts(f"{y + 1}-01-01"))
        print(f"{y}: latih {2017}-{y - 1}, lolos dasar {nc}, terpilih {len(sel)} ({sum(specs[j]['arah'] == 'S' for j in sel)} SHORT saja)  ->  maju {ringkas(f)}",
              round(time.time() - t0), "s", flush=True)
    semua = np.vstack([gabung(hasil[y], ts(f"{y}-01-01"), ts(f"{y + 1}-01-01")) for y in tahun_uji])
    print("GABUNGAN 2021-2026:", ringkas(semua))
    pickle.dump(dict(sel2=hasil), open(f"{K}/wf_e2.pkl", "wb"))
    pickle.dump(dict(CACHE_N=CACHE_N, CACHE_B=CACHE_B), open(f"{K}/wf_cache.pkl", "wb"))
    print("selesai", round(time.time() - t0), "s")

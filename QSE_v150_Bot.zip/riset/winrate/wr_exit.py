"""Uji cara keluar untuk menaikkan win rate (WR). Semua sinyal jalur terbukti 2021-2026, jalan di candle 1 jam.
Varian: (nama, [(level_R, porsi), ...], pindah SL ke entry setelah TP pertama?, TP penuh R atau None)."""
import os, sys, pickle, time
import numpy as np, pandas as pd

X = pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = X[(X["rank"] <= X.jalur.map(LIK).fillna(999)) & (X.t >= "2021-01-01")]
TPR = {"snr_vol": 3.0, "smc_choch": 3.0, "mcginley": 4.0, "orderblock": 4.0}
TRL = {"ichimoku": 4.0, "ema_short": 4.0, "msb_hpz": 4.0, "rsi_vol": 3.0, "GZH": 3.0}
SLA = {"ichimoku": 1.5, "ema_short": 1.5, "mcginley": 1.5}
VAR = [
    ("dasar (aturan jalur)", [], False, None),
    ("TP bertahap 25% 1R, 50% 2R (sekarang)", [(1.0, 0.25), (2.0, 0.50)], False, None),
    ("TP bertahap sekarang + SL ke entry setelah 1R", [(1.0, 0.25), (2.0, 0.50)], True, None),
    ("50% di 1R + SL ke entry", [(1.0, 0.50)], True, None),
    ("50% di 0.75R + SL ke entry", [(0.75, 0.50)], True, None),
    ("50% di 0.5R + SL ke entry", [(0.5, 0.50)], True, None),
    ("30% di 0.5R + SL ke entry", [(0.5, 0.30)], True, None),
    ("50% di 1R, sisa tanpa pindah SL", [(1.0, 0.50)], False, None),
    ("33% 1R + 33% 2R + SL ke entry", [(1.0, 0.33), (2.0, 0.33)], True, None),
    ("TP penuh 1R", [], False, 1.0),
    ("TP penuh 1.5R", [], False, 1.5),
    ("TP penuh 2R", [], False, 2.0),
]


def sim(O, H, L, C, k0, end, e, d, risk, atr, jalur, parts, be, full):
    sl = e - d * risk
    best = e
    sisa, real = 1.0, 0.0
    tp = e + d * full * risk if full else (e + d * TPR[jalur] * risk if jalur in TPR else None)
    tr0 = None if full else TRL.get(jalur)
    lv = list(parts)
    for j in range(k0, end):
        hi, lo = H[j], L[j]
        if (lo <= sl) if d == 1 else (hi >= sl):
            return real + sisa * (sl - e) * d / risk
        while lv and ((hi >= e + d * lv[0][0] * risk) if d == 1 else (lo <= e + d * lv[0][0] * risk)):
            r, p = lv.pop(0)
            p = min(p, sisa)
            real += p * r
            sisa -= p
            if be:
                sl = max(sl, e) if d == 1 else min(sl, e)
        if sisa <= 1e-9:
            return real
        if tp is not None and ((hi >= tp) if d == 1 else (lo <= tp)):
            return real + sisa * (tp - e) * d / risk
        best = max(best, hi) if d == 1 else min(best, lo)
        if tr0 is not None and (j - k0) % 4 == 3:
            sl = max(sl, best - tr0 * atr) if d == 1 else min(sl, best + tr0 * atr)
    return real + sisa * (C[end - 1] - e) * d / risk


if __name__ == "__main__":
    t0 = time.time()
    rows = []
    for s, Z in X.groupby("sym"):
        p = f"../data/{s}_60.csv"
        if not os.path.exists(p):
            continue
        h = pd.read_csv(p, index_col=0, parse_dates=True)
        ix = h.index
        O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
        for r in Z.itertuples():
            k0 = ix.searchsorted(r.t + pd.Timedelta(hours=4))
            if k0 >= len(ix) or ix[k0] != r.t + pd.Timedelta(hours=4):
                continue
            e = O[k0]
            risk = e / r.er
            d = int(r.arah)
            atr = risk / SLA.get(r.jalur, 2.0)
            cost = 0.0015 * e / risk
            maks = 180 if r.jalur in TPR else 240
            end = min(k0 + maks, len(ix))
            if end - k0 < maks:
                continue
            out = dict(t=r.t, jalur=r.jalur, sym=s, arah=d)
            for nm, parts, be, full in VAR:
                out[nm] = sim(O, H, L, C, k0, end, e, d, risk, atr, r.jalur, parts, be, full) - cost
            rows.append(out)
    R = pd.DataFrame(rows)
    R.to_pickle("wr_exit.pkl")
    pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
    print("trade", len(R), round(time.time() - t0), "s")
    for nm, *_ in VAR:
        o = []
        for per, W in (("2021-23", R[R.t < "2024"]), ("2024-26", R[R.t >= "2024"])):
            x = W[nm].values
            o.append(f"{per} WR {np.mean(x > 0) * 100:4.1f}% PF {pf(x):.2f} total {x.sum():+7.0f}R")
        print(f"{nm:46s} | " + " | ".join(o), flush=True)

import pandas as pd, numpy as np
R = pd.read_pickle("wr_exit.pkl").sort_values("t").reset_index(drop=True)
V = [c for c in R.columns if c not in ("t", "jalur", "sym", "arah")]
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
def streak(x):
    m = c = 0
    for v in x:
        c = c + 1 if v <= 0 else 0; m = max(m, c)
    return m
print(f"{'cara keluar':46s} | {'WR':>5s} {'PF':>5s} {'total':>7s} {'DD':>6s} {'total/DD':>8s} {'rugi beruntun':>13s} | per periode total/DD")
for nm in V:
    x = R[nm].values
    o = []
    for per, W in (("21-23", R[R.t < "2024"]), ("24-26", R[R.t >= "2024"])):
        y = W[nm].values; o.append(f"{per} {y.sum() / dd(y):.1f}")
    print(f"{nm:46s} | {np.mean(x > 0) * 100:4.1f}% {pf(x):5.2f} {x.sum():+7.0f} {dd(x):6.0f} {x.sum() / dd(x):8.1f} {streak(x):13d} | " + " ".join(o))
print()
print("Per jalur, total R 2021-23 / 2024-26: dasar | sekarang (TP bertahap) | 30% 0.5R + SL ke entry")
for j, Z in R.groupby("jalur"):
    o = []
    for nm in ("dasar (aturan jalur)", "TP bertahap 25% 1R, 50% 2R (sekarang)", "30% di 0.5R + SL ke entry", "50% di 0.75R + SL ke entry"):
        a, b = Z[Z.t < "2024"][nm], Z[Z.t >= "2024"][nm]
        o.append(f"{a.sum():+5.0f}/{b.sum():+5.0f} WR {np.mean(Z[nm] > 0) * 100:3.0f}%")
    print(f"{j:11s} n {len(Z):5d} | " + " | ".join(o))

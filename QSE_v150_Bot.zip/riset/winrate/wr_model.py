"""Model peluang menang per sinyal jalur terbukti. Ciri hanya yang bisa dihitung live dari candle 4J saat sinyal.
Latih 2021-2023, uji 2024-2026 (tidak pernah dilihat saat latih)."""
import os, sys, time, pickle
import numpy as np, pandas as pd

LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = pd.read_pickle("semua_f.pkl")
X = X[(X["rank"] <= X.jalur.map(LIK).fillna(999)) & (X.t >= "2021-01-01")].copy()
RJ = pd.read_pickle("raja.pkl")[["jalur", "sym", "t", "n", "fix", "plus", "pull", "jebakan_lawan", "channel_atas",
                                "macd_hist_searah", "adx_20_kurang"]]
X = X.merge(RJ.drop_duplicates(["jalur", "sym", "t"]), on=["jalur", "sym", "t"], how="left")
for c in ("n", "plus", "jebakan_lawan", "channel_atas", "macd_hist_searah", "adx_20_kurang"):
    X[c] = X[c].fillna(0)
X["fix"] = X["fix"].fillna(False).astype(int)
X["pull"] = X["pull"].fillna(False).astype(int)


def ema(x, n):
    return pd.Series(x).ewm(span=n, adjust=False).mean().values


def ind(df):
    o, h, l, c, v = (df[k].values.astype(float) for k in ("open", "high", "low", "close", "volume"))
    pc = np.r_[c[0], c[:-1]]
    tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values
    d_ = np.diff(c, prepend=c[0])
    up = pd.Series(np.clip(d_, 0, None)).ewm(alpha=1 / 14, adjust=False).mean().values
    dn = pd.Series(np.clip(-d_, 0, None)).ewm(alpha=1 / 14, adjust=False).mean().values
    rsi = 100 - 100 / (1 + up / np.maximum(dn, 1e-12))
    hu = np.r_[0, h[1:] - h[:-1]]
    ld = np.r_[0, l[:-1] - l[1:]]
    sm = lambda x: pd.Series(x).ewm(alpha=1 / 14, adjust=False).mean().values
    A = np.maximum(atr, 1e-12)
    pdi = 100 * sm(np.where((hu > ld) & (hu > 0), hu, 0)) / A
    mdi = 100 * sm(np.where((ld > hu) & (ld > 0), ld, 0)) / A
    adx = sm(100 * abs(pdi - mdi) / np.maximum(pdi + mdi, 1e-9))
    vr = v / pd.Series(v).rolling(100, min_periods=20).mean().values
    return dict(c=c, atr=atr, rsi=rsi, adx=adx, e20=ema(c, 20), e50=ema(c, 50), e200=ema(c, 200), vr=vr,
                body=(c - o) / A, t=df.index)


def baca(s):
    df = pd.read_csv(f"../data/{s}_240.csv", index_col=0, parse_dates=True)
    return df


btc = ind(baca("BTCUSDT"))
bt_idx = pd.DatetimeIndex(btc["t"])
bd = pd.Series(btc["c"], index=bt_idx).resample("1D").last().dropna()
btc_d200 = np.sign(bd - bd.ewm(span=200, adjust=False).mean()).shift(1)
btc_r7 = (bd / bd.shift(7) - 1).shift(1)

rows = []
t0 = time.time()
for s, Z in X.groupby("sym"):
    try:
        I = ind(baca(s))
    except FileNotFoundError:
        continue
    idx = pd.DatetimeIndex(I["t"])
    for r in Z.itertuples():
        k = idx.searchsorted(r.t)
        if k >= len(idx) or idx[k] != r.t or k < 200:
            continue
        d = int(r.arah)
        c, a = I["c"][k], I["atr"][k]
        kb = bt_idx.searchsorted(r.t)
        if kb >= len(bt_idx) or bt_idx[kb] != r.t:
            continue
        day = r.t.floor("D")
        rows.append(dict(
            idx=r.Index, t=r.t, jalur=r.jalur, sym=s, arah=d, R=r.R, rank=r.rank, fund=d * (r.fund if pd.notna(r.fund) else 0),
            risk_pct=100 / r.er, rsi=d * (I["rsi"][k] - 50), adx=I["adx"][k], atr_pct=a / c * 100,
            jarak50=d * (c - I["e50"][k]) / a, jarak200=d * (c - I["e200"][k]) / a, e2050=d * np.sign(I["e20"][k] - I["e50"][k]),
            r7=d * (c / I["c"][k - 42] - 1) * 100, r30=d * (c / I["c"][k - 180] - 1) * 100 if k >= 180 else 0.0,
            vr=I["vr"][k], body=d * I["body"][k],
            btc4=d * np.sign(btc["c"][kb] - btc["e50"][kb]), btc_rsi=d * (btc["rsi"][kb] - 50),
            btc_d200=d * (btc_d200.get(day, 0) if pd.notna(btc_d200.get(day, np.nan)) else 0),
            btc_r7=d * (btc_r7.get(day, 0) if pd.notna(btc_r7.get(day, np.nan)) else 0) * 100,
            jam=(r.t.hour + 4 + 7) % 24, dw=(r.t + pd.Timedelta(hours=4)).dayofweek,
            n=r.n, fix=r.fix, plus=r.plus, pull=r.pull, jebakan=r.jebakan_lawan, channel=r.channel_atas,
            macdh=r.macd_hist_searah, adx20=r.adx_20_kurang))
F = pd.DataFrame(rows)
F.to_pickle("wr_fitur.pkl")
print("fitur", F.shape, round(time.time() - t0), "s")

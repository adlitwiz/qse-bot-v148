"""Uji tangga TP sebagian (mode seimbang, skor >= 3). Bagian: [(level_R, porsi), ...], SL ke entry setelah TP pertama."""
import os, time
import numpy as np, pandas as pd
import wr_exit as W
VAR = [("20% 0.5R+BE (sekarang)", [(0.5, 0.2)]),
       ("20% 0.5R, 25% 1R", [(0.5, 0.2), (1.0, 0.25)]),
       ("20% 0.5R, 25% 2R", [(0.5, 0.2), (2.0, 0.25)]),
       ("20% 0.5R, 25% 1R, 25% 2R", [(0.5, 0.2), (1.0, 0.25), (2.0, 0.25)]),
       ("25% 0.5R, 25% 1R, 25% 2R", [(0.5, 0.25), (1.0, 0.25), (2.0, 0.25)]),
       ("25% 0.5R, 50% 2R", [(0.5, 0.25), (2.0, 0.5)]),
       ("20% 0.5R, 30% 1.5R", [(0.5, 0.2), (1.5, 0.3)]),
       ("20% 0.5R, 20% 1R, 20% 2R, 20% 3R", [(0.5, 0.2), (1.0, 0.2), (2.0, 0.2), (3.0, 0.2)]),
       ("25% 1R, 50% 2R (lama, tanpa BE)", None)]
t0 = time.time(); rows = []
for s, Z in W.X.groupby("sym"):
    p = f"../data/{s}_60.csv"
    if not os.path.exists(p): continue
    h = pd.read_csv(p, index_col=0, parse_dates=True); ix = h.index
    O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
    for r in Z.itertuples():
        k0 = ix.searchsorted(r.t + pd.Timedelta(hours=4))
        if k0 >= len(ix) or ix[k0] != r.t + pd.Timedelta(hours=4): continue
        e = O[k0]; risk = e / r.er; d = int(r.arah); atr = risk / W.SLA.get(r.jalur, 2.0); cost = 0.0015 * e / risk
        maks = 180 if r.jalur in W.TPR else 240; end = min(k0 + maks, len(ix))
        if end - k0 < maks: continue
        out = dict(t=r.t, jalur=r.jalur, sym=s)
        for nm, parts in VAR:
            if parts is None:
                out[nm] = W.sim(O, H, L, C, k0, end, e, d, risk, atr, r.jalur, [(1.0, 0.25), (2.0, 0.5)], False, None) - cost
            else:
                out[nm] = W.sim(O, H, L, C, k0, end, e, d, risk, atr, r.jalur, parts, True, None) - cost
        rows.append(out)
Y = pd.DataFrame(rows)
exec(open("wr_kelas.py").read().split("pf = lambda")[0].replace('D = pd.read_pickle("wr_data.pkl")', 'D = pd.read_pickle("wr_data.pkl")[["jalur","sym","t","arah","n","fix","plus","pull"]]'))
D = D.merge(Y, on=["jalur", "sym", "t"]).sort_values("t").reset_index(drop=True)
D.to_pickle("wr_tangga.pkl")
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
def streak(x):
    m = c = 0
    for v in x:
        c = c + 1 if v <= 0 else 0; m = max(m, c)
    return m
S = D[D.skor2 >= 3]
print("sinyal mode seimbang", len(S), round(time.time() - t0), "s")
for nm, _ in VAR:
    o = []
    for per, m in (("21-23", S.t < "2024"), ("24-26", S.t >= "2024")):
        y = S.loc[m, nm].values
        o.append(f"{per} WR {np.mean(y > 0) * 100:4.1f} PF {pf(y):.2f} total {y.sum():+5.0f} DD {dd(y):3.0f}")
    x = S[nm].values
    print(f"{nm:36s} WR {np.mean(x > 0)*100:4.1f}% PF {pf(x):.2f} total {x.sum():+6.0f} t/DD {x.sum()/dd(x):5.1f} beruntun {streak(x):3d} | " + " | ".join(o), flush=True)

import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
D = pd.read_pickle("wr_data.pkl").sort_values("t").reset_index(drop=True)
NUM = ["rank", "risk_pct", "rsi", "adx", "atr_pct", "jarak50", "jarak200", "e2050", "r7", "r30", "vr", "body",
       "btc4", "btc_rsi", "btc_d200", "btc_r7", "n", "fix", "plus", "pull", "jebakan", "channel", "macdh", "adx20", "arah"]
D["vr"] = D["vr"].replace([np.inf, -np.inf], np.nan).fillna(1).clip(0, 10)
for c in NUM:
    D[c] = pd.to_numeric(D[c], errors="coerce").fillna(0)
Xc = pd.get_dummies(D[["jalur"]].astype(str)).astype(float)
Xj = pd.get_dummies(D["jam"].astype(str), prefix="jam").astype(float)
Xd = pd.get_dummies(D["dw"].astype(str), prefix="dw").astype(float)
X = pd.concat([D[NUM], Xc, Xj, Xd], axis=1).values
lat, uji = (D.t < "2024").values, (D.t >= "2024").values
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
for target in ("baru", "dasar"):
    y = (D[target] > 0).values.astype(int)
    sc = StandardScaler().fit(X[lat])
    lr = LogisticRegression(C=0.1, max_iter=2000).fit(sc.transform(X[lat]), y[lat])
    gb = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.04, max_leaf_nodes=15, min_samples_leaf=200,
                                        l2_regularization=1.0, random_state=0).fit(X[lat], y[lat])
    for nm, p in (("logistik", lr.predict_proba(sc.transform(X))[:, 1]), ("boosting", gb.predict_proba(X)[:, 1])):
        print(f"== target WR cara {target}, model {nm}: AUC latih {roc_auc_score(y[lat], p[lat]):.3f}, uji 2024-26 {roc_auc_score(y[uji], p[uji]):.3f}")
        q = pd.qcut(p[uji], 5, labels=False)
        for k in range(5):
            m = q == k
            r = D.loc[uji, target].values[m]
            print(f"   kelompok {k + 1} (peluang {p[uji][m].min():.2f}-{p[uji][m].max():.2f}): n {m.sum():5d} WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} total {r.sum():+6.0f}R")
        D[f"p_{target}_{nm}"] = p
D.to_pickle("wr_pred.pkl")

import os, time
import numpy as np, pandas as pd
import wr_exit as W
VAR = [("dasar", [], False, None), ("baru", [(0.5, 0.20)], True, None)]
t0 = time.time()
rows = []
for s, Z in W.X.groupby("sym"):
    p = f"../data/{s}_60.csv"
    if not os.path.exists(p): continue
    h = pd.read_csv(p, index_col=0, parse_dates=True); ix = h.index
    O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
    for r in Z.itertuples():
        k0 = ix.searchsorted(r.t + pd.Timedelta(hours=4))
        if k0 >= len(ix) or ix[k0] != r.t + pd.Timedelta(hours=4): continue
        e = O[k0]; risk = e / r.er; d = int(r.arah); atr = risk / W.SLA.get(r.jalur, 2.0); cost = 0.0015 * e / risk
        maks = 180 if r.jalur in W.TPR else 240; end = min(k0 + maks, len(ix))
        if end - k0 < maks: continue
        out = dict(t=r.t, jalur=r.jalur, sym=s)
        for nm, parts, be, full in VAR:
            out[nm] = W.sim(O, H, L, C, k0, end, e, d, risk, atr, r.jalur, parts, be, full) - cost
        rows.append(out)
Y = pd.DataFrame(rows)
F = pd.read_pickle("wr_fitur.pkl")
D = F.merge(Y, on=["jalur", "sym", "t"], how="inner")
D.to_pickle("wr_data.pkl")
print("data", D.shape, round(time.time() - t0), "s")

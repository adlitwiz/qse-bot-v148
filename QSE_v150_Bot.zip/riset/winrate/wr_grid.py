import os, sys, time, pickle
import numpy as np, pandas as pd
import wr_exit as W
VAR = [("dasar", [], False, None)]
for lv in (0.3, 0.4, 0.5, 0.6, 0.75):
    for p in (0.2, 0.3, 0.4, 0.5):
        VAR.append((f"{int(p*100)}% di {lv}R + BE", [(lv, p)], True, None))
VAR += [("30% 0.5R + BE + 25% 2R", [(0.5, 0.30), (2.0, 0.25)], True, None),
        ("30% 0.5R + 30% 1.5R + BE", [(0.5, 0.30), (1.5, 0.30)], True, None)]
W.VAR = VAR
t0 = time.time()
rows = []
for s, Z in W.X.groupby("sym"):
    p = f"../data/{s}_60.csv"
    if not os.path.exists(p): continue
    h = pd.read_csv(p, index_col=0, parse_dates=True); ix = h.index
    O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
    for r in Z.itertuples():
        k0 = ix.searchsorted(r.t + pd.Timedelta(hours=4))
        if k0 >= len(ix) or ix[k0] != r.t + pd.Timedelta(hours=4): continue
        e = O[k0]; risk = e / r.er; d = int(r.arah); atr = risk / W.SLA.get(r.jalur, 2.0); cost = 0.0015 * e / risk
        maks = 180 if r.jalur in W.TPR else 240; end = min(k0 + maks, len(ix))
        if end - k0 < maks: continue
        out = dict(t=r.t, jalur=r.jalur)
        for nm, parts, be, full in VAR:
            out[nm] = W.sim(O, H, L, C, k0, end, e, d, risk, atr, r.jalur, parts, be, full) - cost
        rows.append(out)
R = pd.DataFrame(rows).sort_values("t").reset_index(drop=True)
R.to_pickle("wr_grid.pkl")
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
def streak(x):
    m = c = 0
    for v in x:
        c = c + 1 if v <= 0 else 0; m = max(m, c)
    return m
print("trade", len(R), round(time.time() - t0), "s")
for nm, *_ in VAR:
    x = R[nm].values
    o = []
    for per, Q in (("21-23", R[R.t < "2024"]), ("24-26", R[R.t >= "2024"])):
        y = Q[nm].values; o.append(f"{per} WR {np.mean(y > 0) * 100:4.1f} PF {pf(y):.2f} t/DD {y.sum() / dd(y):.1f}")
    print(f"{nm:28s} | WR {np.mean(x > 0) * 100:4.1f}% PF {pf(x):.2f} total {x.sum():+6.0f} DD {dd(x):4.0f} t/DD {x.sum() / dd(x):4.1f} beruntun {streak(x):3d} | " + " | ".join(o), flush=True)

import sys, glob, os
import pandas as pd, numpy as np
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot")
from qse_strat import COMBO_EMAS
D = pd.read_pickle("wr_data.pkl")
R = pd.read_pickle("raja.pkl")[["jalur", "sym", "t", "n", "fix", "plus", "pull", "par"]]
R["t"] = pd.to_datetime(R.t, utc=True)
D = D.drop(columns=["n", "fix", "plus", "pull"]).merge(R.drop_duplicates(["jalur", "sym", "t"]), on=["jalur", "sym", "t"], how="left")
h = pd.read_csv("../data/BTCUSDT_60.csv", index_col=0, parse_dates=True)
v4 = h.volume.resample("4h").sum(); rv = v4 / v4.rolling(180).mean()
D["vt"] = rv.reindex(D.t).values > 2.5
D["emas"] = [any((j, p) in COMBO_EMAS for p in (ps if isinstance(ps, (set, frozenset, list)) else [])) for j, ps in zip(D.jalur, D.par)]
D["n"] = D["n"].fillna(0); D["plus"] = D["plus"].fillna(0); D["fix"] = D["fix"].fillna(False).astype(bool); D["pull"] = D["pull"].fillna(False).astype(bool)
D["skor"] = 5 * (D.n >= 5) + 3 * D.fix + 2 * D.emas + (D.n >= 1) + (D.n >= 2) + (D.plus >= 3) + ((D.jalur == "mcginley") & D.pull) + 2 * D.vt
# dominasi
C = {}
for d in ("../data17", "../data"):
    for f in glob.glob(f"{d}/*_D.csv"):
        s = os.path.basename(f).split("_")[0]; x = pd.read_csv(f, index_col=0, parse_dates=True).close
        C[s] = pd.concat([C[s], x]) if s in C else x
C = pd.DataFrame({k: v[~v.index.duplicated(keep="last")].sort_index() for k, v in C.items()})
r = C.pct_change(fill_method=None); b = r.pop("BTCUSDT"); alt = r.clip(-0.5, 0.5).mean(axis=1)
rel = (1 + alt.fillna(0)).cumprod() / (1 + b.fillna(0)).cumprod()
st = (rel > rel.ewm(span=20, adjust=False).mean()).astype(int).shift(1)
dom = st.reindex(D.t.dt.floor("D")).values == 1
J = {"ema_short", "mcginley", "msb_hpz", "rsi_vol", "smc_choch", "ichimoku"}
bonus = (D.arah == -1) & dom & D.jalur.isin(J)
D["skor2"] = np.where(bonus, np.maximum(D.skor, np.minimum(D.skor + 2, 7)), D.skor)
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def baris(nm, m):
    o = []
    for v in ("dasar", "baru"):
        x = D.loc[m, v].values
        o.append(f"{v}: WR {np.mean(x > 0) * 100:4.1f}% PF {pf(x):.2f} total {x.sum():+6.0f}")
    print(f"{nm:34s} n {m.sum():6d} | " + " | ".join(o))
baris("semua", D.skor2 >= -1)
baris("mode seimbang (skor 3+)", D.skor2 >= 3)
baris("NILAI 8 (skor 3-4)", (D.skor2 >= 3) & (D.skor2 <= 4))
baris("NILAI 9 (skor 5-7)", (D.skor2 >= 5) & (D.skor2 <= 7))
baris("NILAI 10 (skor 8+)", D.skor2 >= 8)
baris("COMBO FIX", D.fix)
for j in sorted(D.jalur.unique()):
    baris(f"  seimbang {j}", (D.skor2 >= 3) & (D.jalur == j))
for per, m in (("2021-23", D.t < "2024"), ("2024-26", D.t >= "2024")):
    baris(f"seimbang {per}", (D.skor2 >= 3) & m)
print()
E = pd.read_pickle("wr_exit.pkl")[["jalur", "sym", "t", "TP bertahap 25% 1R, 50% 2R (sekarang)"]].rename(columns={"TP bertahap 25% 1R, 50% 2R (sekarang)": "tpb"})
D = D.merge(E, on=["jalur", "sym", "t"], how="left").sort_values("t").reset_index(drop=True)
TAHAN = {"snr_vol", "smc_choch", "orderblock", "mcginley"}
D["sekarang"] = np.where(D.jalur.isin(TAHAN) | D.fix, D.dasar, D.tpb)
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
def streak(x):
    m = c = 0
    for v in x:
        c = c + 1 if v <= 0 else 0; m = max(m, c)
    return m
S = D[D.skor2 >= 3]
for v, nm in (("dasar", "tahan semua sampai aturan jalur"), ("sekarang", "kebijakan sekarang"), ("baru", "baru: 20% di 0.5R lalu SL ke entry")):
    x = S[v].values
    print(f"seimbang {nm:36s} WR {np.mean(x > 0) * 100:4.1f}% PF {pf(x):.2f} total {x.sum():+6.0f} DD {dd(x):4.0f} total/DD {x.sum() / dd(x):5.1f} rugi beruntun {streak(x)}")

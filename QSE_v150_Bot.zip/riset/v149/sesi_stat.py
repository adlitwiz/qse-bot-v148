import numpy as np, pandas as pd
z=np.load('data/BTCUSDT.npz')
df=pd.DataFrame({'O':z['o'],'Hi':z['h'],'Lo':z['l'],'C':z['c']},index=pd.to_datetime(z['t'],unit='ms',utc=True))
df=df['2019':]
df['d']=df.index.floor('D'); df['jam']=df.index.hour
rows=[]
for d,g in df.groupby('d'):
    if len(g)<24: continue
    A=g[g.jam<7]; L=g[(g.jam>=7)&(g.jam<13)]; N=g[(g.jam>=13)&(g.jam<21)]
    ah,al=A.Hi.max(),A.Lo.min()
    sh=L.Hi.max()>ah; sl=L.Lo.min()<al
    lc=L.C.iloc[-1]
    inside=(al<=lc<=ah)
    rows.append(dict(y=d.year,sh=sh,sl=sl,lon=np.sign(lc-L.O.iloc[0]),ny=np.sign(N.C.iloc[-1]-N.O.iloc[0]),inside=inside,
        ar=(ah-al)/g.O.iloc[0]*100,dr=(g.Hi.max()-g.Lo.min())/g.O.iloc[0]*100,ny_ret=(N.C.iloc[-1]/N.O.iloc[0]-1)*100,
        nyx=(N.Hi.max()>max(ah,L.Hi.max()))|(N.Lo.min()<min(al,L.Lo.min()))))
R=pd.DataFrame(rows); R['per']=np.where(R.y<=2022,'2019-22','2023-26')
for p,g in R.groupby('per'):
    print(p,'hari',len(g))
    print(' London sapu Asia: atas %.0f%% bawah %.0f%% salah satu %.0f%% keduanya %.0f%%'%(100*g.sh.mean(),100*g.sl.mean(),100*(g.sh|g.sl).mean(),100*(g.sh&g.sl).mean()))
    print(' rentang Asia %.2f%%, harian %.2f%%, Asia/harian %.0f%%'%(g.ar.mean(),g.dr.mean(),100*(g.ar/g.dr).mean()))
    for nm,m,arah in (('sapu atas lalu balik ke dalam',g.sh&~g.sl&g.inside,-1),('sapu bawah lalu balik ke dalam',g.sl&~g.sh&g.inside,1),
                      ('tembus atas bertahan',g.sh&~g.sl&~g.inside,1),('tembus bawah bertahan',g.sl&~g.sh&~g.inside,-1)):
        x=g[m]; print(f'  London {nm}: n {len(x)}, NY ke arah {"naik" if arah>0 else "turun"} {100*(x.ny==arah).mean():.0f}%, rata NY {x.ny_ret.mean():+.2f}%')
    print(' NY searah London %.0f%%, NY bikin high/low baru hari itu %.0f%%'%(100*(g.ny==g.lon).mean(),100*g.nyx.mean()))

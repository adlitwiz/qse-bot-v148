"""Uji jalur Sinyal Pelengkap Sektor v150: pemimpin naik 9% vol 4x, pengikut tembus high 20 candle vol 2x -> kartu LONG,
kantong maks 2, lalu posisi ditutup aturan v149 dan tercatat di /jalur."""
import os, sys, time
import numpy as np, pandas as pd
SD = os.path.abspath("st_sektor_%d" % int(time.time())); os.makedirs(SD)
os.environ["QSE_STATE_DIR"] = SD
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot")
import qse_sektor as SK, bybit_fetch as B, qse_catat as CT, qse_perintah as PR
H4 = 4 * 3600 * 1000
now = int(time.time() * 1000); t_last = now - H4 - 60000          # candle 4J terakhir tutup 1 menit lalu
idx = np.arange(t_last - 59 * H4, t_last + 1, H4)
def datar(px):
    return pd.DataFrame(dict(open=px, high=px * 1.01, low=px * 0.99, close=px, volume=100.0), index=idx)
c4 = {s: datar(1.0) for s in ("SOLUSDT", "ADAUSDT", "AVAXUSDT", "DOTUSDT")}
c4["SOLUSDT"].iloc[-2, [0, 1, 3, 4]] = [1.0, 1.10, 1.09, 400.0]          # pemimpin L1 +9%, volume 4x
c4["ADAUSDT"].iloc[-1, [1, 3, 4]] = [1.03, 1.025, 200.0]                  # pengikut tembus high 20, volume 2x
sig = SK.cari(c4)
assert len(sig) == 1 and sig[0]["sym"] == "ADAUSDT" and sig[0]["arah"] == "LONG" and sig[0]["pemimpin"] == "SOLUSDT", sig
# lag 2: pemimpin 2 candle lalu, pengikut baru tembus sekarang
c5 = {s: datar(1.0) for s in ("SOLUSDT", "ADAUSDT", "AVAXUSDT")}
c5["SOLUSDT"].iloc[-3, [0, 1, 3, 4]] = [1.0, 1.10, 1.09, 400.0]
c5["ADAUSDT"].iloc[-1, [1, 3, 4]] = [1.03, 1.025, 200.0]
assert [x["sym"] for x in SK.cari(c5)] == ["ADAUSDT"]
# jalankan penuh dengan data palsu
B.get_tickers = lambda: {s: dict(turnover=1e9, last=1.025) for s in c4}
B.get_symbols = lambda quote="USDT": {s: 0.0001 for s in c4}
k1 = {}
def raw(sym, iv, bars):
    if iv == "240":
        return c4[sym]
    return k1.get(sym, pd.DataFrame(columns=["open", "high", "low", "close", "volume"], dtype=float))
B._raw = raw
out = SK.jalankan(True)
assert len(out) == 1 and "SINYAL PELENGKAP" in out[0] and "ADAUSDT LONG" in out[0] and "0.5x" in out[0], out
d = SK.lihat(); assert len(d["open"]) == 1
it = list(d["open"].values())[0]
# 1J: naik ke +0.5R (TPawal), lalu turun ke entry -> SL entry, R = 0.2*0.5 = +0.10 kotor
e, r = it["entry"], it["risk"]; t0 = now - 8 * 3600000
SK._ubah(lambda dd: [v.update(t_bar=t0) for v in dd["open"].values()])
ix1 = np.arange(t0, t0 + 6 * 3600000, 3600000)
hh = [e + 0.6 * r, e + 0.1 * r, e, e, e, e]; ll = [e - 0.1 * r, e - 0.05 * r, e - 0.2 * r, e, e, e]
k1["ADAUSDT"] = pd.DataFrame(dict(open=e, high=hh, low=ll, close=e, volume=1.0), index=ix1)
SK._ALASAN[0] = ""
out2 = SK._kelola()
assert len(out2) == 1 and "SELESAI" in out2[0], out2
d = SK.lihat(); assert not d["open"] and abs(d["closed"][-1]["R"] - (0.10 - 0.0015 * e / r)) < 0.011, d["closed"][-1]
assert any(c["jalur"] == "sektor" for c in CT._baca()["closed"])
t = PR.jawab("/pelengkap") if hasattr(PR, "jawab") else SK.teks()
assert "Sinyal Pelengkap" in SK.teks() and "Selesai 1 trade" in SK.teks()
# jeda setelah 3 rugi beruntun
SK._ubah(lambda dd: dd["closed"].extend([dict(R=-1.0, selesai=time.time())] * 3))
assert "jeda" in SK._jeda(SK.lihat()["closed"])
print(out[0][:700]); print(SK.status_singkat()); print("lulus")

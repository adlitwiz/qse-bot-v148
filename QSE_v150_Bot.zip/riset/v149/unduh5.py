"""Candle 5 menit Binance spot 2024-01-01 sampai sekarang untuk 20 koin likuid (pelatuk 5 menit)."""
import json, time, urllib.request, numpy as np, os
from concurrent.futures import ThreadPoolExecutor
B = "https://data-api.binance.vision/api/v3"
SY = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "BNBUSDT", "ADAUSDT", "AVAXUSDT", "LINKUSDT", "SUIUSDT", "LTCUSDT", "DOTUSDT",
      "NEARUSDT", "UNIUSDT", "ENAUSDT", "WLDUSDT", "ARBUSDT", "OPUSDT", "AAVEUSDT", "TIAUSDT"]
def get(u):
    for k in range(6):
        try:
            with urllib.request.urlopen(u, timeout=30) as r:
                return json.loads(r.read())
        except Exception:
            time.sleep(1.5 * (k + 1))
    return None
def dl(s):
    p = f"d5/{s}.npz"
    if os.path.exists(p): return s, -1
    out, st = [], 1704067200000
    while True:
        r = get(f"{B}/klines?symbol={s}&interval=5m&startTime={st}&limit=1000")
        if not r: break
        out += r
        if len(r) < 1000: break
        st = r[-1][0] + 300000
    a = np.array([[float(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5])] for x in out[:-1]])
    np.savez(p, t=a[:, 0].astype(np.int64), o=a[:, 1], h=a[:, 2], l=a[:, 3], c=a[:, 4], v=a[:, 5])
    return s, len(a)
with ThreadPoolExecutor(20) as ex:
    for s, n in ex.map(dl, SY):
        print(s, n, flush=True)

"""v149 riset 2: arah dari TF besar resmi (4J, 6J, 1D, BTC), pelatuk dari TF kecil resmi (15m, 30m, 1J).
Pelatuk: T1 sapuan likuiditas lalu ditolak, T2 isi FVG searah, T3 tembus range dengan volume.
Fitur konfirmasi dicatat per event (lokasi S/R 4J, Fibonacci 4J, volume, order flow, BTC, kelelahan) supaya rantai konfirmasi
bisa diuji sebagai saringan bertingkat tanpa menghitung ulang. Simulasi di path 15 menit, SL dicek dulu."""
import os, sys, glob, json, time, pickle
import numpy as np, numba as nb, pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "v2"))
import arus_core as A
M15 = 900000
H = 3600000
D15 = os.path.join(os.path.dirname(os.path.abspath(__file__)), "d15")


def muat(s):
    z = np.load(f"{D15}/{s}.npz")
    return {k: z[k] for k in z.files}


def rs(x, menit):
    k = menit // 15
    t, o, h, l, c, v = x["t"], x["o"], x["h"], x["l"], x["c"], x["v"]
    b = t // (menit * 60000)
    idx = np.flatnonzero(np.r_[True, b[1:] != b[:-1]])
    cnt = np.diff(np.r_[idx, len(t)])
    m = cnt == k
    T = b[idx] * menit * 60000
    O = o[idx]
    Hh = np.maximum.reduceat(h, idx)
    L = np.minimum.reduceat(l, idx)
    C = c[np.r_[idx[1:] - 1, len(t) - 1]]
    V = np.add.reduceat(v, idx)
    return dict(t=T[m], o=O[m], h=Hh[m], l=L[m], c=C[m], v=V[m], menit=menit)


def tutup(Thi, mhi, tlo, mlo):
    return np.searchsorted(Thi + mhi * 60000, tlo + mlo * 60000, side="right") - 1


def state(b, n):
    if len(b["c"]) < n + 60:
        return np.zeros(len(b["c"]), np.int8)
    return A.trend_state(b["c"], A.mcginley(b["c"], n), A.ema(b["c"], 50 if n >= 30 else 20))


@nb.njit(cache=True)
def pivot_levels(h, l, k):
    """Level pivot yang SUDAH terkonfirmasi di tiap bar: pivot di j terkonfirmasi di j+k. Simpan 12 terakhir."""
    n = len(h)
    ph = np.full((n, 12), np.nan)
    pl = np.full((n, 12), np.nan)
    bh = np.full(12, np.nan)
    bl = np.full(12, np.nan)
    for i in range(n):
        j = i - k
        if j - k >= 0:
            okh = True
            okl = True
            for q in range(j - k, j + k + 1):
                if h[q] > h[j]:
                    okh = False
                if l[q] < l[j]:
                    okl = False
            if okh:
                bh[1:] = bh[:-1]
                bh[0] = h[j]
            if okl:
                bl[1:] = bl[:-1]
                bl[0] = l[j]
        ph[i] = bh
        pl[i] = bl
    return ph, pl


@nb.njit(cache=True)
def taruh(out, k, a, b, c, d, e, f):
    out[k, 0] = a
    out[k, 1] = b
    out[k, 2] = c
    out[k, 3] = d
    out[k, 4] = e
    out[k, 5] = f
    return k + 1


@nb.njit(cache=True)
def pelatuk(o, h, l, c, v, a, N):
    """Return array event: i, d, jenis, sl_dasar (level invalidasi tanpa buffer), kekuatan (range/ATR), body ratio."""
    n = len(c)
    out = np.zeros((2 * n, 6))
    k = 0
    for i in range(N + 3, n):
        rg = h[i] - l[i]
        if rg <= 0 or a[i] <= 0:
            continue
        lo = A.mn(l, i - N, i)
        hi = A.mx(h, i - N, i)
        # T1 sapuan lalu tolak
        if l[i] < lo and c[i] > lo and c[i] > o[i] and (c[i] - l[i]) / rg >= 0.6:
            k = taruh(out, k, i, 1, 1, l[i], rg / a[i], (c[i] - o[i]) / rg)
        if h[i] > hi and c[i] < hi and c[i] < o[i] and (h[i] - c[i]) / rg >= 0.6:
            k = taruh(out, k, i, -1, 1, h[i], rg / a[i], (o[i] - c[i]) / rg)
        # T3 tembus range
        if c[i] > hi and c[i] > o[i]:
            k = taruh(out, k, i, 1, 3, A.mn(l, i - 3, i + 1), rg / a[i], (c[i] - o[i]) / rg)
        if c[i] < lo and c[i] < o[i]:
            k = taruh(out, k, i, -1, 3, A.mx(h, i - 3, i + 1), rg / a[i], (o[i] - c[i]) / rg)
        # T2 isi FVG searah (gap 20 bar terakhir, belum tertutup)
        for j in range(i - 1, max(i - 20, 2), -1):
            if l[j] > h[j - 2] and l[j] - h[j - 2] >= 0.25 * a[i]:
                top, bot = l[j], h[j - 2]
                if (j + 1 >= i or A.mn(l, j + 1, i) > top) and l[i] <= top and l[i] > bot - 0.3 * a[i] and c[i] > (top + bot) / 2 and c[i] > o[i]:
                    k = taruh(out, k, i, 1, 2, min(bot, l[i]), rg / a[i], (c[i] - o[i]) / rg)
                break
        for j in range(i - 1, max(i - 20, 2), -1):
            if h[j] < l[j - 2] and l[j - 2] - h[j] >= 0.25 * a[i]:
                top, bot = l[j - 2], h[j]
                if (j + 1 >= i or A.mx(h, j + 1, i) < bot) and h[i] >= bot and h[i] < top + 0.3 * a[i] and c[i] < (top + bot) / 2 and c[i] < o[i]:
                    k = taruh(out, k, i, -1, 2, max(top, h[i]), rg / a[i], (o[i] - c[i]) / rg)
                break
    return out[:k]


@nb.njit(cache=True)
def sim15(t, o, h, l, c, k0, d, sl, e, risk, tp1_r, por1, trail_m, macet_h, macet_mfe, maks_h, maks_aman_h, tp_sr, biaya):
    """Path 15 menit. TP1 di tp1_r (atau level S/R tp_sr kalau > 0 dan lebih dekat tapi >= 0.8R), lalu SL ke entry.
    Sisa: SL berjalan di low/high trail_m candle 15m terakhir (0 = tanpa). Macet: di jam macet_h kalau MFE < macet_mfe R
    dan belum aman, tutup. Belum aman maks maks_h jam, sudah aman maks maks_aman_h jam. Return R bersih, bar keluar, aman."""
    n = len(c)
    sisa = 1.0
    real = 0.0
    aman = -1
    mfe = 0.0
    tp1 = e + d * tp1_r * risk
    if tp_sr > 0:
        jr = (tp_sr - e) * d / risk
        if 0.8 <= jr < tp1_r:
            tp1 = tp_sr
    for j in range(k0, n):
        q = j - k0
        if (d == 1 and l[j] <= sl) or (d == -1 and h[j] >= sl):
            real += sisa * (sl - e) * d / risk
            return real - biaya * e / risk, j, aman
        f = ((h[j] - e) if d == 1 else (e - l[j])) / risk
        if f > mfe:
            mfe = f
        if aman < 0 and ((d == 1 and h[j] >= tp1) or (d == -1 and l[j] <= tp1)):
            real += por1 * (tp1 - e) * d / risk
            sisa -= por1
            aman = q
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            if sisa <= 1e-9:
                return real - biaya * e / risk, j, aman
        if aman >= 0 and trail_m > 0 and q >= trail_m:
            if d == 1:
                st = A.mn(l, j - trail_m + 1, j + 1)
                if st > sl and st < c[j]:
                    sl = st
            else:
                st = A.mx(h, j - trail_m + 1, j + 1)
                if st < sl and st > c[j]:
                    sl = st
        jam = (q + 1) / 4.0
        if aman < 0 and macet_h > 0 and jam == macet_h and mfe < macet_mfe:
            real += sisa * (c[j] - e) * d / risk
            return real - biaya * e / risk, j, aman
        if (aman < 0 and jam >= maks_h) or (aman >= 0 and jam >= maks_aman_h):
            real += sisa * (c[j] - e) * d / risk
            return real - biaya * e / risk, j, aman
    real += sisa * (c[n - 1] - e) * d / risk
    return real - biaya * e / risk, n - 1, aman


@nb.njit(cache=True)
def sim_batch(t, o, h, l, c, k0, d, sl, risk, tpsr, tp1_r, por1, trail_m, macet_h, macet_mfe, maks_h, maks_aman_h, pakai_sr, biaya):
    m = len(k0)
    R = np.zeros(m)
    kx = np.zeros(m, np.int64)
    am = np.zeros(m, np.int64)
    for i in range(m):
        r, k, a = sim15(t, o, h, l, c, k0[i], d[i], sl[i], o[k0[i]], risk[i], tp1_r, por1, trail_m, macet_h, macet_mfe, maks_h, maks_aman_h,
                        tpsr[i] if pakai_sr else 0.0, biaya)
        R[i] = r
        kx[i] = k
        am[i] = a
    return R, kx, am


def bangun(sym, btc):
    x = muat(sym)
    b = {m: rs(x, m) for m in (30, 60, 240, 360, 1440)}
    st4, st6, stD = state(b[240], 34), state(b[360], 34), state(b[1440], 14)
    a4 = A.atr(b[240]["h"], b[240]["l"], b[240]["c"])
    aD = A.atr(b[1440]["h"], b[1440]["l"], b[1440]["c"])
    ph4, pl4 = pivot_levels(b[240]["h"], b[240]["l"], 3)
    ev = []
    for tf, bt in ((15, dict(x, menit=15)), (30, b[30]), (60, b[60])):
        o, h, l, c, v, t = bt["o"], bt["h"], bt["l"], bt["c"], bt["v"], bt["t"]
        a = A.atr(h, l, c)
        vp = A.volpct(v)
        fl = A.delta_flow(o, h, l, c, v, 3)
        E = pelatuk(o, h, l, c, v, a, 20)
        if not len(E):
            continue
        i = E[:, 0].astype(int)
        tt = t[i]
        j4 = tutup(b[240]["t"], 240, tt, tf)
        j6 = tutup(b[360]["t"], 360, tt, tf)
        jD = tutup(b[1440]["t"], 1440, tt, tf)
        ok = (j4 >= 60) & (j6 >= 40) & (jD >= 30)
        E, i, tt, j4, j6, jD = E[ok], i[ok], tt[ok], j4[ok], j6[ok], jD[ok]
        d = E[:, 1].astype(int)
        cc = c[i]
        # level S/R 4J terkonfirmasi: support terdekat di bawah close (LONG) atau resistance di atas (SHORT), dan target sisi lawan
        P_h, P_l = ph4[j4], pl4[j4]
        allv = np.concatenate([P_h, P_l], axis=1)
        bawah = np.where(allv < cc[:, None], allv, -np.inf).max(axis=1)
        atas = np.where(allv > cc[:, None], allv, np.inf).min(axis=1)
        a4i = a4[j4]
        ext = np.where(d == 1, l[i], h[i])
        dsr = np.where(d == 1, (ext - bawah) / a4i, (atas - ext) / a4i)          # jarak ujung candle pelatuk ke S/R searah (ATR 4J)
        tgt = np.where(d == 1, atas, bawah)                                     # tembok di arah trade
        # Fibonacci impuls 4J: 30 candle 4J tutup terakhir
        H4c, L4c = b[240]["h"], b[240]["l"]
        fib = np.full(len(i), np.nan)
        for q in range(len(i)):
            a0, a1 = j4[q] - 29, j4[q] + 1
            hh, ll = H4c[a0:a1], L4c[a0:a1]
            ih, il = hh.argmax(), ll.argmin()
            HI, LO = hh[ih], ll[il]
            if HI > LO:
                fib[q] = (HI - ext[q]) / (HI - LO) if d[q] == 1 and il < ih else ((ext[q] - LO) / (HI - LO) if d[q] == -1 and ih < il else np.nan)
        # kelelahan: gerak 72 jam dan candle 4J terakhir
        C4 = b[240]["c"]; O4 = b[240]["o"]
        lelah = (C4[j4] - C4[np.maximum(j4 - 18, 0)]) / aD[jD] * d
        c4 = (C4[j4] - O4[j4]) / O4[j4] * 100 * d
        # entry: open bar 15m sesudah bar pelatuk tutup
        k0 = np.searchsorted(x["t"], tt + tf * 60000)
        okk = k0 < len(x["t"]) - 2
        gi = np.searchsorted(btc["t4"], tt + tf * 60000, side="right") - 1
        gD = np.searchsorted(btc["tD"], tt + tf * 60000, side="right") - 1
        df = pd.DataFrame(dict(sym=sym, tf=tf, t=tt + tf * 60000, d=d, jenis=E[:, 2].astype(int), sl0=E[:, 3], kuat=E[:, 4], body=E[:, 5],
                               atr=a[i], vp=vp[i], fl=fl[i] * d, s4=st4[j4] * d, s6=st6[j6] * d, sD=stD[jD] * d,
                               b4=btc["s4"][np.maximum(gi, 0)] * d, bD=btc["sD"][np.maximum(gD, 0)] * d, bvol=btc["vol"][np.maximum(gi, 0)] * d,
                               dsr=dsr, tgt=tgt, fib=fib, lelah=lelah, c4=c4, k0=k0, a4=a4i))
        ev.append(df[okk])
    return pd.concat(ev, ignore_index=True) if ev else None, x


def btc_ctx():
    x = muat("BTCUSDT")
    b4, bD = rs(x, 240), rs(x, 1440)
    s4, sD = state(b4, 34), state(bD, 14)
    up = np.where(b4["c"] > b4["o"], b4["v"], 0.0); dn = np.where(b4["c"] < b4["o"], b4["v"], 0.0)
    cs = lambda z: np.convolve(z, np.ones(6), "full")[:len(z)]
    vol = (cs(up) - cs(dn)) / np.maximum(cs(b4["v"]), 1e-9)
    # nilai baru berlaku setelah candle tutup: geser waktu ke waktu tutup
    return dict(t4=b4["t"] + 240 * 60000, s4=s4, vol=vol, tD=bD["t"] + 1440 * 60000, sD=sD)


if __name__ == "__main__":
    t0 = time.time()
    btc = btc_ctx()
    out = []
    X = {}
    for f in sorted(glob.glob(f"{D15}/*.npz")):
        s = os.path.basename(f)[:-4]
        E, x = bangun(s, btc)
        if E is not None:
            out.append(E)
        print(s, 0 if E is None else len(E), round(time.time() - t0), flush=True)
    E = pd.concat(out, ignore_index=True)
    E.to_pickle("ev_mtf.pkl")
    print("event", len(E), E.groupby(["tf", "jenis"]).size().to_dict())

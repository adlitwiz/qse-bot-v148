"""Walk-forward bergulir 6 bulan, profil PER KOIN. Untuk tiap koin dan tiap jendela 6 bulan: pilih kombinasi (TF pelatuk, teknik,
rantai konfirmasi, SL, cara keluar) dengan PF terbaik di SEMUA data koin itu SEBELUM jendela (minimal n trade), lalu pakai di
jendela itu. Koin baru otomatis ikut begitu punya cukup riwayat. Biaya 0.15% harga per trade (komisi taker 2 x 0.055% + slippage).
Juga versi global (satu kombinasi terbaik dari semua koin) dan versi per koin dengan syarat PF masa lalu >= 1.5."""
import sys, itertools, time, pickle, os
import numpy as np, pandas as pd
EVF = sys.argv[1] if len(sys.argv) > 1 else "ev_mtf.pkl"
RSF = sys.argv[2] if len(sys.argv) > 2 else "res_mtf.pkl"
E = pd.read_pickle(EVF)
RES = pickle.load(open(RSF, "rb"))
t0 = time.time()
SEMESTER = 182 * 86400000
w = ((E.t.values - 1609459200000) // SEMESTER).astype(int)          # jendela 6 bulan sejak 2021-01-01
syms = sorted(E.sym.unique())
sid = E.sym.map({s: i for i, s in enumerate(syms)}).values
nw = w.max() + 1
G = sid * nw + w
NG = len(syms) * nw
f = E
KOMPAS = {"-": np.ones(len(f), bool), "4J": f.s4.values > 0, "4J+1D": (f.s4.values > 0) & (f.sD.values > 0),
          "4J+6J+1D": (f.s4.values > 0) & (f.s6.values > 0) & (f.sD.values > 0),
          "4J+1D+BTC4J": (f.s4.values > 0) & (f.sD.values > 0) & (f.b4.values > 0)}
LOK = {"-": np.ones(len(f), bool), "S/R": (f.dsr.values >= -0.3) & (f.dsr.values <= 0.5), "fib": (f.fib.values >= 0.382) & (f.fib.values <= 0.786)}
VOL = {"-": np.ones(len(f), bool), "vol85": f.vp.values >= 85}
FL = {"-": np.ones(len(f), bool), "flow": f.fl.values > 0.2}
LL = {"-": np.ones(len(f), bool), "segar": (f.lelah.values < 2.5) & (f.c4.values < 8)}
tfj = {(tf, j): ((f.tf.values == tf) & (f.jenis.values == j)) for tf in sorted(f.tf.unique()) for j in (1, 2, 3)}
kombo, POS, NEG, CNT = [], [], [], []
for (k1, m1), (k2, m2), (k3, m3), (k4, m4), (k5, m5) in itertools.product(KOMPAS.items(), LOK.items(), VOL.items(), FL.items(), LL.items()):
    base = m1 & m2 & m3 & m4 & m5
    for (tf, j), mt in tfj.items():
        mm = base & mt
        if mm.sum() < 100:
            continue
        for key, R in RES.items():
            ok = mm & ~np.isnan(R)
            g, r = G[ok], R[ok]
            POS.append(np.bincount(g, weights=np.maximum(r, 0), minlength=NG))
            NEG.append(np.bincount(g, weights=np.maximum(-r, 0), minlength=NG))
            CNT.append(np.bincount(g, minlength=NG))
            kombo.append((tf, j, k1, k2, k3, k4, k5) + key)
POS, NEG, CNT = (np.array(x).reshape(len(kombo), len(syms), nw) for x in (POS, NEG, CNT))
print("kombinasi", len(kombo), "waktu", round(time.time() - t0), flush=True)
cP, cN, cC = np.cumsum(POS, 2), np.cumsum(NEG, 2), np.cumsum(CNT, 2)          # kumulatif s.d. jendela w (termasuk)


def pf(p, n):
    return p / np.maximum(n, 1e-9)


hasil = {}
for nama, nmin, pfmin in (("per koin, n masa lalu >= 30", 30, 0.0), ("per koin, n >= 30 dan PF masa lalu >= 1.5", 30, 1.5),
                          ("per koin, n >= 60 dan PF masa lalu >= 1.3", 60, 1.3)):
    tp, tn, tc, per = 0.0, 0.0, 0, []
    for wi in range(2, nw):                          # minimal 1 tahun riwayat global sebelum jendela uji pertama
        P_, N_, C_ = cP[:, :, wi - 1], cN[:, :, wi - 1], cC[:, :, wi - 1]
        sc = np.where(C_ >= nmin, pf(P_, N_), -1)
        best = sc.argmax(0)
        for si in range(len(syms)):
            k = best[si]
            if sc[k, si] < max(pfmin, 0.0) or sc[k, si] <= 0:
                continue
            tp += POS[k, si, wi]; tn += NEG[k, si, wi]; tc += CNT[k, si, wi]
            per.append((syms[si], wi, k, sc[k, si], POS[k, si, wi], NEG[k, si, wi], CNT[k, si, wi]))
    hasil[nama] = (tp, tn, tc, per)
    print(f"{nama}: trade uji {tc}, PF uji {pf(tp, tn):.2f}, total {tp - tn:+.0f}R, rata {(tp - tn) / max(tc, 1):+.3f}R | "
          f"PF masa lalu rata yang dipilih {np.mean([x[3] for x in per]) if per else 0:.2f}", flush=True)
# global: satu kombinasi terbaik dari semua koin di masa lalu
tp, tn, tc = 0.0, 0.0, 0
for wi in range(2, nw):
    P_, N_, C_ = cP[:, :, wi - 1].sum(1), cN[:, :, wi - 1].sum(1), cC[:, :, wi - 1].sum(1)
    sc = np.where(C_ >= 300, pf(P_, N_), -1)
    k = sc.argmax()
    tp += POS[k, :, wi].sum(); tn += NEG[k, :, wi].sum(); tc += CNT[k, :, wi].sum()
    print(f"  jendela {wi}: global pilih {kombo[k][:7]} {kombo[k][7]} {kombo[k][8][:1]} PF lalu {sc[k]:.2f} -> uji PF {pf(POS[k, :, wi].sum(), NEG[k, :, wi].sum()):.2f} n {CNT[k, :, wi].sum()}")
print(f"global satu kombinasi: trade uji {tc}, PF uji {pf(tp, tn):.2f}, total {tp - tn:+.0f}R")
# per tahun untuk versi per koin PF >= 1.5
per = hasil["per koin, n >= 30 dan PF masa lalu >= 1.5"][3]
D = pd.DataFrame(per, columns=["sym", "w", "k", "pf_lalu", "pos", "neg", "n"])
D["tahun"] = 2021 + D.w // 2
print(D.groupby("tahun").apply(lambda g: pd.Series(dict(n=g.n.sum(), pf_uji=g.pos.sum() / max(g.neg.sum(), 1e-9), pf_lalu=g.pf_lalu.mean()))).round(2).to_string())
pickle.dump(dict(kombo=kombo, syms=syms, hasil=hasil), open(f"wf_{os.path.basename(EVF)}", "wb"))

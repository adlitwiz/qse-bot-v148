"""Unduh data derivatif BTCUSDT perpetual dari arsip publik Binance Futures (data.binance.vision): funding rate bulanan dan
metrics harian (open interest tiap 5 menit, rasio long/short). Bybit memblokir akses dari server uji, Binance dipakai sebagai wakil."""
import io, os, sys, zipfile, datetime as dt, urllib.request
import pandas as pd
from concurrent.futures import ThreadPoolExecutor
OUT = sys.argv[1]
B = "https://data.binance.vision/data/futures/um"
def get(u):
    for _ in range(4):
        try:
            with urllib.request.urlopen(u, timeout=60) as r:
                z = zipfile.ZipFile(io.BytesIO(r.read()))
                return pd.read_csv(z.open(z.namelist()[0]))
        except Exception:
            pass
    return None
bulan = pd.period_range("2022-06", "2026-10", freq="M")
fr = [get(f"{B}/monthly/fundingRate/BTCUSDT/BTCUSDT-fundingRate-{p}.zip") for p in bulan]
F = pd.concat([x for x in fr if x is not None])
F.to_csv(f"{OUT}/btc_funding.csv", index=False)
hari = pd.date_range("2022-06-01", "2026-10-31", freq="D")
with ThreadPoolExecutor(16) as ex:
    ms = list(ex.map(lambda d: get(f"{B}/daily/metrics/BTCUSDT/BTCUSDT-metrics-{d:%Y-%m-%d}.zip"), hari))
M = pd.concat([x for x in ms if x is not None])
M.to_csv(f"{OUT}/btc_metrics.csv", index=False)
print("funding", len(F), "metrics", len(M), "hari kosong", sum(x is None for x in ms))

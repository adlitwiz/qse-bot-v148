"""Uji teknik fractal di 387 koin Binance sejak listing (data 1J dirakit jadi 4J dan 1D). Biaya 0.15% harga pulang pergi.
A. Hitung candle: setelah N candle searah beruntun, apakah candle berikutnya berbalik? Uji fade (lawan arah) keluar 1 dan 6 candle.
B. Fractal Bill Williams (pivot 5 candle, terkonfirmasi 2 candle kemudian):
   B1 pembalikan: fractal bawah terbentuk -> LONG, fractal atas -> SHORT, SL di ujung fractal, TP 2x jarak SL, maks 12 candle.
   B2 tembus: harga menembus fractal atas terakhir -> LONG, fractal bawah -> SHORT, SL di fractal lawan terakhir, TP 2x, maks 12 candle.
Hasil per periode 2021-2023 dan 2024-2026 dalam persen gerak harga per trade."""
import glob, os, sys
import numpy as np, pandas as pd
D = sys.argv[1]
FEE = 0.15
out = []
def P(s): print(s); out.append(s)
def muat(f, tf):
    d = pd.read_csv(f, usecols=[0, 1, 2, 3, 4]); d["t"] = pd.to_datetime(d["t"], utc=True)
    d = d.set_index("t").resample(tf).agg(dict(open="first", high="max", low="min", close="last")).dropna()
    return d
def ringkas(nm, r, th):
    r = np.asarray(r); th = np.asarray(th)
    s = f"{nm:38s}"
    for a, b in ((2021, 2023), (2024, 2026)):
        x = r[(th >= a) & (th <= b)]
        if len(x) < 30: s += f" | {a}-{b} n{len(x)}"; continue
        pf = x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
        s += f" | {a}-{b} n{len(x):6d} WR {np.mean(x > 0) * 100:4.1f}% rata {x.mean():+.3f}% PF {pf:.2f}"
    P(s)
def sim(o, h, l, c, i, arah, sl, tp, maks):
    e = c[i]
    for j in range(i + 1, min(i + 1 + maks, len(c))):
        if (l[j] <= sl) if arah > 0 else (h[j] >= sl): return (sl - e) / e * 100 * arah - FEE
        if (h[j] >= tp) if arah > 0 else (l[j] <= tp): return (tp - e) / e * 100 * arah - FEE
    j = min(i + maks, len(c) - 1)
    return (c[j] - e) / e * 100 * arah - FEE
for tf, nm in (("4h", "4J"), ("1D", "1D")):
    A = {n: ([], [], [], []) for n in (3, 5, 7, 9)}
    B1, B2 = ([], []), ([], [])
    for f in sorted(glob.glob(f"{D}/*_60.csv")):
        d = muat(f, tf)
        if len(d) < 200: continue
        o, h, l, c = (d[k].values for k in ("open", "high", "low", "close"))
        th = d.index.year.values
        w = np.sign(c - o)
        run = np.zeros(len(c), int)
        for i in range(1, len(c)):
            run[i] = run[i - 1] + 1 if (w[i] == w[i - 1] and w[i] != 0) else 1
        for n in A:
            idx = np.where((run == n) & (np.arange(len(c)) < len(c) - 7))[0]
            for i in idx:
                arah = -w[i]                      # fade
                A[n][0].append(w[i + 1] == arah)
                A[n][1].append((c[i + 1] - c[i]) / c[i] * 100 * arah - FEE)
                A[n][2].append((c[i + 6] - c[i]) / c[i] * 100 * arah - FEE)
                A[n][3].append(th[i])
        up = np.zeros(len(c), bool); dn = np.zeros(len(c), bool)
        up[2:-2] = (h[2:-2] > h[:-4]) & (h[2:-2] > h[1:-3]) & (h[2:-2] > h[3:-1]) & (h[2:-2] > h[4:])
        dn[2:-2] = (l[2:-2] < l[:-4]) & (l[2:-2] < l[1:-3]) & (l[2:-2] < l[3:-1]) & (l[2:-2] < l[4:])
        fu = fd = None
        posisi_sampai = -1
        for i in range(4, len(c) - 1):
            k = i - 2                              # fractal di k terkonfirmasi saat candle i tutup
            if dn[k]:
                sl = l[k]; e = c[i]
                if e > sl:
                    B1[0].append(sim(o, h, l, c, i, 1, sl, e + 2 * (e - sl), 12)); B1[1].append(th[i])
                fd = l[k]
            if up[k]:
                sl = h[k]; e = c[i]
                if e < sl:
                    B1[0].append(sim(o, h, l, c, i, -1, sl, e - 2 * (sl - e), 12)); B1[1].append(th[i])
                fu = h[k]
            if i <= posisi_sampai or fu is None or fd is None: continue
            if c[i] > fu and c[i - 1] <= fu and fd < c[i]:
                e = c[i]; B2[0].append(sim(o, h, l, c, i, 1, fd, e + 2 * (e - fd), 12)); B2[1].append(th[i]); posisi_sampai = i + 12
            elif c[i] < fd and c[i - 1] >= fd and fu > c[i]:
                e = c[i]; B2[0].append(sim(o, h, l, c, i, -1, fu, e - 2 * (fu - e), 12)); B2[1].append(th[i]); posisi_sampai = i + 12
    P(f"\n=== TF {nm} ===")
    for n in A:
        b = np.array(A[n][0]); t = np.array(A[n][3])
        P(f"Setelah {n} candle searah: candle berikutnya berbalik {b.mean() * 100:.1f}% (n {len(b)})")
        ringkas(f"  fade {n} candle, keluar 1 candle", A[n][1], t)
        ringkas(f"  fade {n} candle, keluar 6 candle", A[n][2], t)
    ringkas("Fractal pembalikan (B1)", *B1)
    ringkas("Fractal tembus (B2)", *B2)
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hasil_fractal.txt"), "w").write("\n".join(out))

"""Uji peta komando BTC (qse_btcmap.hitung): tiap candle 4J tutup 2019-2026, hitung FOKUS dari data yang sudah tutup saja,
lalu cek arah BTC 4 jam dan 24 jam ke depan, dan hasil sinyal robot yang searah lawan berlawanan FOKUS."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot")
sys.path.insert(0, "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v2")
import qse_btcmap as BM, arus_core as A
z = np.load("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v2/data/BTCUSDT.npz")
H = 3600000
d1 = pd.DataFrame(dict(open=z["o"], high=z["h"], low=z["l"], close=z["c"], volume=z["v"]), index=z["t"])
def rs(k):
    T, O, Hh, L, C, V = A.resample(z["t"], z["o"], z["h"], z["l"], z["c"], z["v"], k)
    return pd.DataFrame(dict(open=O, high=Hh, low=L, close=C, volume=V), index=T)
d4, dD = rs(4), rs(24)
rows = []
t0 = pd.Timestamp("2019-01-01").value // 10**6
for T in d4.index[d4.index >= t0]:
    tc = T + 4 * H                                              # waktu candle 4J ini tutup
    a1 = d1[d1.index + H <= tc].iloc[-400:]
    a4 = d4[d4.index + 4 * H <= tc].iloc[-300:]
    aD = dD[dD.index + 24 * H <= tc].iloc[-200:]
    if len(a4) < 100 or len(aD) < 60:
        continue
    p = BM.hitung(a1, a4, aD)
    px = a1["close"].iloc[-1]
    f4 = d1[(d1.index >= tc) & (d1.index < tc + 4 * H)]
    f24 = d1[(d1.index >= tc) & (d1.index < tc + 24 * H)]
    if len(f24) < 24:
        continue
    rows.append(dict(t=tc, fokus=p["fokus"], skor=p["skor"], r4=f4["close"].iloc[-1] / px - 1, r24=f24["close"].iloc[-1] / px - 1,
                     sapu_atas=bool(p["liq_atas"] and f24["high"].max() >= p["liq_atas"][0][0]),
                     sapu_bawah=bool(p["liq_bawah"] and f24["low"].min() <= p["liq_bawah"][0][0])))
D = pd.DataFrame(rows)
D["tahun"] = pd.to_datetime(D.t, unit="ms").dt.year
D.to_pickle("fokus.pkl")
print(len(D), "titik 4J")
for nm, g in D.groupby("fokus"):
    s = 1 if nm == "LONG" else -1 if nm == "SHORT" else 0
    print(f"{nm:6s} {len(g)/len(D)*100:4.0f}% waktu | BTC 24 jam naik {np.mean(g.r24 > 0)*100:.0f}%, rata {g.r24.mean()*100:+.2f}% | 4 jam naik {np.mean(g.r4 > 0)*100:.0f}%")
print("dasar semua waktu: 24 jam naik", round(np.mean(D.r24 > 0) * 100), "%")
print("per tahun, persen tebakan FOKUS benar arah 24 jam (LONG naik, SHORT turun):")
for th, g in D.groupby("tahun"):
    x = g[g.fokus != "TAHAN"]
    benar = np.mean(np.where(x.fokus == "LONG", x.r24 > 0, x.r24 < 0)) * 100
    print(f"  {th}: {benar:.0f}% dari {len(x)} titik (TAHAN {np.mean(g.fokus=='TAHAN')*100:.0f}%)")
print("likuiditas terdekat tersapu dalam 24 jam: atas", round(D.sapu_atas.mean() * 100), "%, bawah", round(D.sapu_bawah.mean() * 100), "%")
for nm in ("LONG", "SHORT"):
    g = D[D.fokus == nm]
    print(f"  saat FOKUS {nm}: sapu atas {g.sapu_atas.mean()*100:.0f}%, sapu bawah {g.sapu_bawah.mean()*100:.0f}%")

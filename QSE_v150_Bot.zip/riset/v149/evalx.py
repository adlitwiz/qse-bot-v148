"""Evaluasi: simulasi tiap event lalu pilih portofolio (urut waktu, slot, satu koin satu posisi, rem harian)."""
import os, sys, json, pickle, time
import numpy as np, pandas as pd
import arus_core as A
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prep")
H = A.H
DAY = 24 * H
_X = {}
G = pickle.load(open(f"{P}/glob.pkl", "rb"))


def X(s):
    if s not in _X:
        _X[s] = pickle.load(open(f"{P}/x_{s}.pkl", "rb"))
    return _X[s]


DEF = dict(tp1_r=1.0, sr_f=0.85, room=0.6, porsi1=0.5, tp2_r=2.0, maks_jam=24, spike=1.0, spike_porsi=0.5,
           stall_jam=8, stall_mode=3, biaya=0.0015, be_off=0.05)


def sim(E, cfg):
    c = dict(DEF, **cfg)
    E = E.copy()
    e = E["e"].values
    d = E["d"].values
    risk = (e - E["sl"].values) * d
    room = (E["sr"].values - e) * d / np.maximum(risk, 1e-12)
    ok = (risk > 0) & (risk / e >= 0.003) & (risk / e <= 0.10)
    if c["room"] > 0:
        ok &= room >= c["room"]
    E = E[ok].copy()
    e, d = E["e"].values, E["d"].values
    risk = (e - E["sl"].values) * d
    room = (E["sr"].values - e) * d / risk
    t1 = np.minimum(c["tp1_r"], np.where(c["sr_f"] > 0, c["sr_f"] * room, 99))
    t1 = np.maximum(t1, 0.4)
    E["tp1R"] = t1
    E["tp1"] = e + d * t1 * risk
    E["tp2"] = np.where(c["tp2_r"] > 0, e + d * c["tp2_r"] * risk, 0.0)
    out = []
    for s, g in E.groupby("sym", sort=False):
        x = X(s)
        R, kx, kode, mfe = A.simulasi_batch(x["t"], x["o"], x["h"], x["l"], x["c"], x["a4"], g["k0"].values.astype(np.int64),
                                            g["d"].values.astype(np.int64), g["sl"].values, g["tp1"].values, g["tp2"].values,
                                            c["porsi1"], c["maks_jam"], c["spike"], c["spike_porsi"], c["stall_jam"], c["stall_mode"],
                                            c["biaya"], c["be_off"])
        g = g.copy()
        g["R"], g["tx"], g["kode"], g["mfe"] = R, x["t"][kx] + H, kode, mfe
        out.append(g)
    return pd.concat(out).sort_values("t", kind="stable")


def portofolio(S, maks=5, top=100, vol_frac=1.0, rem=-3.0, umur_min=60, filt=None, memori=None):
    """S hasil sim (urut t). Universe bulanan dari volume 30 hari sebelumnya. Satu koin satu posisi, slot maks, rem harian."""
    qv, ap = G["qv_bulan"], G["atrp_bulan"]
    uni = {}
    for m, dct in qv.items():
        top_s = sorted(dct, key=lambda s: -dct[s])[:top]
        if vol_frac < 1.0:
            a = ap[m]
            top_s = sorted(top_s, key=lambda s: -a.get(s, 0))[:max(1, int(len(top_s) * vol_frac))]
        uni[m] = set(top_s)
    pertama = {}
    for s in S["sym"].unique():
        pertama[s] = X(s)["t"][0]
    buka = []           # (tx, sym)
    harian = {}
    ambil = np.zeros(len(S), bool)
    mem = {}
    T, sym, tx, R = S["t"].values, S["sym"].values, S["tx"].values, S["R"].values
    fl = filt(S) if filt is not None else np.ones(len(S), bool)
    mkey = (S["sym"] + "|" + S["tf"] + "|" + S["jenis"].astype(str) + "|" + S["d"].astype(str)).values if memori else None
    selesai = []        # antrean hasil untuk memori: (tx, key, R)
    import heapq
    for j in range(len(S)):
        t = T[j]
        if not fl[j]:
            continue
        m = t // DAY // 30
        if sym[j] not in uni.get(m, ()):
            continue
        if t - pertama[sym[j]] < umur_min * DAY:
            continue
        buka = [b for b in buka if b[0] > t]
        if len(buka) >= maks or any(b[1] == sym[j] for b in buka):
            continue
        hari = t // DAY
        if harian.get(hari, 0.0) <= rem:
            continue
        if memori:
            while selesai and selesai[0][0] <= t:
                _, kk, rr = heapq.heappop(selesai)
                mem.setdefault(kk, []).append(rr)
            h = mem.get(mkey[j], [])[-memori["n"]:]
            if len(h) >= memori["min"] and np.mean(h) < memori["batas"]:
                continue
        ambil[j] = True
        buka.append((tx[j], sym[j]))
        hx = tx[j] // DAY
        harian[hx] = harian.get(hx, 0.0) + R[j]
        if memori:
            heapq.heappush(selesai, (tx[j], mkey[j], R[j]))
    return S[ambil]


def stat(T, lab=""):
    if not len(T):
        return f"{lab} 0 trade"
    r = T["R"].values
    w = r[r > 0].sum()
    ls = -r[r < 0].sum()
    eq = np.cumsum(r)
    dd = (np.maximum.accumulate(np.r_[0, eq]) - np.r_[0, eq]).max()
    wk = (T["t"].max() - T["t"].min()) / (7 * DAY) + 1e-9
    return f"{lab} n {len(r)} ({len(r) / wk:.1f}/mg) WR {np.mean(r > 0) * 100:.1f} PF {w / max(ls, 1e-9):.2f} tot {r.sum():+.0f}R rata {r.mean():+.3f} DD {dd:.0f}R"


def ringkas(T, lab):
    IS = T[T["t"] < 1704067200000]
    OOS = T[T["t"] >= 1704067200000]
    return stat(IS, lab + " IS") + "\n   " + stat(OOS, " OOS")

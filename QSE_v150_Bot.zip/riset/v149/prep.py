"""Siapkan data per koin (1 jam + konteks 4J, 1D, BTC, breadth) dan event setup untuk TF pemicu 1J dan 4J."""
import os, sys, json, glob, time, pickle
import numpy as np
import arus_core as A

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prep")
os.makedirs(OUT, exist_ok=True)
H = A.H
DAY = 24 * H

# parameter deteksi bawaan (bisa diubah lewat argumen JSON)
PD = dict(sw=24, fmin=0.5, fmax=0.886, lelah_max=2.5, lelah_balik=3.0, slbuf=0.2, swp=24)
if len(sys.argv) > 1:
    PD.update(json.loads(sys.argv[1]))
TAG = sys.argv[2] if len(sys.argv) > 2 else "dasar"


def muat(sym):
    z = np.load(f"{D}/{sym}.npz")
    t = z["t"].astype(np.int64)
    m = np.r_[True, np.diff(t) > 0]
    return {k: z[k][m] for k in ("t", "o", "h", "l", "c", "v")}


def konteks(x):
    t, o, h, l, c, v = x["t"], x["o"], x["h"], x["l"], x["c"], x["v"]
    T4, O4, H4_, L4, C4, V4 = A.resample(t, o, h, l, c, v, 4)
    TD, OD, HD, LD, CD, VD = A.resample(t, o, h, l, c, v, 24)
    s4 = A.trend_state(C4, A.mcginley(C4, 34), A.ema(C4, 50)) if len(C4) > 60 else np.zeros(len(C4), np.int8)
    sD = A.trend_state(CD, A.mcginley(CD, 14), A.ema(CD, 20)) if len(CD) > 30 else np.zeros(len(CD), np.int8)
    a4 = A.atr(H4_, L4, C4) if len(C4) > 2 else np.zeros(len(C4))
    aD = A.atr(HD, LD, CD) if len(CD) > 2 else np.zeros(len(CD))
    return dict(T4=T4, O4=O4, H4=H4_, L4=L4, C4=C4, V4=V4, s4=s4, a4=a4, TD=TD, OD=OD, CD=CD, sD=sD, aD=aD)


def main():
    syms = [s for s in json.load(open(f"{D}/_daftar.json")) if os.path.exists(f"{D}/{s}.npz")]
    btc = muat("BTCUSDT")
    G = btc["t"]                                          # garis waktu global
    kb = konteks(btc)
    i4 = A.map_closed(kb["T4"], 4, G, 1)
    iD = A.map_closed(kb["TD"], 24, G, 1)
    btc_s4 = np.where(i4 >= 0, kb["s4"][np.maximum(i4, 0)], 0)
    btc_sD = np.where(iD >= 0, kb["sD"][np.maximum(iD, 0)], 0)
    # volume objektif BTC: 6 candle 4J terakhir, volume candle naik lawan turun
    up4 = np.where(kb["C4"] > kb["O4"], kb["V4"], 0.0)
    dn4 = np.where(kb["C4"] < kb["O4"], kb["V4"], 0.0)
    cs = lambda x: np.convolve(x, np.ones(6), "full")[:len(x)]
    vr = (cs(up4) - cs(dn4)) / np.maximum(cs(kb["V4"]), 1e-9)
    btc_vol = np.where(i4 >= 0, vr[np.maximum(i4, 0)], 0)
    btc_fl = A.delta_flow(btc["o"], btc["h"], btc["l"], btc["c"], btc["v"], 24)
    # breadth: fraksi koin dengan close di atas open harian (hari UTC berjalan) dan 24 jam naik
    nG = len(G)
    naik = np.zeros(nG)
    aktif = np.zeros(nG)
    naik24 = np.zeros(nG)
    qv_bulan = {}
    atrp_bulan = {}
    per = {}
    t0 = time.time()
    for s in syms:
        x = muat(s)
        if len(x["t"]) < 24 * 120:
            continue
        gi = np.searchsorted(G, x["t"])
        ok = (gi < nG) & (G[np.minimum(gi, nG - 1)] == x["t"])
        day = x["t"] // DAY
        first = np.r_[True, day[1:] != day[:-1]]
        dopen = x["o"][np.maximum.accumulate(np.where(first, np.arange(len(day)), 0))]
        up = (x["c"] > dopen).astype(float)
        c24 = np.r_[np.full(24, np.nan), x["c"][:-24]]
        u24 = (x["c"] > c24).astype(float)
        naik[gi[ok]] += up[ok]
        naik24[gi[ok]] += u24[ok]
        aktif[gi[ok]] += 1
        # volume dan volatilitas 30 hari per bulan (dipakai bulan berikutnya)
        mon = (x["t"] // DAY // 30)
        qv = x["v"] * x["c"]
        atrp = (x["h"] - x["l"]) / np.maximum(x["c"], 1e-12)
        um = np.unique(mon)
        for m in um:
            sel = mon == m
            qv_bulan.setdefault(m + 1, {})[s] = float(qv[sel].sum())
            atrp_bulan.setdefault(m + 1, {})[s] = float(atrp[sel].mean())
        per[s] = x
    br = naik / np.maximum(aktif, 1)
    br24 = naik24 / np.maximum(aktif, 1)
    print("breadth", time.time() - t0, flush=True)
    glob_ctx = dict(G=G, btc_s4=btc_s4, btc_sD=btc_sD, btc_vol=btc_vol, btc_fl=btc_fl, br=br, br24=br24, aktif=aktif,
                    qv_bulan=qv_bulan, atrp_bulan=atrp_bulan, btc_c=btc["c"])
    pickle.dump(glob_ctx, open(f"{OUT}/glob.pkl", "wb"))
    P = np.array([PD["sw"], PD["fmin"], PD["fmax"], PD["lelah_max"], PD["lelah_balik"], PD["slbuf"], PD["swp"]], float)
    EV = []
    for s, x in per.items():
        t, o, h, l, c, v = x["t"], x["o"], x["h"], x["l"], x["c"], x["v"]
        k = konteks(x)
        a1 = A.atr(h, l, c)
        j4 = A.map_closed(k["T4"], 4, t, 1)
        jD = A.map_closed(k["TD"], 24, t, 1)
        a4_1 = np.where(j4 >= 0, k["a4"][np.maximum(j4, 0)], np.nan)
        aD_1 = np.where(jD >= 0, k["aD"][np.maximum(jD, 0)], np.nan)
        s4_1 = np.where(j4 >= 0, k["s4"][np.maximum(j4, 0)], 0)
        sD_1 = np.where(jD >= 0, k["sD"][np.maximum(jD, 0)], 0)
        c72 = np.r_[np.full(72, np.nan), c[:-72]]
        lelah1 = np.nan_to_num((c - c72) / np.maximum(aD_1, 1e-12))
        gi = np.searchsorted(G, t)
        gi = np.minimum(gi, len(G) - 1)
        simpan = dict(t=t, o=o, h=h, l=l, c=c, a4=np.nan_to_num(a4_1))
        for tf in ("1h", "4h"):
            if tf == "1h":
                tr = np.where((s4_1 == sD_1), s4_1, 0).astype(np.float64)
                tr4 = s4_1.astype(np.float64)
                ev = A.deteksi(o, h, l, c, v, a1, A.rsi(c), A.delta_flow(o, h, l, c, v, 3), A.volpct(v), tr, lelah1, P)
                if not len(ev):
                    continue
                ii = ev[:, 0].astype(int)
                k0 = ii + 1
                tb = t[ii]
                atr_tf = a1[ii]
                trx = tr4[ii]
            else:
                if len(k["C4"]) < 300:
                    continue
                T4, O4, H4_, L4, C4, V4 = k["T4"], k["O4"], k["H4"], k["L4"], k["C4"], k["V4"]
                jD4 = A.map_closed(k["TD"], 24, T4, 4)
                sD4 = np.where(jD4 >= 0, k["sD"][np.maximum(jD4, 0)], 0).astype(np.float64)
                aD4 = np.where(jD4 >= 0, k["aD"][np.maximum(jD4, 0)], np.nan)
                c18 = np.r_[np.full(18, np.nan), C4[:-18]]
                lelah4 = np.nan_to_num((C4 - c18) / np.maximum(aD4, 1e-12))
                P4 = P.copy()
                P4[0] = max(6, P[0] / 2)
                P4[6] = max(6, P[6] / 2)
                ev = A.deteksi(O4, H4_, L4, C4, V4, k["a4"], A.rsi(C4), A.delta_flow(O4, H4_, L4, C4, V4, 2), A.volpct(V4), sD4, lelah4, P4)
                if not len(ev):
                    continue
                ii = ev[:, 0].astype(int)
                tb = T4[ii] + 3 * H                    # bar 1 jam terakhir dari candle 4J
                k0 = np.searchsorted(t, T4[ii] + 4 * H)
                atr_tf = k["a4"][ii]
                trx = sD4[ii]
            m = k0 < len(t)
            ev, k0, tb, atr_tf, trx, ii = ev[m], k0[m], tb[m], atr_tf[m], trx[m], ii[m]
            gti = np.searchsorted(G, tb)
            gti = np.minimum(gti, len(G) - 1)
            for r in range(len(ev)):
                EV.append((s, tf, int(k0[r]), int(t[k0[r]]), int(ev[r, 1]), int(ev[r, 2]), float(ev[r, 3]), float(ev[r, 4]),
                           float(ev[r, 5]), float(atr_tf[r]), float(trx[r]), int(btc_s4[gti[r]]), int(btc_sD[gti[r]]),
                           float(btc_vol[gti[r]]), float(btc_fl[gti[r]]), float(br[gti[r]]), float(br24[gti[r]]),
                           float(lelah1[min(k0[r] - 1, len(lelah1) - 1)]), float(o[k0[r]])))
        pickle.dump(simpan, open(f"{OUT}/x_{s}.pkl", "wb"))
    import pandas as pd
    E = pd.DataFrame(EV, columns=["sym", "tf", "k0", "t", "d", "jenis", "sl", "sr", "rsi", "atr", "tr", "b4", "bD", "bvol", "bfl",
                                  "br", "br24", "lelah", "e"])
    E.to_pickle(f"{OUT}/ev_{TAG}.pkl")
    print("event", len(E), E.groupby(["tf", "jenis"]).size().to_dict(), time.time() - t0, flush=True)


if __name__ == "__main__":
    main()

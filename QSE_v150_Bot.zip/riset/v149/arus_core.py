"""QSE v149 ARUS: mesin riset. Fungsi yang sama dipakai bot live (qse_arus.py menyalin bagian indikator dan deteksi).
Semua keputusan di bar i hanya memakai data sampai close bar i. Konteks TF besar hanya dari candle yang sudah tutup."""
import numpy as np
import numba as nb

H = 3600000


# ---------------- indikator ----------------
@nb.njit(cache=True)
def ema(x, n):
    out = np.empty(len(x))
    a = 2.0 / (n + 1)
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = out[i - 1] + a * (x[i] - out[i - 1])
    return out


@nb.njit(cache=True)
def rma(x, n):
    out = np.empty(len(x))
    out[0] = x[0]
    a = 1.0 / n
    for i in range(1, len(x)):
        out[i] = out[i - 1] + a * (x[i] - out[i - 1])
    return out


@nb.njit(cache=True)
def atr(h, l, c, n=14):
    tr = np.empty(len(c))
    tr[0] = h[0] - l[0]
    for i in range(1, len(c)):
        tr[i] = max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
    return rma(tr, n)


@nb.njit(cache=True)
def mcginley(c, n, k=0.6):
    md = np.empty(len(c))
    md[0] = c[0]
    for i in range(1, len(c)):
        q = k * n * (c[i] / md[i - 1]) ** 4
        md[i] = md[i - 1] + (c[i] - md[i - 1]) / max(q, 1.0)
    return md


@nb.njit(cache=True)
def rsi(c, n=14):
    up = np.zeros(len(c))
    dn = np.zeros(len(c))
    for i in range(1, len(c)):
        d = c[i] - c[i - 1]
        if d > 0:
            up[i] = d
        else:
            dn[i] = -d
    u, w = rma(up, n), rma(dn, n)
    out = np.empty(len(c))
    for i in range(len(c)):
        out[i] = 100.0 - 100.0 / (1.0 + u[i] / max(w[i], 1e-12))
    return out


@nb.njit(cache=True)
def volpct(v, n=50):
    out = np.zeros(len(v))
    for i in range(n, len(v)):
        k = 0
        for j in range(i - n, i):
            if v[j] <= v[i]:
                k += 1
        out[i] = k * 100.0 / n
    return out


@nb.njit(cache=True)
def delta_flow(o, h, l, c, v, n=6):
    """Order flow dari candle (bisa dihitung sama persis dari kline Bybit): volume x letak close di range.
    +1 = semua volume beli agresif, -1 = jual. Dirata n candle."""
    d = np.empty(len(c))
    for i in range(len(c)):
        r = h[i] - l[i]
        d[i] = v[i] * (((c[i] - l[i]) - (h[i] - c[i])) / r) if r > 0 else 0.0
    out = np.zeros(len(c))
    sd, sv = 0.0, 0.0
    for i in range(len(c)):
        sd += d[i]
        sv += v[i]
        if i >= n:
            sd -= d[i - n]
            sv -= v[i - n]
        out[i] = sd / sv if sv > 0 else 0.0
    return out


def resample(t, o, h, l, c, v, k):
    """Gabung candle 1 jam jadi k jam (rata UTC). Bucket tidak lengkap dibuang."""
    b = t // (k * H)
    idx = np.flatnonzero(np.r_[True, b[1:] != b[:-1]])
    cnt = np.diff(np.r_[idx, len(t)])
    O = o[idx]
    Hh = np.maximum.reduceat(h, idx)
    L = np.minimum.reduceat(l, idx)
    C = c[np.r_[idx[1:] - 1, len(t) - 1]]
    V = np.add.reduceat(v, idx)
    T = b[idx] * k * H
    m = cnt == k
    return T[m], O[m], Hh[m], L[m], C[m], V[m]


def map_closed(T_hi, k_hi, t_lo, k_lo):
    """Untuk tiap bar kecil (mulai t_lo, panjang k_lo jam): indeks candle besar terakhir yang SUDAH tutup saat bar kecil tutup."""
    return np.searchsorted(T_hi + k_hi * H, t_lo + k_lo * H, side="right") - 1


def trend_state(c, md, e):
    """+1 naik, -1 turun, 0 sideways. Naik: close di atas McGinley yang menanjak dan di atas EMA."""
    s = np.zeros(len(c), np.int8)
    up = (c > md) & (np.r_[0, np.diff(md)] > 0) & (c > e)
    dn = (c < md) & (np.r_[0, np.diff(md)] < 0) & (c < e)
    s[up] = 1
    s[dn] = -1
    return s



@nb.njit(cache=True)
def mn(x, a, b):
    m = np.inf
    for j in range(max(a, 0), b):
        if x[j] < m:
            m = x[j]
    return m


@nb.njit(cache=True)
def mx(x, a, b):
    m = -np.inf
    for j in range(max(a, 0), b):
        if x[j] > m:
            m = x[j]
    return m

# ---------------- deteksi setup ----------------
# jenis: 1 FIB pantulan koreksi, 2 SWEEP likuiditas searah tren, 3 FVG searah tren, 4 BREAK konsolidasi searah tren,
#        5 BALIK di titik lelah (sweep + tolak harga melawan gerak panjang)
NAMA = {1: "FIB", 2: "SWEEP", 3: "FVG", 4: "BREAK", 5: "BALIK"}


@nb.njit(cache=True)
def deteksi(o, h, l, c, v, a, rs, fl, vp, tr, lelah, P):
    """tr: arah tren TF besar per bar (+1/-1/0). lelah: gerak 3 hari terakhir dalam ATR harian (bertanda).
    P: parameter (array). Return array event [i, d, jenis, sl, tp_sr, zona]."""
    n = len(c)
    sw = int(P[0])          # jendela swing
    fmin, fmax = P[1], P[2]  # zona fib
    lelah_max = P[3]        # tren searah dilarang kalau sudah lari lebih dari ini (ATR harian)
    lelah_balik = P[4]      # BALIK hanya kalau sudah lari minimal ini
    slbuf = P[5]
    swp = int(P[6])         # jendela level sweep
    out = np.zeros((n // 2 + 10, 6))
    k = 0
    for i in range(max(sw, swp) + 3, n):
        if a[i] <= 0:
            continue
        rng = h[i] - l[i]
        if rng <= 0:
            continue
        for d in (1, -1):
            jenis = 0
            sl = 0.0
            searah = tr[i] == d
            # BALIK: sweep ekstrem 72 bar melawan gerak panjang, harga ditolak
            if lelah[i] * (-d) >= lelah_balik:
                if d == 1:
                    lo72 = mn(l, i - 72, i) if i >= 72 else mn(l, 0, i)
                    if l[i] < lo72 and c[i] > lo72 and c[i] > o[i] and (c[i] - l[i]) / rng >= 0.6 and fl[i] > 0:
                        jenis = 5
                        sl = l[i] - slbuf * a[i]
                else:
                    hi72 = mx(h, i - 72, i) if i >= 72 else mx(h, 0, i)
                    if h[i] > hi72 and c[i] < hi72 and c[i] < o[i] and (h[i] - c[i]) / rng >= 0.6 and fl[i] < 0:
                        jenis = 5
                        sl = h[i] + slbuf * a[i]
            if jenis == 0 and searah and lelah[i] * d < lelah_max:
                # 2 SWEEP: tembus low/high swp bar lalu close kembali ke dalam, candle searah
                if d == 1:
                    lv = mn(l, i - swp, i)
                    if l[i] < lv and c[i] > lv and c[i] > o[i] and (c[i] - l[i]) / rng >= 0.55:
                        jenis = 2
                        sl = l[i] - slbuf * a[i]
                else:
                    lv = mx(h, i - swp, i)
                    if h[i] > lv and c[i] < lv and c[i] < o[i] and (h[i] - c[i]) / rng >= 0.55:
                        jenis = 2
                        sl = h[i] + slbuf * a[i]
                # 1 FIB: impuls searah lalu koreksi ke zona fmin..fmax, candle tolak
                if jenis == 0:
                    if d == 1:
                        jh = i - sw
                        for j in range(i - sw, i - 2):
                            if h[j] >= h[jh]:
                                jh = j
                        jl = max(jh - sw, 0)
                        for j in range(max(jh - sw, 0), jh):
                            if l[j] <= l[jl]:
                                jl = j
                        HI, LO = h[jh], l[jl]
                        if HI - LO > 3 * a[i] and mx(h, jh + 1, i) <= HI:
                            fr = (HI - l[i]) / (HI - LO)
                            if fmin <= fr <= fmax and c[i] > o[i] and (c[i] - l[i]) / rng >= 0.5 and fl[i] > 0:
                                jenis = 1
                                sl = min(l[i], HI - fmax * (HI - LO)) - slbuf * a[i]
                    else:
                        jl = i - sw
                        for j in range(i - sw, i - 2):
                            if l[j] <= l[jl]:
                                jl = j
                        jh = max(jl - sw, 0)
                        for j in range(max(jl - sw, 0), jl):
                            if h[j] >= h[jh]:
                                jh = j
                        HI, LO = h[jh], l[jl]
                        if HI - LO > 3 * a[i] and mn(l, jl + 1, i) >= LO:
                            fr = (h[i] - LO) / (HI - LO)
                            if fmin <= fr <= fmax and c[i] < o[i] and (h[i] - c[i]) / rng >= 0.5 and fl[i] < 0:
                                jenis = 1
                                sl = max(h[i], LO + fmax * (HI - LO)) + slbuf * a[i]
                # 3 FVG searah: gap 20 bar terakhir belum tertutup, harga masuk gap lalu close searah
                if jenis == 0:
                    for j in range(i - 1, i - 20, -1):
                        if d == 1 and l[j] > h[j - 2] and l[j] - h[j - 2] >= 0.25 * a[i]:
                            top, bot = l[j], h[j - 2]
                            if mn(l, j + 1, i) > top if j + 1 < i else True:
                                if l[i] <= top and c[i] > (top + bot) / 2 and c[i] > o[i] and l[i] > bot - 0.5 * a[i]:
                                    jenis = 3
                                    sl = min(bot, l[i]) - slbuf * a[i]
                            break
                        if d == -1 and h[j] < l[j - 2] and l[j - 2] - h[j] >= 0.25 * a[i]:
                            top, bot = l[j - 2], h[j]
                            if mx(h, j + 1, i) < bot if j + 1 < i else True:
                                if h[i] >= bot and c[i] < (top + bot) / 2 and c[i] < o[i] and h[i] < top + 0.5 * a[i]:
                                    jenis = 3
                                    sl = max(top, h[i]) + slbuf * a[i]
                            break
                # 4 BREAK konsolidasi: 6 bar sempit lalu close tembus searah dengan volume
                if jenis == 0 and vp[i] >= 70:
                    rh = mx(h, i - 6, i)
                    rl = mn(l, i - 6, i)
                    if rh - rl <= 1.5 * a[i]:
                        if d == 1 and c[i] > rh and fl[i] > 0:
                            jenis = 4
                            sl = rl - slbuf * a[i]
                        elif d == -1 and c[i] < rl and fl[i] < 0:
                            jenis = 4
                            sl = rh + slbuf * a[i]
            if jenis == 0:
                continue
            risk = (c[i] - sl) * d
            if risk < 0.4 * a[i] or risk > 4.0 * a[i]:
                continue
            # target S/R terdekat searah (swing 48 bar), dipakai untuk TP realistis
            if d == 1:
                sr = mx(h, i - 48, i + 1) if i >= 48 else mx(h, 0, i + 1)
            else:
                sr = mn(l, i - 48, i + 1) if i >= 48 else mn(l, 0, i + 1)
            out[k, 0] = i
            out[k, 1] = d
            out[k, 2] = jenis
            out[k, 3] = sl
            out[k, 4] = sr
            out[k, 5] = rs[i]
            k += 1
            if k >= len(out):
                return out[:k]
    return out[:k]


# ---------------- simulasi trade ----------------
@nb.njit(cache=True)
def simulasi(t, o, h, l, c, k0, d, sl0, tp1, tp2, porsi1, maks_jam, a4, spike, spike_porsi, stall_jam, stall_mode, biaya, be_off):
    """Path candle 1 jam mulai indeks k0 (open = entry). SL dicek dulu tiap candle.
    tp1: TP pertama (porsi1 posisi), lalu SL ke entry+be_off*risk. tp2: sisa (0 = tidak ada, keluar lewat waktu/spike).
    spike: tiap candle 4J tutup, kalau candle 4J itu bergerak searah >= spike x ATR 4J dan posisi untung, tutup spike_porsi sisa.
    stall: di jam stall_jam kalau belum kena tp1: mode 1 tutup kalau rugi, mode 2 SL ke -0.5R kalau belum rugi 0.5R (tutup kalau sudah),
    mode 3 dinamis: SL ke low/high 3 candle terakhir (struktur) kalau lebih aman dari SL sekarang.
    Return (R, jam keluar, kode, mfe)."""
    e = o[k0]
    risk = (e - sl0) * d
    if risk <= 0:
        return 0.0, k0, -1, 0.0
    sisa = 1.0
    real = 0.0
    sl = sl0
    kena1 = False
    mfe = 0.0
    n = len(c)
    for k in range(k0, n):
        jam = k - k0
        hi, lo = h[k], l[k]
        # SL dulu
        if (lo <= sl) if d == 1 else (hi >= sl):
            real += sisa * (sl - e) * d / risk
            return real - biaya * e / risk, k, (2 if kena1 else 1), mfe
        fav = ((hi - e) if d == 1 else (e - lo)) / risk
        if fav > mfe:
            mfe = fav
        if not kena1 and ((hi >= tp1) if d == 1 else (lo <= tp1)):
            real += porsi1 * (tp1 - e) * d / risk
            sisa -= porsi1
            kena1 = True
            sl = e + d * be_off * risk
            if sisa <= 1e-9:
                return real - biaya * e / risk, k, 3, mfe
            if (lo <= sl) if d == 1 else (hi >= sl):   # candle yang sama balik ke entry: anggap keluar di entry (konservatif)
                real += sisa * (sl - e) * d / risk
                return real - biaya * e / risk, k, 4, mfe
        if kena1 and tp2 > 0 and ((hi >= tp2) if d == 1 else (lo <= tp2)):
            real += sisa * (tp2 - e) * d / risk
            return real - biaya * e / risk, k, 5, mfe
        # candle 4J tutup?
        if spike > 0 and (t[k] + H) % (4 * H) == 0 and k - 3 >= k0:
            c4 = c[k] - o[k - 3]
            if c4 * d >= spike * a4[k] and (c[k] - e) * d > 0:
                tutup = sisa * spike_porsi if not (kena1 and spike_porsi < 1) else sisa
                real += tutup * (c[k] - e) * d / risk
                sisa -= tutup
                if not kena1:
                    kena1 = True
                    sl = e + d * be_off * risk
                if sisa <= 1e-9:
                    return real - biaya * e / risk, k, 6, mfe
        if stall_mode > 0 and jam + 1 == stall_jam and not kena1:
            rnow = (c[k] - e) * d / risk
            if stall_mode == 1 and rnow < 0:
                real += sisa * rnow
                return real - biaya * e / risk, k, 7, mfe
            if stall_mode == 2:
                if rnow <= -0.5:
                    real += sisa * rnow
                    return real - biaya * e / risk, k, 7, mfe
                if (e - 0.5 * risk * d - sl) * d > 0:
                    sl = e - 0.5 * risk * d
            if stall_mode == 3:
                st = mn(l, k - 2, k + 1) if d == 1 else mx(h, k - 2, k + 1)
                if (st - sl) * d > 0 and (c[k] - st) * d > 0:
                    sl = st
        if jam + 1 >= maks_jam:
            real += sisa * (c[k] - e) * d / risk
            return real - biaya * e / risk, k, 8, mfe
    real += sisa * (c[n - 1] - e) * d / risk
    return real - biaya * e / risk, n - 1, 9, mfe


@nb.njit(cache=True)
def simulasi_batch(t, o, h, l, c, a4, k0s, ds, sls, tp1s, tp2s, porsi1, maks_jam, spike, spike_porsi, stall_jam, stall_mode, biaya, be_off):
    n = len(k0s)
    R = np.zeros(n)
    kx = np.zeros(n, np.int64)
    kode = np.zeros(n, np.int64)
    mfe = np.zeros(n)
    for j in range(n):
        r, k, kd, m = simulasi(t, o, h, l, c, k0s[j], ds[j], sls[j], tp1s[j], tp2s[j], porsi1, maks_jam, a4, spike, spike_porsi,
                               stall_jam, stall_mode, biaya, be_off)
        R[j] = r
        kx[j] = k
        kode[j] = kd
        mfe[j] = m
    return R, kx, kode, mfe

import pandas as pd, numpy as np, pickle
E=pd.read_pickle('prep/ev_dasar.pkl')
E=E[E.t>=1546300800000].copy()
for hh in (4,12,24): E[f'f{hh}']=np.nan
for s,g in E.groupby('sym'):
    x=pickle.load(open(f'prep/x_{s}.pkl','rb')); c=x['c']; o=x['o']
    k0=g.k0.values
    for hh in (4,12,24):
        k=np.minimum(k0+hh-1,len(c)-1)
        E.loc[g.index,f'f{hh}']=(c[k]/o[k0]-1)*g.d.values*100
E['risk']=(E.e-E.sl)*E.d/E.e*100
E.to_pickle('prep/fwd.pkl')

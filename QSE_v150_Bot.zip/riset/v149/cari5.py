"""Cari rantai konfirmasi terbaik. Pilih HANYA dari 2021-2023 (IS), lalu cek 2024-2026 (OOS) tanpa diubah."""
import os, sys, itertools, time, pickle
import numpy as np, pandas as pd
import mtf5 as M
E = pd.read_pickle(os.environ.get("MTF_OUT", "ev_mtf.pkl"))
T24 = int(os.environ.get("T_UJI", "1704067200000"))
X = {}
def x_(s):
    if s not in X:
        X[s] = M.muat(s)
    return X[s]

KELUAR = {"A tp1 1R 50%, trailing 2j, macet 6j, maks 24j": dict(tp1_r=1.0, por1=0.5, trail_m=8, macet_h=6, macet_mfe=0.5, maks_h=24, maks_aman_h=72, pakai_sr=True),
          "B tp 1.5R penuh, macet 6j, maks 24j": dict(tp1_r=1.5, por1=1.0, trail_m=0, macet_h=6, macet_mfe=0.5, maks_h=24, maks_aman_h=24, pakai_sr=True),
          "C tp1 0.7R 50%, trailing 4j, macet 4j, maks 12j": dict(tp1_r=0.7, por1=0.5, trail_m=16, macet_h=4, macet_mfe=0.3, maks_h=12, maks_aman_h=48, pakai_sr=True),
          "D tp1 1R 50%, trailing 4j, tanpa macet, maks 24j": dict(tp1_r=1.0, por1=0.5, trail_m=16, macet_h=0, macet_mfe=0, maks_h=24, maks_aman_h=72, pakai_sr=False)}
BIAYA = float(os.environ.get("BIAYA", "0.0015"))


def simulasi(buf, kel):
    R = np.full(len(E), np.nan)
    for s, g in E.groupby("sym"):
        x = x_(s)
        e = x["o"][g.k0.values]
        d = g.d.values
        sl = g.sl0.values - d * buf * g.atr.values
        risk = (e - sl) * d
        ok = (risk > 0) & (risk / e >= 0.002) & (risk / e <= 0.08)
        idx = g.index.values[ok]
        r, kx, am = M.sim_batch(x["t"], x["o"], x["h"], x["l"], x["c"], g.k0.values[ok].astype(np.int64), d[ok].astype(np.int64), sl[ok],
                                risk[ok], np.nan_to_num(g.tgt.values[ok], posinf=0.0, neginf=0.0), kel["tp1_r"], kel["por1"], int(kel["trail_m"] * M.PJ / 4),
                                kel["macet_h"], kel["macet_mfe"], kel["maks_h"], kel["maks_aman_h"], kel["pakai_sr"], BIAYA)
        R[idx] = r
    return R


if __name__ == "__main__":
    t0 = time.time()
    IS = (E.t < T24).values
    RES = {}
    for buf in (0.1, 0.5):
        for nk, kel in KELUAR.items():
            RES[(buf, nk)] = simulasi(buf, kel)
            print("sim", buf, nk, round(time.time() - t0), flush=True)
    pickle.dump(RES, open(f"res_{os.environ.get('MTF_OUT','x')}_{BIAYA}.pkl", "wb"))
    f = E
    KOMPAS = {"-": np.ones(len(f), bool), "4J": f.s4.values > 0, "4J+1D": (f.s4.values > 0) & (f.sD.values > 0),
              "4J+6J+1D": (f.s4.values > 0) & (f.s6.values > 0) & (f.sD.values > 0),
              "4J+1D+BTC4J": (f.s4.values > 0) & (f.sD.values > 0) & (f.b4.values > 0),
              "4J+1D+BTC1D": (f.s4.values > 0) & (f.sD.values > 0) & (f.bD.values > 0)}
    LOK = {"-": np.ones(len(f), bool), "S/R": (f.dsr.values >= -0.3) & (f.dsr.values <= 0.5),
           "fib": (f.fib.values >= 0.382) & (f.fib.values <= 0.786)}
    VOL = {"-": np.ones(len(f), bool), "vol70": f.vp.values >= 70, "vol85": f.vp.values >= 85}
    FL = {"-": np.ones(len(f), bool), "flow": f.fl.values > 0.2}
    LL = {"-": np.ones(len(f), bool), "segar": (f.lelah.values < 2.5) & (f.c4.values < 8)}
    BV = {"-": np.ones(len(f), bool), "btcvol": f.bvol.values > 0}
    tfj = {(tf, j): ((f.tf.values == tf) & (f.jenis.values == j)) for tf in sorted(f.tf.unique()) for j in (1, 2, 3)}
    rows = []
    for (k1, m1), (k2, m2), (k3, m3), (k4, m4), (k5, m5), (k6, m6) in itertools.product(KOMPAS.items(), LOK.items(), VOL.items(), FL.items(),
                                                                                           LL.items(), BV.items()):
        base = m1 & m2 & m3 & m4 & m5 & m6
        for (tf, j), mt in tfj.items():
            mm = base & mt
            if mm.sum() < 300:
                continue
            for key, R in RES.items():
                r = R[mm]
                ok = ~np.isnan(r)
                r = r[ok]
                isv = IS[mm][ok]
                a, b = r[isv], r[~isv]
                if len(a) < 300 or len(b) < 50:
                    continue
                pf = lambda z: z[z > 0].sum() / max(-z[z < 0].sum(), 1e-9)
                rows.append((tf, j, k1, k2, k3, k4, k5, k6, key[0], key[1], len(a), pf(a), a.mean(), (a > 0).mean(), len(b), pf(b), b.mean(), (b > 0).mean()))
    T = pd.DataFrame(rows, columns="tf jenis kompas lokasi vol flow lelah btcvol buf keluar nIS pfIS rIS wrIS nOOS pfOOS rOOS wrOOS".split())
    T.to_pickle(f"grid_{os.environ.get('MTF_OUT','x')}_{BIAYA}.pkl")
    print("kombinasi", len(T), round(time.time() - t0))
    top = T.sort_values("pfIS", ascending=False).head(25)
    pd.set_option("display.width", 250)
    print(top.round(3).to_string())
    print("\nKorelasi peringkat IS lawan OOS (Spearman):", T[["pfIS", "pfOOS"]].corr("spearman").iloc[0, 1].round(3))
    print("Dari 25 teratas IS, berapa yang PF OOS > 1.2:", (top.pfOOS > 1.2).sum(), ", > 1:", (top.pfOOS > 1).sum())

"""Unduh candle 1 jam Binance spot sejak listing untuk 300 koin USDT paling likuid (pengganti Bybit yang diblokir)."""
import os, sys, time, json, urllib.request, numpy as np
from concurrent.futures import ThreadPoolExecutor
D = os.environ.get("QSE_V2_DATA", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"))
os.makedirs(D, exist_ok=True)
B = "https://data-api.binance.vision/api/v3"
def get(u, tries=6):
    for k in range(tries):
        try:
            with urllib.request.urlopen(u, timeout=30) as r:
                return json.loads(r.read())
        except Exception:
            time.sleep(1.5 * (k + 1))
    return None
info = get(B + "/exchangeInfo?permissions=SPOT")
aktif = {s["symbol"] for s in info["symbols"] if s["status"] == "TRADING" and s["quoteAsset"] == "USDT"}
tk = get(B + "/ticker/24hr")
bad = ("UP", "DOWN", "BULL", "BEAR")
stab = {"USDC", "FDUSD", "TUSD", "USDP", "DAI", "EUR", "AEUR", "USDE", "XUSD", "PYUSD", "BFUSD", "USD1", "UST", "BUSD", "EURI", "PAXG", "WBTC", "WBETH", "BNSOL", "RLUSD"}
rows = []
for t in tk:
    s = t["symbol"]
    if s not in aktif: continue
    b = s[:-4]
    if b in stab or any(b.endswith(x) for x in bad) or b.startswith("USD"): continue
    rows.append((float(t["quoteVolume"]), s))
rows.sort(reverse=True)
N = int(sys.argv[1]) if len(sys.argv) > 1 else 300
SY = [s for _, s in rows[:N]]
if "BTCUSDT" not in SY: SY.insert(0, "BTCUSDT")
json.dump(SY, open(os.path.join(D, "_daftar.json"), "w"))
print(len(SY), SY[:12], flush=True)
def dl(s):
    p = f"{D}/{s}.npz"
    if os.path.exists(p): return s, -1
    out, st = [], 0
    while True:
        r = get(f"{B}/klines?symbol={s}&interval=1h&startTime={st}&limit=1000")
        if not r: break
        out += r
        if len(r) < 1000: break
        st = r[-1][0] + 3600000
    if len(out) < 2000: return s, 0
    a = np.array([[float(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[7]), float(x[9])] for x in out[:-1]])
    np.savez_compressed(p, t=a[:, 0].astype(np.int64), o=a[:, 1], h=a[:, 2], l=a[:, 3], c=a[:, 4], v=a[:, 5], tb=a[:, 6] * a[:, 4])
    return s, len(a)
n = 0
with ThreadPoolExecutor(6) as ex:
    for s, k in ex.map(dl, SY):
        n += 1
        if n % 20 == 0: print(n, s, k, flush=True)
print("SELESAI", len([f for f in os.listdir(D) if f.endswith(".npz")]), flush=True)

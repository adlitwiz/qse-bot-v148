"""Uji setup BALIK (lawan kelelahan) dan ARUS (lanjut tren) dari dataset per jam, simulasi keluar dan portofolio."""
import pandas as pd, numpy as np, pickle, sys, json, itertools
import arus_core as A, evalx as V
B = pd.read_pickle('prep/bars.pkl')
H = 3600000
_k = {}
def kidx(s, t):
    x = V.X(s)
    return np.searchsorted(x['t'], t) + 1

def events(mask, d, score):
    E = B[mask].copy()
    E['d'] = d
    E['score'] = score[mask] if hasattr(score, '__len__') else score
    out = []
    for s, g in E.groupby('sym'):
        x = V.X(s)
        k0 = np.searchsorted(x['t'], g.t.values) + 1
        m = k0 < len(x['t'])
        g = g[m].copy(); k0 = k0[m]
        g['k0'] = k0; g['e'] = x['o'][k0]; g['tf'] = '1h'
        out.append(g)
    return pd.concat(out).sort_values(['t', 'score'], ascending=[True, False], kind='stable')

def sim(E, sl_d=0.6, tp1=0.5, porsi1=0.5, tp2=1.5, maks=24, spike=1.0, sp=0.5, stall=0, smode=0, be=0.05):
    E = E.copy()
    aD = E.aDp.values / 100 * E.e.values
    E['sl'] = E.e - E.d * sl_d * aD
    E['sr'] = E.e + E.d * 99 * aD
    return V.sim(E, dict(tp1_r=tp1, sr_f=0, room=0, porsi1=porsi1, tp2_r=tp2, maks_jam=maks, spike=spike, spike_porsi=sp,
                         stall_jam=stall, stall_mode=smode, be_off=be))

"""Nilai sinyal Tembus Trendline SHORT hasil tt_kumpul.py dengan candle 1J setelah sinyal (tanpa melihat masa depan saat memilih).
Order STOP terisi kalau low menembus entry dalam 24 jam, LIMIT kalau high menyentuh entry, MARKET di open candle berikutnya.
Keluar seperti kartu: SL penuh -1R, TP1 tutup separuh lalu SL ke entry, sisa TP2. Maks 10 hari. SL dan TP di candle yang sama = SL.
Biaya 0.15% harga. Lalu bandingkan penyaring: rekam jejak koin di mesin (win+loss, PF) dan FOKUS BTC (qse_btcmap.hitung)."""
import sys, os, pickle, glob
import numpy as np, pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
import qse_btcmap as BM
D, SRC = sys.argv[1], sys.argv[2:]
MODE = os.environ.get("TT_MODE", "sentuh")
rows = sum((pickle.load(open(f, "rb")) for f in SRC), [])
S = pd.DataFrame(rows)
ld = lambda s, iv: pd.read_csv(f"{D}/{s}_{iv}.csv", index_col=0, parse_dates=True)[["open", "high", "low", "close", "volume"]]
H1 = {}
out = []
def P(s): print(s); out.append(s)
b1, b4, bD = ld("BTCUSDT", "60"), ld("BTCUSDT", "240"), ld("BTCUSDT", "D")
hasil = []
for z in S.itertuples():
    if z.sym not in H1:
        H1[z.sym] = ld(z.sym, "60")
    h = H1[z.sym]
    mulai = z.t + pd.Timedelta(hours=4)
    w = h[h.index >= mulai]
    if len(w) < 30:
        hasil.append((np.nan, np.nan, None)); continue
    o, hi, lo, c = (w[k].values for k in ("open", "high", "low", "close"))
    e, sl, t1, t2 = z.entry, z.sl, z.tp1, z.tp2
    isi = None
    if z.order == "MARKET":
        isi, e = 0, o[0]
    else:
        for j in range(min(24, len(w))):
            if MODE == "tutup4j" and "STOP" in z.order:
                # cara di kartu: tunggu candle 4J tutup di bawah entry, lalu masuk MARKET di open candle berikutnya
                if (j + 1) % 4 == 0 and c[j] < e and j + 1 < len(w):
                    isi, e = j + 1, o[j + 1]; break
                continue
            if ("STOP" in z.order and lo[j] <= e) or ("LIMIT" in z.order and hi[j] >= e):
                isi = j; break
    if isi is None:
        hasil.append((np.nan, np.nan, None)); continue
    risk = sl - e
    if risk <= 0:
        hasil.append((np.nan, np.nan, None)); continue
    R, sisa, stop, tp1 = 0.0, 1.0, sl, False
    akhir = min(len(w), isi + 240)
    for j in range(isi, akhir):
        if hi[j] >= stop:
            R += sisa * (e - stop) / risk; sisa = 0; break
        if not tp1 and lo[j] <= t1:
            R += 0.5 * (e - t1) / risk; sisa = 0.5; tp1 = True; stop = e
        if tp1 and lo[j] <= t2:
            R += sisa * (e - t2) / risk; sisa = 0; break
    if sisa > 0:
        R += sisa * (e - c[akhir - 1]) / risk
    R -= 0.0015 * e / risk
    # FOKUS BTC saat sinyal (data yang sudah tutup saja)
    try:
        q = BM.hitung(b1[b1.index < mulai].iloc[-400:], b4[b4.index < mulai].iloc[-300:], bD[bD.index < mulai - pd.Timedelta(hours=20)].iloc[-200:])
        fok = q["fokus"]
    except Exception:
        fok = None
    hasil.append((R, R * risk / e * 100, fok))
S["R"] = [x[0] for x in hasil]; S["pct"] = [x[1] for x in hasil]; S["fokus"] = [x[2] for x in hasil]
S = S.dropna(subset=["R"]).copy()
S["th"] = S.t.dt.year
S["n_koin"] = S.win + S.loss
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def baris(nm, m):
    x = S[m]
    s = f"{nm:44s} n {len(x):4d} WR {np.mean(x.R > 0) * 100:4.1f}% rata {x.R.mean():+.3f}R ({x.pct.mean():+.2f}%) PF {pf(x.R.values):.2f} |"
    for t in (2023, 2024, 2025, 2026):
        y = x[x.th == t].R.values
        s += f" {t} n{len(y)} PF {pf(y):.2f}" if len(y) else f" {t} -"
    P(s)
P(f"Cara masuk: {MODE}"); P(f"Sinyal terisi: {len(S)} dari {S.sym.nunique()} koin, {S.t.min():%Y-%m} sampai {S.t.max():%Y-%m}")
semua = np.ones(len(S), bool)
baris("Semua (aturan jalur sekarang)", semua)
for n0 in (5, 10, 20):
    for p0 in (1.0, 1.3, 1.5):
        baris(f"Rekam jejak koin >= {n0} trade, PF >= {p0}", (S.n_koin >= n0) & (S.pf >= p0))
baris("Rekam jejak koin < 10 trade", S.n_koin < 10)
baris("Rekam jejak >= 10 trade, PF < 1.3", (S.n_koin >= 10) & (S.pf < 1.3))
baris("FOKUS BTC SHORT (searah)", S.fokus == "SHORT")
baris("FOKUS BTC TAHAN", S.fokus == "TAHAN")
baris("FOKUS BTC LONG (lawan)", S.fokus == "LONG")
baris("Searah BTC + jejak >= 10 PF >= 1.3", (S.fokus == "SHORT") & (S.n_koin >= 10) & (S.pf >= 1.3))
baris("Rapor koin A/B", S.rapor.isin(["A", "B"]))
baris("Mutu A", S.mutu == "A")
S.to_pickle(os.path.join(os.path.dirname(SRC[0]), "tt_hasil.pkl"))
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), f"hasil_tt_{MODE}.txt"), "w").write("\n".join(out))

"""Dataset per jam (koin universe top 100 volume bulan lalu): fitur saat close bar i, target return arah naik bar i+1..i+h."""
import pandas as pd, numpy as np, pickle, json, os
import arus_core as A
G=pickle.load(open('prep/glob.pkl','rb'))
qv=G['qv_bulan']; DAY=86400000; H=3600000
uni={m:set(sorted(d,key=lambda s:-d[s])[:100]) for m,d in qv.items()}
syms=[f[2:-4] for f in os.listdir('prep') if f.startswith('x_')]
rows=[]
Gt=G['G']
for s in syms:
    x=pickle.load(open(f'prep/x_{s}.pkl','rb'))
    z=np.load(f'data/{s}.npz'); 
    t,o,h,l,c=x['t'],x['o'],x['h'],x['l'],x['c']
    v=z['v'][np.r_[True,np.diff(z['t'])>0]]
    if len(t)<24*200: continue
    TD,OD,HD,LD,CD,VD=A.resample(t,o,h,l,c,v,24)
    aD=A.atr(HD,LD,CD); jD=A.map_closed(TD,24,t,1); aD1=np.where(jD>=0,aD[np.maximum(jD,0)],np.nan)
    sD=A.trend_state(CD,A.mcginley(CD,14),A.ema(CD,20)); sD1=np.where(jD>=0,sD[np.maximum(jD,0)],0)
    T4,O4,H4,L4,C4,V4=A.resample(t,o,h,l,c,v,4); j4=A.map_closed(T4,4,t,1)
    s4=A.trend_state(C4,A.mcginley(C4,34),A.ema(C4,50)); s41=np.where(j4>=0,s4[np.maximum(j4,0)],0)
    r4=A.rsi(C4); r41=np.where(j4>=0,r4[np.maximum(j4,0)],50)
    a1=A.atr(h,l,c); r1=A.rsi(c); fl=A.delta_flow(o,h,l,c,v,6); vp=A.volpct(v)
    n=len(c)
    def lag(x,k): return np.r_[np.full(k,np.nan),x[:-k]]
    def fwd(k): 
        idx=np.minimum(np.arange(n)+k,n-1); return c[idx]/np.r_[o[1:],np.nan]-1
    hi72=pd.Series(h).rolling(72).max().values; lo72=pd.Series(l).rolling(72).min().values
    hi24p=lag(pd.Series(h).rolling(24).max().values,1); lo24p=lag(pd.Series(l).rolling(24).min().values,1)
    mon=t//DAY//30
    ok=np.array([s in uni.get(m,()) for m in mon]) & (np.arange(n)>24*60) & (t>=1546300800000)
    gi=np.minimum(np.searchsorted(Gt,t),len(Gt)-1)
    d=dict(sym=np.full(n,s), t=t, l72=(c-lag(c,72))/aD1, l24=(c-lag(c,24))/aD1, l6=(c-lag(c,6))/aD1,
           pos72=(c-lo72)/np.maximum(hi72-lo72,1e-12), sw_lo=(l<lo24p)&(c>lo24p), sw_hi=(h>hi24p)&(c<hi24p),
           r1=r1, r4=r41, s4=s41, sD=sD1, fl=fl, vp=vp, atrp=a1/c*100, aDp=aD1/c*100,
           br=G['br'][gi], br24=G['br24'][gi], b4=G['btc_s4'][gi], bD=G['btc_sD'][gi], bvol=G['btc_vol'][gi],
           body=(c-o)/np.maximum(h-l,1e-12), hour=(t//H)%24,
           f4=fwd(4)*100, f12=fwd(12)*100, f24=fwd(24)*100)
    df=pd.DataFrame(d)[ok]
    rows.append(df.dropna(subset=['l72','f24']))
B=pd.concat(rows,ignore_index=True)
for k in B.columns:
    if B[k].dtype==np.float64: B[k]=B[k].astype(np.float32)
B.to_pickle('prep/bars.pkl'); print(len(B))

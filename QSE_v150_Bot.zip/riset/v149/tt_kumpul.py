"""Kumpulkan sinyal Tembus Trendline SHORT (aturan jalur bot: close 4J di bawah EMA 200, saran baru belum tersentuh, bukan TUNGGU)
dengan mesin QSE yang sama dengan bot (candle 1D/1W berjalan dibangun dari 1J yang sudah tutup), dijalankan mundur tiap 3 candle 4J di 30 koin (data Bybit 2022-2026).
Catat rekam jejak koin di pola itu SAAT sinyal muncul (win, loss, net_r, pf dari mesin) supaya gerbang profil bisa diuji tanpa bocor.
Pakai: python tt_kumpul.py DATA_DIR OUT.pkl bagian(0/1) jumlah_bagian(2)"""
import os, sys, time, pickle
os.environ.setdefault("QSE_STATE_DIR", "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/tt/st")
os.makedirs(os.environ["QSE_STATE_DIR"], exist_ok=True)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
import pandas as pd, numpy as np, qse_scan
D, OUT, BAG, NB = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
ld = lambda s, iv: pd.read_csv(f"{D}/{s}_{iv}.csv", index_col=0, parse_dates=True)[["open", "high", "low", "close", "volume"]]
def tick(p):
    s = f"{p:.10f}".rstrip("0"); d = len(s.split(".")[1]) if "." in s else 0
    return 10 ** -max(2, min(8, d))
btc = ld("BTCUSDT", "240")
syms = sorted(f[:-8] for f in os.listdir(D) if f.endswith("_240.csv"))[BAG::NB]
rows, selesai = [], set()
if len(sys.argv) > 5 and os.path.exists(OUT) and os.path.exists(sys.argv[5]):          # lanjut setelah terputus
    rows = pickle.load(open(OUT, "rb"))
    selesai = {x.split()[0] for x in open(sys.argv[5]) if x.strip() and "GAGAL" not in x and x.split()[0].endswith("USDT")}
for s in syms:
    if s in selesai:
        continue
    t0 = time.time()
    h4, h1, dD, dW = ld(s, "240"), ld(s, "60"), ld(s, "D"), ld(s, "W")
    e200 = h4["close"].ewm(span=200, adjust=False).mean()
    tk = tick(h4["close"].iloc[-1]); seen = set()
    for n in range(3000, len(h4) + 1, 3):
        x = h4.iloc[max(0, n - 4999):n]; ts = x.index[-1]
        if x["close"].iloc[-1] >= e200.iloc[n - 1]:
            continue
        try:
            h1c = h1[h1.index < ts + pd.Timedelta(hours=4)]
            # candle 1D dan 1W yang sedang berjalan dibangun dari 1J yang sudah tutup (seperti bot live), supaya tidak melihat masa depan
            d0 = (ts + pd.Timedelta(hours=3)).floor("D"); w0 = d0 - pd.Timedelta(days=d0.weekday())
            agg = lambda z, t0: pd.DataFrame(dict(open=[z.open.iloc[0]], high=[z.high.max()], low=[z.low.min()], close=[z.close.iloc[-1]],
                                                  volume=[z.volume.sum()]), index=[t0])
            dDc = pd.concat([dD[dD.index < d0], agg(h1c[h1c.index >= d0], d0)])
            dWc = pd.concat([dW[dW.index < w0], agg(h1c[h1c.index >= w0], w0)])
            r = qse_scan.process(s, x, h1c, dDc, dWc, btc[btc.index <= ts], tk, "240")
        except Exception as ex:
            print(s, n, "GAGAL", ex, flush=True); continue
        for z in r["saran"]:
            if z["pola"] != "Tembus Trendline" or z["arah"] != "SHORT" or z["order"] == "TUNGGU":
                continue
            if z["sudah_masuk"] or z["tersentuh"] or z["sl_kena"] or z["tp1_kena"]:
                continue
            k = round(z["entry"], 10)
            if k in seen:
                continue
            seen.add(k)
            rows.append(dict(sym=s, t=ts, close=r["close"], order=z["order"], entry=z["entry"], sl=z["sl"], tp1=z["tp1"], tp2=z["tp2"],
                             win=z["win"], loss=z["loss"], net_r=z["net_r"], pf=z["pf"], wr=z["wr"], rapor=r["rapor"], mutu=z["mutu"]))
    print(s, len(rows), f"{time.time() - t0:.0f}s", flush=True)
    pickle.dump(rows, open(OUT, "wb"))
pickle.dump(rows, open(OUT, "wb"))
print("SELESAI", flush=True)

"""Unduh candle 1J Binance spot (data.binance.vision) untuk koin di daftar, simpan waktu, volume, dan Taker Buy Base Volume.
Dipakai untuk order flow delta: (2 x taker buy - volume) / volume. Pakai: python unduh_taker.py OUT daftar.txt"""
import io, os, sys, zipfile, urllib.request
import numpy as np, pandas as pd
from concurrent.futures import ThreadPoolExecutor
OUT, DAFTAR = sys.argv[1], sys.argv[2]
B = "https://data.binance.vision/data/spot/monthly/klines"
bulan = [str(p) for p in pd.period_range("2022-06", "2026-10", freq="M")]
def get(s, m):
    u = f"{B}/{s}/1h/{s}-1h-{m}.zip"
    for _ in range(3):
        try:
            with urllib.request.urlopen(u, timeout=60) as r:
                z = zipfile.ZipFile(io.BytesIO(r.read()))
                d = pd.read_csv(z.open(z.namelist()[0]), header=None, usecols=[0, 5, 9])
                t = d[0].values.astype(np.int64)
                t = np.where(t > 10**14, t // 1000, t)          # 2025+ dalam mikrodetik
                return pd.DataFrame(dict(t=t, v=d[5].values, tb=d[9].values))
        except urllib.error.HTTPError:
            return None
        except Exception:
            pass
    return None
def satu(s):
    f = f"{OUT}/{s}.npz"
    if os.path.exists(f):
        return s, "ada"
    with ThreadPoolExecutor(8) as ex:
        xs = [x for x in ex.map(lambda m: get(s, m), bulan) if x is not None]
    if not xs:
        return s, "kosong"
    D = pd.concat(xs).drop_duplicates("t").sort_values("t")
    np.savez(f, t=D.t.values, v=D.v.values.astype(float), tb=D.tb.values.astype(float))
    return s, len(D)
syms = [x.strip() for x in open(DAFTAR) if x.strip()]
with ThreadPoolExecutor(4) as ex:
    for s, n in ex.map(satu, syms):
        print(s, n, flush=True)

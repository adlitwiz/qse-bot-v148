"""Seberapa besar BTC bergerak setelah tiap jenis berita dibanding jam yang sama di minggu biasa (2021 - Okt 2026, candle 1 jam).
Rasio 1.0 = sama dengan biasa. FOMC, CPI, NFP sebagai pembanding (sudah dipakai robot)."""
import json, numpy as np, pandas as pd
from zoneinfo import ZoneInfo
B = pd.read_csv("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/k5/data/BTCUSDT_60.csv",
                index_col=0, parse_dates=True)
B = B[B.index >= "2020-12-01"]
O, H, L, C = (B[k].values for k in ("open", "high", "low", "close"))
idx = {t: i for i, t in enumerate(B.index)}
NY, CET, UTC = ZoneInfo("America/New_York"), ZoneInfo("Europe/Berlin"), ZoneInfo("UTC")
ev = json.load(open("makro_tanggal.json"))


def waktu(jenis, d):
    y, m, dd = map(int, d.split("-"))
    if jenis == "FOMC":
        return pd.Timestamp(y, m, dd, 14, 0, tz=NY).tz_convert(UTC)
    if jenis in ("CPI", "NFP", "GDP", "PCE"):
        return pd.Timestamp(y, m, dd, 8, 30, tz=NY).tz_convert(UTC)
    if jenis == "ECB":
        return pd.Timestamp(y, m, dd, 13, 45, tz=CET).tz_convert(UTC)
    if jenis == "BOJ":
        return pd.Timestamp(y, m, dd, 2, 30, tz=UTC)


K = []          # (jenis, waktu utc)
for j, L_ in ev.items():
    K += [(j, waktu(j, d)) for d in L_]
sec = json.load(open("../sec/earnings_8k.json"))
for nm, rows in sec.items():
    for fd, acc, items in rows:
        t = pd.Timestamp(acc.replace(".000Z", "")).tz_localize(UTC)
        if t < pd.Timestamp("2021-01-01", tz=UTC) or t > pd.Timestamp("2026-10-11", tz=UTC):
            continue
        sesi = "setelah tutup" if t.hour >= 19 else ("sebelum buka" if t.hour < 14 else "jam bursa")
        K.append((f"EARN {nm}", t))
semua_jam = {t.floor("h") for _, t in K}


def gerak(i0, h):
    i1 = i0 + h - 1
    if i0 < 0 or i1 >= len(C):
        return None
    return abs(np.log(C[i1] / O[i0])) * 100, (H[i0:i1 + 1].max() - L[i0:i1 + 1].min()) / O[i0] * 100


def ukur(t, h):
    t0 = t.floor("h")
    i0 = idx.get(t0)
    if i0 is None:
        return None
    ev_ = gerak(i0, h)
    bl = []
    for w in (-4, -3, -2, -1, 1, 2, 3, 4):
        tb = t0 + pd.Timedelta(weeks=w)
        if any(abs((tb - x).total_seconds()) < 6 * 3600 for x in semua_jam if abs((x - tb).days) <= 1):
            continue
        g = gerak(idx.get(tb, -1), h) if tb in idx else None
        if g:
            bl.append(g)
    if not ev_ or len(bl) < 3:
        return None
    return ev_[0], np.mean([b[0] for b in bl]), ev_[1], np.mean([b[1] for b in bl])


rows = []
for j, t in K:
    for h in (1, 4, 24):
        r = ukur(t, h)
        if r:
            rows.append(dict(jenis=j, t=t, h=h, ev=r[0], bl=r[1], ev_rng=r[2], bl_rng=r[3], tahun=t.year))
D = pd.DataFrame(rows)
D["grup"] = D.jenis.where(~D.jenis.str.startswith("EARN"), D.jenis)
D.to_pickle("reaksi_btc.pkl")
print("jenis           n   | gerak 1 jam: kejadian lawan biasa (rasio) | 4 jam (rasio) | 24 jam (rasio) | rasio 2021-23 / 2024-26 (4 jam) | 4 jam > 2x biasa")
for j in ["FOMC", "CPI", "NFP", "GDP", "PCE", "ECB", "BOJ"] + sorted(x for x in D.jenis.unique() if x.startswith("EARN")):
    s = []
    for h in (1, 4, 24):
        x = D[(D.jenis == j) & (D.h == h)]
        s.append(f"{x.ev.mean():.2f}% lawan {x.bl.mean():.2f}% ({x.ev.mean() / x.bl.mean():.2f})")
    x4 = D[(D.jenis == j) & (D.h == 4)]
    a = x4[x4.tahun <= 2023]; b = x4[x4.tahun >= 2024]
    r_ab = f"{a.ev.mean() / a.bl.mean():.2f} / {b.ev.mean() / b.bl.mean():.2f}"
    besar = np.mean(x4.ev > 2 * x4.bl) * 100
    print(f"{j:14s} {len(x4):3d} | {s[0]} | {s[1]} | {s[2]} | {r_ab} | {besar:.0f}%")

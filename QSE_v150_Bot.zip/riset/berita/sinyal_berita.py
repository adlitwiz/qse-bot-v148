"""Sinyal jalur yang entry dekat berita (3 jam sebelum sampai 1 jam sesudah rilis): hasil per trade dengan aturan sekarang
(k8_0.5: TP 20% di +0.5R lalu SL entry, jam ke-8 SL -0.5R, batas 36 jam) dibanding sinyal lain. Populasi live 2021-2026."""
import os, sys, json, numpy as np, pandas as pd
D = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/k5/strat"
os.chdir(D); sys.path.insert(0, D)
import pf_jeda as J
B, P = J.B, J.P
R = B.R
live = P.live
x = R["k8_0.5"].values
masuk = pd.to_datetime(R.masuk.values, utc=True)
sys.path.insert(0, "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/berita/riset")
os.chdir("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/berita/riset")
import reaksi_btc as RB          # waktu kejadian K
pf = lambda v: v[v > 0].sum() / max(1e-9, -v[v < 0].sum())
print(f"populasi live {live.sum()} sinyal, PF {pf(x[live]):.2f}, WR {np.mean(x[live] > 0) * 100:.1f}%, rata {x[live].mean():+.3f}R")
grup = {}
for j, t in RB.K:
    g = j if not j.startswith("EARN") else ("EARN kripto (COIN, MSTR)" if j in ("EARN COIN", "EARN MSTR") else "EARN big tech + minyak")
    grup.setdefault(g, []).append(t)
mi = masuk.values.astype("datetime64[ns]").astype(np.int64)
for g, ts in grup.items():
    tt = np.array(sorted(pd.DatetimeIndex(ts).values.astype("datetime64[ns]").astype(np.int64)))
    # entry dalam [t-3j, t+1j]
    k = np.searchsorted(tt, mi - 3600 * 10**9 * 1)          # kejadian pertama >= masuk - 1 jam
    dekat = np.zeros(len(mi), bool)
    ok = k < len(tt)
    dekat[ok] = (tt[k[ok]] - mi[ok]) <= 3 * 3600 * 10**9
    m = live & dekat
    a = m & (masuk.year <= 2023); b = m & (masuk.year >= 2024)
    lain = live & ~dekat
    print(f"{g:26s} n {m.sum():4d} | PF {pf(x[m]):.2f} WR {np.mean(x[m] > 0) * 100:4.1f}% rata {x[m].mean():+.3f}R | "
          f"21-23 n {a.sum():3d} PF {pf(x[a]):.2f} | 24-26 n {b.sum():3d} PF {pf(x[b]):.2f} | lain PF {pf(x[lain]):.2f} rata {x[lain].mean():+.3f}")

"""Ambil kejadian unlock cliff dari dataset DefiLlama untuk koin yang ada di populasi sinyal (111 koin).
Ukuran unlock = token cliff dibagi supply yang sudah terbuka sehari sebelumnya (proxy circulating)."""
import json, os, glob, numpy as np, pandas as pd
U = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/berita/unlock"
cg = {x["id"]: x["symbol"].upper() for x in json.load(open(U + "/../cg_list.json"))}
UNIV = set(open("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/berita/riset/univ.txt").read().split())


def sym_bybit(s):
    for c in (f"{s}USDT", f"1000{s}USDT"):
        if c in UNIV:
            return c
    return None


rows, peta = [], {}
for f in sorted(glob.glob(U + "/*.json")):
    if f.endswith("_list.json"):
        continue
    try:
        d = json.load(open(f))
    except Exception:
        continue
    gid = d.get("gecko_id") or (d.get("metadata", {}).get("token", "").split("coingecko:")[-1] if "coingecko:" in d.get("metadata", {}).get("token", "") else None)
    s = cg.get(gid or "")
    sb = sym_bybit(s) if s else None
    if not sb:
        continue
    peta.setdefault(sb, []).append(os.path.basename(f))
    # supply terbuka harian = jumlah semua alokasi
    tot = {}
    for a in d.get("documentedData", {}).get("data", []):
        for p in a.get("data", []):
            tot[p["timestamp"]] = tot.get(p["timestamp"], 0.0) + (p.get("unlocked") or 0.0)
    if not tot:
        continue
    ts = np.array(sorted(tot)); vs = np.array([tot[t] for t in ts])
    for e in d.get("metadata", {}).get("unlockEvents", []):
        cl = e.get("cliffAllocations") or []
        jml = sum(c.get("amount") or 0 for c in cl)
        if jml <= 0:
            continue
        k = np.searchsorted(ts, e["timestamp"] - 86400, side="right") - 1
        if k < 0 or vs[k] <= 0:
            continue
        kat = sorted({c.get("category", "") for c in cl})
        rows.append(dict(sym=sb, proto=os.path.basename(f)[:-5], t=pd.Timestamp(e["timestamp"], unit="s", tz="UTC"), token=jml,
                         pct=jml / vs[k] * 100, kat=",".join(kat), insider=any(c.get("category") == "insiders" for c in cl)))
D = pd.DataFrame(rows).sort_values("t")
D.to_pickle("unlock_kejadian.pkl")
print("protokol cocok:", {k: v for k, v in sorted(peta.items())})
print("koin:", D.sym.nunique(), "kejadian:", len(D))
x = D[(D.t >= "2021-01-01") & (D.t < "2026-10-12")]
for b in (0.5, 1, 2, 5):
    print(f"cliff >= {b}% supply terbuka: {np.sum(x.pct >= b)} kejadian, {x[x.pct >= b].sym.nunique()} koin")
print(x[x.pct >= 2].groupby("sym").size().sort_values(ascending=False).head(30).to_dict())

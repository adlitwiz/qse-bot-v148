"""Uji token unlock 2021 - Okt 2026: (A) harga koin relatif BTC sebelum dan sesudah unlock besar, (B) hasil sinyal jalur
yang entry dekat unlock (aturan keluar sekarang k8_0.5), LONG dan SHORT dipisah, dibanding sinyal lain di koin yang sama."""
import os, sys, numpy as np, pandas as pd
DATA = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/k5/data"
U = pd.read_pickle("unlock_kejadian.pkl")
U = U[(U.t >= "2021-01-01") & (U.t < "2026-10-05")]
day = lambda s: pd.read_csv(f"{DATA}/{s}_D.csv", index_col=0, parse_dates=True)["close"]
btc = np.log(day("BTCUSDT"))
pf = lambda v: v[v > 0].sum() / max(1e-9, -v[v < 0].sum())
print("== A. harga koin relatif BTC (log %), unlock besar lawan rata-rata 7 hari koin itu ==")
for bts in (1, 2, 5):
    E = U[U.pct >= bts].copy()
    E["d"] = E.t.dt.floor("D")
    E = E.drop_duplicates(["sym", "d"])
    hasil = {w: [] for w in ((-14, -7), (-7, 0), (0, 7), (7, 14), (-3, 3))}
    base = []
    per = []
    for s, g in E.groupby("sym"):
        try:
            c = np.log(day(s))
        except Exception:
            continue
        rel = (c - btc).dropna()
        r7 = (rel.shift(-7) - rel).dropna()
        base.append(r7.mean() * 100)
        for _, e in g.iterrows():
            d = e.d.tz_localize(None) if e.d.tzinfo else e.d
            d = pd.Timestamp(d).tz_localize(rel.index.tz) if rel.index.tz is not None else pd.Timestamp(d)
            if d not in rel.index:
                continue
            i = rel.index.get_loc(d)
            for (a, b) in hasil:
                if i + a >= 0 and i + b < len(rel):
                    hasil[(a, b)].append(((rel.iloc[i + b] - rel.iloc[i + a]) * 100, e.t.year))
    print(f"-- cliff >= {bts}% supply terbuka: {len(E)} kejadian, rata 7 hari biasa koin ini {np.mean(base):+.2f}%")
    for w, v in hasil.items():
        x = np.array([a for a, _ in v]); y = np.array([t for _, t in v])
        if len(x):
            print(f"   hari {w[0]:+d} s/d {w[1]:+d}: rata {x.mean():+.2f}% median {np.median(x):+.2f}% turun {np.mean(x < 0) * 100:.0f}% | "
                  f"2021-23 {x[y <= 2023].mean():+.2f}% (n {np.sum(y <= 2023)}) 2024-26 {x[y >= 2024].mean():+.2f}% (n {np.sum(y >= 2024)})")

print("\n== B. sinyal jalur dekat unlock (entry 7 hari sebelum sampai 2 hari sesudah) ==")
D = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/k5/strat"
cwd = os.getcwd(); os.chdir(D); sys.path.insert(0, D)
import pf_jeda as J
os.chdir(cwd)
R = J.B.R; live = J.P.live
x = R["k8_0.5"].values
masuk = pd.to_datetime(R.masuk.values, utc=True)
mi = masuk.values.astype("datetime64[ns]").astype(np.int64)
for bts in (1, 2, 5):
    dekat = np.zeros(len(R), bool)
    E = U[U.pct >= bts]
    for s, g in E.groupby("sym"):
        ts = np.sort(g.t.values.astype("datetime64[ns]").astype(np.int64))
        m = (R.sym.values == s)
        idx = np.where(m)[0]
        k = np.searchsorted(ts, mi[idx] - 2 * 86400 * 10**9)
        ok = k < len(ts)
        hit = np.zeros(len(idx), bool)
        hit[ok] = (ts[k[ok]] - mi[idx][ok]) <= 7 * 86400 * 10**9
        dekat[idx] = hit
    koin = R.sym.isin(set(E.sym)).values
    for arah, nm in ((1, "LONG"), (-1, "SHORT")):
        a = live & dekat & (R.arah.values == arah)
        b = live & ~dekat & koin & (R.arah.values == arah)
        a1 = a & (masuk.year <= 2023); a2 = a & (masuk.year >= 2024)
        b1 = b & (masuk.year <= 2023); b2 = b & (masuk.year >= 2024)
        print(f"cliff >= {bts}% {nm:5s} dekat unlock n {a.sum():4d} PF {pf(x[a]):.2f} rata {x[a].mean():+.3f}R WR {np.mean(x[a] > 0) * 100:.0f}% "
              f"[21-23 {pf(x[a1]):.2f} n{a1.sum()} | 24-26 {pf(x[a2]):.2f} n{a2.sum()}]  lain di koin sama n {b.sum():4d} PF {pf(x[b]):.2f} "
              f"[{pf(x[b1]):.2f} | {pf(x[b2]):.2f}]")

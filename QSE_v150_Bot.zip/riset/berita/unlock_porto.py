"""Dampak aturan unlock ke simulasi satu orang (aturan final: jam 8, 36 jam, 5+2 slot, jeda 3 kalah 24 jam)."""
import os, sys, numpy as np, pandas as pd
U = pd.read_pickle("unlock_kejadian.pkl")
U = U[(U.t >= "2020-12-01") & (U.t < "2026-10-20") & (U.pct >= 1)]
D = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/k5/strat"
cwd = os.getcwd(); os.chdir(D); sys.path.insert(0, D)
import pf_jeda as J
os.chdir(cwd)
B, P = J.B, J.P
R = B.R; live = P.live
masuk = pd.to_datetime(R.masuk.values, utc=True)
mi = masuk.values.astype("datetime64[ns]").astype(np.int64)
NS = 86400 * 10**9
tahan = np.zeros(len(R), bool)
for s, g in U.groupby("sym"):
    ts = np.sort(g.t.values.astype("datetime64[ns]").astype(np.int64))
    idx = np.where((R.sym.values == s) & (R.arah.values == 1))[0]
    k = np.searchsorted(ts, mi[idx], side="right")
    ok = k < len(ts)
    hit = np.zeros(len(idx), bool)
    hit[ok] = (ts[k[ok]] - mi[idx][ok]) <= 7 * NS
    tahan[idx] = hit
jd = dict(k=3, jenis="kalah", lanjut="jam", jam=24)
for nm, m in (("final sekarang", live), ("+ tahan LONG unlock", live & ~tahan)):
    a = B.porto2("k8_0.5", 5, 2, m, jeda=jd)
    print(B.metrik("k8_0.5", a, nm, tahun=True), flush=True)
print("sinyal live yang ditahan:", (live & tahan).sum())

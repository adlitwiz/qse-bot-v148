"""Aturan yang bisa dipasang: unlock cliff >= X% supply terbuka dalam N hari SETELAH entry (belum terjadi saat sinyal)."""
import os, sys, numpy as np, pandas as pd
U = pd.read_pickle("unlock_kejadian.pkl")
U = U[(U.t >= "2020-12-01") & (U.t < "2026-10-20")]
D = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/k5/strat"
cwd = os.getcwd(); os.chdir(D); sys.path.insert(0, D)
import pf_jeda as J
os.chdir(cwd)
R = J.B.R; live = J.P.live
x = R["k8_0.5"].values
masuk = pd.to_datetime(R.masuk.values, utc=True)
mi = masuk.values.astype("datetime64[ns]").astype(np.int64)
pf = lambda v: v[v > 0].sum() / max(1e-9, -v[v < 0].sum())
NS = 86400 * 10**9
for bts in (0.5, 1, 2):
    for hari in (3, 7, 14):
        dekat = np.zeros(len(R), bool)
        E = U[U.pct >= bts]
        for s, g in E.groupby("sym"):
            ts = np.sort(g.t.values.astype("datetime64[ns]").astype(np.int64))
            idx = np.where(R.sym.values == s)[0]
            k = np.searchsorted(ts, mi[idx], side="right")          # unlock pertama sesudah entry
            ok = k < len(ts)
            hit = np.zeros(len(idx), bool)
            hit[ok] = (ts[k[ok]] - mi[idx][ok]) <= hari * NS
            dekat[idx] = hit
        koin = R.sym.isin(set(E.sym)).values
        out = []
        for arah, nm in ((1, "LONG"), (-1, "SHORT")):
            a = live & dekat & (R.arah.values == arah)
            b = live & ~dekat & koin & (R.arah.values == arah)
            a1 = a & (masuk.year <= 2023); a2 = a & (masuk.year >= 2024)
            b1 = b & (masuk.year <= 2023); b2 = b & (masuk.year >= 2024)
            out.append(f"{nm} n{a.sum():3d} PF {pf(x[a]):.2f} [{pf(x[a1]):.2f} n{a1.sum()} | {pf(x[a2]):.2f} n{a2.sum()}] sum {x[a].sum():+.1f}R "
                       f"(lain {pf(x[b1]):.2f}|{pf(x[b2]):.2f})")
        print(f">= {bts}% dalam {hari:2d} hari | " + " || ".join(out))

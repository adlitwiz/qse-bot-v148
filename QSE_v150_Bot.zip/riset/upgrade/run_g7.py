"""Grup 7: model penilai sinyal (meta-label). Target: trade dasar untung (R > 0).
Dua lipatan waktu: latih 2021-23 uji 2024-26, dan latih 2024-26 uji 2021-23. Prediksi tiap periode selalu dari model yang
tidak pernah melihat periode itu. Saringan: buang q% sinyal dengan peluang terendah (batas dari sebaran prediksi, tanpa label).
Aturan lolos sama (P): dua periode, dua populasi."""
import json, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score
import var_lib as V
import core as Cx
S = V.S
base = V.run()
Rb = base["R"]
BM = {pop: V.port(base, pop)[0] for pop in V.POP}
out = []
def P(s=""):
    print(s, flush=True); out.append(s)

def fitur(S):
    X = pd.DataFrame(index=S.index)
    X["jalur"] = S.jalur.astype("category").cat.codes
    X["arah"] = S.arah.values
    for k in ("vp", "drop6", "pump6", "drop12", "pump12", "body", "dist_sup", "dist_res", "dist_lo50", "dist_hi50", "rank", "combo", "mp", "mm"):
        X[k] = S[k].astype(float).clip(-20, 20) if k.startswith(("dist", "drop", "pump", "body")) else S[k].astype(float)
    for k in ("vol_tinggi", "raja", "fix", "emas", "p921", "inside", "pump"):
        X[k] = S[k].astype(float)
    X["pullback"] = S.pullback.map({True: 1.0, False: 0.0}).fillna(-1.0)
    X["atr_pct"] = S.atr / S.px * 100
    lo, hi = S.px - S.dist_lo50 * S.atr, S.px + S.dist_hi50 * S.atr
    X["pos50"] = ((S.px - lo) / (hi - lo).where(hi > lo)).clip(-1, 2)
    X["jam"] = S.masuk_h % 24
    X["hari"] = (S.masuk_h // 24 + 3) % 7
    # BTC 24 jam dan 7 hari sebelum masuk
    a, n = Cx.OFF["BTCUSDT"]
    bt = Cx.TS[a:a + n]
    bc = Cx.C[a:a + n]
    j = np.clip(np.searchsorted(bt, S.masuk_h.values * 3600000) - 1, 168, n - 1)
    X["btc24"] = (bc[j] / bc[j - 24] - 1) * 100
    X["btc168"] = (bc[j] / bc[j - 168] - 1) * 100
    # koin sendiri lawan BTC 7 hari
    k0 = S.k0.values
    X["koin168"] = (Cx.C[k0 - 1] / Cx.C[np.maximum(k0 - 169, 0)] - 1) * 100 - X["btc168"].values
    return X

X = fitur(S)
y = (Rb > 0).astype(int)
PA, PB = V.PA, V.PB
pr = np.zeros(len(S))
for tr_, te_, nm in ((PA, PB, "latih 2021-23 -> uji 2024-26"), (PB, PA, "latih 2024-26 -> uji 2021-23")):
    m = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=200, min_samples_leaf=200,
                                       l2_regularization=1.0, categorical_features=[0], random_state=0)
    m.fit(X[tr_], y[tr_])
    pr[te_] = m.predict_proba(X[te_])[:, 1]
    P(f"{nm}: AUC {roc_auc_score(y[te_], pr[te_]):.3f}")
for per, mk in (("2021-23", PA), ("2024-26", PB)):
    q = pd.qcut(pr[mk], 5, labels=False, duplicates="drop")
    r = Rb[mk]
    P(f"  {per} rata R per kelompok peluang (rendah ke tinggi): " + "  ".join(f"{r[q == i].mean():+.3f}" for i in range(5))
      + "  | WR " + " ".join(f"{np.mean(r[q == i] > 0) * 100:.0f}" for i in range(5)))
np.save(f"{Cx.SC}/pr_g7.npy", pr)
P()
for qq in (0.1, 0.2, 0.3, 0.4, 0.5):
    buang = np.zeros(len(S), bool)
    for mk in (PA, PB):
        buang[mk] = pr[mk] < np.quantile(pr[mk], qq)
    s = ""
    for pop in V.PRIMER:
        mm, _ = V.port(base, pop, pilih=~buang)
        s += (f"\n    [{pop}] WR {mm['wr']:4.1f} ({BM[pop]['wr']:4.1f}) PF {mm['pf']:.2f} ({BM[pop]['pf']:.2f}) tot {mm['total']:+4.0f} ({BM[pop]['total']:+4.0f}) "
              f"DD {mm['dd']:3.0f} ({BM[pop]['dd']:3.0f}) | 21-23 WR {mm['wr_a']:4.1f}/{BM[pop]['wr_a']:4.1f} PF {mm['pf_a']:.2f}/{BM[pop]['pf_a']:.2f} tot {mm['tot_a']:+4.0f}/{BM[pop]['tot_a']:+4.0f}"
              f" | 24-26 WR {mm['wr_b']:4.1f}/{BM[pop]['wr_b']:4.1f} PF {mm['pf_b']:.2f}/{BM[pop]['pf_b']:.2f} tot {mm['tot_b']:+4.0f}/{BM[pop]['tot_b']:+4.0f}"
              f" lolosP {V.lolos(mm, BM[pop], 'P')} lolosW {V.lolos(mm, BM[pop], 'W')}")
    P(f"buang {int(qq * 100)}% peluang terendah{s}")
open(f"{Cx.SC}/hasil_g7.txt", "w").write("\n".join(out))

"""Grup 13b: jam ke-8 dinamis (jam pengecekan dari volatilitas 1 jam saat entry), kombinasi umur 24 jam, memori per koin
dari catatan semua sinyal (bukan hanya yang diambil). Pembanding dan aturan lolos sama dengan run_g13."""
import numpy as np, pandas as pd
src = open("run_g13.py").read().split("LV = jalan(base)")[0].replace("cache=True", "cache=False")
ns = {"__name__": "g13b"}
exec(src, ns)
for k in ("S", "run", "jalan", "fmt", "porto", "mt", "base", "uji", "otak", "masuk", "thn", "V", "Cx", "P", "out"):
    globals()[k] = ns[k]
out.clear()
LV = jalan(base)
P(fmt("LIVE sekarang", LV, LV))
k0 = S.k0.values
tr = np.zeros(len(S))
for q in range(1, 15):
    a = k0 - q
    tr += np.maximum(Cx.H[a] - Cx.L[a], np.maximum(abs(Cx.H[a] - Cx.C[a - 1]), abs(Cx.L[a] - Cx.C[a - 1])))
atr1 = tr / 14
qq = S.risk.values / atr1
P(f"risk / ATR 1 jam: median {np.median(qq):.2f}, p10 {np.quantile(qq, .1):.2f}, p90 {np.quantile(qq, .9):.2f}")
VAR = []
for tgt, lo, hi in ((8, 6, 12), (10, 6, 16), (12, 8, 16), (12, 8, 20)):
    c = tgt / np.median(qq ** 2)
    jk = np.clip(np.round(c * qq ** 2), lo, hi).astype(int)
    VAR.append((f"jam dinamis median {tgt} ({lo}-{hi} jam)", dict(jk=jk)))
    VAR.append((f"jam dinamis median {tgt} ({lo}-{hi}) + umur 24 jam", dict(jk=jk, jstop=24)))
VAR += [("jam 12 + umur 24 jam", dict(jk=12, jstop=24)), ("jam 12 hanya melawan", dict(jk=12, jmode=4)),
        ("jam 10", dict(jk=10)), ("jam 16", dict(jk=16)), ("jam 12 SL -0.6R", dict(jk=12, jsl=-0.6, jthr=-0.6))]
HS = {}
for nm, kw in VAR:
    r = run(**kw); HS[nm] = r
    P(fmt(nm, jalan(r), LV))
# memori per koin dari catatan semua sinyal (bayangan): rata R sinyal koin itu yang sudah selesai sebelum masuk
kel = masuk + base["hrs"]
sid = pd.factorize(S.sym.values)[0]
o = np.argsort(kel, kind="stable")
def mem_mask(nlast, nmin, batas, res=base):
    kel_ = masuk + res["hrs"]
    ok = np.ones(len(S), bool)
    for s in np.unique(sid):
        idx = np.nonzero(sid == s)[0]
        ko = idx[np.argsort(kel_[idx], kind="stable")]
        kk, rr = kel_[ko], res["R"][ko]
        for i in idx:
            j = np.searchsorted(kk, masuk[i], side="right")
            h = rr[max(0, j - nlast):j]
            if len(h) >= nmin and h.mean() < batas:
                ok[i] = False
    return ok
for mem in ((10, 5, -0.2), (10, 5, -0.1), (20, 8, -0.1), (20, 10, 0.0)):
    mk = mem_mask(*mem)
    P(f"-- memori {mem}: dibuang {(~mk & uji & otak).sum()} sinyal, rata R {base['R'][~mk & uji & otak].mean():+.3f}")
    P(fmt(f"memori per koin (bayangan) {mem}", jalan(base, mk), LV))
open(f"{Cx.SC}/hasil_g13b.txt", "w").write("\n".join(out))

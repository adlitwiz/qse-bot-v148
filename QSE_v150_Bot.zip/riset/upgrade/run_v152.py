"""v152 (permintaan 3 Nov 22:09): slot aman dinamis + 4 mesin sinyal mandiri.
Asal: uji 6 perubahan permintaan user 3 Nov 2026 (11:04 dan 11:06). Data Binance 383 koin 1J, universe 150 likuid, satu orang.
Semua keputusan pakai data sebelum sinyal. Ambang dipilih di 2023-2024, dinilai di 2025-2026. Biaya 0.15% harga.
1. Rem 7 hari jadi mode: saat rem, hanya NILAI 10 (skor 90) dan/atau setengah risiko, bukan tahan total.
   Gerbang profil dilonggarkan (gabungan semua jalur arah sama, min 5). LONG akhir pekan boleh kalau volume 24 jam >= 2x rata 30 hari.
2. TPawal 40-50% di +0.5R, SL ke -0.25R, SL ke entry di +0.8R. Posisi aman tidak dihitung dalam batas 4 (runner).
3. Sapuan likuiditas 1 dan 2 candle 4J + volume >= 2x, di support kuat (disentuh >= 2x) atau divergensi RSI.
   Derivatif BTC (Binance Futures): BTC turun + OI turun + funding sangat minus -> SHORT ditahan (cermin untuk LONG).
4. Masuk koreksi: tunggu koreksi di 1J, Conditional Stop di atas high candle pantulan, SL di ujung ekor pantulan, TP dihitung ulang.
5. Laporan: per bulan 2025-2026, sinyal per minggu, WR, PF, DD, v149 lawan gabungan perubahan yang lolos."""
import os, numpy as np, pandas as pd
from numba import njit
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "v150"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
import core as Cx
DERIV = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/deriv"
CSV = os.path.join(Cx.SC, "data")
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
H_, L_, C_, O_, TS = Cx.H, Cx.L, Cx.C, Cx.O, Cx.TS
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
ar = S.arah.values; jl = S.jalur.values; masuk = S.masuk_h.values; k0 = S.k0.values
dow = pd.to_datetime(S["T"].values, unit="ms", utc=True).dayofweek.values
wkL = (ar == 1) & (dow >= 5)
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
dasar_mask = ok & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
m8 = dasar_mask & izin & ~wkL                         # v149 seperti bot live (akhir pekan LONG ditahan)
lat = thn <= 2024; tes = thn >= 2025
minggu = lambda T: max((T[:, 0].max() - T[:, 0].min()) / 168, 1) if len(T) else 1
def nilai(nm, T, ringkas=True):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]; th_ = thn[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    t2 = T[th_ >= 2025]; r2 = t2[:, 2]
    P(f"   {nm:56s} n {len(r):5d} {len(r) / minggu(T):4.1f}/mgg WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} tot {r.sum():+5.0f}R DD {dd(r[o_]):3.0f}R | "
      f"PF<1 {int((pm < 1).sum()):2d}/{len(pm)} terburuk {tm.min():+5.1f} | 23-24 PF {pf(r[th_ <= 2024]):.2f} | 25-26 n/mgg {len(r2) / minggu(t2):4.1f} "
      f"WR {np.mean(r2 > 0) * 100 if len(r2) else 0:4.1f}% PF {pf(r2):.2f} DD {dd(r2[np.argsort(t2[:, 1], kind='stable')]):3.0f}R")
    return T
# rem 7 hari dari trade kertas semua sinyal m8 yang sudah selesai
def rem_flag(res, pilih, batas=-3.0):
    R = res["R"]; kel = masuk + res["hrs"]; idx = np.nonzero(pilih)[0]
    o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
    f = np.zeros(len(S), bool)
    j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
    f[idx] = (cs[j] - cs[j0]) < batas
    return f
def skala(T, mask_half):
    T = T.copy(); h = mask_half[T[:, 3].astype(int)]; T[h, 2] *= 0.5; return T
P("== DASAR ==")
rem = rem_flag(baru, m8)
B0 = nilai("v149 tanpa rem 7 hari", jalankan(baru, m8, 4, 0))
B1 = nilai("v149 + rem 7 hari TOTAL (terpasang)", jalankan(baru, m8 & ~rem, 4, 0))


P("\nMetrik: per minggu, WR, expectancy, total, DD, total/DD. Latih 2023-2024, uji 2025-2026. Lulus: uji expectancy >= +0.15R, n >= 100.")
@njit(cache=False)
def sim3(Hh, L, C, k0, n, d, e, risk, atrt, tp_r, trail, tps_lv, por, sl_aft, be_lv, jk, jstop):
    sl = e - d * risk; best = e; sisa = 1.0; real = 0.0; aman = -1; tpsd = False
    lvp = e + d * tps_lv * risk; lvb = e + d * be_lv * risk
    has_tp = tp_r > 0; tp = e + d * tp_r * risk
    for j in range(n):
        hi = Hh[k0 + j]; lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if not tpsd and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += por * tps_lv; sisa = 1.0 - por; tpsd = True
            nsl = e + d * sl_aft * risk
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if tpsd and aman < 0 and ((d == 1 and hi >= lvb) or (d == -1 and lo <= lvb)):
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1
        if tpsd and aman < 0 and sl_aft >= 0:
            aman = j + 1
        if has_tp and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        if d == 1:
            if hi > best: best = hi
        else:
            if lo < best: best = lo
        if j % 4 == 3 and trail > 0:
            nsl = best - d * trail * atrt
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if not tpsd and j + 1 == jk:
            rn = (C[k0 + j] - e) * d / risk
            if rn <= -0.5:
                return real + sisa * rn, j + 1, aman
            if rn < 0:
                nsl = e - d * 0.5 * risk
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
        if not tpsd and j + 1 == jstop:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman
def jalan3(tps_lv, por, sl_aft, be_lv, k0a=None, ea=None, riska=None, nmaxa=None, pilih=None):
    pilih = m8 if pilih is None else pilih
    Rn = np.full(len(S), np.nan); hn = np.zeros(len(S), np.int64); an = np.full(len(S), -1, np.int64)
    k0a = k0 if k0a is None else k0a; nmaxa = S.nmax.values if nmaxa is None else nmaxa
    for i in np.nonzero(pilih)[0]:
        if k0a[i] < 0:
            continue
        e = O_[k0a[i]] if ea is None else ea[i]; rk = S.risk.values[i] if riska is None else riska[i]
        r, h, a = sim3(H_, L_, C_, k0a[i], nmaxa[i], ar[i], e, rk, S.atrt.values[i], S.tp_r.values[i], S.trail.values[i],
                       tps_lv, por, sl_aft, be_lv, 12, 30)
        Rn[i] = r - Cx.BIAYA * e / rk; hn[i] = h + (k0a[i] - k0[i]); an[i] = a + (k0a[i] - k0[i]) if a >= 0 else -1
    return dict(R=Rn, hrs=hn, aman=an)

R = baru["R"]; sid = pd.factorize(S.sym.values)[0]
def porto2(ev, cap=4, runner=None, jeda=True):
    """ev: DataFrame masuk, keluar, aman, sym, arah, R, (runner boleh). Satu orang, maks cap berisiko + runner aman, jeda 24 jam setelah 3 rugi."""
    ev = ev.sort_values("masuk", kind="stable")
    buka, trades = [], []; beruntun = 0; jeda_dari = None; antri = []
    for z in ev.itertuples():
        t = z.masuk
        if antri:
            antri.sort(); sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and beruntun >= 3:
                        jeda_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        if jeda and jeda_dari is not None:
            if t >= jeda_dari + 24:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b[1] > t]
        if any(b[0] == z.sym for b in buka):
            continue
        rn = int(getattr(z, "runner", 0)) if runner is None else runner
        berisiko = [b for b in buka if b[2] > t]
        if len(berisiko) >= cap or len(buka) >= cap + rn:
            continue
        if sum(1 for b in berisiko if b[3] == z.arah) >= 4:
            continue
        buka.append((z.sym, z.keluar, z.aman, z.arah)); antri.append((z.keluar, z.R)); trades.append((t, z.keluar, z.R, z.bulan))
    return pd.DataFrame(trades, columns=["masuk", "keluar", "R", "bulan"])
def ukur(nm, T, cetak=True):
    T = T.copy(); T["th"] = T.bulan.str[:4].astype(int)
    hasil = {}
    for per, m_ in (("23-24", (T.th >= 2023) & (T.th <= 2024)), ("25-26", T.th >= 2025)):
        x = T[m_].sort_values("keluar"); r = x.R.values; d_ = dd(r)
        mg = max((x.masuk.max() - x.masuk.min()) / 168, 1) if len(x) else 1
        hasil[per] = dict(n=len(r), mg=len(r) / mg, wr=np.mean(r > 0) * 100 if len(r) else 0, exp=r.mean() if len(r) else 0, tot=r.sum(), dd=d_)
    if cetak:
        tm = T[T.th >= 2025].groupby("bulan").R.sum()
        P(f"   {nm:60s} | " + " | ".join(f"{p} {h['mg']:4.1f}/mgg WR {h['wr']:4.1f}% exp {h['exp']:+.3f}R tot {h['tot']:+5.0f}R DD {h['dd']:3.0f}R tot/DD {h['tot'] / max(h['dd'], 1e-9):4.1f}"
                                         for p, h in hasil.items()) + f" | 25-26 bulan rugi {int((tm < 0).sum())}/{len(tm)}")
    return hasil
bulan_of = lambda tms: pd.to_datetime(tms, unit="ms", utc=True).strftime("%Y-%m")
ev_v149 = pd.DataFrame(dict(masuk=masuk[m8], keluar=masuk[m8] + baru["hrs"][m8],
                            aman=np.where(baru["aman"][m8] >= 0, masuk[m8] + np.maximum(baru["aman"][m8], 0), masuk[m8] + baru["hrs"][m8]),
                            sym=sid[m8], arah=ar[m8], R=R[m8], bulan=bln[m8]))
P("\n== 1. SLOT AMAN DINAMIS ==")
ukur("v149 slot 4 (tanpa rem 7 hari, pembanding mesin)", porto2(ev_v149, runner=0))
ukur("v149 slot 4+2 selalu", porto2(ev_v149, runner=2))
# kertas 7 hari dan efisiensi BTC 20 candle 4J saat sinyal
idx = np.nonzero(m8)[0]; kel = masuk + baru["hrs"]
o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
k7 = cs[j] - cs[j0]
b0, bl = Cx.OFF["BTCUSDT"]; bT = TS[b0:b0 + bl]; bC = C_[b0:b0 + bl]
jb = np.searchsorted(bT, TS[k0[idx]]) - 1
erb = np.array([abs(bC[q] - bC[q - 80]) / max(np.abs(np.diff(bC[q - 80:q + 1:4])).sum(), 1e-12) if q >= 80 else 0 for q in jb])
for ambang in (0.1, 0.2, 0.3):
    fl = (k7 > 0) & (erb >= ambang)
    ev = ev_v149.copy(); ev["runner"] = np.where(fl, 2, 0)
    ukur(f"slot +2 hanya saat kertas 7 hari positif & efisiensi BTC >= {ambang}", porto2(ev))
ev = ev_v149.copy(); ev["runner"] = np.where(k7 > 0, 2, 0)
ukur("slot +2 hanya saat kertas 7 hari positif", porto2(ev))

# ---------- data per koin untuk mesin baru ----------
ranks = S.groupby("sym")["rank"].median()
koin = [s for s in Cx.OFF if s in ranks.index and ranks[s] <= 150]
DATA = {}
for s in koin:
    a, n = Cx.OFF[s]
    f = os.path.join(CSV, f"{s}_60.csv")
    if not os.path.exists(f):
        continue
    vv = pd.read_csv(f, usecols=["volume"]).volume.values.astype(float)
    if len(vv) != n:
        continue
    t = TS[a:a + n]; g = t // 14400000; ix = np.r_[0, np.nonzero(np.diff(g))[0] + 1]
    h4 = np.maximum.reduceat(H_[a:a + n], ix); l4 = np.minimum.reduceat(L_[a:a + n], ix)
    c4 = C_[a + np.r_[ix[1:] - 1, n - 1]]; o4 = O_[a + ix]; v4 = np.add.reduceat(vv, ix)
    DATA[s] = dict(a=a, n=n, v=vv, ix=ix, h4=h4, l4=l4, c4=c4, o4=o4, v4=v4, t4=t[ix],
                   at4=pd.Series(h4 - l4).rolling(14).mean().values)
# tren BTC 4J: close di atas EMA 50
bd = DATA.get("BTCUSDT")
btc_e50 = pd.Series(bd["c4"]).ewm(span=50, adjust=False).mean().values
def btc_arah(tms):
    q = np.searchsorted(bd["t4"], np.asarray(tms) - 14400000, "right") - 1          # candle 4J BTC yang sudah TUTUP sebelum waktu tms
    q = np.clip(q, 0, len(bd["c4"]) - 1)
    return np.where(bd["c4"][q] > btc_e50[q], 1, -1)
def nilai_mesin(nm, sig):
    """sig: list (sym, k_global_entry, arah, risk, atrt). Simulasi aturan keluar v149 di 1J. Satu posisi per koin."""
    rows = []; terakhir = {}
    for s, k, d, rk, at in sorted(sig, key=lambda z: z[1]):
        a, n = Cx.OFF[s]
        if k >= a + n - 2 or rk <= 0 or not np.isfinite(at):
            continue
        if terakhir.get(s, -1) >= k:
            continue
        e = O_[k]
        nmax = min(240, a + n - k - 1)
        r, h, am = sim3(H_, L_, C_, k, nmax, d, e, rk, at, 0.0, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
        terakhir[s] = k + h
        mh = TS[k] // 3600000
        rows.append((mh, mh + h, mh + (am if am >= 0 else h), s, d, r - Cx.BIAYA * e / rk, bulan_of([TS[k]])[0]))
    ev = pd.DataFrame(rows, columns=["masuk", "keluar", "aman", "sym", "arah", "R", "bulan"])
    ev["th"] = ev.bulan.str[:4].astype(int)
    la = ev[(ev.th >= 2023) & (ev.th <= 2024)].R.values; te = ev[ev.th >= 2025].R.values
    mg = lambda x: len(x) / max((x.masuk.max() - x.masuk.min()) / 168, 1) if len(x) else 0
    P(f"   {nm:62s} latih n {len(la):5d} ({mg(ev[(ev.th >= 2023) & (ev.th <= 2024)]):4.1f}/mgg) WR {np.mean(la > 0) * 100 if len(la) else 0:4.1f}% exp {la.mean() if len(la) else 0:+.3f}R"
      f" | uji n {len(te):5d} ({mg(ev[ev.th >= 2025]):4.1f}/mgg) WR {np.mean(te > 0) * 100 if len(te) else 0:4.1f}% exp {te.mean() if len(te) else 0:+.3f}R tot/DD "
      f"{te.sum() / max(dd(ev[ev.th >= 2025].sort_values('keluar').R.values), 1e-9):4.1f}")
    return ev, (la.mean() if len(la) >= 100 else -9)
LULUS = {}
def pilih_terbaik(judul, hasil):
    best = max(hasil, key=lambda z: z[2])
    ev = best[1]; te = ev[ev.th >= 2025].R.values
    ok_ = len(te) >= 100 and te.mean() >= 0.15
    P(f"   >> dipilih di latih: {best[0]} | uji exp {te.mean() if len(te) else 0:+.3f}R n {len(te)} -> {'LULUS' if ok_ else 'TIDAK LULUS'}")
    if ok_:
        LULUS[judul] = ev

P("\n== 2. VOLATILITY SQUEEZE BREAKOUT (1J dan 4J) ==")
hasil = []
for tf in (1, 4):
    for N in (40, 50):
        for vk in (2.0, 3.0):
            sig = []
            for s, D in DATA.items():
                a = D["a"]
                if tf == 1:
                    h, l, c, v = H_[a:a + D["n"]], L_[a:a + D["n"]], C_[a:a + D["n"]], D["v"]; kmap = lambda i: a + i + 1; tms = TS[a:a + D["n"]]
                    at = pd.Series(D["h4"] - D["l4"]).rolling(14).mean().values; at_of = lambda i: at[min(np.searchsorted(D["ix"], i, "right") - 1, len(at) - 1)]
                else:
                    h, l, c, v = D["h4"], D["l4"], D["c4"], D["v4"]; ix = D["ix"]; kmap = lambda i, ix=ix: a + ix[i + 1] if i + 1 < len(ix) else -1
                    tms = D["t4"]; at_of = lambda i, at=D["at4"]: at[i]
                cs = pd.Series(c); bw = (4 * cs.rolling(20).std() / cs.rolling(20).mean()).values
                bwmin = pd.Series(bw).rolling(N).min().values
                va = pd.Series(v).rolling(20).mean().shift(1).values
                arah_b = btc_arah(tms + (3600000 if tf == 1 else 14400000))
                cand = np.nonzero(np.isfinite(bw) & (bw <= bwmin * 1.0001))[0]
                lewat = -1
                for i in cand:
                    if i < N + 20 or i <= lewat or i >= len(c) - 1:
                        continue
                    if True:
                        top = h[i - 9:i + 1].max(); bot = l[i - 9:i + 1].min()
                        for j in range(i + 1, min(i + 13, len(c) - 1)):
                            d = 1 if c[j] > top else (-1 if c[j] < bot else 0)
                            if d == 0:
                                continue
                            if v[j] >= vk * va[j] and d == arah_b[j]:
                                k = kmap(j)
                                if k > 0:
                                    e = O_[k]; sl = bot if d == 1 else top; rk = (e - sl) * d
                                    if 0.004 * e <= rk <= 0.08 * e:
                                        sig.append((s, k, d, rk, at_of(j)))
                            break
                        lewat = i + 12
            ev, ex = nilai_mesin(f"TF {tf}J squeeze {N} periode, volume >= {vk}x, searah BTC", sig)
            hasil.append((f"TF {tf}J N{N} vol{vk}", ev, ex))
pilih_terbaik("squeeze", hasil)

P("\n== 3. SEKTOR PEMIMPIN-PENGIKUT ==")
P("   catatan: robot belum punya peta sektor. Sektor dibentuk dari korelasi return harian 2022 (sebelum periode latih), 15 kelompok.")
from scipy.cluster.hierarchy import linkage, fcluster
dly = {}
for s, D in DATA.items():
    a, n = D["a"], D["n"]; t = TS[a:a + n]; day = t // 86400000
    ix = np.r_[np.nonzero(np.diff(day))[0], n - 1]
    dly[s] = pd.Series(C_[a + ix], index=day[ix])
DD = pd.DataFrame(dly)
d0, d1 = pd.Timestamp("2022-01-01").value // 86400000000000, pd.Timestamp("2023-01-01").value // 86400000000000
ret = DD[(DD.index >= d0) & (DD.index < d1)].pct_change().dropna(axis=1, thresh=200).drop(columns=["BTCUSDT"], errors="ignore")
ret = ret.sub(DD["BTCUSDT"].pct_change().reindex(ret.index), axis=0)          # korelasi setelah gerak BTC dibuang
cor = ret.corr().fillna(0)
Z = linkage(1 - cor.values[np.triu_indices(len(cor), 1)], "average")
grp = dict(zip(cor.columns, fcluster(Z, 15, "maxclust")))
P(f"   {len(grp)} koin punya data 2022 cukup untuk dikelompokkan")
# tabel 4J return dan volume rasio per koin, disejajarkan waktu
t4all = sorted(set(np.concatenate([DATA[s]["t4"] for s in grp])))
pos = {t: q for q, t in enumerate(t4all)}
RET = np.full((len(t4all), len(grp)), np.nan); VR = RET.copy(); HI20 = RET.copy(); CL = RET.copy(); LO20 = RET.copy()
kol = list(grp)
for jj, s in enumerate(kol):
    D = DATA[s]; q = np.array([pos[t] for t in D["t4"]])
    RET[q, jj] = D["c4"] / D["o4"] - 1; VR[q, jj] = D["v4"] / pd.Series(D["v4"]).rolling(20).mean().shift(1).values
    HI20[q, jj] = pd.Series(D["h4"]).rolling(20).max().shift(1).values; LO20[q, jj] = pd.Series(D["l4"]).rolling(20).min().shift(1).values; CL[q, jj] = D["c4"]
gv = np.array([grp[s] for s in kol])
hasil = []
for lead_r in (0.05, 0.08):
    for lag_v in (1.5, 2.0):
        sig = []
        for q in range(25, len(t4all) - 3):
            for g in np.unique(gv):
                m_ = gv == g
                if m_.sum() < 3:
                    continue
                rr_ = RET[q, m_]; vr_ = VR[q, m_]
                for d in (1, -1):
                    lead = np.nanmax(rr_ * d)
                    if not (lead >= lead_r):
                        continue
                    li = np.nanargmax(rr_ * d)
                    if not (vr_[li] >= 3):
                        continue
                    anggota = np.nonzero(m_)[0]
                    for jj in anggota:
                        if jj == anggota[li] or not (abs(RET[q, jj]) < 0.015 or np.isnan(RET[q, jj])):
                            continue
                        for q2 in (q + 1, q + 2):          # pengikut menembus resistance 20 candle dengan volume awal
                            if np.isnan(CL[q2, jj]):
                                break
                            tembus = CL[q2, jj] > HI20[q2, jj] if d == 1 else CL[q2, jj] < LO20[q2, jj]
                            if tembus and VR[q2, jj] >= lag_v:
                                s = kol[jj]; D = DATA[s]; i4 = np.searchsorted(D["t4"], t4all[q2])
                                if i4 + 1 < len(D["ix"]):
                                    k = D["a"] + D["ix"][i4 + 1]; e = O_[k]; rk = 1.5 * D["at4"][i4]
                                    if np.isfinite(rk) and 0.004 * e <= rk <= 0.08 * e:
                                        sig.append((s, k, d, rk, D["at4"][i4]))
                                break
        ev, ex = nilai_mesin(f"pemimpin >= {lead_r * 100:.0f}% vol 3x, pengikut tembus R20 vol >= {lag_v}x", sig)
        hasil.append((f"lead {lead_r} lagv {lag_v}", ev, ex))
pilih_terbaik("sektor", hasil)

P("\n== 4. TEMBUS EKSTREM MINGGU LALU PERTAMA KALI (4J) ==")
hasil = []
for er_min in (0.2, 0.3):
    for vk in (1.0, 1.5):
        sig = []
        for s, D in DATA.items():
            t4 = D["t4"]; wk = (t4 // 86400000 + 3) // 7          # minggu mulai Senin
            dfw = pd.DataFrame(dict(w=wk, h=D["h4"], l=D["l4"])).groupby("w").agg(h=("h", "max"), l=("l", "min"))
            ph = dfw.h.shift(1).reindex(wk).values; pl = dfw.l.shift(1).reindex(wk).values
            c = D["c4"]; va = pd.Series(D["v4"]).rolling(20).mean().shift(1).values
            sudah = {}
            for i in range(25, len(c) - 1):
                w = wk[i]
                if sudah.get(w):
                    continue
                d = 1 if c[i] > ph[i] else (-1 if c[i] < pl[i] else 0)
                if d == 0 or not np.isfinite(ph[i]):
                    continue
                sudah[w] = True
                er = abs(c[i] - c[i - 20]) / max(np.abs(np.diff(c[i - 20:i + 1])).sum(), 1e-12)
                if er < er_min or D["v4"][i] < vk * va[i]:
                    continue
                k = D["a"] + D["ix"][i + 1]; e = O_[k]; rk = 1.5 * D["at4"][i]
                if np.isfinite(rk) and 0.004 * e <= rk <= 0.08 * e:
                    sig.append((s, k, d, rk, D["at4"][i]))
        ev, ex = nilai_mesin(f"efisiensi >= {er_min}, volume >= {vk}x", sig)
        hasil.append((f"er {er_min} vol {vk}", ev, ex))
pilih_terbaik("mingguan", hasil)

P("\n== 5. IMPULS VOLUME PERTAMA SETELAH PASAR TIDUR (1J) ==")
hasil = []
for rng in (0.04, 0.06):
    for vk in (4.0, 6.0):
        sig = []
        for s, D in DATA.items():
            a, n = D["a"], D["n"]; h, l, c, o, v = H_[a:a + n], L_[a:a + n], C_[a:a + n], O_[a:a + n], D["v"]
            hh = pd.Series(h).rolling(72).max().shift(1).values; ll = pd.Series(l).rolling(72).min().shift(1).values
            va = pd.Series(v).rolling(20).mean().shift(1).values
            at = D["at4"]; ix = D["ix"]
            c1 = np.r_[c[0], c[:-1]]
            with np.errstate(invalid="ignore", divide="ignore"):
                hit = ((hh - ll) / c1 <= rng) & (v >= vk * va) & ((h - l) > 0) & (np.abs(c - o) / np.maximum(h - l, 1e-12) >= 0.7) & \
                      (((c > o) & (c > hh)) | ((c < o) & (c < ll)))
            lewat = -1
            for i in np.nonzero(hit)[0]:
                if i < 100 or i <= lewat or i >= n - 2:
                    continue
                d = 1 if c[i] > o[i] else -1
                k = a + i + 1; e = O_[k]; sl = l[i] if d == 1 else h[i]; rk = (e - sl) * d
                i4 = min(np.searchsorted(ix, i, "right") - 1, len(at) - 1)
                if 0.004 * e <= rk <= 0.08 * e:
                    sig.append((s, k, d, rk, at[i4]))
                lewat = i + 72
        ev, ex = nilai_mesin(f"rentang 72 jam <= {rng * 100:.0f}%, volume >= {vk}x, badan >= 70%", sig)
        hasil.append((f"rng {rng} vol {vk}", ev, ex))
pilih_terbaik("impuls", hasil)

P("\n== GABUNGAN mesin yang lulus dengan v149 (slot 4), per bulan 2025-2026 ==")
if LULUS:
    allv = pd.concat([ev_v149] + [e.drop(columns=["th"]) for e in LULUS.values()])
    A = porto2(ev_v149, runner=0); B_ = porto2(allv, runner=0)
    ukur("v149", A); ukur("v149 + " + ", ".join(LULUS), B_)
    ta = A[A.bulan >= "2025-01"].groupby("bulan").R.agg(["count", "sum"]); tb = B_[B_.bulan >= "2025-01"].groupby("bulan").R.agg(["count", "sum"])
    P(ta.join(tb, lsuffix="_v149", rsuffix="_baru").round(2).to_string())
else:
    P("   tidak ada mesin yang lulus, tidak ada yang digabung")
open("hasil_v152.txt", "w").write("\n".join(out))

import sys, time
import numpy as np, pandas as pd
import core as Cx

S0 = pd.read_pickle(f"{Cx.SC}/sig.pkl")
S = Cx.siapkan(S0)
S.to_pickle(f"{Cx.SC}/S.pkl")
print("sinyal setelah gerbang", len(S))
print(S.groupby("jalur").size().to_dict())
print("nilai_n", S.nilai_n.value_counts().sort_index().to_dict())
R_now = Cx.jalankan(S, jk=0, jstop=36)
R_j8 = Cx.jalankan(S)
cls = lambda n: np.where(n >= 8, 10, np.where(n >= 5, 9, np.where(n >= 3, 8, 0)))
S["kelas"] = cls(S.nilai_n.values)
print("== per trade, tanpa batas slot (aturan jam 8 + 36j) dan 36j saja")
for nm, res in (("36j (TP20+BE)", R_now), ("jam8 (FINAL)", R_j8)):
    for k in (0, 8, 9, 10):
        mk = (S.kelas.values == k)
        x = res["R"][mk]
        print(f"{nm:16s} kelas {k:2d} n {mk.sum():5d} WR {np.mean(x > 0) * 100:5.1f} PF {Cx.pf(x):.2f} rata {x.mean():+.3f} SLp {np.mean(x < -0.9) * 100:.1f}%")
    mk = S.kelas.values >= 8
    x = res["R"][mk]
    print(f"{nm:16s} kelas>=8 n {mk.sum():5d} WR {np.mean(x > 0) * 100:5.1f} PF {Cx.pf(x):.2f} rata {x.mean():+.3f} SLp {np.mean(x < -0.9) * 100:.1f}%")
print("== portofolio satu orang (5+2 slot)")
for nmP, mk in (("semua", np.ones(len(S), bool)), ("nilai>=3 (seimbang)", (S.nilai_n >= 3).values), ("nilai>=5 (profit)", (S.nilai_n >= 5).values)):
    print("----", nmP, int(mk.sum()), "sinyal")
    for nm, res, jk in (("36j tanpa jeda", R_now, 0), ("36j + jeda 3/24j", R_now, 3), ("jam8 tanpa jeda", R_j8, 0), ("jam8 + jeda 3/24j (FINAL)", R_j8, 3)):
        T = Cx.portofolio(S, res, pilih=mk, jeda_k=jk)
        print(Cx.baris(nm, Cx.metrik(T, S)), flush=True)

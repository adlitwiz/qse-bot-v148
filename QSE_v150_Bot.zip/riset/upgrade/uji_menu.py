"""Uji v150 menu tombol, papan Lab WR, dan saringan AMD."""
import os, sys, time, json
SD = os.path.abspath("st_menu_%d" % int(time.time())); os.makedirs(SD)
os.environ.update(QSE_STATE_DIR=SD, TELEGRAM_BOT_TOKEN="x", TELEGRAM_CHAT_ID="-100")
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot")
import qse_menu as M, qse_lab as LB, qse_sesi as SS, qse_saya as SY
KIRIM = []
class R:
    def __init__(s, d): s.d = d
    def json(s): return {"ok": True, "result": {"message_id": 7}}
M.requests.post = lambda url, data=None, timeout=None: (KIRIM.append((url.rsplit("/", 1)[1], data)), R(data))[1]
# 1. keyboard dikirim sekali per versi
M.pastikan_menu(); M.pastikan_menu()
assert sum(k[0] == "sendMessage" for k in KIRIM) == 1 and "keyboard" in KIRIM[0][1]["reply_markup"]
# 2. tombol langsung -> perintah
assert M.dari_pesan("📊 Status", 1) == ("/status", [])
assert M.dari_pesan("😴 Mode Tidur", 1) == ("/tidur", [])
assert M.dari_pesan("halo", 1) is None
# 3. tombol sub menu -> pesan inline, lalu tombol inline -> perintah
KIRIM.clear(); assert M.dari_pesan("🧩 Jalur Sinyal", 1) is None
mk = json.loads(KIRIM[-1][1]["reply_markup"]); data = [b["callback_data"] for r in mk["inline_keyboard"] for b in r]
assert "c:/pelengkap" in data and "c:/lab" in data and all(len(x.encode()) <= 64 for x in data)
assert M.dari_tombol({"id": "q", "data": "c:/pelengkap", "from": {"id": 1}, "message": {"message_id": 5}}) == ("/pelengkap", [])
# 4. minta ketik: Cek Koin -> analisa -> ketik SOL
assert M.dari_tombol({"id": "q", "data": "t:/cek", "from": {"id": 9}, "message": {"message_id": 5}}) is None
assert M.dari_pesan("SOL", 8) is None                      # orang lain tidak ikut terpakai
assert M.dari_pesan("SOL", 9) == ("/cek", ["SOL"])
assert M.dari_pesan("SOL", 9) is None                      # sekali pakai
assert M.dari_tombol({"id": "q", "data": "t:/entry LONG MARKET", "from": {"id": 9}, "message": {}}) is None
assert M.dari_pesan("AVAX", 9) == ("/entry", ["LONG", "MARKET", "AVAX"])
# 5. konfirmasi tutup
KIRIM.clear(); assert M.dari_tombol({"id": "q", "data": "y:/tutup SOL", "from": {"id": 9}, "message": {"message_id": 5}}) is None
assert "c:/tutup SOL" in KIRIM[-1][1]["reply_markup"]
# 6. semua callback_data di semua sub menu <= 64 byte dan perintahnya dikenal
import qse_perintah as PR
src = open("/mnt/user-data/outputs/QSE_v148_Bot/qse_perintah.py").read()
for nm, (_, rows) in M.SUB.items():
    for r in rows:
        for t, d in r:
            assert len(d.encode()) <= 64, d
            c = d[2:].split()[0]
            assert f'"{c}"' in src, c
for v in M.LABEL.values():
    if v: assert f'"{v}"' in src, v
# 7. Lab: kirim hanya WR 20 trade >= 60%, UTAMA >= 65%
v = {"maju": [1.0] * 12 + [-1.0] * 8}; assert LB.kelas_wr(v)[0] == "KIRIM"
v = {"maju": [1.0] * 13 + [-1.0] * 7}; assert LB.kelas_wr(v)[0] == "UTAMA"
v = {"maju": [1.0] * 11 + [-1.0] * 9}; assert LB.kelas_wr(v)[0] == "DIAM"
v = {"maju": [1.0] * 15}; assert LB.kelas_wr(v)[0] == "DIAM"
now = LB._now()
d = {"closed": [dict(id="a", R=1.2, alasan="TP", t=now - 7200 - 3600, selesai=now - 3600), dict(id="a", R=-1, alasan="SL", t=now - 9000, selesai=now - 8000),
                dict(id="a", R=2, alasan="TP", t=now - 40 * 86400, selesai=now - 35 * 86400)]}
r = LB.rapor30(d, "a"); assert (r["w"], r["l"], round(r["jam_tp"])) == (1, 1, 2), r
assert "menang 1, kalah 1, WR 50%" in LB.baris_rapor(d, "a")
# 8. AMD: LONG ditolak kalau low Asia disapu lalu harga balik ke range
H = 3600000; t0 = int(time.time() // 86400 * 86400 * 1000)
asia = [(t0 + i * H, 101.0, 99.0, 100.0) for i in range(8)]
SY._kline = lambda sym, iv, limit=1000: asia + [(t0 + 8 * H, 100.5, 98.0, 99.2), (t0 + 9 * H, 100.2, 99.1, 100.0)]
jam = t0 / 1000 + 10 * 3600 + 60
assert SS.amd_melawan("X", "LONG", jam).startswith("AMD melawan")
assert SS.amd_melawan("X", "SHORT", jam) == ""
assert SS.amd_melawan("X", "LONG", t0 / 1000 + 5 * 3600) == ""          # sebelum 08 UTC tidak dicek
SY._kline = lambda sym, iv, limit=1000: asia + [(t0 + 8 * H, 100.5, 98.0, 98.5)]
assert SS.amd_melawan("X", "LONG", t0 / 1000 + 9 * 3600 + 60) == ""     # masih di bawah range: bukan AMD
print("uji_menu: semua lulus")

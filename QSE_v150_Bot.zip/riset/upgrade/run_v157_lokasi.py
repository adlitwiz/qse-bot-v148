"""v157 bagian 1: FVG, Order Flow taker, sesi/AMD sebagai SARINGAN LOKASI di atas sinyal v149 (4330 sinyal, 2023-2026).
Fitur dihitung dari candle 1J yang sudah tutup sebelum entry. Ambang dipilih di 2023-2024, dinilai di 2025-2026."""
import json, numpy as np, pandas as pd
SC = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad"
Z = np.load(f"{SC}/k10/h1.npz"); OFF = json.load(open(f"{SC}/k10/off.json"))
O, H, L, C, T = Z["O"], Z["H"], Z["L"], Z["C"], Z["T"]
D = pd.read_pickle(f"{SC}/v157/v149_sig.pkl")
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0
TK = {}
def taker(s):
    if s not in TK:
        try:
            z = np.load(f"{SC}/taker/{s}.npz"); TK[s] = pd.DataFrame(dict(v=z["v"], tb=z["tb"]), index=z["t"])
        except Exception:
            TK[s] = None
    return TK[s]
F = []
for r in D.itertuples():
    k = int(r.k0); a, n = OFF[r.sym]; d = r.arah; i = k - 1                    # candle 1J terakhir yang sudah tutup
    lo = max(a, i - 20)
    fvg = 0
    for j in range(lo + 2, i + 1):
        if d == 1 and L[j] > H[j - 2] and L[j + 1:i + 1].min(initial=9e18) > H[j - 2]:
            fvg = 1
        if d == -1 and H[j] < L[j - 2] and H[j + 1:i + 1].max(initial=-9e18) < L[j - 2]:
            fvg = 1
    tk = taker(r.sym); tr = vr = np.nan
    if tk is not None and T[i] in tk.index:
        q = tk.index.get_loc(T[i]); v = tk.v.values
        tr = tk.tb.values[q] / max(v[q], 1e-12); vr = v[q] / max(v[max(0, q - 24):q].mean(), 1e-12)
        tr4 = tk.tb.values[max(0, q - 3):q + 1].sum() / max(v[max(0, q - 3):q + 1].sum(), 1e-12)
    else:
        tr4 = np.nan
    jam = pd.Timestamp(T[k], unit="ms").hour
    # AMD: range Asia (00-08 UTC) hari itu disapu berlawanan arah sinyal lalu harga kembali masuk
    h0 = k - (jam % 24)
    if jam >= 8 and h0 >= a:
        ah, al = H[h0:h0 + 8].max(), L[h0:h0 + 8].min()
        sw = (L[h0 + 8:k].min(initial=9e18) < al) if d == 1 else (H[h0 + 8:k].max(initial=-9e18) > ah)
        amd = int(sw and al < C[i] < ah)
    else:
        amd = -1
    F.append((fvg, tr * d if d == 1 else (1 - tr), tr4 if d == 1 else 1 - tr4, vr, jam, amd))
F = pd.DataFrame(F, columns=["fvg", "tk", "tk4", "vr", "jam", "amd"], index=D.index)
D = D.join(F); lat = D.th <= 2024; tes = D.th >= 2025
def baris(nm, m):
    a, b = D.R[lat & m].values, D.R[tes & m].values
    P(f"   {nm:44s} latih n {len(a):4d} ex {a.mean() if len(a) else 0:+.3f} PF {pf(a):.2f} | uji n {len(b):4d} ex {b.mean() if len(b) else 0:+.3f} PF {pf(b):.2f} WR {np.mean(b > 0) * 100 if len(b) else 0:4.1f}%")
P(f"Sinyal v149: {len(D)}, dengan data taker {D.tk.notna().sum()}")
baris("SEMUA v149", D.R.notna())
P("FVG searah terbuka di 20 candle 1J terakhir")
baris("ada FVG", D.fvg == 1); baris("tanpa FVG", D.fvg == 0)
P("Order flow taker searah (candle 1J terakhir, tk = porsi taker searah)")
for lo_, hi_ in ((0, 0.45), (0.45, 0.5), (0.5, 0.55), (0.55, 1.01)):
    baris(f"taker searah {lo_:.2f}-{hi_:.2f}", (D.tk >= lo_) & (D.tk < hi_))
for lo_, hi_ in ((0, 0.47), (0.47, 0.53), (0.53, 1.01)):
    baris(f"taker 4 jam searah {lo_:.2f}-{hi_:.2f}", (D.tk4 >= lo_) & (D.tk4 < hi_))
for lo_, hi_ in ((0, 1), (1, 2), (2, 3), (3, 99)):
    baris(f"volume 1J x{lo_}-{hi_}", (D.vr >= lo_) & (D.vr < hi_))
P("Sesi (jam UTC entry)")
for nm, a_, b_ in (("Asia 00-08", 0, 8), ("London 08-13", 8, 13), ("NY 13-21", 13, 21), ("Malam 21-24", 21, 24)):
    baris(nm, (D.jam >= a_) & (D.jam < b_))
P("AMD: range Asia disapu berlawanan arah lalu kembali masuk range")
baris("AMD terjadi", D.amd == 1); baris("tidak", D.amd == 0)
D.to_pickle(f"{SC}/v157/v149_lokasi.pkl")
open("hasil_v157_lokasi.txt", "w").write("\n".join(out))

"""Grup 20: apa yang benar-benar membedakan sinyal bagus di masa depan (untuk label PRIORITAS UTAMA dan skor keyakinan).
Per sinyal 2023-2026 (lolos profil koin x jalur x arah n>=10 PF>=1.3), dikelompokkan menurut NILAI, peluang otak, PF profil masa lalu."""
import numpy as np, pandas as pd
src = open("run_g19c.py").read().split('P("\\n== (d)')[0]
ns = {"__name__": "g20"}
exec(src, ns)
S, R, thn, pc, masuk, keluar, sid, jl, ar, ok, otak, uji, P, out, Cx = (ns[k] for k in ("S", "R", "thn", "pc", "masuk", "keluar", "sid", "jl", "ar", "ok", "otak", "uji", "P", "out", "Cx"))
out.clear()
gid = (sid * 100 + jl) * 3 + ar + 1
pfl = np.full(len(S), np.nan); nl = np.zeros(len(S)); wrl = np.full(len(S), np.nan)
for g in np.unique(gid):
    ix = np.nonzero(gid == g)[0]
    ko = ix[np.argsort(keluar[ix], kind="stable")]
    kk, rr = keluar[ko], R[ko]
    cpos, cneg, cw = np.r_[0, np.cumsum(np.maximum(rr, 0))], np.r_[0, np.cumsum(np.maximum(-rr, 0))], np.r_[0, np.cumsum(rr > 0)]
    j = np.searchsorted(kk, masuk[ix], side="right")
    pfl[ix] = cpos[j] / np.maximum(cneg[j], 1e-9); nl[ix] = j; wrl[ix] = cw[j] / np.maximum(j, 1)
lulus = (nl >= 10) & (pfl >= 1.3)
base = lulus & ok & otak & uji
def tab(nama, kat):
    D = pd.DataFrame(dict(k=kat[base], R=R[base], th=thn[base]))
    g = D.groupby("k", observed=True)
    T = pd.DataFrame(dict(n=g.size(), WR=g.R.apply(lambda x: (x > 0).mean() * 100), PF=g.R.apply(lambda x: x[x > 0].sum() / -x[x < 0].sum()),
                          rata=g.R.mean(), rata_2324=D[D.th <= 2024].groupby("k", observed=True).R.mean(),
                          rata_2526=D[D.th >= 2025].groupby("k", observed=True).R.mean()))
    P(f"\n{nama}\n" + T.round(3).to_string())
tab("NILAI (label combo)", pd.cut(S.nilai_n.values, [-1, 2, 4, 7, 99], labels=["0-2", "3-4 (NILAI 8)", "5-7 (NILAI 9)", "8+ (NILAI 10)"]))
tab("peluang otak (persentil tahun berjalan)", pd.cut(pc, [0, .2, .4, .6, .8, 1], labels=["0-20", "20-40", "40-60", "60-80", "80-100"]))
tab("PF profil masa lalu koin x jalur x arah", pd.cut(pfl, [1.3, 1.6, 2.0, 3.0, 1e9], labels=["1.3-1.6", "1.6-2", "2-3", "3+"]))
tab("WR profil masa lalu", pd.cut(wrl, [0, .55, .65, .75, 1.01], labels=["<55", "55-65", "65-75", "75+"]))

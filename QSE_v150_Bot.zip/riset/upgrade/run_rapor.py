"""Rapor kejujuran v149: robot lama (v148) lawan v149 final, 2023-2024 dan 2025-2026 berdampingan, satu orang, data Binance 96 koin.
v148: jam ke-8 SL -0.5R, batas 36 jam, 5 berisiko + 2 aman, maks 4 searah, otak, rem harian, jeda.
v149: jam ke-12 dinamis, 30 jam, filter SHORT dump 12%, gerbang profil koin x jalur x arah (n>=10, PF>=1.3, walk-forward), maks 4 posisi jalan."""
import numpy as np, pandas as pd
src = open("run_g19c.py").read().split('P("\\n== (d)')[0]
ns = {"__name__": "rapor"}
exec(src, ns)
S, run, V, thn, otak, uji, ok = (ns[k] for k in ("S", "run", "V", "thn", "otak", "uji", "ok"))
masuk = S.masuk_h.values
def jalankan(res, pilih, cap, runner):
    ns["B"] = res; ns["R"] = res["R"]; ns["keluar"] = masuk + res["hrs"]
    return ns["porto"](pilih, cap=cap, runner=runner)
def profil(res):
    ns["R"] = res["R"]; ns["keluar"] = masuk + res["hrs"]
    gid = (ns["sid"] * 100 + ns["jl"]) * 3 + S.arah.values + 1
    izin = np.ones(len(S), bool); kel = ns["keluar"]; R = res["R"]
    for g in np.unique(gid):
        ix = np.nonzero(gid == g)[0]; ko = ix[np.argsort(kel[ix], kind="stable")]
        cp, cn = np.r_[0, np.cumsum(np.maximum(R[ko], 0))], np.r_[0, np.cumsum(np.maximum(-R[ko], 0))]
        j = np.searchsorted(kel[ko], masuk[ix], side="right")
        izin[ix] = (j >= 10) & (cp[j] / np.maximum(cn[j], 1e-9) >= 1.3)
    return izin
lama = run()
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
rows = []
for nama, res, pil, cap, rn in (("v148 lama", lama, np.ones(len(S), bool), 5, 2), ("v149 final", baru, ok & izin, 4, 0)):
    for pop in V.PRIMER:
        T = jalankan(res, V.POP[pop] & pil & otak & uji, cap, rn)
        for per, mk in (("2023-2024", lambda th: th <= 2024), ("2025-2026", lambda th: th >= 2025), ("2023-2026", lambda th: th >= 0)):
            m_ = mk(thn[T[:, 3].astype(int)])
            r = T[m_, 2]; o = np.argsort(T[m_, 1], kind="stable"); eq = np.cumsum(r[o])
            k = mx = 0
            for v in r[o]:
                k = k + 1 if v <= 0 else 0; mx = max(mx, k)
            minggu = (T[m_, 0].max() - T[m_, 0].min()) / 168
            rows.append((nama, "NILAI 8+" if pop == "SEIMBANG" else "semua sinyal", per, len(r), round(len(r) / minggu, 1), round(np.mean(r > 0) * 100, 1),
                         round(r[r > 0].sum() / -r[r < 0].sum(), 2), round(r.sum()), round(float((np.maximum.accumulate(eq) - eq).max())), mx))
D = pd.DataFrame(rows, columns=["versi", "populasi", "periode", "trade", "per_minggu", "WR", "PF", "total_R", "DD_R", "rugi_beruntun_maks"])
pd.set_option("display.width", 200)
print(D.to_string(index=False))
open(f"{ns['Cx'].SC}/hasil_rapor.txt", "w").write(D.to_string(index=False))

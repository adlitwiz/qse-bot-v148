"""Grup 9: otak gabungan = penilai sinyal + peramal harga. Walk-forward tahunan, buang 10%, aturan P di 2023-24 dan 2025-26.
A  = otak sekarang (klasifikasi R > 0, fitur live).
C  = satu model klasifikasi dengan fitur ramalan tambahan (RSI 4J, jarak EMA 50/200 4J, return 4/24/72 jam koin dan BTC).
B  = peramal: regresi return koin 24 jam searah sinyal (fitur sama dengan C).
AB = gabungan peringkat A dan B (rata-rata peringkat persentil di tahun uji)."""
import os, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import roc_auc_score
import var_lib as V, core as Cx
src = open("latih_otak.py").read().split("pr = np.full")[0]
ns = {}
exec(src, ns)
S, X, y, thn, base, PARAM = ns["S"], ns["X"].copy(), ns["y"], ns["thn"], ns["base"], ns["PARAM"]
C, O = Cx.C, Cx.O
k0 = S.k0.values
N4 = 250
def ema(a, n):
    k = 2 / (n + 1); e = a[:, 0].copy()
    for j in range(1, a.shape[1]):
        e = e + k * (a[:, j] - e)
    return e
def rsi(a, n=14):
    d = np.diff(a, axis=1); up, dn = np.maximum(d, 0), np.maximum(-d, 0)
    au, ad = up[:, :n].mean(1), dn[:, :n].mean(1)
    for j in range(n, d.shape[1]):
        au = (au * (n - 1) + up[:, j]) / n; ad = (ad * (n - 1) + dn[:, j]) / n
    return 100 - 100 / (1 + au / np.maximum(ad, 1e-12))
def tutup4(idx_akhir):
    """N4 close 4J terakhir (tiap 4 jam mundur dari jam idx_akhir)."""
    off = np.arange(N4 - 1, -1, -1) * 4
    return C[np.maximum(idx_akhir[:, None] - off[None, :], 0)]
c4 = tutup4(k0 - 1)
a, n = Cx.OFF["BTCUSDT"]
bt = Cx.TS[a:a + n]
jb = a + np.clip(np.searchsorted(bt, S.masuk_h.values * 3600000) - 1, 0, n - 1)
b4 = tutup4(jb)
E = pd.DataFrame(index=S.index)
for nm, arr in (("koin", c4), ("btc", b4)):
    E[nm + "_rsi"] = rsi(arr)
    E[nm + "_e50"] = (arr[:, -1] / ema(arr, 50) - 1) * 100
    E[nm + "_e200"] = (arr[:, -1] / ema(arr, 200) - 1) * 100
    E[nm + "_r4"] = (arr[:, -1] / arr[:, -2] - 1) * 100
    E[nm + "_r72"] = (arr[:, -1] / arr[:, -19] - 1) * 100
d = S.arah.values
for k in list(E.columns):          # searah sinyal: positif = mendukung arah sinyal
    if not k.endswith("rsi"):
        E[k + "_s"] = E[k] * d
X2 = pd.concat([X, E], axis=1)
fwd = (C[np.minimum(k0 + 23, len(C) - 1)] / O[k0] - 1) * 100 * d
fwd = np.clip(fwd, -30, 30)
out = []
def P(s=""):
    print(s, flush=True); out.append(s)
pA, pC, pB = (np.full(len(S), np.nan) for _ in range(3))
PR = {k: v for k, v in PARAM.items()}
for t in (2023, 2024, 2025, 2026):
    tr, te = thn < t, thn == t
    pA[te] = HistGradientBoostingClassifier(**PR).fit(X[tr], y[tr]).predict_proba(X[te])[:, 1]
    pC[te] = HistGradientBoostingClassifier(**PR).fit(X2[tr], y[tr]).predict_proba(X2[te])[:, 1]
    pB[te] = HistGradientBoostingRegressor(**PR).fit(X2[tr], fwd[tr]).predict(X2[te])
    P(f"{t}: AUC A {roc_auc_score(y[te], pA[te]):.3f}  C {roc_auc_score(y[te], pC[te]):.3f}  B(ramal) {roc_auc_score(y[te], pB[te]):.3f}"
      f"  | korelasi ramalan lawan return 24 jam nyata {np.corrcoef(pB[te], fwd[te])[0, 1]:+.3f}")
def pct(x, mk):
    r = np.zeros(len(x)); r[mk] = pd.Series(x[mk]).rank(pct=True).values; return r
pAB = np.zeros(len(S))
for t in (2023, 2024, 2025, 2026):
    mk = thn == t
    pAB[mk] = (pct(pA, mk)[mk] + pct(pB, mk)[mk]) / 2
uji = thn >= 2023
def mt(T):
    r, i = T[:, 3], T[:, 4].astype(int)
    o = dict(n=len(r), wr=np.mean(r > 0) * 100, pf=r[r > 0].sum() / -r[r < 0].sum(), tot=r.sum())
    eq = np.cumsum(r); o["dd"] = float(np.max(np.maximum.accumulate(eq) - eq))
    for nm, mk in (("a", thn[i] <= 2024), ("b", thn[i] >= 2025)):
        x = r[mk]; o["pf_" + nm], o["tot_" + nm], o["wr_" + nm] = x[x > 0].sum() / -x[x < 0].sum(), x.sum(), np.mean(x > 0) * 100
    return o
B0 = {pop: mt(Cx.portofolio(S, base, pilih=V.POP[pop] & uji)) for pop in V.PRIMER}
P()
for nm, sc in (("A otak sekarang", pA), ("C satu model + fitur ramalan", pC), ("B ramalan harga saja", pB), ("AB gabungan A + ramalan", pAB)):
    for q in (0.10, 0.20):
        buang = np.zeros(len(S), bool)
        for t in (2023, 2024, 2025, 2026):
            mk = thn == t; buang[mk] = sc[mk] < np.quantile(sc[mk], q)
        s = ""
        for pop in V.PRIMER:
            v, b = mt(Cx.portofolio(S, base, pilih=V.POP[pop] & uji & ~buang)), B0[pop]
            s += (f"\n    [{pop}] WR {v['wr']:.1f}/{b['wr']:.1f} PF {v['pf']:.2f}/{b['pf']:.2f} tot {v['tot']:+.0f}/{b['tot']:+.0f} DD {v['dd']:.0f}/{b['dd']:.0f} | "
                  f"23-24 PF {v['pf_a']:.2f} tot {v['tot_a']:+.0f} | 25-26 PF {v['pf_b']:.2f} tot {v['tot_b']:+.0f} | lolosP {V.lolos(v, b, 'P')}")
        P(f"{nm}, buang {int(q * 100)}%{s}")
open(f"{Cx.SC}/hasil_g9.txt", "w").write("\n".join(out))

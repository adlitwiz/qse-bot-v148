"""Uji 'tahun mirip': pilih di 2022+2024, nilai di 2026. Dan analog kuartal: ciri kuartal sebelumnya (sudah diketahui)
dicocokkan dengan kuartal lama, varian terbaik di kuartal SESUDAH analog dipakai di kuartal 2026 itu."""
import numpy as np, pandas as pd
exec(open("run_rezim.py").read().split("# uji: pilih di 2025")[0].replace("print(", "(lambda *a, **k: None)("))
EV = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v154_ev.pkl")
EV["q"] = pd.PeriodIndex(EV.bulan, freq="M").asfreq("Q").astype(str).str.replace("Q", "Q")
f_ = lambda x: f"n {len(x):4d} WR {np.mean(x.R > 0) * 100 if len(x) else 0:4.1f}% exp {x.R.mean() if len(x) else 0:+.3f}R tot {x.R.sum():+6.1f}R"
def opsi(g):
    for var, gg in g.groupby("varian"):
        for fn, fm in (("semua", np.ones(len(gg), bool)), ("killzone", gg.kz.values), ("Top 50", gg.tier.values < 50), ("luar Top 50", gg.tier.values >= 50)):
            yield f"{var} {fn}", gg[fm]
print("A. Pilih di 2022 (Jun-Des) + 2024, nilai murni di Jan-Okt 2026:")
for mesin, g in EV.groupby("mesin", sort=False):
    pil = [(x[x.th.isin([2022, 2024])].R.mean() if (x.th.isin([2022, 2024])).sum() >= 60 else -9, nm, x) for nm, x in opsi(g)]
    b = max(pil, key=lambda z: z[0]); x = b[2]
    print(f"  {mesin:12s} {b[1]:38s} | 2022+2024 {f_(x[x.th.isin([2022, 2024])])} | 2026 {f_(x[x.th == 2026])}")
# analog kuartal
Qs = Q.copy(); Zq = (Qs - Qs.mean()) / Qs.std(); urut = list(Qs.index)
print("\nB. Analog kuartal (ciri kuartal sebelumnya -> 3 kuartal lama paling mirip -> varian terbaik di kuartal sesudahnya):")
for mesin, g in EV.groupby("mesin", sort=False):
    ops = list(opsi(g)); hasil = []
    for tq in ("2026Q1", "2026Q2", "2026Q3", "2026Q4"):
        prev = urut[urut.index(tq) - 1] if tq in urut else "2026Q3"
        kand = [q for q in urut if q < "2025Q4" and q >= "2022Q2" and q != prev]
        dj = np.sqrt(((Zq.loc[kand] - Zq.loc[prev]) ** 2).sum(axis=1)).sort_values()
        analog = [urut[urut.index(q) + 1] for q in dj.index[:3]]
        best = max(ops, key=lambda o: o[1][o[1].q.isin(analog)].R.mean() if o[1].q.isin(analog).sum() >= 15 else -9)
        hasil.append(best[1][best[1].q == tq.replace("Q", "Q")])
    x = pd.concat(hasil)
    print(f"  {mesin:12s} 2026: {f_(x)}")
print("\nPembanding v149 di 2026 (hasil_v153, Jan-Okt): positif, lihat rapor bulanan.")

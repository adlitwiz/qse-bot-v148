"""Grup 10: cari celah. Pembanding = otak sekarang (A, buang 10%), walk-forward 2023-2026.
Aturan pra-daftar:
  PINTAR: PF naik >= 0.02 di 2023-24 dan 2025-26, dua populasi, total >= 95% A, WR tidak turun > 1 poin.
  DD:     DD turun >= 15% di dua populasi, total >= 90% A, PF tidak turun.
Varian otak: + fitur performa jalur terbaru (rata R trade jalur yang sama yang sudah selesai 30 dan 90 hari, semua jalur 14 hari),
  target regresi R, model lebih dalam. Varian DD: lot dari peluang, batas posisi searah, gabungan."""
import os, heapq, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
import var_lib as V, core as Cx
src = open("latih_otak.py").read().split("pr = np.full")[0]
ns = {}
exec(src, ns)
S, X, y, thn, base, PARAM = ns["S"], ns["X"].copy(), ns["y"], ns["thn"], ns["base"], dict(ns["PARAM"])
Rb = base["R"]
masuk = S.masuk_h.values
keluar = masuk + base["hrs"]
jl = S.jalur.values
ar = S.arah.values
out = []
def P(s=""):
    print(s, flush=True); out.append(s)

# ---- fitur performa jalur terbaru (hanya trade yang SUDAH selesai sebelum sinyal masuk) ----
def perf(mask_grup_fn, hari):
    v = np.full(len(S), np.nan); cnt = np.zeros(len(S))
    o = np.argsort(keluar, kind="stable")
    kel_s, R_s = keluar[o], Rb[o]
    for g in mask_grup_fn():
        idx = np.nonzero(g)[0]
        gi = g[o]
        kk, rr = kel_s[gi], R_s[gi]
        cs = np.r_[0, np.cumsum(rr)]
        hi = np.searchsorted(kk, masuk[idx], side="left")              # selesai sebelum masuk
        lo = np.searchsorted(kk, masuk[idx] - hari * 24, side="left")
        n_ = hi - lo
        v[idx] = np.where(n_ >= 5, (cs[hi] - cs[lo]) / np.maximum(n_, 1), np.nan)
        cnt[idx] = n_
    return v, cnt
grup_jl = lambda: [jl == j for j in np.unique(jl)]
grup_jla = lambda: [(jl == j) & (ar == a) for j in np.unique(jl) for a in (-1, 1)]
grup_all = lambda: [np.ones(len(S), bool)]
grup_arah = lambda: [ar == a for a in (-1, 1)]
F = pd.DataFrame(index=S.index)
F["jl30"], F["jl30_n"] = perf(grup_jl, 30)
F["jl90"], _ = perf(grup_jl, 90)
F["jla60"], _ = perf(grup_jla, 60)
F["all14"], F["all14_n"] = perf(grup_all, 14)
F["arah14"], _ = perf(grup_arah, 14)
XF = pd.concat([X, F], axis=1)

def wf(Xm, target, kind="clf", prm=None):
    p = np.full(len(S), np.nan)
    prm = prm or PARAM
    for t in (2023, 2024, 2025, 2026):
        tr, te = thn < t, thn == t
        if kind == "clf":
            p[te] = HistGradientBoostingClassifier(**prm).fit(Xm[tr], target[tr]).predict_proba(Xm[te])[:, 1]
        else:
            p[te] = HistGradientBoostingRegressor(**prm).fit(Xm[tr], target[tr]).predict(Xm[te])
    return p
def pctl(sc):
    r = np.full(len(S), np.nan)
    for t in (2023, 2024, 2025, 2026):
        mk = thn == t
        r[mk] = pd.Series(sc[mk]).rank(pct=True).values
    return r

# ---- portofolio dengan batas searah dan bobot lot ----
def porto(pilih, maks_searah=99, cap=5, runner=2, jeda_k=3, jeda_jam=24, rugi_hari=None):
    am = base["aman"]
    aman_t = np.where(am >= 0, masuk + np.maximum(am, 0), keluar)
    sid = pd.factorize(S.sym.values)[0]
    buka, antri, trades = [], [], []
    beruntun, jeda_dari = 0, None
    for idx in range(len(S)):
        if not pilih[idx]:
            continue
        t = masuk[idx]
        if antri:
            antri.sort(); sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and beruntun >= jeda_k:
                        jeda_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        if jeda_dari is not None:
            if t >= jeda_dari + jeda_jam:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b[1] > t]
        if rugi_hari is not None:
            h0 = (t // 24) * 24
            rr = sum(x[2] for x in trades if h0 <= x[1] <= t)
            if rr <= -rugi_hari:
                continue
        if any(b[0] == sid[idx] for b in buka):
            continue
        berisiko = [b for b in buka if b[2] > t]
        if len(berisiko) >= cap or len(buka) >= cap + runner:
            continue
        if sum(1 for b in berisiko if b[3] == ar[idx]) >= maks_searah:
            continue
        buka.append((sid[idx], keluar[idx], aman_t[idx], ar[idx]))
        antri.append((keluar[idx], Rb[idx]))
        trades.append((t, keluar[idx], Rb[idx], idx))
    return np.array(trades, float).reshape(-1, 4)
def mt(T, w=None):
    r = T[:, 2] * (w[T[:, 3].astype(int)] if w is not None else 1.0)
    i = T[:, 3].astype(int)
    o = np.argsort(T[:, 1], kind="stable")
    eq = np.cumsum(r[o])
    m = dict(n=len(r), wr=np.mean(T[:, 2] > 0) * 100, pf=r[r > 0].sum() / -r[r < 0].sum(), tot=r.sum(),
             dd=float((np.maximum.accumulate(eq) - eq).max()))
    for nm, mk in (("a", thn[i] <= 2024), ("b", thn[i] >= 2025)):
        x = r[mk]; m["pf_" + nm], m["tot_" + nm], m["wr_" + nm] = x[x > 0].sum() / -x[x < 0].sum(), x.sum(), np.mean(T[mk, 2] > 0) * 100
    return m
uji = thn >= 2023
def jalan(pilih, w=None, **kw):
    return {pop: mt(porto(V.POP[pop] & uji & pilih, **kw), w) for pop in V.PRIMER}
def fmt(nm, M, A):
    s = nm
    for pop in V.PRIMER:
        v, a = M[pop], A[pop]
        s += (f"\n    [{pop}] WR {v['wr']:.1f}/{a['wr']:.1f} PF {v['pf']:.2f}/{a['pf']:.2f} tot {v['tot']:+.0f}/{a['tot']:+.0f} DD {v['dd']:.0f}/{a['dd']:.0f}"
              f" | 23-24 PF {v['pf_a']:.2f}/{a['pf_a']:.2f} | 25-26 PF {v['pf_b']:.2f}/{a['pf_b']:.2f}")
    pin = all((M[p]["pf_a"] >= A[p]["pf_a"] + 0.02) and (M[p]["pf_b"] >= A[p]["pf_b"] + 0.02) and M[p]["tot"] >= 0.95 * A[p]["tot"]
              and M[p]["wr"] >= A[p]["wr"] - 1 for p in V.PRIMER)
    ddk = all(M[p]["dd"] <= 0.85 * A[p]["dd"] and M[p]["tot"] >= 0.90 * A[p]["tot"] and M[p]["pf"] >= A[p]["pf"] for p in V.PRIMER)
    return s + f"\n    lolos PINTAR {pin}  lolos DD {ddk}"
def buang_q(sc, q=0.10):
    pc = pctl(sc)
    return ~(pc < q)

pA = wf(X, y)
TANPA = jalan(np.ones(len(S), bool))
A = jalan(buang_q(pA))
P(fmt("TANPA OTAK (pembanding saja)", TANPA, A))
P(fmt("A otak sekarang", A, A))
P("\n== PUTARAN 2 (DRAWDOWN)")
pc = pctl(pA)
W1 = np.where(pc < 0.40, 0.5, np.where(pc >= 0.80, 1.5, 1.0))
W2 = np.where(pc < 0.40, 0.5, 1.0)
W3 = np.clip(0.5 + pc, 0.5, 1.5)
W4 = np.where(pc < 0.40, 0.75, 1.0)
for nm, w, kw in (("maks 4 searah + lot 0.5x 10-40% dan 1.5x 20% teratas", W1, dict(maks_searah=4)),
                  ("maks 4 searah + lot 0.5x 10-40%", W2, dict(maks_searah=4)),
                  ("lot mengikuti peluang 0.6x sampai 1.5x", W3, {}),
                  ("maks 4 searah + lot mengikuti peluang", W3, dict(maks_searah=4)),
                  ("lot 0.75x untuk 10-40%", W4, {}),
                  ("rugi hari ini 2R = stop entry sampai besok", None, dict(rugi_hari=2)),
                  ("rugi hari ini 3R = stop entry sampai besok", None, dict(rugi_hari=3)),
                  ("jeda 12 jam setelah 2 rugi beruntun", None, dict(jeda_k=2, jeda_jam=12)),
                  ("maks 4 searah + rugi hari 3R", None, dict(maks_searah=4, rugi_hari=3))):
    P(fmt(f"A + {nm}", jalan(buang_q(pA), w, **kw), A))
open(f"{Cx.SC}/hasil_g10b.txt", "w").write("\n".join(out))

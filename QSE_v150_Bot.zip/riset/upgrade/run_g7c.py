"""Grup 7c: aturan lolos P di uji walk-forward (fitur live), periode 2023-24 dan 2025-26, dua populasi. Buang 10%."""
import os, numpy as np
os.environ["G7_FITUR"] = "live"
src = open("run_g7b.py").read().split("uji = thn >= 2023")[0]
ns = {}
exec(src, ns)
S, base, thn, pr, V, Cx = ns["S"], ns["base"], ns["thn"], ns["pr"], ns["V"], ns["Cx"]
np.save(f"{Cx.SC}/pr_g7_live.npy", pr)
uji = thn >= 2023
def m(T):
    r, i = T[:, 3], T[:, 4].astype(int)
    o = {}
    for nm, mk in (("a", thn[i] <= 2024), ("b", thn[i] >= 2025)):
        x = r[mk]
        o["pf_" + nm] = x[x > 0].sum() / -x[x < 0].sum()
        o["tot_" + nm] = x.sum()
        o["wr_" + nm] = np.mean(x > 0) * 100
    return o
out = []
for q in (0.1, 0.2, 0.3):
    buang = np.zeros(len(S), bool)
    for t in (2023, 2024, 2025, 2026):
        mk = thn == t
        buang[mk] = pr[mk] < np.quantile(pr[mk], q)
    for pop in V.PRIMER:
        b = m(Cx.portofolio(S, base, pilih=V.POP[pop] & uji))
        v = m(Cx.portofolio(S, base, pilih=V.POP[pop] & uji & ~buang))
        s = (f"buang {int(q*100)}% [{pop}] 2023-24 PF {v['pf_a']:.2f}/{b['pf_a']:.2f} tot {v['tot_a']:+.0f}/{b['tot_a']:+.0f} WR {v['wr_a']:.1f}/{b['wr_a']:.1f} | "
             f"2025-26 PF {v['pf_b']:.2f}/{b['pf_b']:.2f} tot {v['tot_b']:+.0f}/{b['tot_b']:+.0f} WR {v['wr_b']:.1f}/{b['wr_b']:.1f} | lolosP {V.lolos(v, b, 'P')}")
        print(s); out.append(s)
open(f"{Cx.SC}/hasil_g7c.txt", "w").write("\n".join(out))

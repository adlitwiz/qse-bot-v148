"""Grup 22: bedah kelompok rugi PER TAHUN, LONG dan SHORT terpisah, semua koin (QSE_UJI_DIR=k10: 387 koin Binance sejak listing).
Pilih kelompok yang rugi di 2024 DAN 2025 (rata < -0.05R, PF < 0.95, n >= 40 per tahun), lalu konfirmasi di 2026 (Jan-Okt) yang tidak
ikut memilih: hanya yang juga rugi di 2026 yang dipasang. Fitur dipotong desil (+ ambang persen candle). Aturan keluar v149,
filter dump 12% SHORT dan pump 10% LONG sudah terpasang. Juga cetak tabel per tahun semua sinyal."""
import numpy as np, pandas as pd, json, os
src = open("run_g15.py").read().split("B = run(")[0]
ns = {"__name__": "g22"}
exec(src, ns)
S, run, Cx, P, out = ns["S"], ns["run"], ns["Cx"], ns["P"], ns["out"]
out.clear()
B = run(jk=12, jmode=4, jstop=30)
R = B["R"]; ar = S.arah.values; th = S.tahun.values
pct = S.body.values * S.atr.values / S.px.values * 100 * (-ar)
ok = ~(((ar == -1) & (pct >= 12)) | ((ar == 1) & (pct >= 10)))
X = ns["ns"]["X"].copy()
UNI = S["rank"].values <= float(os.environ.get("UNI_RANK", "9999"))          # universe seperti bot live: koin likuid teratas
X["candle_pct"] = pct
X["nilai_n"] = S.nilai_n.values
for k in ("dist_sup", "dist_res", "rank", "drop12", "pump12"):
    X[k] = S[k].values.astype(float)
ok = ok & UNI
P(f"Sinyal: {len(S)} dari {S.sym.nunique()} koin, {S.tahun.min()}-{S.tahun.max()}")
P("Per tahun semua sinyal (lolos filter candle):")
for a, nm in ((1, "LONG"), (-1, "SHORT")):
    s = f"  {nm}:"
    for t in sorted(np.unique(th)):
        x = R[ok & (ar == a) & (th == t)]
        if len(x):
            s += f" {t} n{len(x)} {x.mean():+.2f}R PF {x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9):.2f} |"
    P(s)
P("  per jalur x arah, rata R 2024 / 2025 / 2026:")
for j in sorted(S.jalur.unique()):
    for a, nm in ((1, "LONG"), (-1, "SHORT")):
        m = ok & (S.jalur.values == j) & (ar == a)
        if m.sum() < 50:
            continue
        P(f"    {j:11s} {nm:5s} " + " ".join(f"{t}: {R[m & (th == t)].mean():+.2f} (n {np.sum(m & (th == t))})" for t in (2021, 2022, 2023, 2024, 2025, 2026)))
temu = []
for a, nm in ((1, "LONG"), (-1, "SHORT")):
    m0 = ok & (ar == a)
    for kol in X.columns:
        if kol == "arah":
            continue
        x = X[kol].values.astype(float)
        if kol == "jalur":
            bins = [(v - 0.5, v + 0.5) for v in np.unique(x[m0])]
        else:
            q = np.nanquantile(x[m0], np.linspace(0, 1, 11))
            bins = list(zip(q[:-1], q[1:])) + [(q[0], q[3]), (q[7], q[10])]
        for lo, hi in bins:
            g = m0 & (x >= lo) & (x <= hi)
            y = {t: R[g & (th == t)] for t in (2024, 2025, 2026)}
            pf = lambda z: z[z > 0].sum() / max(-z[z < 0].sum(), 1e-9)
            if all(len(y[t]) >= 40 and y[t].mean() < -0.05 and pf(y[t]) < 0.95 for t in (2024, 2025)):
                temu.append(dict(arah=nm, fitur=kol, dari=round(lo, 3), sampai=round(hi, 3), n24=len(y[2024]), r24=round(y[2024].mean(), 3),
                                 n25=len(y[2025]), r25=round(y[2025].mean(), 3), n26=len(y[2026]), r26=round(y[2026].mean(), 3) if len(y[2026]) else None,
                                 r2123=round(R[g & (th >= 2021) & (th <= 2023)].mean(), 3), konfirmasi=bool(len(y[2026]) >= 20 and y[2026].mean() < 0)))
D = pd.DataFrame(temu)
pd.set_option("display.width", 220)
P(f"\nKelompok rugi di 2024 DAN 2025 (dipilih), lalu dicek di 2026 (konfirmasi): {len(D)} kelompok")
if len(D):
    P(D.to_string(index=False))
    json.dump(D[D.konfirmasi].to_dict("records"), open(f"{Cx.SC}/bocor.json", "w"))
open(f"{Cx.SC}/hasil_g22.txt", "w").write("\n".join(out))

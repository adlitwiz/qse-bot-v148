import numpy as np, pandas as pd, os
src = open("run_g15.py").read().split("B = run(")[0]
ns = {"__name__": "okt"}
exec(src, ns)
S, run = ns["S"], ns["run"]
B = run(jk=12, jmode=4, jstop=30)
R = B["R"]; S = S.copy(); S["R"] = R
t = pd.to_datetime(S["T"], unit="ms", utc=True)
S["bln"] = t.dt.strftime("%Y-%m")
ar = S.arah.values
pct = S.body.values * S.atr.values / S.px.values * 100 * (-ar)
ok = ~(((ar == -1) & (pct >= 12)) | ((ar == 1) & (pct >= 10))) & (S["rank"].values <= 150)
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
print("akhir data", t.max())
for b in ("2026-07", "2026-08", "2026-09", "2026-10"):
    m = ok & (S.bln.values == b)
    x = R[m]
    print(b, "semua", len(x), f"WR {np.mean(x > 0)*100:.0f}% rata {x.mean():+.2f}R PF {pf(x):.2f}")
    for j in sorted(S.jalur.unique()):
        y = R[m & (S.jalur.values == j)]
        if len(y): print("   ", j, len(y), f"WR {np.mean(y > 0)*100:.0f}% rata {y.mean():+.2f}R PF {pf(y):.2f}")
    for nv, nm in ((8, "N10"), (5, "N9"), (3, "N8")):
        y = R[m & (S.nilai_n.values >= nv)]
        print("   ", nm, len(y), f"WR {np.mean(y > 0)*100:.0f}% rata {y.mean():+.2f}R PF {pf(y):.2f}" if len(y) else "")

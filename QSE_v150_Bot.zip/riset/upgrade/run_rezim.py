"""Kemiripan rezim pasar 2026 dengan tahun sebelumnya + uji pilih di 2025, nilai di 2026."""
import numpy as np, pandas as pd, core as Cx
H_, L_, C_, TS = Cx.H, Cx.L, Cx.C, Cx.TS
def harian(s):
    a, n = Cx.OFF[s]; t = pd.to_datetime(TS[a:a + n], unit="ms", utc=True)
    df = pd.DataFrame(dict(h=H_[a:a + n], l=L_[a:a + n], c=C_[a:a + n]), index=t)
    return df.resample("1D").agg(dict(h="max", l="min", c="last")).dropna()
B = harian("BTCUSDT"); B["r"] = B.c.pct_change(); B["ma200"] = B.c.rolling(200).mean()
B["er30"] = (B.c - B.c.shift(30)).abs() / B.c.diff().abs().rolling(30).sum()
alt = {}
for s in Cx.OFF:
    if s == "BTCUSDT": continue
    d = harian(s); 
    if len(d) > 400: alt[s] = d.c
A = pd.DataFrame(alt).pct_change()
rows = []
for th in range(2018, 2027):
    m = (B.index.year == th) & (B.index.month <= 10)
    b = B[m]; a_ = A[A.index.year == th][A.index[A.index.year == th].month <= 10]
    a_ = a_.loc[:, a_.notna().sum() > 200]
    eq = b.c / b.c.iloc[0]
    kor = a_.corrwith(b.r.reindex(a_.index)).median()
    lebih = ((1 + a_).prod() - 1).median() - (eq.iloc[-1] - 1)
    rows.append(dict(tahun=th, btc_ret=(eq.iloc[-1] - 1) * 100, vol=b.r.std() * np.sqrt(365) * 100,
                     efisiensi=b.er30.mean(), di_atas_ma200=(b.c > b.ma200).mean() * 100,
                     dd_maks=((eq.cummax() - eq) / eq.cummax()).max() * 100, rentang_harian=((b.h - b.l) / b.c).mean() * 100,
                     korelasi_alt=kor, alt_lawan_btc=lebih * 100))
R = pd.DataFrame(rows).set_index("tahun")
pd.set_option("display.width", 200)
print("Ciri pasar Jan-Okt tiap tahun (BTC harian + median altcoin):")
print(R.round(2).to_string())
f = ["vol", "efisiensi", "di_atas_ma200", "dd_maks", "rentang_harian", "korelasi_alt", "alt_lawan_btc", "btc_ret"]
Z = (R[f] - R[f].mean()) / R[f].std()
jarak = np.sqrt(((Z - Z.loc[2026]) ** 2).sum(axis=1)).drop(2026).sort_values()
print("\nJarak ciri 2026 ke tahun lain (makin kecil makin mirip):")
print(jarak.round(2).to_string())
# per kuartal 2026
print("\nPer kuartal 2026 vs kuartal paling mirip sejak 2018:")
q = []
for th in range(2018, 2027):
    for k in range(1, 5):
        m = (B.index.year == th) & ((B.index.month - 1) // 3 + 1 == k)
        if m.sum() < 60: continue
        b = B[m]; eq = b.c / b.c.iloc[0]
        q.append(dict(q=f"{th}Q{k}", btc_ret=(eq.iloc[-1] - 1) * 100, vol=b.r.std() * np.sqrt(365) * 100, efisiensi=b.er30.mean(),
                      dd_maks=((eq.cummax() - eq) / eq.cummax()).max() * 100, di_atas_ma200=(b.c > b.ma200).mean() * 100))
Q = pd.DataFrame(q).set_index("q"); fq = list(Q.columns); Zq = (Q - Q.mean()) / Q.std()
for k in ("2026Q1", "2026Q2", "2026Q3"):
    if k in Zq.index:
        dj = np.sqrt(((Zq - Zq.loc[k]) ** 2).sum(axis=1)).drop(k); dj = dj[~dj.index.str.startswith("2026")].sort_values()
        print(f"  {k} ({Q.loc[k].btc_ret:+.0f}%, vol {Q.loc[k].vol:.0f}%): mirip " + ", ".join(f"{i} ({Q.loc[i].btc_ret:+.0f}%)" for i in dj.index[:3]))

# uji: pilih di 2025, nilai di 2026
EV = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v154_ev.pkl")
EV["bln"] = EV.bulan
print("\nPilih varian di 2025 saja (data terbaru), nilai murni di Jan-Okt 2026:")
for mesin, g in EV.groupby("mesin", sort=False):
    pil = []
    for var, gg in g.groupby("varian"):
        for fn, fm in (("semua", np.ones(len(gg), bool)), ("killzone", gg.kz.values), ("Top 50", gg.tier.values < 50), ("luar Top 50", gg.tier.values >= 50)):
            x = gg[fm]; la = x[x.th == 2025]; te = x[x.th == 2026]
            pil.append((la.R.mean() if len(la) >= 40 else -9, f"{var} {fn}", la, te, x[x.th.isin([2023, 2024])]))
    b = max(pil, key=lambda z: z[0])
    f_ = lambda x: f"n {len(x):4d} WR {np.mean(x.R > 0) * 100 if len(x) else 0:4.1f}% exp {x.R.mean() if len(x) else 0:+.3f}R"
    print(f"  {mesin:12s} pilihan 2025: {b[1]:38s} | 23-24 {f_(b[4])} | 2025 {f_(b[2])} | 2026 {f_(b[3])} -> {'LULUS' if len(b[3]) >= 60 and b[3].R.mean() >= 0.15 else 'TIDAK LULUS'}")

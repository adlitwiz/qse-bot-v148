"""Grup 14: pindai tiap jam. Sinyal jalur dihitung dari candle 4J yang batasnya digeser 0, 1, 2, 3 jam (bt_prep.py dengan
QSE_FASE). Bot sekarang hanya fase 0 (candle 4J Bybit). Pindai tiap jam = gabungan 4 fase, sinyal paling awal yang diambil.
Pertanyaan: (1) apakah keunggulan jalur tetap ada di fase lain (bukan kebetulan batas jam), (2) apakah gabungan lebih baik
dari fase 0 saja. Keluar memakai aturan baru (jam 12 hanya melawan, umur 30 jam). Tanpa otak (otak dilatih di fase 0).
Aturan lolos sama: P di 2021-23 dan 2024-26 (periode penuh data), dua populasi."""
import os, json, numpy as np, pandas as pd
os.environ["QSE_UJI_DIR"] = os.environ.get("QSE_UJI_DIR", "")
import core as Cx
src = open("run_g13.py").read()
ns = {}
exec("from numba import njit\nimport numpy as np\n" + src[src.index("@njit(cache=True)\ndef sim2("):src.index("def run(")].replace("cache=True", "cache=False"), ns)
sim2_semua = ns["sim2_semua"]
BASE = os.path.dirname(Cx.SC.rstrip("/"))
DIRS = {0: Cx.SC, 1: f"{BASE}/k9f1", 2: f"{BASE}/k9f2", 3: f"{BASE}/k9f3"}
out = []
def P(s=""):
    print(s, flush=True); out.append(s)


def muat(f):
    S = pd.read_pickle(f"{DIRS[f]}/S.pkl")
    off = json.load(open(f"{DIRS[f]}/off.json"))
    assert off == Cx.OFF, "urutan data beda"
    S = S.copy()
    S["fase"] = f
    return S


def sim(S, jmode=4, jk=12, jstop=30):
    R, hrs, am = sim2_semua(Cx.H, Cx.L, Cx.C, Cx.O, S.k0.values, S.nmax.values, S.arah.values.astype(np.int64), S.risk.values,
                            S.atrt.values, S.tp_r.values, S.trail.values, jmode, np.full(len(S), jk, np.int64), -0.5, -0.5, jstop, 0.0,
                            0.5, Cx.BIAYA)
    S = S.copy()
    S["R"], S["hrs"], S["aman"] = R, hrs, am
    return S


def porto(S, cap=5, runner=2, jeda_k=3, jeda_jam=24, rugi_hari=3, maks_searah=4):
    S = S.sort_values(["masuk_h", "fase"], kind="stable")
    masuk, R, hrs, am, ar = S.masuk_h.values, S.R.values, S.hrs.values, S.aman.values, S.arah.values
    keluar = masuk + hrs
    aman_t = np.where(am >= 0, masuk + np.maximum(am, 0), keluar)
    sid = pd.factorize(S.sym.values)[0]
    buka, antri, trades = [], [], []
    beruntun, jeda_dari = 0, None
    for idx in range(len(S)):
        t = masuk[idx]
        if antri:
            antri.sort(); sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and beruntun >= jeda_k:
                        jeda_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        if jeda_dari is not None:
            if t >= jeda_dari + jeda_jam:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b[1] > t]
        h0 = (t // 24) * 24
        if sum(x[2] for x in trades if h0 <= x[1] <= t) <= -rugi_hari:
            continue
        if any(b[0] == sid[idx] for b in buka):
            continue
        berisiko = [b for b in buka if b[2] > t]
        if len(berisiko) >= cap or len(buka) >= cap + runner:
            continue
        if sum(1 for b in berisiko if b[3] == ar[idx]) >= maks_searah:
            continue
        buka.append((sid[idx], keluar[idx], aman_t[idx], ar[idx]))
        antri.append((keluar[idx], R[idx]))
        trades.append((t, keluar[idx], R[idx], idx))
    T = np.array(trades, float).reshape(-1, 4)
    return T, S


def mt(T, S):
    r = T[:, 2]
    th = S.tahun.values[T[:, 3].astype(int)]
    o = np.argsort(T[:, 1], kind="stable")
    eq = np.cumsum(r[o])
    m = dict(n=len(r), wr=np.mean(r > 0) * 100, pf=r[r > 0].sum() / -r[r < 0].sum(), tot=r.sum(), dd=float((np.maximum.accumulate(eq) - eq).max()))
    for nm, mk in (("a", th < 2024), ("b", th >= 2024)):
        x = r[mk]
        m["pf_" + nm], m["tot_" + nm], m["wr_" + nm] = x[x > 0].sum() / -x[x < 0].sum(), x.sum(), np.mean(x > 0) * 100
    return m


def baris(nm, m, b=None):
    s = (f"{nm:42s} n {m['n']:5d} WR {m['wr']:.1f} PF {m['pf']:.2f} tot {m['tot']:+.0f} DD {m['dd']:.0f} | 21-23 PF {m['pf_a']:.2f} "
         f"{m['tot_a']:+.0f} | 24-26 PF {m['pf_b']:.2f} {m['tot_b']:+.0f}")
    if b:
        ok = (m["pf_a"] >= b["pf_a"] + 0.02 and m["pf_b"] >= b["pf_b"] + 0.02 and m["tot"] >= 0.95 * b["tot"] and m["wr"] >= b["wr"] - 1)
        s += f" | lolos P {ok}"
    return s


F = {f: sim(muat(f)) for f in DIRS if os.path.exists(f"{DIRS[f]}/S.pkl")}
POP = {"SEMUA": lambda S: S, "NILAI 8+": lambda S: S[S.nilai_n >= 3]}
P("== per sinyal (tanpa batas slot): apakah keunggulan ada di semua fase")
for f, S in F.items():
    for nm, fn in POP.items():
        x = fn(S).R.values
        P(f"fase {f} {nm:9s} n {len(x):5d} WR {np.mean(x > 0) * 100:.1f} PF {x[x > 0].sum() / -x[x < 0].sum():.2f} rata {x.mean():+.3f}")
P("\n== portofolio satu orang")
for nm, fn in POP.items():
    T0, S0 = porto(fn(F[0]))
    b = mt(T0, S0)
    P(baris(f"[{nm}] fase 0 saja (bot sekarang)", b))
    for f in F:
        if f:
            T, Sx = porto(fn(F[f]))
            P(baris(f"[{nm}] fase {f} saja", mt(T, Sx)))
    G = pd.concat([fn(F[f]) for f in F], ignore_index=True)
    T, Sx = porto(G)
    P(baris(f"[{nm}] pindai tiap jam (gabungan {len(F)} fase)", mt(T, Sx), b))
    tk = Sx.fase.values[T[:, 3].astype(int)]
    P(f"    trade dari fase: " + ", ".join(f"{f}: {np.sum(tk == f)}" for f in F))
open(f"{Cx.SC}/hasil_g14.txt", "w").write("\n".join(out))

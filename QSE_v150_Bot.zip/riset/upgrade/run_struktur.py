"""v149 riset struktur (permintaan 3 Nov 2026). Semua keputusan hanya pakai data sebelum sinyal. Pilih di 2023-2024, uji di 2025-2026.
A. Rem performa berjalan per jalur: 3 rugi beruntun, PF 10 terakhir < 0.8 (usulan user), dan rem sistem 7 hari.
B. Filter cuaca pasar saat sinyal: kemiringan McGinley BTC, rasio jarum candle (koin dan BTC), kerapatan volatilitas (ATR 24j / ATR 14 hari),
   efisiensi tren 5 hari (koin dan BTC). Tabel per kelompok, lalu aturan terbaik 2023-2024 dicek 2025-2026 dan per bulan.
C. Strategi B pantulan setelah sapuan likuiditas (4J): low menembus low 20 candle lalu tutup kembali di atasnya setelah turun >= F%
   (LONG), cermin untuk SHORT. SL di ujung sapuan, TP kR, maks 48 jam, biaya 0.15%. Lalu korelasi bulanan dengan strategi A (v149)
   dan hasil gabungan per bulan."""
import os, numpy as np, pandas as pd
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "struktur"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
m8 = ok & izin & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
R = baru["R"]; masuk = S.masuk_h.values; keluar = masuk + baru["hrs"]; ar = S.arah.values; jl = S.jalur.values
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
def nilai(nm, T):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    th_ = thn[i]
    P(f"   {nm:50s} n {len(r):5d} PF {pf(r):.2f} total {r.sum():+6.0f}R DD {dd(r[o_]):4.0f}R | PF<1 {int((pm < 1).sum()):2d}/{len(pm)} PF>=1.5 {int((pm >= 1.5).sum()):2d} "
      f"terburuk {tm.min():+5.1f}R | 23-24 {pf(r[th_ <= 2024]):.2f} 25-26 {pf(r[th_ >= 2025]):.2f} | 2026-07 {tm.get('2026-07', 0):+.1f} 2026-10 {tm.get('2026-10', 0):+.1f}")
    return tm
dasar = jalankan(baru, m8, 4, 0)
P("== A. REM PERFORMA BERJALAN (trade kertas yang sudah selesai sebelum sinyal) ==")
tmA = nilai("v149 sekarang", dasar)
idx = np.nonzero(m8)[0]
o = idx[np.argsort(keluar[idx], kind="stable")]; kk = keluar[o]; rr = R[o]; jj = jl[o]
def flag(fn):
    f = np.zeros(len(S), bool)
    for i in idx:
        j = np.searchsorted(kk, masuk[i], side="right")
        f[i] = fn(i, j)
    return f
def beruntun(x):
    k = 0
    for v in x[::-1]:
        if v <= 0: k += 1
        else: break
    return k
cs = np.r_[0, np.cumsum(rr)]
def rugi7(i, j, b=-3.0):
    j0 = np.searchsorted(kk, masuk[i] - 168, side="right"); return (cs[j] - cs[j0]) < b
FL = {
    "jalur 3 rugi beruntun: istirahat": flag(lambda i, j: beruntun(rr[:j][jj[:j] == jl[i]][-3:]) >= 3),
    "jalur PF 10 terakhir < 0.8: istirahat": flag(lambda i, j: (lambda x: len(x) >= 10 and pf(x) < 0.8)(rr[:j][jj[:j] == jl[i]][-10:])),
    "jalur 3 beruntun ATAU PF10 < 0.8": None,
    "sistem 7 hari rugi > 3R: istirahat": flag(rugi7),
    "sistem 7 hari rugi > 2R": flag(lambda i, j: rugi7(i, j, -2.0)),
    "sistem 7 hari rugi > 5R": flag(lambda i, j: rugi7(i, j, -5.0)),
}
FL["jalur 3 beruntun ATAU PF10 < 0.8"] = FL["jalur 3 rugi beruntun: istirahat"] | FL["jalur PF 10 terakhir < 0.8: istirahat"]
for nm, fl in FL.items():
    nilai(nm, jalankan(baru, m8 & ~fl, 4, 0))
FL["sistem 7 hari > 3R + jalur PF10 < 0.8"] = FL["sistem 7 hari rugi > 3R: istirahat"] | FL["jalur PF 10 terakhir < 0.8: istirahat"]
nilai("sistem 7 hari > 3R + jalur PF10 < 0.8", jalankan(baru, m8 & ~FL["sistem 7 hari > 3R + jalur PF10 < 0.8"], 4, 0))

P("\n== B. FILTER CUACA PASAR SAAT SINYAL ==")
OFF, TS = Cx.OFF, Cx.TS
O_, H_, L_, C_ = Cx.O, Cx.H, Cx.L, Cx.C
k0 = S.k0.values
def fitur_koin(k, a):
    lo = max(a, k - 120)
    h, l, c, o_ = H_[lo:k], L_[lo:k], C_[lo:k], O_[lo:k]
    if len(c) < 60:
        return np.nan, np.nan, np.nan
    rg = np.maximum(h - l, 1e-12)
    jar = float(np.sum(rg - np.abs(c - o_)) / np.sum(rg))
    er = abs(c[-1] - c[0]) / max(np.abs(np.diff(c)).sum(), 1e-12)
    lo2 = max(a, k - 336)
    a24 = np.mean(H_[k - 24:k] - L_[k - 24:k]); a14 = np.mean(H_[lo2:k] - L_[lo2:k])
    return jar, er, a24 / max(a14, 1e-12)
fk = np.full((len(S), 3), np.nan)
syms = S.sym.values
for i in idx:
    fk[i] = fitur_koin(k0[i], OFF[syms[i]][0])
b0, bl = OFF["BTCUSDT"]; bT = TS[b0:b0 + bl]; bC = C_[b0:b0 + bl]; bH = H_[b0:b0 + bl]; bL = L_[b0:b0 + bl]; bO = O_[b0:b0 + bl]
mg = np.empty(len(bC)); mg[0] = bC[0]; n_ = 136
for t in range(1, len(bC)):
    mg[t] = mg[t - 1] + (bC[t] - mg[t - 1]) / (0.6 * n_ * (bC[t] / mg[t - 1]) ** 4)
fb = np.full((len(S), 3), np.nan)
for i in idx:
    t = np.searchsorted(bT, TS[k0[i]])
    if t < 400:
        continue
    fb[i, 0] = (mg[t - 1] / mg[t - 25] - 1) * 100 * ar[i]          # kemiringan McGinley BTC 24 jam, searah sinyal = positif
    h, l, c, o_ = bH[t - 120:t], bL[t - 120:t], bC[t - 120:t], bO[t - 120:t]
    rg = np.maximum(h - l, 1e-12)
    fb[i, 1] = np.sum(rg - np.abs(c - o_)) / np.sum(rg)
    fb[i, 2] = abs(c[-1] - c[0]) / max(np.abs(np.diff(c)).sum(), 1e-12)
FT = {"jarum koin 5 hari": fk[:, 0], "efisiensi tren koin 5 hari": fk[:, 1], "kerapatan vol koin (ATR24/ATR14h)": fk[:, 2],
      "kemiringan McGinley BTC searah": fb[:, 0], "jarum BTC 5 hari": fb[:, 1], "efisiensi tren BTC 5 hari": fb[:, 2]}
lat = m8 & (thn <= 2024); tes = m8 & (thn >= 2025)
calon = []
for nm, x in FT.items():
    q = np.nanquantile(x[lat], [0.2, 0.4, 0.6, 0.8])
    gr = np.digitize(x, q)
    s = f"   {nm:36s}"
    for g in range(5):
        a_ = R[lat & (gr == g)]; b_ = R[tes & (gr == g)]
        s += f" | k{g + 1} {pf(a_):.2f}/{pf(b_):.2f}"
    P(s + "   (PF 2023-24 / 2025-26 per kelompok 20%)")
    for g in (0, 4):
        buang = gr == g
        calon.append((pf(R[lat & ~buang]) - pf(R[lat]), nm, g, buang))
calon.sort(key=lambda z: -z[0])
P("   Aturan buang kelompok terbaik dipilih di 2023-2024, dicek 2025-2026 dan per bulan:")
for d_, nm, g, buang in calon[:3]:
    nilai(f"buang {nm} k{g + 1} (naik {d_:+.2f} di latih)", jalankan(baru, m8 & ~buang, 4, 0))

P("\n== C. STRATEGI B: PANTULAN SETELAH SAPUAN LIKUIDITAS (4J), sinyal tingkat koin, 150 koin likuid ==")
ranks = S.groupby("sym")["rank"].median()
koin = [s for s in OFF if s in ranks.index and ranks[s] <= 150]
def strat_b(F, tpk, arah_ok):
    rows = []
    for s in koin:
        a, n = OFF[s]
        t = TS[a:a + n]; g = t // 14400000
        ix = np.r_[0, np.nonzero(np.diff(g))[0] + 1]
        if len(ix) < 60:
            continue
        o4 = O_[a + ix]; h4 = np.maximum.reduceat(H_[a:a + n], ix); l4 = np.minimum.reduceat(L_[a:a + n], ix)
        c4 = C_[a + np.r_[ix[1:] - 1, n - 1]]
        tr = h4 - l4; at = pd.Series(tr).rolling(14).mean().values
        for i in range(21, len(ix) - 1):
            if ix[i + 1] - ix[i] != 4 and i + 1 < len(ix) - 1 and False:
                continue
            for d in (1, -1):
                if d not in arah_ok:
                    continue
                if d == 1:
                    batas = l4[i - 20:i].min(); jatuh = (h4[i - 6:i].max() - l4[i]) / h4[i - 6:i].max()
                    if not (l4[i] < batas and c4[i] > batas and jatuh >= F):
                        continue
                    sl = l4[i] - 0.1 * at[i]
                else:
                    batas = h4[i - 20:i].max(); jatuh = (h4[i] - l4[i - 6:i].min()) / l4[i - 6:i].min()
                    if not (h4[i] > batas and c4[i] < batas and jatuh >= F):
                        continue
                    sl = h4[i] + 0.1 * at[i]
                k = a + ix[i + 1]; e = O_[k]; risk = (e - sl) * d
                if not (0.005 * e <= risk <= 0.08 * e):
                    continue
                tp = e + d * tpk * risk; r_ = None
                for j in range(k, min(k + 48, a + n)):
                    if (L_[j] <= sl) if d == 1 else (H_[j] >= sl):
                        r_ = -1.0; break
                    if (H_[j] >= tp) if d == 1 else (L_[j] <= tp):
                        r_ = tpk; break
                if r_ is None:
                    j = min(k + 47, a + n - 1); r_ = (C_[j] - e) * d / risk
                rows.append((TS[k], s, d, r_ - 0.0015 * e / risk))
    return pd.DataFrame(rows, columns=["t", "sym", "arah", "R"])
grid = []
for F in (0.05, 0.08, 0.12):
    for tpk in (1.0, 1.5, 2.0):
        for arah_ok, an in (((1,), "LONG"), ((-1,), "SHORT"), ((1, -1), "dua arah")):
            B = strat_b(F, tpk, arah_ok)
            if not len(B):
                continue
            y = pd.to_datetime(B.t, unit="ms", utc=True).dt.year.values
            la, te = B.R.values[(y >= 2021) & (y <= 2024)], B.R.values[y >= 2025]
            grid.append((pf(la), F, tpk, an, arah_ok, len(la), pf(te), len(te)))
            P(f"   jatuh >= {F * 100:.0f}% TP {tpk}R {an:8s}: 2021-24 n {len(la):5d} PF {pf(la):.2f} | 2025-26 n {len(te):5d} PF {pf(te):.2f}")
grid.sort(key=lambda z: -z[0])
best = grid[0]
P(f"   Dipilih dari 2021-2024: jatuh >= {best[1] * 100:.0f}% TP {best[2]}R {best[3]} (PF latih {best[0]:.2f}), uji 2025-26 PF {best[6]:.2f}")
B = strat_b(best[1], best[2], best[4])
B["b"] = pd.to_datetime(B.t, unit="ms", utc=True).dt.strftime("%Y-%m")
tmB = B[B.t >= TS[k0[idx]].min()].groupby("b").R.sum()
nB = B.groupby("b").R.count()
# skala B: rata 4 trade per minggu maks seperti robot, pakai rata per trade x jumlah wajar (maks 20 per bulan)
tmB_s = B.groupby("b").R.apply(lambda x: x.mean() * min(len(x), 20))
gab = pd.concat([tmA.rename("A"), tmB_s.rename("B")], axis=1).fillna(0)
gab = gab[gab.index >= "2023-01"]
P(f"   Korelasi bulanan A lawan B: {gab.A.corr(gab.B):+.2f}")
P(f"   Bulan A merah ({int((gab.A < 0).sum())}): rata B di bulan itu {gab.B[gab.A < 0].mean():+.2f}R, di bulan A hijau {gab.B[gab.A >= 0].mean():+.2f}R")
for w in (0.0, 0.5, 1.0):
    g = gab.A + w * gab.B
    P(f"   Gabungan A + {w:.1f} x B: bulan rugi {int((g < 0).sum())}/{len(g)}, terburuk {g.min():+.1f}R, total {g.sum():+.0f}R, "
      f"2026-07 {g.get('2026-07', 0):+.1f}R 2026-10 {g.get('2026-10', 0):+.1f}R")
open("hasil_struktur.txt", "w").write("\n".join(out))

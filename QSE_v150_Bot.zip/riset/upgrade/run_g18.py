"""Grup 18: keluar dinamis sesuai laju harga. Dasar v149 (TP 20% di +0.5R lalu SL entry, jam 12 dinamis, 30 jam, trailing jalur).
Tambahan yang diuji:
  macet: di jam h, posisi belum aman dengan MFE < m R ditutup (hanya yang jalan di tempat)
  tembok: TP sebagian 50% saat harga menyentuh resistance (LONG) / support (SHORT) pivot 4J terdekat, kalau jaraknya 0.5-3R
  struktur: posisi yang sudah aman, SL ikut low/high 8 candle 1 jam terakhir (selain trailing jalur)
  pucuk: candle 4J searah >= 1.5 ATR yang tutup dekat resistance (<= 0.5 ATR) -> TP 50%
Pembanding = v149 MARKET + filter dump 12%."""
import numpy as np
from numba import njit
src = open("run_g15.py").read().split("B = run(")[0]
ns = {"__name__": "g18"}
exec(src, ns)
S, run, jalan, fmt, P, out, Cx = (ns[k] for k in ("S", "run", "jalan", "fmt", "P", "out", "Cx"))
out.clear()


@njit(cache=False)
def sim3(Hh, L, C, O, k0, n, d, e, risk, atrt, tp_r, trail, tembok, macet_h, macet_m, tbk_por, strk, pucuk):
    sl = e - d * risk
    best = e
    sisa = 1.0
    real = 0.0
    aman = -1
    lvp = e + d * 0.5 * risk
    tp = e + d * tp_r * risk
    mfe = 0.0
    tbk_ok = tembok > 0 and 0.5 <= (tembok - e) * d / risk <= 3.0
    kena_tbk = False
    for j in range(n):
        hi = Hh[k0 + j]
        lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        f = ((hi - e) if d == 1 else (e - lo)) / risk
        if f > mfe:
            mfe = f
        if aman < 0 and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += 0.2 * sisa * 0.5
            sisa *= 0.8
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1
        if tbk_ok and not kena_tbk and tbk_por > 0 and ((d == 1 and hi >= tembok) or (d == -1 and lo <= tembok)):
            real += tbk_por * sisa * (tembok - e) * d / risk
            sisa *= (1 - tbk_por)
            kena_tbk = True
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            if aman < 0:
                aman = j + 1
        if tp_r > 0 and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        if d == 1:
            best = max(best, hi)
        else:
            best = min(best, lo)
        if j % 4 == 3:
            if trail > 0:
                nsl = best - d * trail * atrt
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
            if pucuk and tembok > 0 and not kena_tbk:
                c4 = (C[k0 + j] - O[k0 + j - 3]) * d
                if c4 >= 1.5 * atrt and abs(tembok - C[k0 + j]) <= 0.5 * atrt and (C[k0 + j] - e) * d > 0:
                    real += 0.5 * sisa * (C[k0 + j] - e) * d / risk
                    sisa *= 0.5
                    kena_tbk = True
                    if (d == 1 and e > sl) or (d == -1 and e < sl):
                        sl = e
                    if aman < 0:
                        aman = j + 1
        if strk > 0 and aman >= 0 and j >= strk:
            if d == 1:
                st = L[k0 + j - strk + 1]
                for q in range(k0 + j - strk + 1, k0 + j + 1):
                    st = min(st, L[q])
                if st > sl and st < C[k0 + j]:
                    sl = st
            else:
                st = Hh[k0 + j - strk + 1]
                for q in range(k0 + j - strk + 1, k0 + j + 1):
                    st = max(st, Hh[q])
                if st < sl and st > C[k0 + j]:
                    sl = st
        if macet_h > 0 and aman < 0 and j + 1 == macet_h and mfe < macet_m:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
        if aman < 0 and j + 1 == 12:
            rnow = (C[k0 + j] - e) * d / risk
            if rnow <= -0.5:
                return real + sisa * rnow, j + 1, aman
            if rnow < 0:
                nsl = e - d * 0.5 * risk
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
        if aman < 0 and j + 1 == 30:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman


@njit(cache=False)
def sim3_semua(Hh, L, C, O, k0, nmax, d, risk, atrt, tp_r, trail, tembok, macet_h, macet_m, tbk_por, strk, pucuk, biaya):
    m = len(k0)
    R = np.zeros(m)
    hrs = np.zeros(m, np.int64)
    am = np.zeros(m, np.int64)
    for i in range(m):
        e = O[k0[i]]
        r, h, a = sim3(Hh, L, C, O, k0[i], nmax[i], d[i], e, risk[i], atrt[i], tp_r[i], trail[i], tembok[i], macet_h, macet_m, tbk_por, strk, pucuk)
        R[i] = r - biaya * e / risk[i]
        hrs[i] = h
        am[i] = a
    return R, hrs, am


ar = S.arah.values
gerak = S.body.values * S.atr.values / S.px.values * 100 * (-ar)
ok = ~((ar == -1) & (gerak >= 12))
tembok = np.where(ar == 1, S.px.values + S.dist_res.values * S.atr.values, S.px.values - S.dist_sup.values * S.atr.values)
tembok = np.nan_to_num(np.where(np.isfinite(tembok) & (tembok > 0), tembok, 0.0))


def jalan3(**kw):
    p = dict(macet_h=0, macet_m=0.0, tbk_por=0.0, strk=0, pucuk=False)
    p.update(kw)
    R, hrs, am = sim3_semua(Cx.H, Cx.L, Cx.C, Cx.O, S.k0.values, S.nmax.values, ar.astype(np.int64), S.risk.values, S.atrt.values,
                            S.tp_r.values, S.trail.values, tembok, p["macet_h"], p["macet_m"], p["tbk_por"], p["strk"], p["pucuk"], Cx.BIAYA)
    return dict(R=R, hrs=hrs, aman=am)


B0 = jalan3()
B = run(jk=12, jmode=4, jstop=30)
P(f"cek sim3 dasar = v149: selisih R maks {np.abs(B0['R'] - B['R']).max():.2e}")
LV = jalan(B, ok)
P(fmt("v149 MARKET + filter dump 12%", LV, LV))
for nm, kw in (("macet 6 jam MFE < 0.3R", dict(macet_h=6, macet_m=0.3)), ("macet 8 jam MFE < 0.3R", dict(macet_h=8, macet_m=0.3)),
               ("macet 8 jam MFE < 0.5R", dict(macet_h=8, macet_m=0.5)), ("macet 16 jam MFE < 0.4R", dict(macet_h=16, macet_m=0.4)),
               ("tembok S/R 4J: TP 50%", dict(tbk_por=0.5)), ("tembok S/R 4J: TP 30%", dict(tbk_por=0.3)),
               ("struktur 8 candle 1J untuk posisi aman", dict(strk=8)), ("struktur 16 candle 1J untuk posisi aman", dict(strk=16)),
               ("pucuk: lonjakan 4J di dekat tembok TP 50%", dict(pucuk=True)),
               ("macet 8j/0.3R + tembok 30%", dict(macet_h=8, macet_m=0.3, tbk_por=0.3)),
               ("macet 8j/0.3R + struktur 16", dict(macet_h=8, macet_m=0.3, strk=16)),
               ("tembok 30% + struktur 16 + pucuk", dict(tbk_por=0.3, strk=16, pucuk=True))):
    P(fmt(nm, jalan(jalan3(**kw), ok), LV))
open(f"{Cx.SC}/hasil_g18.txt", "w").write("\n".join(out))

"""Grup 8: hanya sinyal searah BTC 4J (naik = LONG saja, turun = SHORT saja). Dua definisi: BTC naik versi bot (EMA 50)
dan izin BTC bot (izin_long, izin_short)."""
import numpy as np
import var_lib as V, core as Cx
S = V.S
base = V.run()
BM = {p: V.port(base, p)[0] for p in V.POP}
BZ = Cx.BZ
hm = BZ["Hmin"]
j = np.clip(S.masuk_h.values - int(np.ravel(hm)[0]) - 1, 0, len(BZ["naik"]) - 1)
naik, il, isr = BZ["naik"][j], BZ["izin_long"][j], BZ["izin_short"][j]
ar = S.arah.values
out = []
for nm, keep in (("searah BTC EMA50", ((ar == 1) & (naik == 1)) | ((ar == -1) & (naik == 0))),
                 ("izin BTC bot", ((ar == 1) & (il == 1)) | ((ar == -1) & (isr == 1)))):
    for pop in V.PRIMER:
        m, _ = V.port(base, pop, pilih=keep)
        b = BM[pop]
        s = (f"{nm} [{pop}] dibuang {(~keep & V.POP[pop]).sum()} rata R dibuang {base['R'][~keep & V.POP[pop]].mean():+.3f} | WR {m['wr']:.1f}/{b['wr']:.1f} PF {m['pf']:.2f}/{b['pf']:.2f} "
             f"tot {m['total']:+.0f}/{b['total']:+.0f} DD {m['dd']:.0f}/{b['dd']:.0f} | 21-23 PF {m['pf_a']:.2f}/{b['pf_a']:.2f} 24-26 PF {m['pf_b']:.2f}/{b['pf_b']:.2f} lolosP {V.lolos(m, b, 'P')}")
        print(s); out.append(s)
open(f"{Cx.SC}/hasil_g8.txt", "w").write("\n".join(out))

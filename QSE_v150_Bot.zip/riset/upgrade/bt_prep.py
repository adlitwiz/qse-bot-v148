"""Siapkan populasi sinyal untuk uji variasi aturan: data 1 jam Binance 2021-2026 -> candle 4J -> sinyal 6 jalur robot
(ema_short, rsi_vol, mcginley, snr_vol, msb_hpz, smc_choch) memakai fungsi indikator yang sama dengan bot (qse_strat, qse_smccore).
Keluaran: sig.pkl (satu baris per sinyal + fitur), h1.npz (array 1 jam gabungan), btc_izin.npz (izin arah BTC per jam)."""
import os, sys, glob, time, json
from concurrent.futures import ProcessPoolExecutor
SC = os.environ.get("QSE_UJI_DIR", os.path.dirname(os.path.abspath(__file__)))
os.environ["QSE_STATE_DIR"] = SC + "/st_bt"
os.makedirs(os.environ["QSE_STATE_DIR"], exist_ok=True)
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")))
import numpy as np, pandas as pd
from numba import njit
from numpy.lib.stride_tricks import sliding_window_view as swv
import qse_strat as ST
import qse_smccore as K
import qse_ichimoku as IC

DATA = os.environ.get("QSE_UJI_DATA", SC + "/data")          # CSV 1 jam per koin ({SYM}_60.csv, kolom t, open, high, low, close, volume)
OUT = SC
H1, H4 = 3600000, 14400000
FASE = int(os.environ.get("QSE_FASE", "0"))          # geser batas candle 4J (jam), untuk uji pindai tiap jam
BUANG = {"PAXG", "WBTC", "RLUSD", "XAUT", "U", "MUB", "RENDER", "CRCLB", "NVDAB", "SNDKB", "TSLAB", "SPCXB", "AMDB", "EWYB", "INTCB", "MSTRB",
         "NFP", "BMT"}
MIN_BAR = 4000
LIK30 = {"rsi_vol", "snr_vol", "msb_hpz", "smc_choch"}          # jalur yang hanya untuk 30 koin paling likuid
SL_ATR = {"ema_short": 1.5, "mcginley": 1.5}                     # lainnya 2.0
TPR = {"snr_vol": 3.0, "smc_choch": 3.0, "mcginley": 4.0}
TRL = {"ema_short": 4.0, "msb_hpz": 4.0, "rsi_vol": 3.0}
UMUR = {"ema_short": 8.1, "mcginley": 8.1, "rsi_vol": 8.1, "snr_vol": 6.1, "smc_choch": 2.1, "msb_hpz": 1.0}


def muat(sym):
    df = pd.read_csv(f"{DATA}/{sym}_60.csv")
    ts = ((pd.to_datetime(df["t"], utc=True) - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(milliseconds=1)).values.astype(np.int64)
    return ts, df[["open", "high", "low", "close", "volume"]].values.astype(float)


def blok4(ts, X):
    """Candle 4J dari 1 jam (hanya blok lengkap 4 jam berurutan). Return dict array."""
    g = (ts - FASE * H1) // H4
    chg = np.r_[True, g[1:] != g[:-1]]
    st = np.nonzero(chg)[0]
    en = np.r_[st[1:], len(ts)]
    ok = (en - st == 4)
    ok &= (ts[np.minimum(st + 3, len(ts) - 1)] - ts[st] == 3 * H1)
    st, en = st[ok], en[ok]
    o = X[st, 0]
    h = np.array([X[a:b, 1].max() for a, b in zip(st, en)])
    l = np.array([X[a:b, 2].min() for a, b in zip(st, en)])
    c = X[en - 1, 3]
    v = np.array([X[a:b, 4].sum() for a, b in zip(st, en)])
    return dict(T=ts[st], o=o, h=h, l=l, c=c, v=v, k1=st + 4)       # k1 = index 1 jam lokal pertama sesudah blok


def btc_fitur():
    ts, X = muat("BTCUSDT")
    b = blok4(ts, X)
    c = b["c"]
    e20, e50 = ST._ema(c, 20), ST._ema(c, 50)
    mom = np.r_[False, c[1:] > c[:-1]]
    dn = (c < e20) & (e20 < e50)
    up = (c > e20) & (e20 > e50)
    izin_long = ~(dn & ~mom)
    izin_short = ~(up & mom)
    naik = c > e50
    v = b["v"]
    volr = np.full(len(v), np.nan)
    for i in range(179, len(v)):
        volr[i] = v[i] / v[i - 179:i + 1].mean()
    return dict(T=b["T"], naik=naik, izin_long=izin_long, izin_short=izin_short, volr=volr)


@njit(cache=True)
def _sr(h, l, c, a, pl, ph, per, lb):
    n = len(c)
    ds = np.full(n, np.inf)
    dr = np.full(n, np.inf)
    for i in range(per + lb, n):
        sup = 0.0
        res = np.inf
        for j in range(i - per, i - lb - 1, -1):
            if pl[j] and l[j] < c[i] and l[j] > sup:
                sup = l[j]
            if ph[j] and h[j] > c[i] and h[j] < res:
                res = h[j]
        if sup > 0:
            ds[i] = (c[i] - sup) / a[i]
        if res < np.inf:
            dr[i] = (res - c[i]) / a[i]
    return ds, dr


def sr_pivot(h, l, c, a, per=5, lb=150):
    """Jarak (ATR) ke support terdekat di bawah close dan resistance terdekat di atas close dari pivot terkonfirmasi (per kiri, per kanan)
    dalam lb candle terakhir. Pivot di j baru dikenal di j+per, jadi tidak ada intip masa depan."""
    n = len(c)
    ph = np.zeros(n, np.bool_)
    pl = np.zeros(n, np.bool_)
    for t in range(per, n - per):
        if l[t] < l[t - per:t].min() and l[t] <= l[t + 1:t + per + 1].min():
            pl[t] = True
        if h[t] > h[t - per:t].max() and h[t] >= h[t + 1:t + per + 1].max():
            ph[t] = True
    return _sr(h, l, c, a, pl, ph, per, lb)


def proses(sym):
    t0 = time.time()
    ts, X = muat(sym)
    b = blok4(ts, X)
    T, o, h, l, c, v, k1 = (b[k] for k in ("T", "o", "h", "l", "c", "v", "k1"))
    n = len(c)
    out = []
    if n < 300:
        return sym, out, 0.0
    a = ST._atr(h, l, c)
    e20, e50, e200 = ST._ema(c, 20), ST._ema(c, 50), ST._ema(c, 200)
    r = ST._rsi(c)
    md = ST._mcginley(c)
    vp = np.full(n, np.nan)
    W = swv(v, 100)                       # W[m] = v[m:m+100]
    vp[100:] = (W[:n - 100] <= v[100:, None]).mean(axis=1) * 100
    ds, dr = sr_pivot(h, l, c, a)
    # fitur umum
    hh6 = pd.Series(h).rolling(6).max().values
    ll6 = pd.Series(l).rolling(6).min().values
    hh12 = pd.Series(h).rolling(12).max().values
    ll12 = pd.Series(l).rolling(12).min().values
    lo50 = pd.Series(l).shift(1).rolling(50).min().values
    hi50 = pd.Series(h).shift(1).rolling(50).max().values
    btc = BTC
    # BTC di candle yang sama (T sama)
    ib = np.searchsorted(btc["T"], T)
    ib = np.minimum(ib, len(btc["T"]) - 1)
    cocok = btc["T"][ib] == T
    naik = np.where(cocok, btc["naik"][ib], np.nan)
    sig = {}                               # (i, jalur) -> arah
    for i in range(260, n):
        if not cocok[i]:
            continue
        # ema_short
        if e20[i] < e50[i] and e20[i - 1] >= e50[i - 1] and c[i] < e200[i] and naik[i] == 0:
            sig[(i, "ema_short")] = -1
        if vp[i] >= 80:
            if r[i] > 50 and r[i - 1] <= 50 and c[i] > e200[i] and e50[i] > e200[i]:
                sig[(i, "rsi_vol")] = 1
            elif r[i] < 50 and r[i - 1] >= 50 and c[i] < e200[i] and e50[i] < e200[i]:
                sig[(i, "rsi_vol")] = -1
            if c[i] > md[i] and c[i - 1] <= md[i - 1] and c[i] > e200[i]:
                sig[(i, "mcginley")] = 1
            elif c[i] < md[i] and c[i - 1] >= md[i - 1] and c[i] < e200[i]:
                sig[(i, "mcginley")] = -1
    searah = lambda i, ar: (c[i] > e200[i]) == (ar == 1)
    for x in K.snr(h, l, c, 20):
        i, ar = x[0], x[1]
        if i >= 260 and cocok[i] and searah(i, ar) and vp[i] >= 80 and naik[i] == (1 if ar == 1 else 0):
            sig[(i, "snr_vol")] = ar
    vpa = K.volpct(v)
    for x in K.msb(o, h, l, c, v, 7, 0.5, vpa):
        i, ar = x[0], x[1]
        if i >= 260 and cocok[i] and x[5]["skor"] > 80 and searah(i, ar):
            sig[(i, "msb_hpz")] = ar
    for x in K.smc(o, h, l, c, 5, 50):
        i, ar = x[0], x[1]
        if i >= 260 and cocok[i] and x[5]["tag"] == "choch" and searah(i, ar):
            sig[(i, "smc_choch")] = ar
    # Ichimoku (qse_ichimoku._sinyal, versi seluruh seri)
    tk = (IC._hh(h, 9) + IC._ll(l, 9)) / 2
    kj = (IC._hh(h, 26) + IC._ll(l, 26)) / 2
    sa = np.r_[np.full(26, np.nan), ((tk + kj) / 2)[:-26]]
    sb = np.r_[np.full(26, np.nan), ((IC._hh(h, 52) + IC._ll(l, 52)) / 2)[:-26]]
    for i in range(260, n):
        if not cocok[i] or np.isnan(sa[i]) or np.isnan(sb[i]):
            continue
        if c[i] > max(sa[i], sb[i]) and tk[i] > kj[i] and tk[i - 1] <= kj[i - 1]:
            sig[(i, "ichimoku")] = 1
        elif c[i] < min(sa[i], sb[i]) and tk[i] < kj[i] and tk[i - 1] >= kj[i - 1]:
            sig[(i, "ichimoku")] = -1
    # Order Block + Volume (qse_ob._sinyal): LONG saja, BTC 4J di atas EMA 50
    obsl = {}
    for i in range(260, n):
        if not cocok[i] or naik[i] != 1:
            continue
        j = i - 5
        if not (c[j] < o[j] and (c[j + 1:i + 1] > o[j + 1:i + 1]).all()):
            continue
        if abs(c[j] - c[i]) / c[j] * 100 < 2.0 or c[i] <= e200[i] or vp[i] < 80:
            continue
        sig[(i, "orderblock")] = 1
        obsl[i] = l[j] - 0.3 * a[i]
    # pendukung combo: EMA 9/21 + volume dan candle inside bar
    e9, e21 = ST._ema(c, 9), ST._ema(c, 21)
    s921 = np.zeros(n, np.int8)
    for i in range(210, n):
        if vp[i] >= 80:
            if e9[i] > e21[i] and e9[i - 1] <= e21[i - 1] and c[i] > e200[i]:
                s921[i] = 1
            elif e9[i] < e21[i] and e9[i - 1] >= e21[i - 1] and c[i] < e200[i]:
                s921[i] = -1
    inside = np.r_[False, (h[1:] <= h[:-1]) & (l[1:] >= l[:-1])]
    dfm = pd.DataFrame(dict(open=o, high=h, low=l, close=c, volume=v))
    for (i, jl), ar in sig.items():
        if i + 1 >= n or k1[i] >= len(ts) or ts[k1[i]] != T[i] + H4:
            continue
        pull = None
        if jl == "mcginley":
            pull = bool((c[i] > e200[i] and e20[i] < e50[i]) if ar == 1 else (c[i] < e200[i] and e20[i] > e50[i]))
        out.append(dict(sym=sym, jalur=jl, arah=ar, i4=i, T=int(T[i]), k1=int(k1[i]), atr=float(a[i]), px=float(c[i]),
                        drop6=float((hh6[i] - c[i]) / a[i]), pump6=float((c[i] - ll6[i]) / a[i]),
                        drop12=float((hh12[i] - c[i]) / a[i]), pump12=float((c[i] - ll12[i]) / a[i]),
                        body=float((o[i] - c[i]) / a[i]), dist_sup=float(ds[i]), dist_res=float(dr[i]),
                        dist_lo50=float((c[i] - lo50[i]) / a[i]), dist_hi50=float((hi50[i] - c[i]) / a[i]),
                        pullback=pull, vp=float(vp[i]),
                        risk0=(float(c[i] - obsl[i]) if jl == "orderblock" else np.nan), inside=bool(inside[i])))
        # pendukung EMA 9/21 searah dalam 18 candle 4J terakhir
        w = s921[max(i - 17, 0):i + 1]
        out[-1]["p921"] = bool((w == ar).any())
        # mutu (plus/minus) dan pump
        try:
            sk, mp, mm = ST.mutu(dfm.iloc[max(0, i - 299):i + 1], "LONG" if ar == 1 else "SHORT")
        except Exception:
            sk, mp, mm = 0, [], []
        out[-1]["mp"] = len(mp)
        out[-1]["mm"] = len(mm)
        out[-1]["pump"] = bool(ar == -1 and i >= 181 and c[i] / c[i - 180] - 1 > 0.30)
    return sym, out, time.time() - t0


def init():
    global BTC
    BTC = btc_fitur()


if __name__ == "__main__":
    t0 = time.time()
    init()
    syms = []
    for f in sorted(glob.glob(f"{DATA}/*_60.csv")):
        s = os.path.basename(f)[:-7]
        if s.replace("USDT", "") in BUANG:
            continue
        with open(f) as fh:
            nb = sum(1 for _ in fh) - 1
        if nb >= MIN_BAR:
            syms.append(s)
    print("simbol", len(syms), flush=True)
    rows = []
    with ProcessPoolExecutor(2, initializer=init) as ex:
        for k, (s, out, dt) in enumerate(ex.map(proses, syms)):
            rows += out
            print(f"{k + 1}/{len(syms)} {s} {len(out)} sinyal {dt:.0f}s", flush=True)
    S = pd.DataFrame(rows)
    # array 1 jam gabungan
    off = {}
    O, Hh, L, C, TS = [], [], [], [], []
    tot = 0
    for s in syms:
        ts, X = muat(s)
        off[s] = (tot, len(ts))
        O.append(X[:, 0]); Hh.append(X[:, 1]); L.append(X[:, 2]); C.append(X[:, 3]); TS.append(ts)
        tot += len(ts)
    np.savez(f"{OUT}/h1.npz", O=np.concatenate(O), H=np.concatenate(Hh), L=np.concatenate(L), C=np.concatenate(C), T=np.concatenate(TS))
    json.dump(off, open(f"{OUT}/off.json", "w"))
    # peringkat likuid: rata-rata 30 hari volume dolar harian, digeser 1 hari
    dv = {}
    for s in syms:
        ts, X = muat(s)
        d = pd.Series(X[:, 4] * X[:, 3], index=pd.to_datetime(ts, unit="ms", utc=True)).resample("1D").sum()
        dv[s] = d
    D = pd.DataFrame(dv)
    D[D == 0] = np.nan
    rk = D.rolling(30, min_periods=10).mean().shift(1).rank(axis=1, ascending=False)
    rk.index = ((rk.index - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(days=1)).astype(int)
    S["day"] = (S["T"] // 86400000).astype(int)
    rkv = []
    for s, dday in zip(S["sym"], S["day"]):
        try:
            rkv.append(float(rk.at[dday, s]))
        except Exception:
            rkv.append(np.nan)
    S["rank"] = rkv
    # izin BTC per jam mutlak
    bt = BTC
    Hmin = int(min(np.concatenate(TS)) // H1)
    Hmax = int(max(np.concatenate(TS)) // H1)
    nh = Hmax - Hmin + 2
    il = np.ones(nh, bool); isr = np.ones(nh, bool); nk = np.zeros(nh, bool); vr = np.full(nh, np.nan)
    tutup_h = (bt["T"] + H4) // H1 - Hmin               # jam mulai berlaku flag blok
    for q in range(len(bt["T"])):
        a0 = int(tutup_h[q]); a1 = int(tutup_h[q + 1]) if q + 1 < len(bt["T"]) else nh
        if a0 < 0:
            a0 = 0
        if a0 >= nh:
            break
        il[a0:a1] = bt["izin_long"][q]; isr[a0:a1] = bt["izin_short"][q]; nk[a0:a1] = bt["naik"][q]; vr[a0:a1] = bt["volr"][q]
    np.savez(f"{OUT}/btc_izin.npz", Hmin=Hmin, izin_long=il, izin_short=isr, naik=nk, volr=vr)
    # volume pasar tinggi dan kombo
    S = S.sort_values(["sym", "i4"]).reset_index(drop=True)
    bi = np.searchsorted(bt["T"], S["T"].values)
    bi = np.minimum(bi, len(bt["T"]) - 1)
    S["vol_tinggi"] = bt["volr"][bi] > 2.5
    NAMA = {kk: cfg["nama"] for kk, cfg in ST.STRAT.items()}
    NAMA.update({"ichimoku": "Ichimoku", "orderblock": "Order Block"})
    grp = {}
    for idx, (sy, ar, i4, jl) in enumerate(zip(S["sym"], S["arah"], S["i4"], S["jalur"])):
        grp.setdefault((sy, ar), []).append((i4, jl, idx))
    cb = np.zeros(len(S), int)
    raja = np.zeros(len(S), bool)
    fix = np.zeros(len(S), bool)
    emas = np.zeros(len(S), bool)
    for key, lst in grp.items():
        for (i4, jl, idx) in lst:
            nm = {NAMA[j2] for (i2, j2, _) in lst if j2 != jl and i4 - 17 <= i2 <= i4}
            if S.at[idx, "p921"]:
                nm.add("EMA 9/21 + Volume")
            if nm and S.at[idx, "inside"]:
                nm.add("candle inside bar")
            nm = sorted(nm)
            cb[idx] = len(nm)
            raja[idx] = ST.combo_raja(nm)
            fix[idx] = bool(ST.combo_fix(jl, nm))
            emas[idx] = bool(ST.combo_emas(jl, nm))
    S["combo"] = cb
    S["raja"], S["fix"], S["emas"] = raja, fix, emas
    n_ = (5 * S.raja + 3 * S.fix + 2 * S.emas + (S.combo >= 1).astype(int) + (S.combo >= 2).astype(int) + (S.mp >= 3).astype(int)
          + S.pullback.fillna(False).astype(int) + 2 * S.vol_tinggi.astype(int))
    S["nilai_n"] = n_
    S["masuk_h"] = (S["k1"].astype(np.int64) * 0)          # diisi saat sim dari array T
    S.to_pickle(f"{OUT}/sig.pkl")
    print("selesai", len(S), "sinyal", round(time.time() - t0), "s", flush=True)
    print(S.groupby("jalur").size().to_string())

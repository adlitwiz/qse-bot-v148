"""Grup 6: entry telat (1 dan 2 candle 4J setelah sinyal) dipisah menurut posisi harga lawan entry robot:
minus (harga melawan, -0.5R sampai 0) lawan plus (0 sampai +0.5R). Syarat sama dengan robot: trade robot belum kena SL."""
import numpy as np
import var_lib as V
import core as Cx
S = V.S
H, L, C, O = Cx.H, Cx.L, Cx.C, Cx.O
k0s, nm, ar, rk, at, tp, tr = (S.k0.values, S.nmax.values, S.arah.values.astype(np.int64), S.risk.values, S.atrt.values,
                               S.tp_r.values, S.trail.values)
thn = S.tahun.values
out = []
def P(s=""):
    print(s, flush=True); out.append(s)
for lag in (4, 8):
    rows = []
    for i in range(len(S)):
        k0, d, risk = int(k0s[i]), int(ar[i]), float(rk[i])
        e = O[k0]
        sl = e - d * risk
        if nm[i] <= lag + 2:
            continue
        seg_l, seg_h = L[k0:k0 + lag], H[k0:k0 + lag]
        if (d == 1 and seg_l.min() <= sl) or (d == -1 and seg_h.max() >= sl):
            continue          # robot sudah kena SL: sinyal tidak valid
        if (d == 1 and seg_h.max() >= e + 0.5 * risk) or (d == -1 and seg_l.min() <= e - 0.5 * risk):
            sudah_tp = True
        else:
            sudah_tp = False
        e2 = O[k0 + lag]
        pos = (e2 - e) * d / risk
        if abs(pos) > 0.5:
            continue
        r2 = abs(e2 - sl)
        if r2 <= 0:
            continue
        R, *_ = Cx.sim1(H, L, C, k0 + lag, int(nm[i] - lag), d, e2, r2, at[i] * r2 / risk, tp[i] * risk / r2 if tp[i] > 0 else 0.0,
                        tr[i], 0.5, 0.20, 0.0, 8, -0.5, -0.5, 36, 0)
        R -= Cx.BIAYA * e2 / r2
        rows.append((pos, R, thn[i], sudah_tp, V.POP["SEIMBANG"][i]))
    a = np.array([(p, r, t, s, b) for p, r, t, s, b in rows], dtype=float)
    P(f"== entry {lag // 4} candle 4J setelah sinyal, {len(a)} trade")
    for nmz, m in (("minus -0.5..0", (a[:, 0] < 0)), ("plus 0..+0.5", (a[:, 0] >= 0)),
                   ("minus, belum sentuh +0.5R", (a[:, 0] < 0) & (a[:, 3] == 0))):
        for pn, pm in (("SEMUA", np.ones(len(a), bool)), ("SEIMBANG", a[:, 4] == 1)):
            x = a[m & pm]
            r = x[:, 1]
            ra, rb = r[x[:, 2] < 2024], r[x[:, 2] >= 2024]
            pf = lambda z: z[z > 0].sum() / -z[z < 0].sum() if (z < 0).any() else 0
            P(f"  {nmz:28s} [{pn:8s}] n {len(r):5d} WR {np.mean(r > 0) * 100:4.1f} rata {r.mean():+.3f}R PF {pf(r):.2f} | 21-23 {ra.mean():+.3f} PF {pf(ra):.2f} | 24-26 {rb.mean():+.3f} PF {pf(rb):.2f}")
open(f"{Cx.SC}/hasil_g6.txt", "w").write("\n".join(out))

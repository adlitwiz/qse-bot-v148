"""Grup 17: klasifikasi sinyal jalur sebelum masuk. KUAT (dorongan volume dan candle besar) = MARKET langsung.
LEMAH atau dekat jenuh = tunggu pantulan nyata: harga koreksi minimal x R, lalu candle 1 jam tutup berbalik searah sinyal
(close searah dan di atas setengah range candle itu), masuk di open berikutnya, SL tetap di level SL sinyal. Tidak ada pantulan
dalam W jam = tidak masuk. Bukan LIMIT buta. Keluar v149. Pembanding = v149 MARKET + filter dump 12%."""
import numpy as np
from numba import njit
src = open("run_g15.py").read().split("B = run(")[0]
ns = {"__name__": "g17"}
exec(src, ns)
S, run, jalan, fmt, P, out, Cx, sim2 = (ns[k] for k in ("S", "run", "jalan", "fmt", "P", "out", "Cx", "sim2"))
out.clear()


@njit(cache=False)
def pantul_semua(Hh, L, C, O, k0, nmax, d, risk, atrt, tp_r, trail, x, W, biaya):
    m = len(k0)
    R = np.zeros(m)
    hrs = np.zeros(m, np.int64)
    am = np.full(m, -1, np.int64)
    isi = np.zeros(m, np.bool_)
    for i in range(m):
        e0 = O[k0[i]]
        sl = e0 - d[i] * risk[i]
        lv = e0 - d[i] * x * risk[i]
        sentuh = False
        j = -1
        for q in range(min(W, nmax[i] - 3)):
            a = k0[i] + q
            if (d[i] == 1 and L[a] <= sl) or (d[i] == -1 and Hh[a] >= sl):
                break                                              # SL sinyal tersentuh dulu: batal
            if (d[i] == 1 and L[a] <= lv) or (d[i] == -1 and Hh[a] >= lv):
                sentuh = True
            if sentuh:
                rg = Hh[a] - L[a]
                if rg > 0 and ((d[i] == 1 and C[a] > O[a] and C[a] >= L[a] + 0.5 * rg) or
                               (d[i] == -1 and C[a] < O[a] and C[a] <= Hh[a] - 0.5 * rg)):
                    j = q
                    break
        if j < 0:
            continue
        e = O[k0[i] + j + 1]
        rk = (e - sl) * d[i]
        if rk <= 0.2 * risk[i]:
            continue
        isi[i] = True
        r, h, a2 = sim2(Hh, L, C, O, k0[i] + j + 1, nmax[i] - j - 1, d[i], e, rk, atrt[i], tp_r[i], trail[i], 4, 12, -0.5, -0.5, 30,
                        0.0, 0.5, 0.5, 0.20)
        R[i] = r - biaya * e / rk
        hrs[i] = j + 1 + h
        am[i] = (j + 1 + a2) if a2 >= 0 else -1
    return R, hrs, am, isi


ar = S.arah.values
thn = S.tahun.values
gerak = S.body.values * S.atr.values / S.px.values * 100 * (-ar)
ok = ~((ar == -1) & (gerak >= 12))
B = run(jk=12, jmode=4, jstop=30)
LV = jalan(B, ok)
P(fmt("v149 MARKET + filter dump 12%", LV, LV))
vp = S.vp.values
dorong = (vp >= np.nanmedian(vp)) & (gerak >= np.nanmedian(gerak))
lelah = ((ar == -1) & (S.drop12.values >= 4)) | ((ar == 1) & (S.pump12.values >= 4))
KELAS = {"KUAT = volume dan candle di atas median": dorong, "KUAT = volume di atas median": vp >= np.nanmedian(vp),
         "KUAT = volume tinggi dan belum jenuh": dorong & ~lelah}
P(f"MARKET rata per sinyal: KUAT {B['R'][ok & dorong].mean():+.3f}, LEMAH {B['R'][ok & ~dorong].mean():+.3f}")
for x in (0.25, 0.5):
    for W in (6, 12):
        R, hrs, am, isi = pantul_semua(Cx.H, Cx.L, Cx.C, Cx.O, S.k0.values, S.nmax.values, ar.astype(np.int64), S.risk.values, S.atrt.values,
                                       S.tp_r.values, S.trail.values, x, W, Cx.BIAYA)
        P(f"\n-- tunggu koreksi {x}R lalu candle 1J berbalik, maks {W} jam: masuk {isi[ok].mean() * 100:.0f}% sinyal, "
          f"rata R yang masuk {R[isi & ok].mean():+.3f}, MARKET sinyal yang sama {B['R'][isi & ok].mean():+.3f}, "
          f"MARKET sinyal yang tidak masuk {B['R'][~isi & ok].mean():+.3f}")
        for nk, kuat in KELAS.items():
            lem = ~kuat
            gab = dict(R=np.where(lem, R, B["R"]), hrs=np.where(lem, hrs, B["hrs"]), aman=np.where(lem, am, B["aman"]))
            pil = ok & (kuat | isi)
            rr = np.where(lem & ~isi, 0.0, gab["R"])
            P(f"   {nk}: rata R per sinyal LEMAH (0 kalau tidak masuk) {rr[ok & lem].mean():+.3f} lawan MARKET {B['R'][ok & lem].mean():+.3f} "
              f"| 21-23 {rr[ok & lem & (thn < 2024)].mean():+.3f}/{B['R'][ok & lem & (thn < 2024)].mean():+.3f} "
              f"24-26 {rr[ok & lem & (thn >= 2024)].mean():+.3f}/{B['R'][ok & lem & (thn >= 2024)].mean():+.3f}")
            P("   " + fmt(f"KUAT MARKET, LEMAH tunggu pantulan {x}R {W}j ({nk})", jalan(gab, pil), LV).replace("\n", "\n   "))
open(f"{Cx.SC}/hasil_g17.txt", "w").write("\n".join(out))

"""Paritas qse_sektor.py (bot live) dengan backtest run_v154 mesin sektor 'pemimpin0.08 taker0.0'.
1. simulasi() = sim3 untuk 2000 entry acak. 2. cari() pada jendela 60 candle 4J = daftar sinyal backtest, Jan-Okt 2026."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "../..")
SRC154 = open("run_v154.py").read()
src = open("run_v153.py").read().split('P("\\n== 2. ORDER FLOW')[0]
exec(src)
import qse_sektor as SK
rng = np.random.default_rng(1); beda = 0; n = 0
ks = list(Cx.OFF)
while n < 2000:
    s = ks[rng.integers(len(ks))]; a, m = Cx.OFF[s]
    if m < 600: continue
    k = a + rng.integers(300, m - 260); d = int(rng.choice([1, -1])); e = O_[k]; at = (H_[k - 56:k] - L_[k - 56:k]).mean() * 2
    rk = 1.5 * at
    r, h, am = sim3(H_, L_, C_, k, 240, d, e, rk, at, 0.0, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
    sel, r2, h2, sl, aman = SK.simulasi(e, d, rk, at, H_[k:k + 240], L_[k:k + 240], C_[k:k + 240])
    n += 1
    if abs(r - r2) > 1e-9 or h != h2 or not sel:
        beda += 1
print(f"1. simulasi lawan sim3: {n} entry, beda {beda}")
assert beda == 0
# 2. sinyal
T0 = int(pd.Timestamp("2026-01-01", tz="UTC").value // 10**6) // 3600000
seg = SRC154[SRC154.index("# ---------- sektor ----------"):SRC154.index("P(\"sektor selesai\")")]
seg = seg.replace("for tbm in (0.0, 0.55):", "for tbm in (0.0,):").replace("for lead_r in (0.05, 0.08):", "for lead_r in (0.08,):")
seg = seg.replace('        SEMUA.append(sim_list(sig, "sektor", f"pemimpin{lead_r} taker{tbm}"))', "        SIG = list(sig)")
exec(seg)
bt = {(s_, int(k), int(d)) for s_, k, d, rk, at, _, _, _ in SIG}
live = set()
semua_t4 = sorted(set(np.concatenate([DATA[s_]["t4"] for s_ in kol])))
for t in [x for x in semua_t4 if x >= T0 * 3600000]:
    c4 = {}
    for s_ in kol:
        D = DATA[s_]; q = np.searchsorted(D["t4"], t, "right")
        if q < 60 or D["t4"][q - 1] != t:
            continue
        sl_ = slice(q - 60, q)
        c4[s_] = pd.DataFrame(dict(open=D["o4"][sl_], high=D["h4"][sl_], low=D["l4"][sl_], close=D["c4"][sl_], volume=D["v4"][sl_]), index=D["t4"][sl_])
    for x in SK.cari(c4):
        D = DATA[x["sym"]]; q = np.searchsorted(D["t4"], t)
        if q + 1 < len(D["ix"]):
            k = D["a"] + D["ix"][q + 1]; e = O_[k]
            if 0.004 * e <= x["risk"] <= 0.08 * e:
                live.add((x["sym"], int(k), 1 if x["arah"] == "LONG" else -1))
print(f"2. sinyal 2026: backtest {len(bt)}, live {len(live)}, sama {len(bt & live)}, hanya backtest {len(bt - live)}, hanya live {len(live - bt)}")
print(sorted(bt ^ live)[:10])

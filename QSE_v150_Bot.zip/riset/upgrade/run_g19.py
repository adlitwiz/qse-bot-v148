"""Grup 19: (a) profil per koin walk-forward untuk sinyal jalur: koin x jalur x arah boleh dikirim hanya kalau sinyal masa lalunya
(semua sinyal yang SUDAH selesai sebelum masuk, catatan bayangan) PF >= batas. (b) rem darurat: setelah 3 SL beruntun atau rugi harian
-3R, hanya sinyal peluang tertinggi yang boleh (otak 20% teratas dan NILAI 8+), lawan jeda penuh 24 jam (sekarang). (c) maks 4 posisi
jalan per orang (tanpa slot aman tambahan), slot yang terbuka diisi sinyal peluang tertinggi. Pembanding v149 + filter dump 12%."""
import numpy as np, pandas as pd
src = open("run_g15.py").read().split("B = run(")[0]
ns = {"__name__": "g19"}
exec(src, ns)
S, run, P, out, Cx, V, thn = (ns[k] for k in ("S", "run", "P", "out", "Cx", "V", "thn"))
out.clear()
otak, uji = ns["otak"], ns["uji"]
ar = S.arah.values
gerak = S.body.values * S.atr.values / S.px.values * 100 * (-ar)
ok = ~((ar == -1) & (gerak >= 12))
B = run(jk=12, jmode=4, jstop=30)
masuk = S.masuk_h.values
keluar = masuk + B["hrs"]
R = B["R"]
# peluang otak walk-forward (sama dengan live)
from sklearn.ensemble import HistGradientBoostingClassifier
X, y = ns["ns"]["X"], ns["ns"]["y"]
pA = np.full(len(S), np.nan)
for t in (2023, 2024, 2025, 2026):
    pA[thn == t] = HistGradientBoostingClassifier(**ns["ns"]["PARAM"]).fit(X[thn < t], y[thn < t]).predict_proba(X[thn == t])[:, 1]
pc = np.full(len(S), np.nan)
for t in (2023, 2024, 2025, 2026):
    mk = thn == t
    pc[mk] = pd.Series(pA[mk]).rank(pct=True).values
sid = pd.factorize(S.sym.values)[0]
jl = pd.factorize(S.jalur.values)[0]


def porto(pilih, cap=5, runner=2, maks_searah=4, rem="jeda", top=None, urut_peluang=False):
    am = B["aman"]
    aman_t = np.where(am >= 0, masuk + np.maximum(am, 0), keluar)
    idxs = np.nonzero(pilih)[0]
    if urut_peluang:
        idxs = idxs[np.lexsort((-np.nan_to_num(pc[idxs]), masuk[idxs]))]
    buka, antri, trades = [], [], []
    beruntun, rem_dari = 0, None
    for idx in idxs:
        t = masuk[idx]
        if antri:
            antri.sort(); sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if rem_dari is None and beruntun >= 3:
                        rem_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        h0 = (t // 24) * 24
        rugi_hari = sum(x[2] for x in trades if h0 <= x[1] <= t) <= -3
        darurat = (rem_dari is not None and t < rem_dari + 24) or rugi_hari
        if rem_dari is not None and t >= rem_dari + 24:
            rem_dari, beruntun = None, 0
        if darurat:
            if rem == "jeda":
                continue
            if rem == "prioritas" and not (top[idx]):
                continue
        buka = [b for b in buka if b[1] > t]
        if any(b[0] == sid[idx] for b in buka):
            continue
        berisiko = [b for b in buka if b[2] > t]
        if len(berisiko) >= cap or len(buka) >= cap + runner:
            continue
        if sum(1 for b in berisiko if b[3] == ar[idx]) >= maks_searah:
            continue
        buka.append((sid[idx], keluar[idx], aman_t[idx], ar[idx]))
        antri.append((keluar[idx], R[idx]))
        trades.append((t, keluar[idx], R[idx], idx))
    return np.array(trades, float).reshape(-1, 4)


def mt(T):
    r = T[:, 2]; i = T[:, 3].astype(int)
    o = np.argsort(T[:, 1], kind="stable"); eq = np.cumsum(r[o])
    m = dict(n=len(r), wr=np.mean(r > 0) * 100, pf=r[r > 0].sum() / -r[r < 0].sum(), tot=r.sum(), dd=float((np.maximum.accumulate(eq) - eq).max()))
    # kerugian beruntun terpanjang (urut waktu keluar)
    k = mx = 0
    for v in r[o]:
        k = k + 1 if v <= 0 else 0
        mx = max(mx, k)
    m["beruntun"] = mx
    for nm, mk in (("a", thn[i] <= 2024), ("b", thn[i] >= 2025)):
        x = r[mk]; m["pf_" + nm], m["tot_" + nm] = x[x > 0].sum() / -x[x < 0].sum(), x.sum()
    return m


def baris(nm, pilih, **kw):
    s = nm
    for pop in V.PRIMER:
        m = mt(porto(V.POP[pop] & pilih & otak & uji & ok, **kw))
        s += (f"\n    [{pop}] n {m['n']} WR {m['wr']:.1f} PF {m['pf']:.2f} tot {m['tot']:+.0f}R DD {m['dd']:.0f}R rugi beruntun maks {m['beruntun']}"
              f" | 23-24 PF {m['pf_a']:.2f} {m['tot_a']:+.0f} | 25-26 PF {m['pf_b']:.2f} {m['tot_b']:+.0f}")
    return s


semua = np.ones(len(S), bool)
P(baris("v149 sekarang (5 berisiko + 2 aman, jeda 24 jam setelah 3 rugi, rem harian -3R)", semua))
P("\n== (a) profil per koin walk-forward (catatan bayangan semua sinyal yang sudah selesai)")
for grup, gid in (("koin", sid), ("koin x jalur", sid * 100 + jl), ("koin x jalur x arah", (sid * 100 + jl) * 3 + ar + 1)):
    o_ = np.argsort(keluar, kind="stable")
    for nmin, pmin, baru in ((10, 1.0, True), (10, 1.5, True), (10, 1.5, False), (20, 1.2, True)):
        izin = np.ones(len(S), bool)
        for g in np.unique(gid):
            ix = np.nonzero(gid == g)[0]
            ko = ix[np.argsort(keluar[ix], kind="stable")]
            kk, rr = keluar[ko], R[ko]
            cpos, cneg = np.r_[0, np.cumsum(np.maximum(rr, 0))], np.r_[0, np.cumsum(np.maximum(-rr, 0))]
            j = np.searchsorted(kk, masuk[ix], side="right")
            n_ = j
            pf_ = cpos[j] / np.maximum(cneg[j], 1e-9)
            izin[ix] = np.where(n_ >= nmin, pf_ >= pmin, baru)
        r_b = R[~izin & ok & otak & uji]
        P(f"-- {grup}, n masa lalu >= {nmin}, PF masa lalu >= {pmin}, koin/kombinasi baru {'boleh' if baru else 'ditahan'}: "
          f"dibuang {len(r_b)} sinyal, rata R yang dibuang {r_b.mean():+.3f}")
        P(baris("   ", izin))
P("\n== (b) rem darurat")
top = (pc >= 0.8) & (S.nilai_n.values >= 3)
P(baris("rem: jeda penuh 24 jam (sekarang)", semua, rem="jeda"))
P(baris("rem: hanya sinyal peluang 20% teratas + NILAI 8+", semua, rem="prioritas", top=top))
P(baris("tanpa rem", semua, rem="tanpa"))
P("\n== (c) maks posisi jalan per orang")
P(baris("maks 4 posisi jalan total, slot kosong diisi peluang tertinggi", semua, cap=4, runner=0, urut_peluang=True))
P(baris("maks 4 posisi jalan total, urut waktu", semua, cap=4, runner=0))
P(baris("maks 4 + rem prioritas", semua, cap=4, runner=0, urut_peluang=True, rem="prioritas", top=top))
open(f"{Cx.SC}/hasil_g19.txt", "w").write("\n".join(out))

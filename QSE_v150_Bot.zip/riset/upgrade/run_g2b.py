"""Grup 2b: porsi TP sebagian berbeda per kelas NILAI (proksi nilai dari label yang bisa direplikasi)."""
import numpy as np
import var_lib as V
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(s)
S = V.S
kelas = np.where(S.nilai_n.values >= 8, 10, np.where(S.nilai_n.values >= 5, 9, np.where(S.nilai_n.values >= 3, 8, 0)))
base = V.run()
BM = V.port(base, "SEIMBANG")[0]
P("== GRUP 2b. Porsi TP sebagian per kelas NILAI (populasi SEIMBANG = NILAI 8 ke atas). Level tetap +0.5R")
P(V.fmt("dasar 20/20/20", BM))
def porsi(p8, p9, p10):
    return np.where(kelas == 10, p10, np.where(kelas == 9, p9, np.where(kelas == 8, p8, 0.20)))
for nm, (p8, p9, p10) in {"NILAI10 10%, lain 20%": (0.2, 0.2, 0.1), "NILAI10 10%, NILAI9 20%, NILAI8 30%": (0.3, 0.2, 0.1),
                          "NILAI10 10%, NILAI9 15%, NILAI8 20%": (0.2, 0.15, 0.1), "NILAI10 10%, NILAI9 10%": (0.2, 0.1, 0.1),
                          "NILAI8 30%": (0.3, 0.2, 0.2), "NILAI10 30%, NILAI8 10%": (0.1, 0.2, 0.3)}.items():
    res = V.run(tps_por=porsi(p8, p9, p10))
    m, _ = V.port(res, "SEIMBANG")
    d = V.pasangan(res, base, "SEIMBANG")
    per = ""
    for k in (8, 9, 10):
        mk = (kelas == k)
        dd = (res["R"] - base["R"])[mk]
        per += f" k{k}:{dd.mean():+.3f}"
    P(V.fmt(nm, m, BM, f" | dR/sinyal {d[0]:+.4f} t {d[1]:+.1f}{per} lolosP {V.lolos(m, BM, 'P')} lolosW {V.lolos(m, BM, 'W')}"))
open(f"{Cx.SC}/hasil_g2b.txt", "w").write("\n".join(out))

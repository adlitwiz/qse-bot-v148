"""Rapor per tahun (2023, 2024, 2025, 2026), satu orang, NILAI 8+ dan semua sinyal:
v148 lama | v149 tahap 2 (jam 12 dinamis, 30 jam, dump 12%, profil koin, maks 4) | + LONG pump 10% | + kelompok bocor terkonfirmasi (bocor.json)."""
import json, os, numpy as np, pandas as pd
src = open("run_rapor.py").read().split("lama = run()")[0]
ns = {"__name__": "rapor2"}
exec(src, ns)
S, V, thn, otak, uji, ok = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok"))
run, jalankan, profil = ns["run"], ns["jalankan"], ns["profil"]
ar = S.arah.values
pct = S.body.values * S.atr.values / S.px.values * 100 * (-ar)
pump10 = (ar == 1) & (pct >= 10)
bocor = np.zeros(len(S), bool)
import core as Cx
bf = f"{Cx.SC}/bocor.json"
def cari(d, k):
    while k not in d:
        d = d["ns"]
    return d[k]
if os.path.exists(bf):
    Xf = cari(ns, "X").copy()
    Xf["candle_pct"] = pct
    Xf["nilai_n"] = S.nilai_n.values
    for k in ("dist_sup", "dist_res", "rank", "drop12", "pump12"):
        Xf[k] = S[k].values.astype(float)
    for g in json.load(open(bf)):
        x = Xf[g["fitur"]].values.astype(float)
        bocor |= (ar == (1 if g["arah"] == "LONG" else -1)) & (x >= g["dari"]) & (x <= g["sampai"])
lama = run()
UNI = S["rank"].values <= float(os.environ.get("UNI_RANK", "9999"))          # universe seperti bot live: koin likuid teratas
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
rows = []
for nama, res, pil, cap, rn in (("v148 lama", lama, np.ones(len(S), bool), 5, 2), ("v149 tahap 2", baru, ok & izin, 4, 0),
                                ("+ LONG pump 10%", baru, ok & izin & ~pump10, 4, 0), ("+ kelompok bocor", baru, ok & izin & ~pump10 & ~bocor, 4, 0)):
    for pop in V.PRIMER:
        T = jalankan(res, V.POP[pop] & pil & otak & uji & UNI, cap, rn)
        th_t = thn[T[:, 3].astype(int)]
        for per in (2023, 2024, 2025, 2026, "2023-26"):
            m_ = (th_t == per) if per != "2023-26" else np.ones(len(T), bool)
            r = T[m_, 2]; o = np.argsort(T[m_, 1], kind="stable"); eq = np.cumsum(r[o])
            pf = r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9)
            rows.append((nama, "NILAI 8+" if pop == "SEIMBANG" else "semua", per, len(r), round(np.mean(r > 0) * 100, 1), round(pf, 2),
                         round(r.sum()), round(float((np.maximum.accumulate(eq) - eq).max()) if len(eq) else 0)))
D = pd.DataFrame(rows, columns=["versi", "populasi", "tahun", "trade", "WR", "PF", "total_R", "DD_R"])
pd.set_option("display.width", 200)
txt = f"{S.sym.nunique()} koin, bocor dipakai: {int(bocor.sum())} sinyal\n" + D.to_string(index=False)
print(txt)
open(f"{Cx.SC}/hasil_rapor2.txt", "w").write(txt)

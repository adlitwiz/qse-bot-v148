"""Grup 4: entry ulang di sinyal yang masih berlaku setelah trade pertama keluar impas atau rugi."""
import numpy as np
import var_lib as V
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(s)
S = V.S
base = V.run()
BM = {pop: V.port(base, pop)[0] for pop in V.POP}
ar = S.arah.values
Hmin = int(Cx.BZ["Hmin"])
abs_exit = S.masuk_h.values + base["hrs"]
ix = np.clip(abs_exit - Hmin, 0, len(Cx.BZ["naik"]) - 1)
izin = np.where(ar == 1, Cx.BZ["izin_long"][ix], Cx.BZ["izin_short"][ix])
naik = Cx.BZ["naik"][ix]
sejajar = (ar == 1) & naik | (ar == -1) & ~naik
FIL = {"tanpa filter": None, "F1 izin BTC (aturan bot)": izin, "F2 BTC searah EMA50": sejajar}
KD = {"BE (SL di entry setelah TP20)": {Cx.K_SLBE}, "jam 8 (-0.5R)": {Cx.K_SLJ8, Cx.K_J8}, "SL penuh": {Cx.K_SL0},
      "BE + jam 8": {Cx.K_SLBE, Cx.K_SLJ8, Cx.K_J8}, "semua impas atau rugi": {Cx.K_SL0, Cx.K_SLJ8, Cx.K_J8, Cx.K_SLBE}}
P("== GRUP 4. Entry ulang LIMIT di (harga keluar trade pertama - offset x risk), berlaku selama sinyal masih berlaku (umur per jalur), satu kali per sinyal")
P("Jumlah keluar per jenis (semua sinyal): " + ", ".join(f"{n} {int((base['kd'] == k).sum())}" for n, k in (("SL awal", Cx.K_SL0), ("SL jam8", Cx.K_SLJ8), ("tutup jam8", Cx.K_J8), ("SL BE", Cx.K_SLBE), ("SL trailing", Cx.K_SLTR), ("TP", Cx.K_TP), ("36j", Cx.K_36), ("akhir", Cx.K_END))))
for nm, pem in KD.items():
    for off in (0.0, 0.3, 0.5, 1.0):
        re = Cx.entry_ulang(S, base, pem, off)
        for fn, ff in FIL.items():
            row = []
            for pop in V.PRIMER:
                mk = V.POP[pop]
                T = Cx.portofolio(S, base, pilih=mk, re=re, filter_re=ff)
                m = Cx.metrik(T, S)
                b = BM[pop]
                r1 = T[T[:, 5] == 1][:, 3]
                ok = V.lolos(m, b, "P")
                # trade entry ulang: jumlah dan rata R, per periode lewat waktu masuk
                if len(r1):
                    th = (np.array([0]) )
                row.append((pop, m, b, r1, ok))
            s = f"{nm:30s} offset {off:3.1f}R {fn:26s}"
            for pop, m, b, r1, ok in row:
                s += (f"\n     [{pop}] re-entry {len(r1):4d} rata {r1.mean() if len(r1) else 0:+.3f} WR {np.mean(r1 > 0) * 100 if len(r1) else 0:4.1f} PF {Cx.pf(r1):.2f} | "
                      f"portofolio PF {m['pf']:.2f} ({b['pf']:.2f}) tot {m['total']:+4.0f} ({b['total']:+4.0f}) DD {m['dd']:3.0f} ({b['dd']:3.0f}) WR {m['wr']:4.1f} ({b['wr']:4.1f}) "
                      f"| 21-23 PF {m['pf_a']:.2f}/{b['pf_a']:.2f} {m['tot_a']:+4.0f}/{b['tot_a']:+4.0f} | 24-26 PF {m['pf_b']:.2f}/{b['pf_b']:.2f} {m['tot_b']:+4.0f}/{b['tot_b']:+4.0f} lolosP {ok}")
            P(s)
open(f"{Cx.SC}/hasil_g4.txt", "w").write("\n".join(out))

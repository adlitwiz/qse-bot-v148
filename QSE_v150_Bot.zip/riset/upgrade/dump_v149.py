"""Simpan daftar sinyal v149 (m8, seperti bot live) beserta R simulasi tunggal, untuk uji filter lokasi masuk v157."""
import numpy as np, pandas as pd
src = open("run_v153.py").read().split('P("== DASAR ==")')[0]
exec(src)
idx = np.nonzero(m8)[0]
D = pd.DataFrame(dict(sym=S.sym.values[idx], k0=S.k0.values[idx], arah=ar[idx], masuk=masuk[idx], R=baru["R"][idx], th=thn[idx]))
T = jalankan(baru, m8, 4, 0)
D["porto"] = np.isin(idx, T[:, 3].astype(int))
D.to_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v157/v149_sig.pkl")
print(len(D), D.porto.sum(), D.groupby("th").R.agg(["count", "mean"]))

"""v156 (permintaan 4 Nov 08:03): uji gabungan poin yang belum pernah diuji.
A. Aturan keluar SHORT terpisah (TPawal lebih cepat 0.4R, 40% posisi). LONG tetap v149.
B. Profil koin dihitung ulang tiap awal bulan dari jendela 6 bulan terakhir.
C. Altseason: indeks 9 alt besar lawan BTC (7 hari) dan arah BTC 30 hari, mengatur LONG.
D. Perisai berita makro: FOMC, CPI, NFP, PCE, GDP, ECB, BOJ. Tahan atau setengah lot 2 jam sebelum dan sesudah rilis.
E. Ichimoku Kumo Twist 4J + lonjakan volume sebagai mesin mandiri.
F. Segitiga Top 50 atau sektor terpanas + jam aktif + pita Bollinger menyempit.
Pilih di 2023-2024, nilai di 2025-2026. Yang lolos digabung, laporan per bulan 2025-2026. Biaya 0.15% harga."""
import json, numpy as np, pandas as pd
SRC154 = open("run_v154.py").read()
src = open("run_v153.py").read().split('P("\\n== 2. ORDER FLOW')[0]
exec(src)
exec(SRC154[SRC154.index("NAMA = "):SRC154.index("SEMUA = []")])
exec(SRC154[SRC154.index("def ringkas"):SRC154.index("LATIH = ")])
exec(SRC154[SRC154.index("def kantong"):SRC154.index('for nm, x in (("squeeze N50')])
out.clear()
EV = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v154_ev.pkl")
NAMA = pd.factorize(S.sym.values)[1]
pfx = lambda r: r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9)
BL = list(pd.period_range("2025-01", "2026-10", freq="M").strftime("%Y-%m"))

def ev_dari(res, mask, kali=None):
    """Daftar trade v149 dari hasil simulasi res dan mask sinyal. Runner aman dinamis seperti bot."""
    Rr = res["R"]; hrs = res["hrs"]; am = res["aman"]; idx = np.nonzero(mask & np.isfinite(Rr))[0]
    kel = masuk + hrs; o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(Rr[o])]
    j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right"); k7_ = cs[j] - cs[j0]
    jb = np.searchsorted(bT, TS[k0[idx]]) - 1
    erb_ = np.array([abs(bC[q] - bC[q - 80]) / max(np.abs(np.diff(bC[q - 80:q + 1:4])).sum(), 1e-12) if q >= 80 else 0 for q in jb])
    r_ = Rr[idx] * (kali[idx] if kali is not None else 1.0)
    return pd.DataFrame(dict(masuk=masuk[idx], keluar=kel[idx], aman=np.where(am[idx] >= 0, masuk[idx] + np.maximum(am[idx], 0), kel[idx]),
                             sym=NAMA[sid[idx]], arah=ar[idx], R=r_, bulan=bln[idx], runner=np.where((k7_ > 0) & (erb_ >= 0.1), 2, 0)))
def nilai(nm, T, cetak=True):
    T = T.copy(); T["th"] = T.bulan.str[:4].astype(int); h = {}
    for per, m_ in (("23-24", T.th <= 2024), ("25-26", T.th >= 2025)):
        x = T[m_ & (T.th >= 2023)].sort_values("keluar"); r = x.R.values; mg = max((x.masuk.max() - x.masuk.min()) / 168, 1)
        h[per] = dict(n=len(r), mg=len(r) / mg, wr=np.mean(r > 0) * 100, exp=r.mean(), pf=pfx(r), tot=r.sum(), dd=dd(r))
    tm = T[T.th >= 2025].groupby("bulan").R.sum().reindex(BL, fill_value=0)
    h["rugi"] = int((tm < 0).sum()); h["tm"] = tm
    if cetak:
        P(f"   {nm:60s} | " + " | ".join(f"{p} {v['mg']:4.1f}/mgg WR {v['wr']:4.1f}% exp {v['exp']:+.3f}R PF {v['pf']:.2f} tot {v['tot']:+5.0f}R DD {v['dd']:3.0f}R"
                                          for p, v in h.items() if p in ("23-24", "25-26")) + f" | bulan rugi {h['rugi']}/22")
    return h
def pilih(judul, daftar):
    """daftar: (nama, h). Pilih skor latih = total/DD 2023-2024. Lolos kalau uji total naik dan bulan rugi tidak bertambah."""
    b = max(daftar, key=lambda z: z[1]["23-24"]["tot"] / max(z[1]["23-24"]["dd"], 1))
    h0 = daftar[0][1]; h = b[1]
    lolos = b[0] != daftar[0][0] and h["25-26"]["tot"] > h0["25-26"]["tot"] and h["rugi"] <= h0["rugi"]
    P(f"   >> {judul}: pilihan latih '{b[0]}' -> uji tot {h['25-26']['tot']:+.0f}R (dasar {h0['25-26']['tot']:+.0f}R), "
      f"bulan rugi {h['rugi']} (dasar {h0['rugi']}) -> {'LOLOS' if lolos else 'TIDAK LOLOS'}")
    return b if lolos else daftar[0]

P("== DASAR v149 (5 berisiko... seperti bot: 4 berisiko + slot aman dinamis) ==")
D0 = [("v149 sekarang", nilai("v149 sekarang", porto2(ev_dari(baru, m8))))]

P("\n== A. ATURAN KELUAR SHORT TERPISAH (LONG tetap v149) ==")
pool = dasar_mask & ~wkL
DA = list(D0); RES_A = {"v149 sekarang": baru}
for tps, por, be in ((0.4, 0.4, 0.5), (0.4, 0.4, 0.8), (0.3, 0.4, 0.5), (0.4, 0.3, 0.5), (0.5, 0.4, 0.5)):
    rs = jalan3(tps, por, 0.0, be, pilih=pool & (ar == -1))
    gab = {k: np.where(ar == -1, rs[k], baru[k]) for k in ("R", "hrs", "aman")}
    nm = f"SHORT TPawal {por * 100:.0f}% di +{tps}R, SL ke entry di +{be}R"
    RES_A[nm] = gab; DA.append((nm, nilai(nm, porto2(ev_dari(gab, m8)))))
pilA = pilih("aturan keluar SHORT", DA); RES = RES_A[pilA[0]]

P("\n== B. PROFIL KOIN DIHITUNG ULANG TIAP AWAL BULAN ==")
gid = pd.factorize(pd.Series(S.sym.values).astype(str) + "|" + pd.Series(jl).astype(str) + "|" + pd.Series(ar).astype(str))[0]
awal_bln = (pd.to_datetime(bln + "-01", utc=True).astype("int64") // 10**9 // 3600).values
def profil_bergulir(res, jendela_h, nmin, pfmin, acuan="bulan"):
    izin_ = np.zeros(len(S), bool); kel = masuk + res["hrs"]; Rr = res["R"]
    for g in np.unique(gid):
        ix = np.nonzero(gid == g)[0]; ko = ix[np.argsort(kel[ix], kind="stable")]; kk = kel[ko]
        cp = np.r_[0, np.cumsum(np.maximum(np.nan_to_num(Rr[ko]), 0))]; cn = np.r_[0, np.cumsum(np.maximum(-np.nan_to_num(Rr[ko]), 0))]
        t = awal_bln[ix] if acuan == "bulan" else masuk[ix]
        j1 = np.searchsorted(kk, t, side="right"); j0 = np.searchsorted(kk, t - jendela_h, side="right") if jendela_h else np.zeros(len(ix), int)
        n_ = j1 - j0; p_ = (cp[j1] - cp[j0]) / np.maximum(cn[j1] - cn[j0], 1e-9)
        izin_[ix] = (n_ >= nmin) & (p_ >= pfmin)
    return izin_
DB = [("profil sekarang (semua riwayat, tiap sinyal)", nilai("profil sekarang", porto2(ev_dari(RES, m8))))]; MB = {DB[0][0]: m8}
for nm, iz in (("riwayat penuh, dihitung awal bulan", profil_bergulir(RES, 0, 10, 1.3)),
               ("jendela 6 bln, n>=5, PF>=1.3, awal bulan", profil_bergulir(RES, 4320, 5, 1.3)),
               ("jendela 6 bln, n>=8, PF>=1.3, awal bulan", profil_bergulir(RES, 4320, 8, 1.3)),
               ("jendela 6 bln, n>=5, PF>=1.5, awal bulan", profil_bergulir(RES, 4320, 5, 1.5))):
    MB[nm] = pool & iz; DB.append((nm, nilai(nm, porto2(ev_dari(RES, pool & iz)))))
    nm2 = "profil sekarang ATAU " + nm
    MB[nm2] = pool & (izin | iz); DB.append((nm2, nilai(nm2, porto2(ev_dari(RES, pool & (izin | iz))))))
pilB = pilih("profil koin", DB); M = MB[pilB[0]]

P("\n== C. ALTSEASON (9 alt besar lawan BTC 7 hari, BTC 30 hari, dari candle harian yang sudah tutup) ==")
ALT9 = ("ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "LINKUSDT", "AVAXUSDT", "BNBUSDT", "LTCUSDT")
def harian(s):
    a, n = Cx.OFF[s]; t = pd.to_datetime(TS[a:a + n], unit="ms", utc=True)
    return pd.Series(C_[a:a + n], index=t).resample("1D").last()
bd_ = harian("BTCUSDT"); al = pd.concat([np.log(harian(s)) for s in ALT9 if s in Cx.OFF], axis=1)
alt7 = al.diff(7).mean(axis=1); rasio7 = alt7 - np.log(bd_).diff(7); btc30 = bd_ / bd_.shift(30) - 1
hari = pd.to_datetime(TS[k0], unit="ms", utc=True).floor("1D") - pd.Timedelta(days=1)       # pakai hari yang sudah tutup
kn = (rasio7.reindex(hari).values > 0); bn = (btc30.reindex(hari).values > 0)
REZ = {"alt naik, BTC naik": kn & bn, "alt naik, BTC turun": kn & ~bn, "BTC naik, alt tertinggal": ~kn & bn, "alt dan BTC lemah": ~kn & ~bn}
for nm, mz in REZ.items():
    for d, dn in ((1, "LONG"), (-1, "SHORT")):
        x = M & mz & (ar == d)
        P(f"   {nm:26s} {dn:5s} sinyal v149: 23-24 n {int((x & lat).sum()):4d} exp {np.nanmean(RES['R'][x & lat]):+.3f}R | 25-26 n {int((x & tes).sum()):4d} exp {np.nanmean(RES['R'][x & tes]):+.3f}R")
DC = [("tanpa altseason", nilai("tanpa altseason", porto2(ev_dari(RES, M))))]; MC = {DC[0][0]: M}
for nm, mz in REZ.items():
    m_ = M & ~(mz & (ar == 1)); MC[f"tahan LONG saat {nm}"] = m_
    DC.append((f"tahan LONG saat {nm}", nilai(f"tahan LONG saat {nm}", porto2(ev_dari(RES, m_)))))
longgar = pool & (ar == 1) & REZ["alt naik, BTC naik"]
m_ = M | longgar; MC["longgarkan LONG (tanpa gerbang profil) saat alt naik dan BTC naik"] = m_
DC.append(("longgarkan LONG (tanpa gerbang profil) saat alt naik dan BTC naik", nilai("longgarkan LONG saat alt naik dan BTC naik", porto2(ev_dari(RES, m_)))))
m_ = (M & ~(REZ["alt naik, BTC turun"] & (ar == 1))) | longgar; MC["tahan LONG saat jebakan alt + longgarkan saat alt dan BTC naik"] = m_
DC.append(("tahan LONG saat jebakan alt + longgarkan saat alt dan BTC naik", nilai("jebakan alt ditahan + longgar saat keduanya naik", porto2(ev_dari(RES, m_)))))
pilC = pilih("altseason", DC); M = MC[pilC[0]]

P("\n== D. PERISAI BERITA MAKRO (2 jam sebelum dan sesudah rilis) ==")
MK = json.load(open("../berita/makro_tanggal.json"))
JAM = {"FOMC": 18, "CPI": 12, "NFP": 12, "PCE": 12, "GDP": 12, "ECB": 12, "BOJ": 3}
ev_jam = np.array(sorted(int(pd.Timestamp(d + f" {JAM[k]:02d}:30", tz="UTC").value // 10**9 // 3600) for k, v in MK.items() for d in v))
def dekat(t, kunci=None, w=2):
    jj = ev_jam if kunci is None else np.array(sorted(int(pd.Timestamp(d + f" {JAM[k]:02d}:30", tz="UTC").value // 10**9 // 3600) for k in kunci for d in MK[k]))
    q = np.searchsorted(jj, t); a_ = np.abs(t - jj[np.clip(q - 1, 0, len(jj) - 1)]); b_ = np.abs(jj[np.clip(q, 0, len(jj) - 1)] - t)
    return np.minimum(a_, b_) <= w
dk_all = dekat(masuk); dk_big = dekat(masuk, ("FOMC", "CPI", "NFP"))
P(f"   sinyal v149 dekat rilis (semua jenis): 23-24 exp {np.nanmean(RES['R'][M & dk_all & lat]):+.3f}R n {int((M & dk_all & lat).sum())} | "
  f"25-26 exp {np.nanmean(RES['R'][M & dk_all & tes]):+.3f}R n {int((M & dk_all & tes).sum())}")
DD_ = [("tanpa perisai", nilai("tanpa perisai", porto2(ev_dari(RES, M))))]; MD = {DD_[0][0]: (M, None)}
for nm, dk in (("semua rilis", dk_all), ("FOMC, CPI, NFP saja", dk_big)):
    MD[f"tahan sinyal dekat {nm}"] = (M & ~dk, None); DD_.append((f"tahan sinyal dekat {nm}", nilai(f"tahan sinyal dekat {nm}", porto2(ev_dari(RES, M & ~dk)))))
    kl = np.where(dk, 0.5, 1.0); MD[f"setengah lot dekat {nm}"] = (M, kl)
    DD_.append((f"setengah lot dekat {nm}", nilai(f"setengah lot dekat {nm}", porto2(ev_dari(RES, M, kl)))))
pilD = pilih("perisai makro", DD_); M, KALI = MD[pilD[0]]
UTAMA = porto2(ev_dari(RES, M, KALI))

P("\n== E. ICHIMOKU KUMO TWIST 4J + LONJAKAN VOLUME (mesin mandiri) ==")
def hh_(x, n): return pd.Series(x).rolling(n).max().values
def ll_(x, n): return pd.Series(x).rolling(n).min().values
def ichi(vk, btc_f, slm):
    sig = []
    for s_, D in DATA.items():
        h, l, c, v, a = D["h4"], D["l4"], D["c4"], D["v4"], D["a"]; ix = D["ix"]; at = D["at4"]
        tk = (hh_(h, 9) + ll_(l, 9)) / 2; kj = (hh_(h, 26) + ll_(l, 26)) / 2
        spa = (tk + kj) / 2; spb = (hh_(h, 52) + ll_(l, 52)) / 2                      # awan masa depan (twist)
        sa = np.r_[np.full(26, np.nan), spa[:-26]]; sb = np.r_[np.full(26, np.nan), spb[:-26]]   # awan sekarang
        va = pd.Series(v).rolling(20).mean().shift(1).values; arb = btc_arah(D["t4"] + 14400000)
        lewat = -1; i0 = max(np.searchsorted(D["t4"], T0 * 3600000), 80)
        for i in range(i0, len(c) - 1):
            if i <= lewat or not np.isfinite(sa[i]) or not np.isfinite(at[i]):
                continue
            twist_up = spa[i] > spb[i] and spa[i - 1] <= spb[i - 1]; twist_dn = spa[i] < spb[i] and spa[i - 1] >= spb[i - 1]
            d = 1 if (twist_up and c[i] > max(sa[i], sb[i])) else (-1 if (twist_dn and c[i] < min(sa[i], sb[i])) else 0)
            if d == 0 or not v[i] >= vk * va[i] or (btc_f and d != arb[i]) or i + 1 >= len(ix):
                continue
            k = a + ix[i + 1]; e = O_[k]
            sl = (kj[i] if slm == "kijun" else e - d * 1.5 * at[i]); rk = (e - sl) * d
            if 0.004 * e <= rk <= 0.08 * e:
                sig.append((s_, k, d, rk, at[i], None, D["t4"][i], 4)); lewat = i + 6
    return sig
IC = []
for vk in (1.5, 2.0):
    for bf in (False, True):
        for slm in ("kijun", "atr"):
            nm = f"vol {vk}x, BTC searah {'ya' if bf else 'tidak'}, SL {slm}"
            ev = sim_list(ichi(vk, bf, slm), "ichimoku", nm)
            la = ev[(ev.th >= 2023) & (ev.th <= 2024)]; te = ev[ev.th >= 2025]
            P(f"   {nm:40s} latih {ringkas(la)} | uji {ringkas(te)}"); IC.append((la.R.mean() if len(la) >= 60 else -9, nm, ev))
b = max(IC, key=lambda z: z[0]); ICHI = b[2]; te = ICHI[ICHI.th >= 2025]
P(f"   >> pilihan latih: {b[1]} -> uji {ringkas(te)} PF {pfx(te.R.values):.2f}")

P("\n== F. SEGITIGA: Top 50 ATAU sektor terpanas minggu itu, + jam aktif, + pita Bollinger menyempit ==")
SEK = {}
for sec, cs in {"L1": "ADA ALGO APT ATOM AVAX BCH CELO CFX CKB DOT EGLD ETC HBAR ICP ICX IOTA KAVA KSM LTC MINA NEAR NEO ONE ONT QTUM ROSE SEI SOL SUI TRX VET XLM XRP XTZ ZIL DASH RVN ZEC TIA INJ",
                "L2": "ARB OP IMX LRC SKL STX", "DEFI": "1INCH AAVE COMP CRV DYDX GMX JUP KNC LDO PENDLE SNX SUSHI UNI YFI ZRX RUNE ENA WOO UMA",
                "ORACLE": "API3 BAND LINK PYTH TRB GRT", "MEME": "1000BONK 1000FLOKI 1000PEPE 1000SHIB DOGE WIF BONK FLOKI PEPE SHIB", "AI": "FET WLD NMR ARPA IOTX",
                "GAME": "ALICE APE AXS ENJ GALA GMT MANA SAND HOOK CHZ THETA", "DEPIN": "AR FIL STORJ ANKR JASMY"}.items():
    for c_ in cs.split():
        SEK[c_ + "USDT"] = sec
# return 7 hari per koin per jam (candle 1J tutup), median per sektor, peringkat
def ret7(s_, ms):
    a, n = Cx.OFF[s_]; q = np.searchsorted(TS[a:a + n], ms) - 1
    return C_[a + q] / C_[a + q - 168] - 1 if q >= 168 else np.nan
SG = EV[EV.mesin == "segitiga"].copy()
SG["ms"] = SG.masuk * 3600000
SG["sek"] = SG.sym.map(SEK)
jam_u = np.unique(SG.ms.values); panas = {}
kol = [s_ for s_ in DATA if s_ in SEK]
for t in jam_u:
    r = pd.Series({s_: ret7(s_, t) for s_ in kol}).groupby(lambda s_: SEK[s_]).median().dropna()
    panas[t] = set(r.sort_values(ascending=False).index[:2]) if len(r) else set()
SG["panas"] = [s_ in SEK and SEK[s_] in panas.get(t, set()) for s_, t in zip(SG.sym, SG.ms)]
def bbw_pct(s_, ms):
    D = DATA[s_]; q = np.searchsorted(D["t4"], ms - 14400000, "right") - 1
    if q < 120:
        return np.nan
    c = pd.Series(D["c4"][q - 119:q + 1]); bw = (c.rolling(20).std() / c.rolling(20).mean()).dropna().values
    return (bw[:-1] < bw[-1]).mean()
SG["bbw"] = [bbw_pct(s_, t) for s_, t in zip(SG.sym, SG.ms)]
FS = []
for var, g in SG.groupby("varian"):
    for fn, fm in (("Top 50", g.tier < 50), ("Top 50 atau sektor panas", (g.tier < 50) | g.panas), ("Top 50 atau sektor panas + jam aktif", ((g.tier < 50) | g.panas) & g.kz),
                   ("Top 50 atau sektor panas + pita sempit", ((g.tier < 50) | g.panas) & (g.bbw <= 0.3)),
                   ("Top 50 atau sektor panas + jam aktif + pita sempit", ((g.tier < 50) | g.panas) & g.kz & (g.bbw <= 0.3))):
        x = g[fm.values]; la = x[(x.th >= 2023) & (x.th <= 2024)]
        FS.append((la.R.mean() if len(la) >= 40 else -9, f"{var} | {fn}", x))
for sc, nm, x in sorted(FS, key=lambda z: -z[0])[:8]:
    la = x[(x.th >= 2023) & (x.th <= 2024)]; te = x[x.th >= 2025]
    P(f"   {nm:72s} latih {ringkas(la)} | uji {ringkas(te)}")
b = max(FS, key=lambda z: z[0]); SEGF = b[2]; te = SEGF[SEGF.th >= 2025]
P(f"   >> pilihan latih: {b[1]} -> uji {ringkas(te)} PF {pfx(te.R.values) if len(te) else 0:.2f}")

P("\n== G. KANTONG PELENGKAP (slot sendiri maks 2, lot 0.5x) bersama v149 hasil A-D ==")
hU = nilai("v149 hasil A-D (utama)", UTAMA)
SQ = EV[(EV.mesin == "squeeze") & (EV.varian == "N50 vol2.0")]; IMP = EV[(EV.mesin == "impuls") & (EV.varian == "rentang0.04 vol4.0")]
SEKT = EV[(EV.mesin == "sektor") & (EV.varian == "pemimpin0.08 taker0.0")]
KAND = {"Ichimoku Kumo Twist": ICHI, "Segitiga tersaring": SEGF, "Squeeze N50 vol2": SQ, "Impuls 4% vol4": IMP, "Sektor 8%": SEKT}
hasil_k = {}
for nm, x in KAND.items():
    K_ = kantong(x)
    h = nilai(f"+ kantong {nm}", pd.concat([UTAMA, K_]))
    lolos_latih = h["23-24"]["tot"] > hU["23-24"]["tot"]
    hasil_k[nm] = (h, lolos_latih, K_)
    P(f"      latih 23-24 menambah {h['23-24']['tot'] - hU['23-24']['tot']:+.1f}R -> {'dipakai' if lolos_latih else 'tidak dipakai'} | "
      f"uji 25-26 menambah {h['25-26']['tot'] - hU['25-26']['tot']:+.1f}R, bulan rugi {h['rugi']} (utama {hU['rugi']})")
pakai = [nm for nm, v in hasil_k.items() if v[1]]
if pakai:
    KG = kantong(pd.concat([KAND[nm] for nm in pakai]))
    hG = nilai(f"SISTEM GABUNGAN: utama + kantong ({', '.join(pakai)})", pd.concat([UTAMA, KG]))
else:
    hG = hU; KG = UTAMA.iloc[0:0]
P("\n== H. PER BULAN 2025-2026 (R) ==")
h0 = D0[0][1]
P(f"   {'bulan':8s} {'v149 sekarang':>14s} {'utama A-D':>10s} {'gabungan':>9s}")
for b_ in BL:
    P(f"   {b_:8s} {h0['tm'][b_]:+14.1f} {hU['tm'][b_]:+10.1f} {hG['tm'][b_]:+9.1f}")
P(f"   {'total':8s} {h0['tm'].sum():+14.1f} {hU['tm'].sum():+10.1f} {hG['tm'].sum():+9.1f}")
P(f"   bulan rugi: v149 {h0['rugi']}, utama {hU['rugi']}, gabungan {hG['rugi']}")
P(f"   pilihan: A '{pilA[0]}' | B '{pilB[0]}' | C '{pilC[0]}' | D '{pilD[0]}' | kantong {pakai}")
open("hasil_v156.txt", "w").write("\n".join(out))

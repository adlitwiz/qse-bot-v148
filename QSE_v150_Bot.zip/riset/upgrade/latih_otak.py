"""Otak robot: model penilai sinyal. Fitur hanya yang bisa dihitung sama persis di live (qse_otak.fitur).
1. Uji walk-forward tahunan (latih tahun sebelumnya saja), buang 10% peluang terendah, aturan lolos P di 2023-24 dan 2025-26.
2. Latih model akhir dengan semua data, ekspor ke otak_model.json (pohon keputusan, dibaca qse_otak tanpa sklearn).
3. Cek pembaca numpy sama dengan sklearn."""
import json, os, sys, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score
import var_lib as V, core as Cx
JALUR = ["ema_short", "ichimoku", "mcginley", "msb_hpz", "orderblock", "rsi_vol", "smc_choch", "snr_vol"]
KOLOM = (["jalur", "arah", "vp", "drop6", "pump6", "drop12", "pump12", "body", "dist_lo50", "dist_hi50", "pos50",
         "atr_pct", "jam", "hari", "btc24", "btc168", "koin168", "mp", "mm"])
PARAM = dict(max_depth=3, learning_rate=0.05, max_iter=200, min_samples_leaf=200, l2_regularization=1.0, categorical_features=[0],
             random_state=0)          # sama dengan uji run_g7b/g7c (jalur kategori)
BUANG = 0.10
S = V.S
base = V.run()
Rb = base["R"]
y = (Rb > 0).astype(int)
thn = S.tahun.values
out = []
def P(s=""):
    print(s, flush=True); out.append(s)

X = pd.DataFrame(index=S.index)
X["jalur"] = np.array([JALUR.index(j) for j in S.jalur.values], float)
X["arah"] = S.arah.astype(float)
X["vp"] = S.vp.astype(float)
for k in ("drop6", "pump6", "drop12", "pump12", "body", "dist_lo50", "dist_hi50"):
    X[k] = S[k].astype(float).clip(-20, 20)
lo, hi = S.px - S.dist_lo50 * S.atr, S.px + S.dist_hi50 * S.atr
X["pos50"] = ((S.px - lo) / (hi - lo).where(hi > lo)).clip(-1, 2)
X["atr_pct"] = S.atr / S.px * 100
X["jam"] = (S.masuk_h % 24).astype(float)
X["hari"] = ((S.masuk_h // 24 + 3) % 7).astype(float)
a, n = Cx.OFF["BTCUSDT"]
bt, bc = Cx.TS[a:a + n], Cx.C[a:a + n]
j = np.clip(np.searchsorted(bt, S.masuk_h.values * 3600000) - 1, 168, n - 1)
X["btc24"] = (bc[j] / bc[j - 24] - 1) * 100
X["btc168"] = (bc[j] / bc[j - 168] - 1) * 100
k0 = S.k0.values
X["koin168"] = (Cx.C[k0 - 1] / Cx.C[np.maximum(k0 - 169, 0)] - 1) * 100 - X["btc168"].values
X["mp"] = S.mp.astype(float)
X["mm"] = S.mm.astype(float)
X = X[KOLOM]

pr = np.full(len(S), np.nan)
for t in (2023, 2024, 2025, 2026):
    m = HistGradientBoostingClassifier(**PARAM).fit(X[thn < t], y[thn < t])
    pr[thn == t] = m.predict_proba(X[thn == t])[:, 1]
    P(f"walk-forward {t}: AUC {roc_auc_score(y[thn == t], pr[thn == t]):.3f}")
uji = thn >= 2023
buang = np.zeros(len(S), bool)
for t in (2023, 2024, 2025, 2026):
    mk = thn == t
    buang[mk] = pr[mk] < np.quantile(pr[mk], BUANG)
def mt(T):
    r, i = T[:, 3], T[:, 4].astype(int)
    o = dict(n=len(r), wr=np.mean(r > 0) * 100, pf=r[r > 0].sum() / -r[r < 0].sum(), tot=r.sum())
    eq = np.cumsum(r); o["dd"] = float(np.max(np.maximum.accumulate(eq) - eq))
    for nm, mk in (("a", thn[i] <= 2024), ("b", thn[i] >= 2025)):
        x = r[mk]
        o["pf_" + nm], o["tot_" + nm], o["wr_" + nm] = x[x > 0].sum() / -x[x < 0].sum(), x.sum(), np.mean(x > 0) * 100
    return o
lolos_semua = True
for pop in V.PRIMER:
    b = mt(Cx.portofolio(S, base, pilih=V.POP[pop] & uji))
    v = mt(Cx.portofolio(S, base, pilih=V.POP[pop] & uji & ~buang))
    ok = V.lolos(v, b, "P")
    lolos_semua &= ok
    P(f"[{pop}] 2023-2026 n {v['n']}/{b['n']} WR {v['wr']:.1f}/{b['wr']:.1f} PF {v['pf']:.2f}/{b['pf']:.2f} tot {v['tot']:+.0f}/{b['tot']:+.0f} DD {v['dd']:.0f}/{b['dd']:.0f}"
      f" | 2023-24 PF {v['pf_a']:.2f}/{b['pf_a']:.2f} tot {v['tot_a']:+.0f}/{b['tot_a']:+.0f} | 2025-26 PF {v['pf_b']:.2f}/{b['pf_b']:.2f} tot {v['tot_b']:+.0f}/{b['tot_b']:+.0f} | lolosP {ok}")
    r_b = Rb[buang & V.POP[pop] & uji]
    P(f"    sinyal yang dibuang: {len(r_b)} rata {r_b.mean():+.3f}R WR {np.mean(r_b > 0) * 100:.1f}")
P(f"LOLOS SEMUA: {lolos_semua}")

# model akhir: semua data
M = HistGradientBoostingClassifier(**PARAM).fit(X, y)
p_all = M.predict_proba(X)[:, 1]
batas = float(np.quantile(p_all[thn >= 2025], BUANG))
pohon = []
for it in M._predictors:
    nd = it[0].nodes
    pohon.append(dict(f=nd["feature_idx"].tolist(), t=[float(x) for x in nd["num_threshold"]], l=nd["left"].tolist(),
                      r=nd["right"].tolist(), leaf=nd["is_leaf"].astype(int).tolist(), v=[float(x) for x in nd["value"]],
                      kiri_nan=nd["missing_go_to_left"].astype(int).tolist(), kat=nd["is_categorical"].astype(int).tolist(),
                      bi=nd["bitset_idx"].tolist(), bits=np.asarray(it[0].raw_left_cat_bitsets).astype(np.int64).tolist()))
model = dict(kolom=KOLOM, jalur=JALUR, awal=float(np.ravel(M._baseline_prediction)[0]), pohon=pohon, batas=batas, buang=BUANG,
             dilatih="Binance spot 1 jam, 96 koin, 2021-2026, %d sinyal" % len(S))
json.dump(model, open(os.environ.get("OTAK_OUT", "otak_model.json"), "w"))
# cek pembaca
sys.path.insert(0, os.path.abspath("../.."))
import importlib
os.environ.setdefault("QSE_STATE_DIR", "/tmp/otak_cek")
spec = importlib.util.spec_from_file_location("otak_baca", os.path.abspath("../../qse_otak.py"))
if os.path.exists(spec.origin):
    ob = importlib.util.module_from_spec(spec); spec.loader.exec_module(ob)
    mdl = ob._muat(os.environ.get("OTAK_OUT", "otak_model.json"))
    pn = np.array([ob.peluang_x(mdl, row) for row in X.values[:3000]])
    P(f"cek pembaca numpy lawan sklearn: selisih maks {np.abs(pn - p_all[:3000]).max():.2e}")
P(f"batas peluang (10% terendah 2025-2026): {batas:.4f}")
open(f"{Cx.SC}/hasil_otak.txt", "w").write("\n".join(out))

"""Grup 3: filter LONG setelah dump tajam, filter SHORT dekat support (dan LONG dekat resistance)."""
import numpy as np
import var_lib as V
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(s)
S = V.S
base = V.run()
BM = {pop: V.port(base, pop)[0] for pop in V.POP}
ar = S.arah.values
Rb = base["R"]

def uji(nm, buang):
    """buang = mask sinyal yang DIBUANG. Per populasi: portofolio tanpa sinyal itu + statistik sinyal yang dibuang."""
    keep = ~buang
    s = ""
    for pop in V.PRIMER:
        mk = V.POP[pop]
        b = buang & mk
        rem = Rb[b]
        ra, rb_ = Rb[b & V.PA], Rb[b & V.PB]
        m, _ = V.port(base, pop, pilih=keep)
        ok = V.lolos(m, BM[pop], "P")
        s += (f"\n    [{pop}] buang {b.sum():5d} ({b.sum() / mk.sum() * 100:4.1f}%) rata R dibuang {rem.mean() if len(rem) else 0:+.3f} (21-23 {ra.mean() if len(ra) else 0:+.3f}, 24-26 {rb_.mean() if len(rb_) else 0:+.3f}) "
              f"WR {np.mean(rem > 0) * 100 if len(rem) else 0:4.1f} | portofolio: PF {m['pf']:.2f} (dasar {BM[pop]['pf']:.2f}) tot {m['total']:+4.0f} ({BM[pop]['total']:+4.0f}) DD {m['dd']:3.0f} ({BM[pop]['dd']:3.0f}) "
              f"21-23 PF {m['pf_a']:.2f}/{BM[pop]['pf_a']:.2f} {m['tot_a']:+4.0f}/{BM[pop]['tot_a']:+4.0f} 24-26 PF {m['pf_b']:.2f}/{BM[pop]['pf_b']:.2f} {m['tot_b']:+4.0f}/{BM[pop]['tot_b']:+4.0f} lolosP {ok}")
    P(f"{nm}{s}")

P("== GRUP 3a. LONG setelah dump tajam (buang LONG kalau dump >= X ATR sebelum sinyal)")
for X in (2, 3, 4, 5, 6):
    uji(f"LONG buang kalau turun dari tertinggi 6 candle 4J (24 jam) >= {X} ATR", (ar == 1) & (S.drop6.values >= X))
for X in (3, 4, 6, 8):
    uji(f"LONG buang kalau turun dari tertinggi 12 candle 4J (48 jam) >= {X} ATR", (ar == 1) & (S.drop12.values >= X))
for X in (1.5, 2, 3):
    uji(f"LONG buang kalau candle sinyal merah panjang (open-close) >= {X} ATR", (ar == 1) & (S.body.values >= X))
P()
P("== GRUP 3a'. Cermin: SHORT setelah naik tajam (info saja)")
for X in (3, 4, 5):
    uji(f"SHORT buang kalau naik dari terendah 6 candle >= {X} ATR", (ar == -1) & (S.pump6.values >= X))
P()
P("== GRUP 3b. SHORT dekat support (jarak ke support pivot terdekat di bawah, ATR) dan LONG dekat resistance")
for D in (0.5, 1.0, 1.5, 2.0, 3.0):
    uji(f"SHORT buang kalau jarak ke support pivot < {D} ATR", (ar == -1) & (S.dist_sup.values < D))
for D in (0.5, 1.0, 1.5, 2.0, 3.0):
    uji(f"LONG buang kalau jarak ke resistance pivot < {D} ATR", (ar == 1) & (S.dist_res.values < D))
for D in (0.5, 1.0, 1.5, 2.0):
    uji(f"SHORT dekat support DAN LONG dekat resistance < {D} ATR", ((ar == -1) & (S.dist_sup.values < D)) | ((ar == 1) & (S.dist_res.values < D)))
P()
P("== GRUP 3b'. Versi low/high 50 candle (bukan pivot)")
for D in (0.5, 1.0, 1.5, 2.0):
    uji(f"SHORT buang kalau jarak ke low 50 candle < {D} ATR", (ar == -1) & (S.dist_lo50.values < D))
    uji(f"LONG buang kalau jarak ke high 50 candle < {D} ATR", (ar == 1) & (S.dist_hi50.values < D))
open(f"{Cx.SC}/hasil_g3.txt", "w").write("\n".join(out))

"""Grup 5: SnR dengan syarat break atau retracement, ukuran Fibonacci 0.886.
Rentang = high dan low 50 candle 4J sebelum sinyal. pos = (harga - low) / (high - low), 0 di dasar, 1 di puncak.
SHORT dengan pos kecil = menjual di dekat support (risiko memantul). LONG dengan pos besar = membeli di dekat resistance.
Break = harga sudah tutup di luar rentang (dist_lo50 < 0 untuk SHORT, dist_hi50 < 0 untuk LONG). Fib 0.886: pos < 0.114 atau > 0.886."""
import numpy as np
import var_lib as V
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(s)
S = V.S
base = V.run()
BM = {pop: V.port(base, pop)[0] for pop in V.POP}
ar = S.arah.values
Rb = base["R"]
px, at = S.px.values, S.atr.values
lo50 = px - S.dist_lo50.values * at
hi50 = px + S.dist_hi50.values * at
rng = np.where(hi50 > lo50, hi50 - lo50, np.nan)
pos = (px - lo50) / rng
brk_s = S.dist_lo50.values < 0
brk_l = S.dist_hi50.values < 0
snr = (S.jalur.values == "snr_vol")

def uji(nm, buang):
    keep = ~buang
    s = ""
    for pop in V.PRIMER:
        mk = V.POP[pop]
        b = buang & mk
        rem = Rb[b]
        m, _ = V.port(base, pop, pilih=keep)
        ok = V.lolos(m, BM[pop], "P")
        okw = V.lolos(m, BM[pop], "W")
        s += (f"\n    [{pop}] buang {b.sum():5d} ({b.sum() / mk.sum() * 100:4.1f}%) rata R dibuang {rem.mean() if len(rem) else 0:+.3f} WR dibuang {np.mean(rem > 0) * 100 if len(rem) else 0:4.1f} | "
              f"WR {m['wr']:4.1f} ({BM[pop]['wr']:4.1f}) PF {m['pf']:.2f} ({BM[pop]['pf']:.2f}) tot {m['total']:+4.0f} ({BM[pop]['total']:+4.0f}) DD {m['dd']:3.0f} ({BM[pop]['dd']:3.0f}) "
              f"21-23 PF {m['pf_a']:.2f}/{BM[pop]['pf_a']:.2f} 24-26 PF {m['pf_b']:.2f}/{BM[pop]['pf_b']:.2f} lolosP {ok} lolosW {okw}")
    P(f"{nm}{s}")

P(f"snr_vol: {snr.sum()} sinyal dari {len(S)}. SHORT {int((snr & (ar == -1)).sum())}, LONG {int((snr & (ar == 1)).sum())}")
for nm, msk in (("SEMUA JALUR", np.ones(len(S), bool)), ("HANYA snr_vol", snr)):
    P(f"\n== {nm}")
    for q in (0.114, 0.25, 0.40, 0.50):
        uji(f"[{nm}] SHORT buang kalau pos < {q} (belum break)", msk & (ar == -1) & (pos < q) & ~brk_s)
        uji(f"[{nm}] SHORT buang kalau pos < {q} (termasuk yang break)", msk & (ar == -1) & (pos < q))
    for q in (0.114, 0.25, 0.40, 0.50):
        uji(f"[{nm}] LONG buang kalau pos > {1 - q:.3f} (belum break)", msk & (ar == 1) & (pos > 1 - q) & ~brk_l)
    q = 0.114
    uji(f"[{nm}] SHORT dan LONG di zona Fib 0.886 (belum break)", msk & (((ar == -1) & (pos < q) & ~brk_s) | ((ar == 1) & (pos > 1 - q) & ~brk_l)))
    uji(f"[{nm}] Retracement: SHORT hanya kalau pos >= 0.5 atau break", msk & (ar == -1) & (pos < 0.5) & ~brk_s)
    uji(f"[{nm}] Retracement: LONG hanya kalau pos <= 0.5 atau break", msk & (ar == 1) & (pos > 0.5) & ~brk_l)
open(f"{Cx.SC}/hasil_g5.txt", "w").write("\n".join(out))

"""segitiga (permintaan 3 Nov 23:01): slot aman dinamis + 4 mesin sinyal mandiri.
Asal: uji 6 perubahan permintaan user 3 Nov 2026 (11:04 dan 11:06). Data Binance 383 koin 1J, universe 150 likuid, satu orang.
Semua keputusan pakai data sebelum sinyal. Ambang dipilih di 2023-2024, dinilai di 2025-2026. Biaya 0.15% harga.
1. Rem 7 hari jadi mode: saat rem, hanya NILAI 10 (skor 90) dan/atau setengah risiko, bukan tahan total.
   Gerbang profil dilonggarkan (gabungan semua jalur arah sama, min 5). LONG akhir pekan boleh kalau volume 24 jam >= 2x rata 30 hari.
2. TPawal 40-50% di +0.5R, SL ke -0.25R, SL ke entry di +0.8R. Posisi aman tidak dihitung dalam batas 4 (runner).
3. Sapuan likuiditas 1 dan 2 candle 4J + volume >= 2x, di support kuat (disentuh >= 2x) atau divergensi RSI.
   Derivatif BTC (Binance Futures): BTC turun + OI turun + funding sangat minus -> SHORT ditahan (cermin untuk LONG).
4. Masuk koreksi: tunggu koreksi di 1J, Conditional Stop di atas high candle pantulan, SL di ujung ekor pantulan, TP dihitung ulang.
5. Laporan: per bulan 2025-2026, sinyal per minggu, WR, PF, DD, v149 lawan gabungan perubahan yang lolos."""
import os, numpy as np, pandas as pd
from numba import njit
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "v150"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
import core as Cx
DERIV = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/deriv"
CSV = os.path.join(Cx.SC, "data")
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
H_, L_, C_, O_, TS = Cx.H, Cx.L, Cx.C, Cx.O, Cx.TS
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
ar = S.arah.values; jl = S.jalur.values; masuk = S.masuk_h.values; k0 = S.k0.values
dow = pd.to_datetime(S["T"].values, unit="ms", utc=True).dayofweek.values
wkL = (ar == 1) & (dow >= 5)
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
dasar_mask = ok & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
m8 = dasar_mask & izin & ~wkL                         # v149 seperti bot live (akhir pekan LONG ditahan)
lat = thn <= 2024; tes = thn >= 2025
minggu = lambda T: max((T[:, 0].max() - T[:, 0].min()) / 168, 1) if len(T) else 1
def nilai(nm, T, ringkas=True):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]; th_ = thn[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    t2 = T[th_ >= 2025]; r2 = t2[:, 2]
    P(f"   {nm:56s} n {len(r):5d} {len(r) / minggu(T):4.1f}/mgg WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} tot {r.sum():+5.0f}R DD {dd(r[o_]):3.0f}R | "
      f"PF<1 {int((pm < 1).sum()):2d}/{len(pm)} terburuk {tm.min():+5.1f} | 23-24 PF {pf(r[th_ <= 2024]):.2f} | 25-26 n/mgg {len(r2) / minggu(t2):4.1f} "
      f"WR {np.mean(r2 > 0) * 100 if len(r2) else 0:4.1f}% PF {pf(r2):.2f} DD {dd(r2[np.argsort(t2[:, 1], kind='stable')]):3.0f}R")
    return T
# rem 7 hari dari trade kertas semua sinyal m8 yang sudah selesai
def rem_flag(res, pilih, batas=-3.0):
    R = res["R"]; kel = masuk + res["hrs"]; idx = np.nonzero(pilih)[0]
    o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
    f = np.zeros(len(S), bool)
    j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
    f[idx] = (cs[j] - cs[j0]) < batas
    return f
def skala(T, mask_half):
    T = T.copy(); h = mask_half[T[:, 3].astype(int)]; T[h, 2] *= 0.5; return T
P("== DASAR ==")
rem = rem_flag(baru, m8)
B0 = nilai("v149 tanpa rem 7 hari", jalankan(baru, m8, 4, 0))
B1 = nilai("v149 + rem 7 hari TOTAL (terpasang)", jalankan(baru, m8 & ~rem, 4, 0))


P("\nMetrik: per minggu, WR, expectancy, total, DD, total/DD. Latih 2023-2024, uji 2025-2026. Lulus: uji expectancy >= +0.15R, n >= 100.")
@njit(cache=False)
def sim3(Hh, L, C, k0, n, d, e, risk, atrt, tp_r, trail, tps_lv, por, sl_aft, be_lv, jk, jstop):
    sl = e - d * risk; best = e; sisa = 1.0; real = 0.0; aman = -1; tpsd = False
    lvp = e + d * tps_lv * risk; lvb = e + d * be_lv * risk
    has_tp = tp_r > 0; tp = e + d * tp_r * risk
    for j in range(n):
        hi = Hh[k0 + j]; lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if not tpsd and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += por * tps_lv; sisa = 1.0 - por; tpsd = True
            nsl = e + d * sl_aft * risk
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if tpsd and aman < 0 and ((d == 1 and hi >= lvb) or (d == -1 and lo <= lvb)):
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1
        if tpsd and aman < 0 and sl_aft >= 0:
            aman = j + 1
        if has_tp and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        if d == 1:
            if hi > best: best = hi
        else:
            if lo < best: best = lo
        if j % 4 == 3 and trail > 0:
            nsl = best - d * trail * atrt
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if not tpsd and j + 1 == jk:
            rn = (C[k0 + j] - e) * d / risk
            if rn <= -0.5:
                return real + sisa * rn, j + 1, aman
            if rn < 0:
                nsl = e - d * 0.5 * risk
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
        if not tpsd and j + 1 == jstop:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman
def jalan3(tps_lv, por, sl_aft, be_lv, k0a=None, ea=None, riska=None, nmaxa=None, pilih=None):
    pilih = m8 if pilih is None else pilih
    Rn = np.full(len(S), np.nan); hn = np.zeros(len(S), np.int64); an = np.full(len(S), -1, np.int64)
    k0a = k0 if k0a is None else k0a; nmaxa = S.nmax.values if nmaxa is None else nmaxa
    for i in np.nonzero(pilih)[0]:
        if k0a[i] < 0:
            continue
        e = O_[k0a[i]] if ea is None else ea[i]; rk = S.risk.values[i] if riska is None else riska[i]
        r, h, a = sim3(H_, L_, C_, k0a[i], nmaxa[i], ar[i], e, rk, S.atrt.values[i], S.tp_r.values[i], S.trail.values[i],
                       tps_lv, por, sl_aft, be_lv, 12, 30)
        Rn[i] = r - Cx.BIAYA * e / rk; hn[i] = h + (k0a[i] - k0[i]); an[i] = a + (k0a[i] - k0[i]) if a >= 0 else -1
    return dict(R=Rn, hrs=hn, aman=an)

R = baru["R"]; sid = pd.factorize(S.sym.values)[0]
def porto2(ev, cap=4, runner=None, jeda=True):
    """ev: DataFrame masuk, keluar, aman, sym, arah, R, (runner boleh). Satu orang, maks cap berisiko + runner aman, jeda 24 jam setelah 3 rugi."""
    ev = ev.sort_values("masuk", kind="stable")
    buka, trades = [], []; beruntun = 0; jeda_dari = None; antri = []
    for z in ev.itertuples():
        t = z.masuk
        if antri:
            antri.sort(); sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and beruntun >= 3:
                        jeda_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        if jeda and jeda_dari is not None:
            if t >= jeda_dari + 24:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b[1] > t]
        if any(b[0] == z.sym for b in buka):
            continue
        rn = int(getattr(z, "runner", 0)) if runner is None else runner
        berisiko = [b for b in buka if b[2] > t]
        if len(berisiko) >= cap or len(buka) >= cap + rn:
            continue
        if sum(1 for b in berisiko if b[3] == z.arah) >= 4:
            continue
        buka.append((z.sym, z.keluar, z.aman, z.arah)); antri.append((z.keluar, z.R)); trades.append((t, z.keluar, z.R, z.bulan))
    return pd.DataFrame(trades, columns=["masuk", "keluar", "R", "bulan"])
def ukur(nm, T, cetak=True):
    T = T.copy(); T["th"] = T.bulan.str[:4].astype(int)
    hasil = {}
    for per, m_ in (("23-24", (T.th >= 2023) & (T.th <= 2024)), ("25-26", T.th >= 2025)):
        x = T[m_].sort_values("keluar"); r = x.R.values; d_ = dd(r)
        mg = max((x.masuk.max() - x.masuk.min()) / 168, 1) if len(x) else 1
        hasil[per] = dict(n=len(r), mg=len(r) / mg, wr=np.mean(r > 0) * 100 if len(r) else 0, exp=r.mean() if len(r) else 0, tot=r.sum(), dd=d_)
    if cetak:
        tm = T[T.th >= 2025].groupby("bulan").R.sum()
        P(f"   {nm:60s} | " + " | ".join(f"{p} {h['mg']:4.1f}/mgg WR {h['wr']:4.1f}% exp {h['exp']:+.3f}R tot {h['tot']:+5.0f}R DD {h['dd']:3.0f}R tot/DD {h['tot'] / max(h['dd'], 1e-9):4.1f}"
                                         for p, h in hasil.items()) + f" | 25-26 bulan rugi {int((tm < 0).sum())}/{len(tm)}")
    return hasil
bulan_of = lambda tms: pd.to_datetime(tms, unit="ms", utc=True).strftime("%Y-%m")
ev_v149 = pd.DataFrame(dict(masuk=masuk[m8], keluar=masuk[m8] + baru["hrs"][m8],
                            aman=np.where(baru["aman"][m8] >= 0, masuk[m8] + np.maximum(baru["aman"][m8], 0), masuk[m8] + baru["hrs"][m8]),
                            sym=sid[m8], arah=ar[m8], R=R[m8], bulan=bln[m8]))
P("\n== 1. SLOT AMAN DINAMIS ==")
ukur("v149 slot 4 (tanpa rem 7 hari, pembanding mesin)", porto2(ev_v149, runner=0))
ukur("v149 slot 4+2 selalu", porto2(ev_v149, runner=2))
# kertas 7 hari dan efisiensi BTC 20 candle 4J saat sinyal
idx = np.nonzero(m8)[0]; kel = masuk + baru["hrs"]
o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
k7 = cs[j] - cs[j0]
b0, bl = Cx.OFF["BTCUSDT"]; bT = TS[b0:b0 + bl]; bC = C_[b0:b0 + bl]
jb = np.searchsorted(bT, TS[k0[idx]]) - 1
erb = np.array([abs(bC[q] - bC[q - 80]) / max(np.abs(np.diff(bC[q - 80:q + 1:4])).sum(), 1e-12) if q >= 80 else 0 for q in jb])
for ambang in (0.1, 0.2, 0.3):
    fl = (k7 > 0) & (erb >= ambang)
    ev = ev_v149.copy(); ev["runner"] = np.where(fl, 2, 0)
    ukur(f"slot +2 hanya saat kertas 7 hari positif & efisiensi BTC >= {ambang}", porto2(ev))
ev = ev_v149.copy(); ev["runner"] = np.where(k7 > 0, 2, 0)
ukur("slot +2 hanya saat kertas 7 hari positif", porto2(ev))

# ---------- data per koin untuk mesin baru ----------
ranks = S.groupby("sym")["rank"].median()
koin = [s for s in Cx.OFF if s in ranks.index and ranks[s] <= 150]
DATA = {}
for s in koin:
    a, n = Cx.OFF[s]
    f = os.path.join(CSV, f"{s}_60.csv")
    if not os.path.exists(f):
        continue
    vv = pd.read_csv(f, usecols=["volume"]).volume.values.astype(float)
    if len(vv) != n:
        continue
    t = TS[a:a + n]; g = t // 14400000; ix = np.r_[0, np.nonzero(np.diff(g))[0] + 1]
    h4 = np.maximum.reduceat(H_[a:a + n], ix); l4 = np.minimum.reduceat(L_[a:a + n], ix)
    c4 = C_[a + np.r_[ix[1:] - 1, n - 1]]; o4 = O_[a + ix]; v4 = np.add.reduceat(vv, ix)
    DATA[s] = dict(a=a, n=n, v=vv, ix=ix, h4=h4, l4=l4, c4=c4, o4=o4, v4=v4, t4=t[ix],
                   at4=pd.Series(h4 - l4).rolling(14).mean().values)
# tren BTC 4J: close di atas EMA 50
bd = DATA.get("BTCUSDT")
btc_e50 = pd.Series(bd["c4"]).ewm(span=50, adjust=False).mean().values
def btc_arah(tms):
    q = np.searchsorted(bd["t4"], np.asarray(tms) - 14400000, "right") - 1          # candle 4J BTC yang sudah TUTUP sebelum waktu tms
    q = np.clip(q, 0, len(bd["c4"]) - 1)
    return np.where(bd["c4"][q] > btc_e50[q], 1, -1)
def nilai_mesin(nm, sig):
    """sig: list (sym, k_global_entry, arah, risk, atrt). Simulasi aturan keluar v149 di 1J. Satu posisi per koin."""
    rows = []; terakhir = {}
    for s, k, d, rk, at in sorted(sig, key=lambda z: z[1]):
        a, n = Cx.OFF[s]
        if k >= a + n - 2 or rk <= 0 or not np.isfinite(at):
            continue
        if terakhir.get(s, -1) >= k:
            continue
        e = O_[k]
        nmax = min(240, a + n - k - 1)
        r, h, am = sim3(H_, L_, C_, k, nmax, d, e, rk, at, 0.0, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
        terakhir[s] = k + h
        mh = TS[k] // 3600000
        rows.append((mh, mh + h, mh + (am if am >= 0 else h), s, d, r - Cx.BIAYA * e / rk, bulan_of([TS[k]])[0]))
    ev = pd.DataFrame(rows, columns=["masuk", "keluar", "aman", "sym", "arah", "R", "bulan"])
    ev["th"] = ev.bulan.str[:4].astype(int)
    la = ev[(ev.th >= 2023) & (ev.th <= 2024)].R.values; te = ev[ev.th >= 2025].R.values
    mg = lambda x: len(x) / max((x.masuk.max() - x.masuk.min()) / 168, 1) if len(x) else 0
    P(f"   {nm:62s} latih n {len(la):5d} ({mg(ev[(ev.th >= 2023) & (ev.th <= 2024)]):4.1f}/mgg) WR {np.mean(la > 0) * 100 if len(la) else 0:4.1f}% exp {la.mean() if len(la) else 0:+.3f}R"
      f" | uji n {len(te):5d} ({mg(ev[ev.th >= 2025]):4.1f}/mgg) WR {np.mean(te > 0) * 100 if len(te) else 0:4.1f}% exp {te.mean() if len(te) else 0:+.3f}R tot/DD "
      f"{te.sum() / max(dd(ev[ev.th >= 2025].sort_values('keluar').R.values), 1e-9):4.1f}")
    return ev, (la.mean() if len(la) >= 100 else -9)
LULUS = {}
def pilih_terbaik(judul, hasil):
    best = max(hasil, key=lambda z: z[2])
    ev = best[1]; te = ev[ev.th >= 2025].R.values
    ok_ = len(te) >= 100 and te.mean() >= 0.15
    P(f"   >> dipilih di latih: {best[0]} | uji exp {te.mean() if len(te) else 0:+.3f}R n {len(te)} -> {'LULUS' if ok_ else 'TIDAK LULUS'}")
    if ok_:
        LULUS[judul] = ev


TAKER = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/taker"
for s_, D in DATA.items():
    f = f"{TAKER}/{s_}.npz"
    D["dl1"] = None
    if not os.path.exists(f):
        continue
    z = np.load(f); a, n = D["a"], D["n"]; t1 = TS[a:a + n]
    j = np.searchsorted(z["t"], t1); j = np.clip(j, 0, len(z["t"]) - 1); okm = z["t"][j] == t1
    v_ = np.where(okm, z["v"][j], np.nan); tb = np.where(okm, z["tb"][j], np.nan)
    net = 2 * tb - v_
    D["dl1"] = (pd.Series(net).rolling(20, min_periods=15).sum() / pd.Series(v_).rolling(20, min_periods=15).sum()).values
    ix = D["ix"]
    net4 = np.add.reduceat(np.nan_to_num(net), ix); v4 = np.add.reduceat(np.nan_to_num(v_), ix)
    D["dl4"] = (pd.Series(net4).rolling(20).sum() / pd.Series(v4).rolling(20).sum()).values
    D["tbr4"] = np.add.reduceat(np.nan_to_num(tb), ix) / np.maximum(v4, 1e-12)
P(f"   koin dengan data taker buy: {sum(1 for D in DATA.values() if D.get('dl1') is not None)} dari {len(DATA)}")

P("\n== 6. ASCENDING / DESCENDING TRIANGLE (1J dan 4J) ==")
def pivots(h, l, k=2):
    n = len(h); ph = []; pl = []
    for i in range(k, n - k):
        if h[i] == h[i - k:i + k + 1].max():
            ph.append(i)
        if l[i] == l[i - k:i + k + 1].min():
            pl.append(i)
    return np.array(ph, int), np.array(pl, int)
def segitiga(h, l, c, v, tol, ntouch):
    """Kembalikan pola LONG (ascending) dan SHORT (descending) yang terbentuk di candle i (pivot sudah terkonfirmasi 2 candle).
    (i, arah, garis_datar, ayunan_terakhir, mulut_awal)."""
    ph, pl = pivots(h, l)
    rg = h - l; out = []; lewat = {1: -1, -1: -1}
    for i in range(65, len(c) - 1):
        for d in (1, -1):
            if i <= lewat[d]:
                continue
            A, Bp = (ph, pl) if d == 1 else (pl, ph)          # A = sisi datar, Bp = sisi miring
            a0, a1 = np.searchsorted(A, i - 60), np.searchsorted(A, i - 2, "right")
            ca = A[a0:a1]
            if len(ca) < ntouch:
                continue
            harga = h[ca] if d == 1 else l[ca]
            garis = harga.max() if d == 1 else harga.min()
            sentuh = ca[np.abs(harga - garis) / garis <= tol / 100]
            if len(sentuh) < ntouch:
                continue
            awal = sentuh[0]
            if not (15 <= i - awal <= 60):
                continue
            seg_c = c[awal:i + 1]
            if (d == 1 and seg_c.max() > garis * (1 + tol / 100)) or (d == -1 and seg_c.min() < garis * (1 - tol / 100)):
                continue
            b0, b1 = np.searchsorted(Bp, awal), np.searchsorted(Bp, i - 2, "right")
            cb = Bp[b0:b1]
            if len(cb) < 2:
                continue
            hb = l[cb] if d == 1 else h[cb]
            naik = np.all(np.diff(hb[-2:]) > 0) if d == 1 else np.all(np.diff(hb[-2:]) < 0)
            if not naik or np.polyfit(cb, hb, 1)[0] * d <= 0:
                continue
            sepertiga = max((i - awal) // 3, 3)
            if rg[i - sepertiga:i + 1].mean() >= rg[awal:awal + sepertiga].mean():
                continue
            out.append((i, d, garis, hb[-1], hb[0]))
            lewat[d] = i + 5
    return out
def sim_sig(sig):
    """sig: (sym, k, arah, risk, atrt, tp_r). Keluar v149. Satu posisi per koin."""
    rows = []; terakhir = {}
    for s_, k, d, rk, at, tpr in sorted(sig, key=lambda z: z[1]):
        a, n = Cx.OFF[s_]
        if k >= a + n - 2 or terakhir.get(s_, -1) >= k or not np.isfinite(at) or rk <= 0:
            continue
        e = O_[k]; nmax = min(240, a + n - k - 1)
        r, h, am = sim3(H_, L_, C_, k, nmax, d, e, rk, at, tpr, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
        terakhir[s_] = k + h; mh = TS[k] // 3600000
        rows.append((mh, mh + h, mh + (am if am >= 0 else h), s_, d, r - Cx.BIAYA * e / rk, bulan_of([TS[k]])[0]))
    ev = pd.DataFrame(rows, columns=["masuk", "keluar", "aman", "sym", "arah", "R", "bulan"]); ev["th"] = ev.bulan.str[:4].astype(int)
    return ev
def lapor(nm, ev, nmin=50):
    la = ev[(ev.th >= 2023) & (ev.th <= 2024)]; te = ev[ev.th >= 2025]
    mg = lambda x: len(x) / max((x.masuk.max() - x.masuk.min()) / 168, 1) if len(x) else 0
    f = lambda x: f"n {len(x):4d} ({mg(x):4.1f}/mgg) WR {np.mean(x.R > 0) * 100 if len(x) else 0:4.1f}% exp {x.R.mean() if len(x) else 0:+.3f}R"
    P(f"   {nm:70s} latih {f(la)} | uji {f(te)}")
    return la.R.mean() if len(la) >= nmin else -9
# BTC efisiensi 20 candle 4J saat waktu ms (candle tutup)
bc4 = bd["c4"]
def btc_er(tms):
    q = np.searchsorted(bd["t4"], np.asarray(tms) - 14400000, "right") - 1
    return np.array([abs(bc4[x] - bc4[x - 20]) / max(np.abs(np.diff(bc4[x - 20:x + 1])).sum(), 1e-12) if x >= 20 else 0 for x in np.atleast_1d(q)])
hasil = []
for tf in (1, 4):
    for tol in (0.3, 0.5):
        for nt in (2, 3):
            sigA = {0: [], 1: []}; sigB = {(vk, tp): [] for vk in (1.5, 2.0) for tp in (0, 1)}
            for s_, D in DATA.items():
                a, n = D["a"], D["n"]
                if tf == 1:
                    h, l, c, v = H_[a:a + n], L_[a:a + n], C_[a:a + n], D["v"]; tbar = TS[a:a + n]; dl = D.get("dl1")
                    kmap = lambda i: a + i + 1; at_of = lambda i: D["at4"][min(np.searchsorted(D["ix"], i, "right") - 1, len(D["at4"]) - 1)]
                    jam = 1
                else:
                    h, l, c, v = D["h4"], D["l4"], D["c4"], D["v4"]; tbar = D["t4"]; dl = D.get("dl4")
                    kmap = lambda i, ix=D["ix"]: a + ix[i + 1] if i + 1 < len(ix) else -1; at_of = lambda i: D["at4"][i]
                    jam = 4
                va = pd.Series(v).rolling(20).mean().shift(1).values
                for (i, d, garis, ayun, mulut) in segitiga(h, l, c, v, tol, nt):
                    tinggi = abs(garis - mulut)
                    sl = ayun * (1 - 0.001) if d == 1 else ayun * (1 + 0.001)
                    # B: candle tutup menembus garis dengan volume, dalam 6 candle sesudah pola terbentuk
                    for j in range(i + 1, min(i + 7, len(c) - 1)):
                        if (l[j] < ayun) if d == 1 else (h[j] > ayun):
                            break
                        if (c[j] > garis) if d == 1 else (c[j] < garis):
                            for vk in (1.5, 2.0):
                                if v[j] >= vk * va[j]:
                                    k = kmap(j)
                                    if k > 0:
                                        e = O_[k]; rk = (e - sl) * d
                                        if 0.003 * e <= rk <= 0.08 * e:
                                            for tp in (0, 1):
                                                sigB[(vk, tp)].append((s_, k, d, rk, at_of(j), ((garis + d * tinggi - e) * d / rk) if tp else 0.0))
                            break
                    # A: Conditional Stop 0.15% di luar garis, dipasang saat pola terbentuk, berlaku 6 candle TF, isi di candle 1J
                    if not (btc_er(tbar[i] + jam * 3600000)[0] >= 0.1 and dl is not None and np.isfinite(dl[i]) and dl[i] * d >= 0):
                        continue
                    stop = garis * (1 + d * 0.0015)
                    g0 = a + (i + 1 if tf == 1 else (D["ix"][i + 1] if i + 1 < len(D["ix"]) else n)) if tf == 1 else (a + D["ix"][i + 1] if i + 1 < len(D["ix"]) else a + n)
                    if tf == 1:
                        g0 = a + i + 1
                    g1 = min(g0 + 6 * jam, a + n - 1)
                    for g in range(g0, g1):
                        if (L_[g] <= sl) if d == 1 else (H_[g] >= sl):
                            break
                        if (H_[g] >= stop) if d == 1 else (L_[g] <= stop):
                            e = max(stop, O_[g]) if d == 1 else min(stop, O_[g]); rk = (e - sl) * d
                            if 0.003 * e <= rk <= 0.08 * e:
                                for tp in (0, 1):
                                    sigA[tp].append((s_, g, d, rk, at_of(i), ((garis + d * tinggi - e) * d / rk) if tp else 0.0, e))
                            break
            for tp in (0, 1):
                # entry A di harga stop (bukan open candle): geser O_ sementara lewat sim khusus
                rows = []; terakhir = {}
                for s_, k, d, rk, at, tpr, e in sorted(sigA[tp], key=lambda z: z[1]):
                    a, n = Cx.OFF[s_]
                    if terakhir.get(s_, -1) >= k:
                        continue
                    nmax = min(240, a + n - k - 1)
                    r, hh, am = sim3(H_, L_, C_, k, nmax, d, e, rk, at, tpr, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
                    terakhir[s_] = k + hh; mh = TS[k] // 3600000
                    rows.append((mh, mh + hh, mh + (am if am >= 0 else hh), s_, d, r - Cx.BIAYA * e / rk, bulan_of([TS[k]])[0]))
                ev = pd.DataFrame(rows, columns=["masuk", "keluar", "aman", "sym", "arah", "R", "bulan"]); ev["th"] = ev.bulan.str[:4].astype(int)
                nm = f"TF {tf}J tol {tol}% sentuh {nt} | A Conditional Stop, BTC tren + delta | TP {'proyeksi mulut' if tp else 'trailing v149'}"
                hasil.append((lapor(nm, ev), nm, ev))
            for (vk, tp), sg in sigB.items():
                ev = sim_sig(sg)
                nm = f"TF {tf}J tol {tol}% sentuh {nt} | B tutup candle + volume {vk}x | TP {'proyeksi mulut' if tp else 'trailing v149'}"
                hasil.append((lapor(nm, ev), nm, ev))
best = max(hasil, key=lambda z: z[0])
te = best[2][best[2].th >= 2025]
P(f"   >> dipilih di latih: {best[1]} (exp latih {best[0]:+.3f}R) -> uji exp {te.R.mean() if len(te) else 0:+.3f}R WR {np.mean(te.R > 0) * 100 if len(te) else 0:.1f}% "
  f"n {len(te)} -> {'LULUS' if len(te) >= 100 and te.R.mean() >= 0.15 else 'TIDAK LULUS'}")
P(f"   per arah (uji): " + ", ".join(f"{'LONG' if d == 1 else 'SHORT'} n {len(g)} exp {g.R.mean():+.3f}R" for d, g in te.groupby("arah")))
open("hasil_segitiga.txt", "w").write("\n".join(out))

"""Pustaka kecil untuk uji variasi: populasi, baseline, perbandingan, aturan lolos."""
import numpy as np, pandas as pd
import core as Cx

S = pd.read_pickle(f"{Cx.SC}/S.pkl")
POP = {"SEMUA": np.ones(len(S), bool), "SEIMBANG": (S.nilai_n >= 3).values, "PROFIT": (S.nilai_n >= 5).values}
PRIMER = ("SEMUA", "SEIMBANG")
THN = S.tahun.values
PA, PB = THN < 2024, THN >= 2024
BASE_P = dict(tps_lv=0.5, tps_por=0.20, sl_aft=0.0, jk=8, jthr=-0.5, jsl=-0.5, jstop=36)
_cache = {}


def run(**kw):
    p = dict(BASE_P)
    p.update(kw)
    key = tuple(sorted((k, (tuple(v) if hasattr(v, "__len__") else v)) for k, v in p.items()))
    if key not in _cache:
        _cache[key] = Cx.jalankan(S, **p)
    return _cache[key]


def port(res, pop, pilih=None, **kw):
    mk = POP[pop] if pilih is None else (POP[pop] & pilih)
    T = Cx.portofolio(S, res, pilih=mk, **kw)
    return Cx.metrik(T, S), T


def lolos(m, b, aturan="P"):
    """Aturan lolos pada satu populasi: kedua periode. P: PF naik >= 0.02, total R >= 95% dasar, WR tidak turun lebih dari 1 poin.
    W: WR naik >= 2 poin, PF tidak turun lebih dari 0.01, total R >= 85% dasar."""
    ok = True
    for per in ("a", "b"):
        if aturan == "P":
            ok &= (m["pf_" + per] >= b["pf_" + per] + 0.02) and (m["tot_" + per] >= 0.95 * b["tot_" + per]) and (m["wr_" + per] >= b["wr_" + per] - 1.0)
        else:
            ok &= (m["wr_" + per] >= b["wr_" + per] + 2.0) and (m["pf_" + per] >= b["pf_" + per] - 0.01) and (m["tot_" + per] >= 0.85 * b["tot_" + per])
    return bool(ok)


def pasangan(res, base, pop):
    """Selisih R per sinyal (varian - dasar) pada populasi: rata-rata, t, dan per periode."""
    mk = POP[pop]
    d = (res["R"] - base["R"])[mk]
    t = d.mean() / (d.std(ddof=1) / np.sqrt(len(d))) if d.std(ddof=1) > 0 else 0.0
    da = (res["R"] - base["R"])[mk & PA]
    db = (res["R"] - base["R"])[mk & PB]
    return d.mean(), t, da.mean(), db.mean()


def fmt(nm, m, b=None, ps=""):
    def dl(k, f="{:+.2f}"):
        return f.format(m[k] - b[k]) if b else ""
    s = (f"{nm:40s} n {m['n']:5d} WR {m['wr']:4.1f} PF {m['pf']:.2f} tot {m['total']:+5.0f} DD {m['dd']:3.0f} | "
         f"21-23 WR {m['wr_a']:4.1f} PF {m['pf_a']:.2f} {m['tot_a']:+4.0f} | 24-26 WR {m['wr_b']:4.1f} PF {m['pf_b']:.2f} {m['tot_b']:+4.0f}")
    if b:
        s += f" | dPF {m['pf_a'] - b['pf_a']:+.2f}/{m['pf_b'] - b['pf_b']:+.2f} dTot {m['tot_a'] - b['tot_a']:+4.0f}/{m['tot_b'] - b['tot_b']:+4.0f}"
    return s + ps

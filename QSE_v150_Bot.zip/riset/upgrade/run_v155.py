"""v155 (permintaan 4 Nov 07:17): Swing Pivot Sniper 4J + putar haluan, memori adaptif jangka pendek,
ranking tunggal Squeeze + Segitiga Top 50, kantong pelengkap dengan Auto-Promotion.
Parameter dipilih di 2023-2024, dinilai di 2025-2026. Semua keputusan pakai data sebelum sinyal. Biaya 0.15% harga."""
import os, numpy as np, pandas as pd
SRC154 = open("run_v154.py").read()
src = open("run_v153.py").read().split('P("\\n== 2. ORDER FLOW')[0]
exec(src)
exec(SRC154[SRC154.index("NAMA = "):SRC154.index("SEMUA = []")])
exec(SRC154[SRC154.index("def ringkas"):SRC154.index("LATIH = ")])
exec(SRC154[SRC154.index("BULAN_UJI"):SRC154.index("WF = {}")])
exec(SRC154[SRC154.index("# ---------- v149 sebagai"):SRC154.index('P("\\n== 2. MESIN')])
exec(SRC154[SRC154.index("def kantong"):SRC154.index('for nm, x in (("squeeze N50')])
out.clear()
TV = porto_isi(pd.DataFrame(columns=evv.columns).assign(jenis="x", runner=0), "sepi", 1.0)
DASAR = bulanan(TV[TV.th >= 2025])
EV = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v154_ev.pkl")
def dua(nm, ev):
    la = ev[(ev.th >= 2023) & (ev.th <= 2024)]; te = ev[ev.th >= 2025]
    P(f"   {nm:64s} latih {ringkas(la)} | uji {ringkas(te)}")
    return la.R.mean() if len(la) >= 60 else -9

# =====================================================================================================
P("== 1. SWING PIVOT SNIPER 4J (masuk di ujung struktur, bukan mengejar breakout) ==")
P("   Zona Demand/Supply = titik balik terkonfirmasi (pivot 3 candle) dalam 20 atau 50 candle 4J terakhir, lebar 0.5 atau 1 ATR.")
P("   LONG: low menyentuh Demand atau Golden Pocket 0.618-0.786, tidak tembus low ayunan (toleransi 0.2 ATR), lalu 1 candle hijau")
P("   menutup di atas setengah candle sentuh. SL di bawah ekor terendah - 0.1 ATR. TP = batas Resistance ayunan. SHORT cermin.")
def piv(h, l, k=3):
    n = len(h); ph = np.zeros(n, bool); pl = np.zeros(n, bool)
    for i in range(k, n - k):
        ph[i] = h[i] == h[i - k:i + k + 1].max(); pl[i] = l[i] == l[i - k:i + k + 1].min()
    return ph, pl
SN = {}
for s_, D in DATA.items():
    h, l, c, o = D["h4"], D["l4"], D["c4"], D["o4"]; ph, pl = piv(h, l)
    SN[s_] = (np.nonzero(ph)[0], np.nonzero(pl)[0])
def sniper(win, lebar, rrmin, gp):
    sig = []
    for s_, D in DATA.items():
        h, l, c, o, at = D["h4"], D["l4"], D["c4"], D["o4"], D["at4"]; PH, PL = SN[s_]; ix = D["ix"]; a = D["a"]
        if len(c) < 120:
            continue
        i_mulai = np.searchsorted(D["t4"], T0 * 3600000)
        for j in range(max(i_mulai, 60), len(c) - 2):          # j = candle konfirmasi (sudah tutup), masuk di open j+1
            A = at[j]
            if not np.isfinite(A) or A <= 0:
                continue
            i = j - 1                                            # candle sentuh
            ph = PH[(PH >= j - win) & (PH <= j - 4)]; pl = PL[(PL >= j - win) & (PL <= j - 4)]   # pivot terkonfirmasi (3 candle kanan)
            if not len(ph) or not len(pl):
                continue
            hi_s = h[ph].max(); lo_s = l[pl].min(); rng_s = hi_s - lo_s
            if rng_s <= 2 * A:
                continue
            for d in (1, -1):
                if d == 1:
                    zona = l[i] <= lo_s + lebar * A or (gp and lo_s + 0.214 * rng_s <= l[i] <= lo_s + 0.382 * rng_s)
                    tahan = min(l[i], l[j]) >= lo_s - 0.2 * A
                    konf = c[j] > o[j] and c[j] > (h[i] + l[i]) / 2
                    sl = min(l[i], l[j]) - 0.1 * A; tp = hi_s - 0.25 * A
                else:
                    zona = h[i] >= hi_s - lebar * A or (gp and hi_s - 0.382 * rng_s <= h[i] <= hi_s - 0.214 * rng_s)
                    tahan = max(h[i], h[j]) <= hi_s + 0.2 * A
                    konf = c[j] < o[j] and c[j] < (h[i] + l[i]) / 2
                    sl = max(h[i], h[j]) + 0.1 * A; tp = lo_s + 0.25 * A
                if not (zona and tahan and konf):
                    continue
                k = a + ix[j + 1]; e = O_[k]; rk = (e - sl) * d; rr = (tp - e) * d / rk if rk > 0 else 0
                if 0.003 * e <= rk <= 0.08 * e and rr >= rrmin:
                    sig.append((s_, k, d, rk, A, rr, D["t4"][j]))
    return sig
def sim_sn(sig, tp_mode, jstop, varian):
    rows = []; terakhir = {}; prev = {}
    for s_, k, d, rk, at, rr, tj in sorted(sig, key=lambda z: z[1]):
        a, n = Cx.OFF[s_]
        if k >= a + n - 2 or terakhir.get(s_, -1) >= k:
            continue
        e = O_[k]; nmax = min(240, a + n - k - 1)
        r, hh, am = sim3(H_, L_, C_, k, nmax, d, e, rk, at, rr if tp_mode == "struktur" else 0.0, 3.0, 0.5, 0.2, 0.0, 0.5, 12, jstop)
        terakhir[s_] = k + hh; mh = TS[k] // 3600000
        pv = prev.get(s_)
        estafet = pv is not None and pv[0] == -d and pv[2] > 0 and mh - pv[1] <= 12
        R_ = r - Cx.BIAYA * e / rk
        rows.append((mh, mh + hh, mh + (am if am >= 0 else hh), s_, d, R_, bulan_of([TS[k]])[0], kena_kz(tj, 4), tier(s_, TS[k]),
                     "sniper", varian, estafet, rr))
        prev[s_] = (d, mh + hh, R_)
    ev = pd.DataFrame(rows, columns=["masuk", "keluar", "aman", "sym", "arah", "R", "bulan", "kz", "tier", "mesin", "varian", "estafet", "rr"])
    ev["th"] = ev.bulan.str[:4].astype(int); return ev
PILS = []
for win in (20, 50):
    for lebar in (0.5, 1.0):
        for rrm in (1.0, 1.5):
            sig = sniper(win, lebar, rrm, True)
            for tpm in ("struktur", "trailing"):
                for js in (30, 120):
                    nm = f"jendela {win} lebar {lebar}ATR RR>={rrm} TP {tpm} batas {js}j"
                    ev = sim_sn(sig, tpm, js, nm); PILS.append((dua(nm, ev), nm, ev))
b = max(PILS, key=lambda z: z[0]); SNIPER = b[2]; te = SNIPER[SNIPER.th >= 2025]
P(f"   >> dipilih di latih: {b[1]} (latih exp {b[0]:+.3f}R) -> uji {ringkas(te)} -> {'LULUS' if len(te) >= 100 and te.R.mean() >= 0.15 else 'TIDAK LULUS'}")
P(f"   per arah uji: " + ", ".join(f"{'LONG' if d == 1 else 'SHORT'} {ringkas(g)}" for d, g in te.groupby("arah")))
P("\n   PUTAR HALUAN (estafet): sinyal yang muncul <= 12 jam setelah posisi arah lawan di koin sama ditutup untung")
for nm, g in (("estafet", SNIPER[SNIPER.estafet]), ("bukan estafet", SNIPER[~SNIPER.estafet])):
    dua(f"pilihan sniper, {nm}", g)

# =====================================================================================================
P("\n== 2. MEMORI ADAPTIF JANGKA PENDEK pada v149 (catatan kertas semua sinyal v149, hanya yang sudah selesai) ==")
evm = evv.copy(); evm["jalur"] = jl[m8]
def memori(ev, aturan, nilai_, bonus=None):
    """aturan: 'koin_jam' karantina koin sekian jam setelah SL, 'koin_n' lewati n sinyal koin itu setelah SL,
    'jalur_jam' karantina jalur+arah sekian jam setelah SL. bonus: lot 1.5x kalau trade kertas terakhir koin itu TP dalam 7 hari."""
    ev = ev.sort_values("masuk", kind="stable").reset_index(drop=True)
    kel = ev.keluar.values; ms = ev.masuk.values; sym = ev.sym.values; jal = ev.jalur.values; ar_ = ev.arah.values; Rv = ev.R.values
    o = np.argsort(kel, kind="stable"); ptr = 0
    akhir_koin = {}; akhir_jalur = {}; lewati = {}; keep = np.ones(len(ev), bool); lot = np.ones(len(ev))
    for q in range(len(ev)):
        t = ms[q]
        while ptr < len(o) and kel[o[ptr]] <= t:
            z = o[ptr]; akhir_koin[sym[z]] = (kel[z], Rv[z]); akhir_jalur[(jal[z], ar_[z])] = (kel[z], Rv[z])
            if Rv[z] <= -0.5:
                lewati[sym[z]] = nilai_ if aturan == "koin_n" else 0
            ptr += 1
        ak = akhir_koin.get(sym[q]); aj = akhir_jalur.get((jal[q], ar_[q]))
        if aturan == "koin_jam" and ak is not None and ak[1] <= -0.5 and t - ak[0] <= nilai_:
            keep[q] = False
        if aturan == "koin_n" and lewati.get(sym[q], 0) > 0:
            keep[q] = False; lewati[sym[q]] -= 1
        if aturan == "jalur_jam" and aj is not None and aj[1] <= -0.5 and t - aj[0] <= nilai_:
            keep[q] = False
        if bonus and ak is not None and ak[1] > 0.5 and t - ak[0] <= 168:
            lot[q] = 1.5
    x = ev[keep].copy(); x["R"] = x.R.values * lot[keep]
    return x
ukur("v149 + slot aman dinamis (pembanding)", porto2(evm))
MEM = []
for aturan, nilai_s in (("koin_jam", (72, 168)), ("koin_n", (3, 5)), ("jalur_jam", (24, 72))):
    for nv in nilai_s:
        for bonus in (False, True):
            nm = f"karantina {aturan} {nv}" + (" + bonus lot 1.5x setelah TP" if bonus else "")
            h = ukur(nm, porto2(memori(evm, aturan, nv, bonus)))
            MEM.append((h["23-24"]["exp"] * h["23-24"]["n"] / max(h["23-24"]["dd"], 1), nm, h))
for bonus in (True,):
    h = ukur("tanpa karantina, hanya bonus lot 1.5x setelah TP", porto2(memori(evm, "tidak", 0, True)))
    MEM.append((h["23-24"]["exp"] * h["23-24"]["n"] / max(h["23-24"]["dd"], 1), "hanya bonus", h))
b = max(MEM, key=lambda z: z[0])
P(f"   >> dipilih di latih (total/DD 2023-2024): {b[1]} -> uji exp {b[2]['25-26']['exp']:+.3f}R WR {b[2]['25-26']['wr']:.1f}% tot {b[2]['25-26']['tot']:+.0f}R DD {b[2]['25-26']['dd']:.0f}R")
P("   memori yang sama pada Swing Sniper:")
sn_m = SNIPER.copy(); sn_m["jalur"] = "sniper"
dua("sniper tanpa memori", sn_m)
for aturan, nv in (("koin_jam", 72), ("koin_jam", 168), ("koin_n", 3), ("koin_n", 5)):
    dua(f"sniper + karantina {aturan} {nv}", memori(sn_m, aturan, nv))

# =====================================================================================================
P("\n== 3. SQUEEZE RANKING TUNGGAL + SEGITIGA TOP 50 ==")
P("   Sinyal squeeze yang masuk di candle 4J yang sama diurutkan: kompresi paling sempit (lebar Bollinger / median 100 candle),")
P("   lalu taker buy searah paling besar. Ambil 1 atau 2 teratas. Aturan ini ditetapkan sebelum melihat hasil.")
def squeeze_rank(N, vk):
    sig = []
    for s_, D in DATA.items():
        a = D["a"]; h, l, c, v = D["h4"], D["l4"], D["c4"], D["v4"]; ix = D["ix"]; tms = D["t4"]
        cs = pd.Series(c); bw = (4 * cs.rolling(20).std() / cs.rolling(20).mean()).values
        bwmin = pd.Series(bw).rolling(N).min().values; bwmed = pd.Series(bw).rolling(100).median().values
        va = pd.Series(v).rolling(20).mean().shift(1).values; arah_b = btc_arah(tms + 14400000)
        tbr = D.get("tbr4"); cand = np.nonzero(np.isfinite(bw) & (bw <= bwmin * 1.0001))[0]; lewat = -1
        for i in cand:
            if i < N + 20 or i <= lewat or i >= len(c) - 1:
                continue
            top = h[i - 9:i + 1].max(); bot = l[i - 9:i + 1].min()
            for j in range(i + 1, min(i + 13, len(c) - 1)):
                d = 1 if c[j] > top else (-1 if c[j] < bot else 0)
                if d == 0:
                    continue
                if v[j] >= vk * va[j] and d == arah_b[j] and j + 1 < len(ix):
                    k = a + ix[j + 1]; e = O_[k]; sl = bot if d == 1 else top; rk = (e - sl) * d
                    if 0.004 * e <= rk <= 0.08 * e:
                        tb = (tbr[j] - 0.5) * d if tbr is not None and np.isfinite(tbr[j]) else 0.0
                        sig.append((s_, k, d, rk, D["at4"][j], bw[i] / bwmed[i] if bwmed[i] > 0 else 9, tb))
                break
            lewat = i + 12
    return sig
def ev_sq(sig, top, varian):
    df = pd.DataFrame(sig, columns=["sym", "k", "d", "rk", "at", "komp", "tb"]); df["jam"] = TS[df.k.values] // 3600000
    if top:
        df["rk1"] = df.groupby("jam").komp.rank(method="first"); df["rk2"] = df.groupby("jam").tb.rank(ascending=False, method="first")
        df["skor"] = df.rk1 + df.rk2; df = df.sort_values(["jam", "skor", "komp"]).groupby("jam").head(top)
    sg = [(z.sym, int(z.k), int(z.d), z.rk, z.at, None, TS[int(z.k)] - 4 * 3600000, 4) for z in df.itertuples()]
    return sim_list(sg, "squeeze", varian)
SQR = []
for N in (30, 50):
    for vk in (1.5, 2.0):
        sg = squeeze_rank(N, vk)
        for top in (0, 1, 2):
            ev = ev_sq(sg, top, f"N{N} vol{vk} top{top if top else 'semua'}")
            SQR.append(ev)
            if top == 0 or (N == 50 and vk == 2.0):
                dua(f"squeeze N{N} vol{vk} {'semua sinyal' if not top else 'ranking ambil ' + str(top)}", ev)
SQR = pd.concat(SQR, ignore_index=True)
P("   walk-forward 6 bulan (pilihan varian x killzone x Top 50 dari 6 bulan sebelumnya), sesudah ranking:")
WFR = {}
for top in ("semua", "1", "2"):
    g = SQR[SQR.varian.str.endswith("top" + top)]
    x, lib = walk(g, 6, 30); tm = bulanan(x); WFR[top] = x
    P(f"   squeeze walk-forward ranking {top:5s}: {ringkas(x)} | bulan rugi {int((tm < 0).sum())}/22, libur {lib}")
SEG = EV[(EV.mesin == "segitiga") & (EV.varian == "TF4J tol0.5 sentuh3 A-stop") & (EV.tier < 50)]
dua("segitiga TF4J tol0.5 sentuh3 Conditional Stop, Top 50 (pilihan latih v154)", SEG)

# =====================================================================================================
P("\n== 4. KANTONG PELENGKAP + AUTO-PROMOTION (2025-2026) ==")
P("   Kantong: slot sendiri maks 2, tidak memakan slot v149. Tiap mesin dicatat kertas terus.")
P("   Lot 0.5x hanya saat 10 trade kertas terakhir mesin itu (yang sudah selesai) WR > 55% dan total > 0. Selain itu kertas (lot 0).")
def promosi(x, lot=0.5, n=10, wr=0.55):
    x = x.sort_values("masuk", kind="stable").reset_index(drop=True); lots = np.zeros(len(x))
    for mesin, g in x.groupby("mesin"):
        kel = g.keluar.values; R_ = g.R.values; o = np.argsort(kel, kind="stable")
        for q, idx in enumerate(g.index):
            t = x.masuk[idx]; selesai = o[kel[o] <= t][-n:]
            if len(selesai) >= n and np.mean(R_[selesai] > 0) > wr and R_[selesai].sum() > 0:
                lots[idx] = lot
    x["lot"] = lots; return x
def kantong_promo(x, cap=2):
    T = porto2(promosi(x).drop(columns=[c for c in ("runner",) if c in x.columns]), cap=cap, runner=0)
    return T
def kantong_lot(x, cap=2):
    x = promosi(x); x2 = x.copy(); x2["R"] = x2.R * x2.lot
    real = x2[x2.lot > 0]
    T = porto2(real, cap=cap, runner=0); T["th"] = T.bulan.str[:4].astype(int); return T, x
SN_ = SNIPER.copy()
KAND = {"Swing Sniper": SN_, "Squeeze walk-forward ranking 2": WFR["2"].assign(mesin="squeeze"),
        "Segitiga Top 50": SEG.assign(mesin="segitiga"),
        "gabungan tiga mesin": pd.concat([SN_, WFR["2"].assign(mesin="squeeze"), SEG.assign(mesin="segitiga")])}
for nm, x in KAND.items():
    x = x[x.th >= 2024]
    K0 = kantong(x); K0 = K0[K0.th >= 2025]
    P(f"   [{nm}] kantong lot 0.5 selalu   : {ringkas(K0.assign(sym=0))}")
    lap_porto(f"      v149 + kantong {nm} lot 0.5 selalu", pd.concat([TV, K0]), DASAR)
    K1, xp = kantong_lot(x); K1 = K1[K1.th >= 2025]
    on = xp[(xp.th >= 2025)]
    P(f"   [{nm}] kantong Auto-Promotion   : {ringkas(K1.assign(sym=0))} | sinyal 2025-26 yang naik kasta {int((on.lot > 0).sum())} dari {len(on)}")
    lap_porto(f"      v149 + kantong {nm} Auto-Promotion", pd.concat([TV, K1]), DASAR)
open("hasil_v155.txt", "w").write("\n".join(out))

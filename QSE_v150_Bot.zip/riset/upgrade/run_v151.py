"""v151 (permintaan 3 Nov 21:36): metrik expectancy, risiko bertingkat, time-decay, mean reversion.
Asal: uji 6 perubahan permintaan user 3 Nov 2026 (11:04 dan 11:06). Data Binance 383 koin 1J, universe 150 likuid, satu orang.
Semua keputusan pakai data sebelum sinyal. Ambang dipilih di 2023-2024, dinilai di 2025-2026. Biaya 0.15% harga.
1. Rem 7 hari jadi mode: saat rem, hanya NILAI 10 (skor 90) dan/atau setengah risiko, bukan tahan total.
   Gerbang profil dilonggarkan (gabungan semua jalur arah sama, min 5). LONG akhir pekan boleh kalau volume 24 jam >= 2x rata 30 hari.
2. TPawal 40-50% di +0.5R, SL ke -0.25R, SL ke entry di +0.8R. Posisi aman tidak dihitung dalam batas 4 (runner).
3. Sapuan likuiditas 1 dan 2 candle 4J + volume >= 2x, di support kuat (disentuh >= 2x) atau divergensi RSI.
   Derivatif BTC (Binance Futures): BTC turun + OI turun + funding sangat minus -> SHORT ditahan (cermin untuk LONG).
4. Masuk koreksi: tunggu koreksi di 1J, Conditional Stop di atas high candle pantulan, SL di ujung ekor pantulan, TP dihitung ulang.
5. Laporan: per bulan 2025-2026, sinyal per minggu, WR, PF, DD, v149 lawan gabungan perubahan yang lolos."""
import os, numpy as np, pandas as pd
from numba import njit
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "v150"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
import core as Cx
DERIV = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/deriv"
CSV = os.path.join(Cx.SC, "data")
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
H_, L_, C_, O_, TS = Cx.H, Cx.L, Cx.C, Cx.O, Cx.TS
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
ar = S.arah.values; jl = S.jalur.values; masuk = S.masuk_h.values; k0 = S.k0.values
dow = pd.to_datetime(S["T"].values, unit="ms", utc=True).dayofweek.values
wkL = (ar == 1) & (dow >= 5)
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
dasar_mask = ok & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
m8 = dasar_mask & izin & ~wkL                         # v149 seperti bot live (akhir pekan LONG ditahan)
lat = thn <= 2024; tes = thn >= 2025
minggu = lambda T: max((T[:, 0].max() - T[:, 0].min()) / 168, 1) if len(T) else 1
def nilai(nm, T, ringkas=True):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]; th_ = thn[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    t2 = T[th_ >= 2025]; r2 = t2[:, 2]
    P(f"   {nm:56s} n {len(r):5d} {len(r) / minggu(T):4.1f}/mgg WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} tot {r.sum():+5.0f}R DD {dd(r[o_]):3.0f}R | "
      f"PF<1 {int((pm < 1).sum()):2d}/{len(pm)} terburuk {tm.min():+5.1f} | 23-24 PF {pf(r[th_ <= 2024]):.2f} | 25-26 n/mgg {len(r2) / minggu(t2):4.1f} "
      f"WR {np.mean(r2 > 0) * 100 if len(r2) else 0:4.1f}% PF {pf(r2):.2f} DD {dd(r2[np.argsort(t2[:, 1], kind='stable')]):3.0f}R")
    return T
# rem 7 hari dari trade kertas semua sinyal m8 yang sudah selesai
def rem_flag(res, pilih, batas=-3.0):
    R = res["R"]; kel = masuk + res["hrs"]; idx = np.nonzero(pilih)[0]
    o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
    f = np.zeros(len(S), bool)
    j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
    f[idx] = (cs[j] - cs[j0]) < batas
    return f
def skala(T, mask_half):
    T = T.copy(); h = mask_half[T[:, 3].astype(int)]; T[h, 2] *= 0.5; return T
P("== DASAR ==")
rem = rem_flag(baru, m8)
B0 = nilai("v149 tanpa rem 7 hari", jalankan(baru, m8, 4, 0))
B1 = nilai("v149 + rem 7 hari TOTAL (terpasang)", jalankan(baru, m8 & ~rem, 4, 0))


P("\nMetrik baru: Expectancy (rata R per trade, sudah ukuran lot), total R, DD, total/DD, WR, sinyal per minggu. Pilih di 2023-24, nilai 2025-26.")
def metrik(nm, T):
    r = T[:, 2]; i = T[:, 3].astype(int); th_ = thn[i]; o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]
    tm = pd.Series(r).groupby(b).sum()
    def blok(m_):
        x = r[m_]; t_ = T[m_]; oo = np.argsort(t_[:, 1], kind="stable"); d_ = dd(x[oo])
        return f"n/mgg {len(x) / minggu(t_):4.1f} WR {np.mean(x > 0) * 100 if len(x) else 0:4.1f}% exp {x.mean() if len(x) else 0:+.3f}R tot {x.sum():+5.0f}R DD {d_:3.0f}R tot/DD {x.sum() / max(d_, 1e-9):4.1f}"
    P(f"   {nm:58s} | 23-24 {blok(th_ <= 2024)} | 25-26 {blok(th_ >= 2025)} | bulan rugi {int((tm < 0).sum())}/{len(tm)} terburuk {tm.min():+.1f}")
    return T
R = baru["R"]; kel = masuk + baru["hrs"]
sid = pd.factorize(S.sym.values)[0]
n10 = S.nilai_n.values >= 8; n9 = S.nilai_n.values >= 5
def mode_rem(T, remf):
    """rem 7 hari menyala: hanya NILAI 10, setengah lot (yang terpasang)."""
    i = T[:, 3].astype(int); keep = ~remf[i] | n10[i]
    T = T[keep].copy(); T[remf[T[:, 3].astype(int)], 2] *= 0.5; return T
def porto_mode(res, pilih, ukuran=None, cap=4, runner=0):
    remf = rem_flag(res, pilih)
    T = jalankan(res, pilih & (~remf | n10), cap, runner)
    if ukuran is not None:
        T = T.copy(); T[:, 2] *= ukuran[T[:, 3].astype(int)]
    T = T.copy(); T[remf[T[:, 3].astype(int)], 2] *= 0.5
    return T

P("\n== 0. DASAR ==")
TA = metrik("v149 terpasang (rem mode NILAI 10 setengah lot), slot 4", porto_mode(baru, m8))
metrik("+ posisi aman di luar slot (maks 2)", porto_mode(baru, m8, runner=2))
metrik("+ posisi aman di luar slot (maks 4)", porto_mode(baru, m8, runner=4))

P("\n== 1. RISIKO BERTINGKAT ==")

R = baru["R"]; kel = masuk + baru["hrs"]
sid = pd.factorize(S.sym.values)[0]
def profil_gab(nmin, pmin, baru_ok):
    gid = sid * 3 + ar + 1
    iz = np.ones(len(S), bool)
    for g in np.unique(gid[dasar_mask]):
        ix = np.nonzero((gid == g))[0]
        ko = ix[np.argsort(kel[ix], kind="stable")]
        cp, cn = np.r_[0, np.cumsum(np.maximum(R[ko], 0))], np.r_[0, np.cumsum(np.maximum(-R[ko], 0))]
        j = np.searchsorted(kel[ko], masuk[ix], side="right")
        iz[ix] = np.where(j >= nmin, cp[j] / np.maximum(cn[j], 1e-9) >= pmin, baru_ok)
    return iz

gab11 = profil_gab(5, 1.1, True)
utama = dasar_mask & izin & n9 & ~wkL
for kecil in (0.3, 0.5):
    for nm, sek in (("NILAI 8 lolos profil ketat", dasar_mask & izin & ~n9 & ~wkL),
                    ("+ NILAI 8+ lolos profil longgar (gabungan arah, PF >= 1.1)", dasar_mask & ~wkL & ~izin & gab11),
                    ("+ keduanya", dasar_mask & ~wkL & ((izin & ~n9) | (~izin & gab11)))):
        uk = np.where(utama, 1.0, kecil)
        pil = utama | sek
        for cap, rn in ((4, 2), (6, 2)):
            metrik(f"utama 1x + {nm} {kecil}x, slot {cap}+{rn}", porto_mode(baru, pil, uk, cap, rn))

P("\n== 2. KELUAR BERBASIS WAKTU (Time-Decay) ==")
@njit(cache=False)
def sim3(Hh, L, C, k0, n, d, e, risk, atrt, tp_r, trail, tps_lv, por, sl_aft, be_lv, jk, jstop):
    sl = e - d * risk; best = e; sisa = 1.0; real = 0.0; aman = -1; tpsd = False
    lvp = e + d * tps_lv * risk; lvb = e + d * be_lv * risk
    has_tp = tp_r > 0; tp = e + d * tp_r * risk
    for j in range(n):
        hi = Hh[k0 + j]; lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if not tpsd and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += por * tps_lv; sisa = 1.0 - por; tpsd = True
            nsl = e + d * sl_aft * risk
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if tpsd and aman < 0 and ((d == 1 and hi >= lvb) or (d == -1 and lo <= lvb)):
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1
        if tpsd and aman < 0 and sl_aft >= 0:
            aman = j + 1
        if has_tp and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        if d == 1:
            if hi > best: best = hi
        else:
            if lo < best: best = lo
        if j % 4 == 3 and trail > 0:
            nsl = best - d * trail * atrt
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if not tpsd and j + 1 == jk:
            rn = (C[k0 + j] - e) * d / risk
            if rn <= -0.5:
                return real + sisa * rn, j + 1, aman
            if rn < 0:
                nsl = e - d * 0.5 * risk
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
        if not tpsd and j + 1 == jstop:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman
def jalan3(tps_lv, por, sl_aft, be_lv, k0a=None, ea=None, riska=None, nmaxa=None, pilih=None):
    pilih = m8 if pilih is None else pilih
    Rn = np.full(len(S), np.nan); hn = np.zeros(len(S), np.int64); an = np.full(len(S), -1, np.int64)
    k0a = k0 if k0a is None else k0a; nmaxa = S.nmax.values if nmaxa is None else nmaxa
    for i in np.nonzero(pilih)[0]:
        if k0a[i] < 0:
            continue
        e = O_[k0a[i]] if ea is None else ea[i]; rk = S.risk.values[i] if riska is None else riska[i]
        r, h, a = sim3(H_, L_, C_, k0a[i], nmaxa[i], ar[i], e, rk, S.atrt.values[i], S.tp_r.values[i], S.trail.values[i],
                       tps_lv, por, sl_aft, be_lv, 12, 30)
        Rn[i] = r - Cx.BIAYA * e / rk; hn[i] = h + (k0a[i] - k0[i]); an[i] = a + (k0a[i] - k0[i]) if a >= 0 else -1
    return dict(R=Rn, hrs=hn, aman=an)

@njit(cache=False)
def sim4(Hh, L, C, k0, n, d, e, risk, atrt, tp_r, trail, cepat_lv, cepat_por, cepat_jam, datar_jam, datar_r):
    sl = e - d * risk; best = e; sisa = 1.0; real = 0.0; aman = -1; tpsd = False; cepat = False
    lvp = e + d * 0.5 * risk; lvc = e + d * cepat_lv * risk
    has_tp = tp_r > 0; tp = e + d * tp_r * risk
    for j in range(n):
        hi = Hh[k0 + j]; lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if cepat_por > 0 and not cepat and j < cepat_jam and ((d == 1 and hi >= lvc) or (d == -1 and lo <= lvc)):
            real += cepat_por * cepat_lv; sisa -= cepat_por; cepat = True
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1; tpsd = True
        if not tpsd and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += 0.2 * sisa * 0.5; sisa = sisa * 0.8; tpsd = True
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1
        if has_tp and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        if d == 1:
            if hi > best: best = hi
        else:
            if lo < best: best = lo
        if j % 4 == 3 and trail > 0:
            nsl = best - d * trail * atrt
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if datar_jam > 0 and not tpsd and j + 1 == datar_jam:
            rn = (C[k0 + j] - e) * d / risk
            if abs(rn) <= datar_r:
                return real + sisa * rn, j + 1, aman
        if not tpsd and j + 1 == 12:
            rn = (C[k0 + j] - e) * d / risk
            if rn <= -0.5:
                return real + sisa * rn, j + 1, aman
            if rn < 0:
                nsl = e - d * 0.5 * risk
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
        if not tpsd and j + 1 == 30:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman
def jalan4(cl, cp, cj, dj, dr, pilih):
    Rn = np.full(len(S), np.nan); hn = np.zeros(len(S), np.int64); an = np.full(len(S), -1, np.int64)
    for i in np.nonzero(pilih)[0]:
        e = O_[k0[i]]; rk = S.risk.values[i]
        r, h, a = sim4(H_, L_, C_, k0[i], S.nmax.values[i], ar[i], e, rk, S.atrt.values[i], S.tp_r.values[i], S.trail.values[i], cl, cp, cj, dj, dr)
        Rn[i] = r - Cx.BIAYA * e / rk; hn[i] = h; an[i] = a
    return dict(R=Rn, hrs=hn, aman=an)
c4 = jalan4(0.35, 0.0, 4, 0, 0.15, m8)
P(f"   cek sim4 tanpa aturan baru = v149: selisih maks {np.nanmax(np.abs(c4['R'][m8] - R[m8])):.3f}R")
TD = {}
for nm, a_ in (("4 jam +0.35R ambil 50%", (0.35, 0.5, 4, 0, 0.15)), ("8 jam masih datar (+-0.15R) tutup", (0.35, 0.0, 4, 8, 0.15)),
               ("keduanya", (0.35, 0.5, 4, 8, 0.15))):
    res = jalan4(*a_, m8); TD[nm] = res
    x = res["R"][m8]
    P(f"   {nm}: tingkat sinyal exp latih {np.nanmean(res['R'][m8 & lat]):+.3f}R uji {np.nanmean(res['R'][m8 & tes]):+.3f}R "
      f"(v149 {np.nanmean(R[m8 & lat]):+.3f}/{np.nanmean(R[m8 & tes]):+.3f}), lama posisi median {np.median(res['hrs'][m8]):.0f} jam (v149 {np.median(baru['hrs'][m8]):.0f})")
    for rn in (0, 2):
        metrik(f"{nm}, slot 4+{rn}", porto_mode(res, m8, runner=rn))

P("\n== 3. MEAN REVERSION Z-SCORE (karet gelang), TP di EMA 20 ==")
ranks = S.groupby("sym")["rank"].median()
koin = [s for s in Cx.OFF if s in ranks.index and ranks[s] <= 150]
@njit(cache=False)
def mr_sim(o, h, l, c, v, ema, z, zmin, konf, mulai, sl_buf, maks, biaya, out_t, out_r, out_d):
    n = len(c); m = 0
    i = mulai
    while i < n - 2:
        d = 0
        if z[i] >= zmin:
            d = -1
        elif z[i] <= -zmin:
            d = 1
        if d == 0:
            i += 1; continue
        ok_ = False
        if konf == 1:
            ok_ = (d == 1 and c[i] > o[i]) or (d == -1 and c[i] < o[i])
        elif konf == 2:
            ok_ = v[i] < v[i - 1] and v[i - 1] < v[i - 2]
        else:
            ok_ = True
        if not ok_:
            i += 1; continue
        e = o[i + 1]
        if d == 1:
            ext = min(l[i], l[i - 1], l[i - 2]); sl = ext - sl_buf * (h[i] - l[i])
        else:
            ext = max(h[i], h[i - 1], h[i - 2]); sl = ext + sl_buf * (h[i] - l[i])
        risk = (e - sl) * d
        if risk <= 0.002 * e or risk > 0.1 * e:
            i += 1; continue
        r = 0.0; done = False; j = i + 1
        while j < min(n, i + 1 + maks):
            if (d == 1 and l[j] <= sl) or (d == -1 and h[j] >= sl):
                r = -1.0; done = True; break
            if (d == 1 and h[j] >= ema[j - 1]) or (d == -1 and l[j] <= ema[j - 1]):
                px = ema[j - 1]
                if (d == 1 and o[j] > px) or (d == -1 and o[j] < px):
                    px = o[j]
                r = (px - e) * d / risk; done = True; break
            j += 1
        if not done:
            j = min(n - 1, i + maks); r = (c[j] - e) * d / risk
        out_t[m] = i + 1; out_r[m] = r - biaya * e / risk; out_d[m] = d; m += 1
        i = j + 1
    return m
rows = []
for s in koin:
    a, n = Cx.OFF[s]
    f = os.path.join(CSV, f"{s}_60.csv")
    if not os.path.exists(f):
        continue
    vv = pd.read_csv(f, usecols=["volume"]).volume.values.astype(float)
    if len(vv) != n:
        continue
    t = TS[a:a + n]
    for tf in (1, 4):
        if tf == 1:
            o, h, l, c, v, tt = O_[a:a + n], H_[a:a + n], L_[a:a + n], C_[a:a + n], vv, t
        else:
            g = t // 14400000; ix = np.r_[0, np.nonzero(np.diff(g))[0] + 1]
            o = O_[a + ix]; h = np.maximum.reduceat(H_[a:a + n], ix); l = np.minimum.reduceat(L_[a:a + n], ix)
            c = C_[a + np.r_[ix[1:] - 1, n - 1]]; v = np.add.reduceat(vv, ix); tt = t[ix]
        if len(c) < 300:
            continue
        cs = pd.Series(c); ema = cs.ewm(span=20, adjust=False).mean().values
        z = ((cs - cs.rolling(20).mean()) / cs.rolling(20).std()).values
        z = np.nan_to_num(z)
        for zmin in (2.0, 2.5):
            for konf in (1, 2):
                ot = np.zeros(len(c), np.int64); orr = np.zeros(len(c)); od = np.zeros(len(c), np.int64)
                m = mr_sim(o, h, l, c, v, ema, z, zmin, konf, 50, 0.1, 24 if tf == 1 else 12, 0.0015, ot, orr, od)
                for q in range(m):
                    rows.append((tt[ot[q]], s, tf, zmin, konf, int(od[q]), orr[q]))
MR = pd.DataFrame(rows, columns=["t", "sym", "tf", "z", "konf", "arah", "R"])
MR["th"] = pd.to_datetime(MR.t, unit="ms", utc=True).dt.year; MR["b"] = pd.to_datetime(MR.t, unit="ms", utc=True).dt.strftime("%Y-%m")
P(f"   {len(MR)} trade karet gelang. Per varian (latih 2021-2024 / uji 2025-2026), expectancy dan PF:")
best = None
for (tf, zmin, konf, d), g in MR.groupby(["tf", "z", "konf", "arah"]):
    la = g[g.th <= 2024].R.values; te = g[g.th >= 2025].R.values
    P(f"   TF {'1J' if tf == 1 else '4J'} z>={zmin} konfirmasi {'candle berbalik' if konf == 1 else 'volume menyusut'} {'LONG' if d == 1 else 'SHORT'}: "
      f"latih n {len(la):6d} exp {la.mean():+.3f}R PF {pf(la):.2f} | uji n {len(te):6d} exp {te.mean():+.3f}R PF {pf(te):.2f}")
    if best is None or la.mean() > best[0]:
        best = (la.mean(), tf, zmin, konf, d)
P(f"   terbaik di latih: TF {best[1]} z {best[2]} konf {best[3]} arah {best[4]}, exp latih {best[0]:+.3f}R")
g = MR[(MR.tf == best[1]) & (MR.z == best[2]) & (MR.konf == best[3]) & (MR.arah == best[4])]
bm = g.groupby("b").R.agg(["count", "mean", "sum"])
P("   bulan sulit 2026 (April, Juli, Oktober) untuk varian terbaik: " + ", ".join(
    f"{m}: n {int(bm.loc[m, 'count'])} exp {bm.loc[m, 'mean']:+.3f}R" for m in ("2026-04", "2026-07", "2026-10") if m in bm.index))
ta = pd.Series(TA[:, 2]).groupby(bln[TA[:, 3].astype(int)]).sum()
ka = pd.concat([ta.rename("A"), bm["mean"].rename("B")], axis=1).dropna()
P(f"   korelasi bulanan hasil A (v149) dengan rata B: {ka.A.corr(ka.B):+.2f}. Bulan A rugi: rata B {ka.B[ka.A < 0].mean():+.3f}R, bulan A untung: {ka.B[ka.A >= 0].mean():+.3f}R")
import pickle
pickle.dump(dict(TA=TA, bln=bln), open(os.path.join(Cx.SC, "v151_TA.pkl"), "wb"))
open("hasil_v151.txt", "w").write("\n".join(out))

"""v154 (permintaan 4 Nov 06:45): lima sudut uji baru untuk mesin Sektor, Segitiga, Squeeze, Impuls, Unlock SHORT.
1. Rolling walk-forward: pilih varian dari 3 atau 6 bulan sebelumnya, uji murni di 1 bulan berikutnya, Jan 2025 sampai Okt 2026.
2. Mesin penambal: hanya masuk saat v149 sepi (posisi berisiko v149 <= 1) atau saat kertas v149 7 hari negatif.
3. Killzone: candle pemicu harus menyentuh jam London 14-17 WIB (07-10 UTC) atau New York 19-23 WIB (12-16 UTC).
4. Kasta likuiditas: Top 50 menurut rata nilai transaksi 30 hari sebelum sinyal, lawan sisanya.
5. Kantong kedua: slot sendiri (maks 2), lot 0.5x, tidak memakan slot v149.
Semua keputusan pakai data sebelum sinyal. Biaya 0.15% harga. Aturan keluar v149."""
import os, numpy as np, pandas as pd
src = open("run_v153.py").read().split('P("\\n== 2. ORDER FLOW')[0]
exec(src)
seg = open("run_segitiga.py").read()
exec(seg[seg.index("def pivots"):seg.index("hasil = []")])
out.clear()
NAMA = pd.factorize(S.sym.values)[1]
KZ = {7, 8, 9, 12, 13, 14, 15}

# ---------- kasta likuiditas: rata nilai transaksi 720 jam sebelum sinyal, peringkat di antara koin DATA ----------
T0 = int(pd.Timestamp("2022-06-01", tz="UTC").value // 10**6) // 3600000
T1 = int(TS.max() // 3600000) + 2
QV = np.full((T1 - T0, len(DATA)), np.nan, dtype=np.float32); KOL = {}
for jj, (s_, D) in enumerate(DATA.items()):
    a, n = D["a"], D["n"]; th = TS[a:a + n] // 3600000; m = th >= T0
    qv = pd.Series(D["v"] * C_[a:a + n]).rolling(720, min_periods=500).mean().shift(1).values
    QV[th[m] - T0, jj] = qv[m]; KOL[s_] = jj
RK = np.full(QV.shape, 999, dtype=np.int16)
for q in range(0, QV.shape[0]):
    row = QV[q]; ok_ = np.isfinite(row)
    if ok_.sum():
        o = np.argsort(-np.where(ok_, row, -1)); RK[q, o] = np.arange(len(row)); RK[q, ~ok_] = 999
def tier(s_, ms):
    q = int(ms // 3600000) - T0
    return int(RK[q, KOL[s_]]) if 0 <= q < len(RK) and s_ in KOL else 999
def kena_kz(start_ms, jam):
    h0 = int(start_ms // 3600000)
    return any(((h0 + x) % 24) in KZ for x in range(jam))

def sim_list(sig, mesin, varian):
    """sig: (sym, k, d, rk, at, e_atau_None, pemicu_ms, pemicu_jam). Keluar v149, satu posisi per koin per varian."""
    rows = []; terakhir = {}
    for s_, k, d, rk, at, e, pm, pj in sorted(sig, key=lambda z: z[1]):
        a, n = Cx.OFF[s_]
        if k >= a + n - 2 or terakhir.get(s_, -1) >= k or not np.isfinite(at) or rk <= 0:
            continue
        e = O_[k] if e is None else e; nmax = min(240, a + n - k - 1)
        r, h, am = sim3(H_, L_, C_, k, nmax, d, e, rk, at, 0.0, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
        terakhir[s_] = k + h; mh = TS[k] // 3600000
        rows.append((mh, mh + h, mh + (am if am >= 0 else h), s_, d, r - Cx.BIAYA * e / rk, bulan_of([TS[k]])[0],
                     kena_kz(pm, pj), tier(s_, TS[k]), mesin, varian))
    ev = pd.DataFrame(rows, columns=["masuk", "keluar", "aman", "sym", "arah", "R", "bulan", "kz", "tier", "mesin", "varian"])
    ev["th"] = ev.bulan.str[:4].astype(int)
    return ev

SEMUA = []
# ---------- squeeze dan impuls ----------
for N in (30, 50):
    for vk in (1.5, 2.0):
        sg = [(s_, k, d, rk, at, None, TS[k] - 4 * 3600000, 4) for s_, k, d, rk, at, dl in sinyal_squeeze(N, vk)]
        SEMUA.append(sim_list(sg, "squeeze", f"N{N} vol{vk}"))
for rng in (0.04, 0.06):
    for vk in (3.0, 4.0):
        sg = [(s_, k, d, rk, at, None, TS[k] - 3600000, 1) for s_, k, d, rk, at, dl in sinyal_impuls(rng, vk)]
        SEMUA.append(sim_list(sg, "impuls", f"rentang{rng} vol{vk}"))
P("squeeze dan impuls selesai")
# ---------- sektor ----------
SEK = {}
for sec, cs in {"L1": "ADA ALGO APT ATOM AVAX BCH CELO CFX CKB DOT EGLD ETC HBAR ICP ICX IOTA KAVA KSM LTC MINA NEAR NEO ONE ONT QTUM ROSE SEI SOL SUI TRX VET XLM XRP XTZ ZIL DASH RVN ZEC TIA INJ",
                "L2": "ARB OP IMX LRC SKL STX", "DEFI": "1INCH AAVE COMP CRV DYDX GMX JUP KNC LDO PENDLE SNX SUSHI UNI YFI ZRX RUNE ENA WOO UMA",
                "ORACLE": "API3 BAND LINK PYTH TRB GRT", "MEME": "1000BONK 1000FLOKI 1000PEPE 1000SHIB DOGE WIF BONK FLOKI PEPE SHIB", "AI": "FET WLD NMR ARPA IOTX",
                "GAME": "ALICE APE AXS ENJ GALA GMT MANA SAND HOOK CHZ THETA", "DEPIN": "AR FIL STORJ ANKR JASMY"}.items():
    for c_ in cs.split():
        SEK[c_ + "USDT"] = sec
kol = [s_ for s_ in DATA if s_ in SEK]
t4all = sorted(set(np.concatenate([DATA[s_]["t4"] for s_ in kol]))); pos = {t: q for q, t in enumerate(t4all)}
RET = np.full((len(t4all), len(kol)), np.nan); VR = RET.copy(); HI20 = RET.copy(); LO20 = RET.copy(); CL = RET.copy(); TBR = RET.copy()
for jj, s_ in enumerate(kol):
    D = DATA[s_]; q = np.array([pos[t] for t in D["t4"]])
    RET[q, jj] = D["c4"] / D["o4"] - 1; VR[q, jj] = D["v4"] / pd.Series(D["v4"]).rolling(20).mean().shift(1).values
    HI20[q, jj] = pd.Series(D["h4"]).rolling(20).max().shift(1).values; LO20[q, jj] = pd.Series(D["l4"]).rolling(20).min().shift(1).values
    CL[q, jj] = D["c4"]; TBR[q, jj] = D.get("tbr4", np.full(len(D["c4"]), np.nan))
gv = np.array([SEK[s_] for s_ in kol]); q_mulai = np.searchsorted(t4all, T0 * 3600000)
for tbm in (0.0, 0.55):
    for lead_r in (0.05, 0.08):
        sig = []
        for q in range(max(25, q_mulai), len(t4all) - 3):
            for g in np.unique(gv):
                m_ = np.nonzero(gv == g)[0]
                if len(m_) < 3:
                    continue
                for d in (1, -1):
                    rr_ = RET[q, m_] * d
                    if not np.any(np.isfinite(rr_)) or not np.nanmax(rr_) >= lead_r:
                        continue
                    li = m_[np.nanargmax(rr_)]
                    tb_ok = tbm == 0 or (TBR[q, li] >= tbm if d == 1 else TBR[q, li] <= 1 - tbm)
                    if not (VR[q, li] >= 3 and tb_ok):
                        continue
                    for jj in m_:
                        if jj == li or not abs(RET[q, jj]) < 0.015:
                            continue
                        for q2 in (q + 1, q + 2):
                            if np.isnan(CL[q2, jj]):
                                break
                            tembus = CL[q2, jj] > HI20[q2, jj] if d == 1 else CL[q2, jj] < LO20[q2, jj]
                            if tembus and VR[q2, jj] >= 1.5:
                                s_ = kol[jj]; D = DATA[s_]; i4 = np.searchsorted(D["t4"], t4all[q2])
                                if i4 + 1 < len(D["ix"]):
                                    k = D["a"] + D["ix"][i4 + 1]; e = O_[k]; rk = 1.5 * D["at4"][i4]
                                    if np.isfinite(rk) and 0.004 * e <= rk <= 0.08 * e:
                                        sig.append((s_, k, d, rk, D["at4"][i4], None, t4all[q2], 4))
                                break
        SEMUA.append(sim_list(sig, "sektor", f"pemimpin{lead_r} taker{tbm}"))
P("sektor selesai")
# ---------- unlock SHORT ----------
U = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/berita/riset/unlock_kejadian.pkl")
U = U[U.pct >= 1.0].copy(); U["ms"] = pd.to_datetime(U.t, utc=True).astype("datetime64[ms, UTC]").astype("int64")
sig = []
for z in U.itertuples():
    D = DATA.get(z.sym)
    if D is None:
        continue
    i0 = np.searchsorted(D["t4"], z.ms); va = pd.Series(D["v4"]).rolling(20).mean().shift(1).values
    for j in range(max(i0, 11), min(i0 + 18, len(D["c4"]) - 1)):
        if D["c4"][j] < D["l4"][j - 10:j].min() and D["v4"][j] >= 1.5 * va[j]:
            k = D["a"] + D["ix"][j + 1]; e = O_[k]; sl = D["h4"][j - 2:j + 1].max(); rk = sl - e
            if 0.004 * e <= rk <= 0.08 * e:
                sig.append((z.sym, k, -1, rk, D["at4"][j], None, D["t4"][j], 4))
            break
SEMUA.append(sim_list(sig, "unlock_short", "patah 4J vol1.5"))
# ---------- segitiga (TP trailing v149) ----------
for tf in (1, 4):
    for tol in (0.3, 0.5):
        for nt in (2, 3):
            sigA, sigB = [], []
            for s_, D in DATA.items():
                a, n = D["a"], D["n"]
                if tf == 1:
                    h, l, c, v = H_[a:a + n], L_[a:a + n], C_[a:a + n], D["v"]; tbar = TS[a:a + n]; dl = D.get("dl1")
                    kmap = lambda i: a + i + 1; at_of = lambda i: D["at4"][min(np.searchsorted(D["ix"], i, "right") - 1, len(D["at4"]) - 1)]
                    jam = 1
                else:
                    h, l, c, v = D["h4"], D["l4"], D["c4"], D["v4"]; tbar = D["t4"]; dl = D.get("dl4")
                    kmap = lambda i, ix=D["ix"]: a + ix[i + 1] if i + 1 < len(ix) else -1; at_of = lambda i: D["at4"][i]
                    jam = 4
                va = pd.Series(v).rolling(20).mean().shift(1).values
                for (i, d, garis, ayun, mulut) in segitiga(h, l, c, v, tol, nt):
                    if tbar[i] < T0 * 3600000:
                        continue
                    sl = ayun * (1 - 0.001) if d == 1 else ayun * (1 + 0.001)
                    for j in range(i + 1, min(i + 7, len(c) - 1)):
                        if (l[j] < ayun) if d == 1 else (h[j] > ayun):
                            break
                        if (c[j] > garis) if d == 1 else (c[j] < garis):
                            if v[j] >= 1.5 * va[j]:
                                k = kmap(j)
                                if k > 0:
                                    e = O_[k]; rk = (e - sl) * d
                                    if 0.003 * e <= rk <= 0.08 * e:
                                        sigB.append((s_, k, d, rk, at_of(j), None, tbar[j], jam))
                            break
                    if not (btc_er(tbar[i] + jam * 3600000)[0] >= 0.1 and dl is not None and np.isfinite(dl[i]) and dl[i] * d >= 0):
                        continue
                    stop = garis * (1 + d * 0.0015)
                    g0 = a + i + 1 if tf == 1 else (a + D["ix"][i + 1] if i + 1 < len(D["ix"]) else a + n)
                    g1 = min(g0 + 6 * jam, a + n - 1)
                    for g in range(g0, g1):
                        if (L_[g] <= sl) if d == 1 else (H_[g] >= sl):
                            break
                        if (H_[g] >= stop) if d == 1 else (L_[g] <= stop):
                            e = max(stop, O_[g]) if d == 1 else min(stop, O_[g]); rk = (e - sl) * d
                            if 0.003 * e <= rk <= 0.08 * e:
                                sigA.append((s_, g, d, rk, at_of(i), e, TS[g], 1))
                            break
            SEMUA.append(sim_list(sigA, "segitiga", f"TF{tf}J tol{tol} sentuh{nt} A-stop"))
            SEMUA.append(sim_list(sigB, "segitiga", f"TF{tf}J tol{tol} sentuh{nt} B-vol1.5"))
    P(f"segitiga TF {tf}J selesai")
EV = pd.concat(SEMUA, ignore_index=True)
EV.to_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v154_ev.pkl")
out.clear()

def ringkas(x):
    if not len(x):
        return "n    0"
    mg = max((x.masuk.max() - x.masuk.min()) / 168, 1); r = x.sort_values("keluar").R.values
    return f"n {len(x):4d} ({len(x) / mg:4.1f}/mgg) WR {np.mean(r > 0) * 100:4.1f}% exp {r.mean():+.3f}R tot {r.sum():+6.1f}R DD {dd(r):5.1f}R"
def bulanan(x, dari="2025-01", ke="2026-10"):
    bl = pd.period_range(dari, ke, freq="M").strftime("%Y-%m")
    return x.groupby("bulan").R.sum().reindex(bl, fill_value=0.0)
LATIH = (EV.th >= 2023) & (EV.th <= 2024); UJI = EV.th >= 2025

P("== 3 dan 4. KILLZONE DAN KASTA LIKUIDITAS (varian tetap, latih 2023-2024, uji 2025-2026) ==")
P("   Per mesin: varian terbaik di latih (n latih >= 50), lalu dipecah per filter. Angka uji tidak dipakai memilih.")
for mesin, g in EV.groupby("mesin", sort=False):
    pil = []
    for var, gg in g.groupby("varian"):
        for fn, fm in (("semua jam, semua koin", np.ones(len(gg), bool)), ("killzone", gg.kz.values), ("Top 50", gg.tier.values < 50),
                       ("killzone + Top 50", gg.kz.values & (gg.tier.values < 50)), ("di luar Top 50", gg.tier.values >= 50)):
            x = gg[fm]; la = x[(x.th >= 2023) & (x.th <= 2024)]
            pil.append((la.R.mean() if len(la) >= 50 else -9, var, fn, x))
    P(f"\n   [{mesin}]")
    for var in sorted(g.varian.unique()):
        for sc, v_, fn, x in pil:
            if v_ != var or fn not in ("semua jam, semua koin", "killzone", "Top 50"):
                continue
            la = x[(x.th >= 2023) & (x.th <= 2024)]; te = x[x.th >= 2025]
            P(f"   {var:28s} {fn:22s} latih {ringkas(la)} | uji {ringkas(te)}")
    b = max(pil, key=lambda z: z[0]); te = b[3][b[3].th >= 2025]
    P(f"   >> pilihan latih: {b[1]} + {b[2]} (latih exp {b[0]:+.3f}R) -> uji {ringkas(te)} -> "
      f"{'LULUS' if len(te) >= 100 and te.R.mean() >= 0.15 else 'TIDAK LULUS'}")

P("\n== 1. ROLLING WALK-FORWARD (pilih di 3 atau 6 bulan sebelumnya, uji murni 1 bulan berikutnya) ==")
P("   Pilihan per bulan: varian x (semua jam / killzone) x (semua koin / Top 50). Pilih exp latih tertinggi dengan n latih >= batas.")
P("   Kalau tidak ada pilihan dengan exp latih > 0, mesin libur bulan itu.")
BULAN_UJI = list(pd.period_range("2025-01", "2026-10", freq="M"))
def walk(g, jendela, nmin):
    hasil = []; libur = 0
    opsi = []
    for var, gg in g.groupby("varian"):
        for fn in ("semua", "kz", "top50", "kz+top50"):
            fm = np.ones(len(gg), bool) if fn == "semua" else (gg.kz.values if fn == "kz" else (gg.tier.values < 50 if fn == "top50" else gg.kz.values & (gg.tier.values < 50)))
            opsi.append((var, fn, gg[fm]))
    for bm in BULAN_UJI:
        lo = (bm - jendela).strftime("%Y-%m"); hi = (bm - 1).strftime("%Y-%m"); b_ = bm.strftime("%Y-%m")
        best = None
        for var, fn, x in opsi:
            la = x[(x.bulan >= lo) & (x.bulan <= hi) & (x.keluar < (pd.Timestamp(b_ + "-01", tz="UTC").value // 10**9) // 3600)]
            if len(la) >= nmin and la.R.mean() > 0 and (best is None or la.R.mean() > best[0]):
                best = (la.R.mean(), var, fn, x)
        if best is None:
            libur += 1; continue
        hasil.append(best[3][best[3].bulan == b_])
    return (pd.concat(hasil) if hasil else EV.iloc[0:0]), libur
WF = {}
for mesin in ("sektor", "segitiga", "squeeze", "impuls"):
    g = EV[EV.mesin == mesin]
    for jendela, nmin in ((3, 15), (6, 30)):
        x, lib = walk(g, jendela, nmin)
        tm = bulanan(x)
        P(f"   {mesin:9s} jendela {jendela} bln: {ringkas(x)} | bulan rugi {int((tm < 0).sum())}/22, libur {lib} | "
          f"{'LULUS' if len(x) >= 100 and x.R.mean() >= 0.15 else 'TIDAK LULUS'}")
        WF[(mesin, jendela)] = x
    gs = g[(g.th >= 2023) & (g.th <= 2024)]
P("   pembanding v149 2025-2026: exp +0.108R WR 60.2% 9.2/mgg (hasil_v153)")

# ---------- v149 sebagai daftar trade ----------
evv = ev_v149.copy(); evv["sym"] = NAMA[evv.sym.values]; evv["runner"] = np.where((k7 > 0) & (erb >= 0.1), 2, 0); evv["jenis"] = "v"
# kertas 7 hari v149 di waktu sembarang t (jam), dari sinyal m8 yang sudah selesai
kel_all = (masuk + baru["hrs"])[m8]; R_all = R[m8]; o_ = np.argsort(kel_all, kind="stable"); KK = kel_all[o_]; CS = np.r_[0, np.cumsum(R_all[o_])]
def kertas7(t):
    return CS[np.searchsorted(KK, t, "right")] - CS[np.searchsorted(KK, t - 168, "right")]
def porto_isi(ev_x, mode, lot, cap=4):
    E = pd.concat([evv, ev_x.assign(jenis="x", runner=0)]).sort_values(["masuk", "jenis"], kind="stable")
    buka = []; trades = []; antri = []; beruntun = 0; jeda_dari = None
    for z in E.itertuples():
        t = z.masuk
        if antri:
            antri.sort(); sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and beruntun >= 3:
                        jeda_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        if jeda_dari is not None:
            if t >= jeda_dari + 24:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b[1] > t]
        if any(b[0] == z.sym for b in buka):
            continue
        berisiko = [b for b in buka if b[2] > t]
        if z.jenis == "x":
            nv = sum(1 for b in berisiko if b[4] == "v")
            if mode == "sepi" and nv > 1:
                continue
            if mode == "rezim" and not kertas7(t) < 0:
                continue
            r = z.R * lot
        else:
            r = z.R
        rn = int(z.runner)
        if len(berisiko) >= cap or len(buka) >= cap + rn or sum(1 for b in berisiko if b[3] == z.arah) >= 4:
            continue
        buka.append((z.sym, z.keluar, z.aman, z.arah, z.jenis)); antri.append((z.keluar, r)); trades.append((t, z.keluar, r, z.bulan, z.jenis))
    T = pd.DataFrame(trades, columns=["masuk", "keluar", "R", "bulan", "jenis"]); T["th"] = T.bulan.str[:4].astype(int)
    return T
def lap_porto(nm, T, dasar=None):
    x = T[T.th >= 2025]; tm = bulanan(x); r = x.sort_values("keluar").R.values; mg = max((x.masuk.max() - x.masuk.min()) / 168, 1)
    s = (f"   {nm:58s} {len(x) / mg:4.1f}/mgg WR {np.mean(r > 0) * 100:4.1f}% exp {r.mean():+.3f}R tot {r.sum():+6.1f}R DD {dd(r):4.1f}R "
         f"bulan rugi {int((tm < 0).sum())}/22")
    if dasar is not None:
        s += f" | hijau jadi merah {int(((dasar >= 0) & (tm < 0)).sum())}, selisih total {r.sum() - dasar.sum():+.1f}R"
    P(s); return tm
P("\n== 2. MESIN PENAMBAL (2025-2026, satu orang, berbagi 4 slot berisiko v149) ==")
TV = porto_isi(EV.iloc[0:0].assign(jenis="x", runner=0), "sepi", 1.0)
DASAR = lap_porto("v149 + slot aman dinamis (pembanding)", TV)
SQ = EV[(EV.mesin == "squeeze") & (EV.varian == "N50 vol2.0")]
UNL = EV[EV.mesin == "unlock_short"]
IMP = EV[(EV.mesin == "impuls") & (EV.varian == "rentang0.04 vol4.0")]
kandidat = {"squeeze N50 vol2 (tetap)": SQ, "impuls 4% vol4 (tetap)": IMP, "unlock SHORT": UNL,
            "squeeze + impuls + unlock": pd.concat([SQ, IMP, UNL])}
for (m_, j_), x in WF.items():
    if j_ == 6:
        kandidat[f"{m_} walk-forward 6 bln"] = x
for nm, x in kandidat.items():
    for mode in ("sepi", "rezim"):
        for lot in (0.5, 1.0):
            T = porto_isi(x, mode, lot)
            lap_porto(f"+ {nm}, {'saat v149 <= 1 posisi' if mode == 'sepi' else 'saat kertas v149 7 hari < 0'}, lot {lot}", T, DASAR)

P("\n== 5. KANTONG KEDUA 'SINYAL PELENGKAP' (slot sendiri maks 2, lot 0.5x, tidak memakan slot v149) ==")
def kantong(x, cap=2, lot=0.5):
    T = porto2(x.drop(columns=[c for c in ("runner",) if c in x.columns]), cap=cap, runner=0)
    T["R"] *= lot; T["th"] = T.bulan.str[:4].astype(int); return T
for nm, x in (("squeeze N50 vol2", SQ), ("unlock SHORT", UNL), ("squeeze + unlock SHORT", pd.concat([SQ, UNL])),
              ("squeeze walk-forward 6 bln", WF[("squeeze", 6)]), ("sektor walk-forward 6 bln", WF[("sektor", 6)])):
    K = kantong(x)
    for per, m_ in (("latih 23-24", (K.th >= 2023) & (K.th <= 2024)), ("uji 25-26", K.th >= 2025)):
        if m_.sum():
            k_ = K[m_]; P(f"   {nm:28s} kantong saja {per}: {ringkas(k_.assign(sym=0))}")
    G = pd.concat([TV.assign(jenis="v"), K.assign(jenis="k")])
    lap_porto(f"   v149 + kantong {nm}", G, DASAR)
open("hasil_v154.txt", "w").write("\n".join(out))

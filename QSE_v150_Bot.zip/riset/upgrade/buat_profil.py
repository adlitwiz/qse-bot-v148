"""Buat profil_koin.json: catatan semua sinyal jalur per koin x jalur x arah dari uji 2021-2026 (aturan keluar v149,
filter dump 12%), untuk gerbang profil walk-forward di bot (qse_otak.profil). Kunci simbol Binance (bot mencocokkan 1000XXX)."""
import json, numpy as np
src = open("run_g15.py").read().split("B = run(")[0]
ns = {"__name__": "profil"}
exec(src, ns)
S, run, Cx = ns["S"], ns["run"], ns["Cx"]
B = run(jk=12, jmode=4, jstop=30)
ar = S.arah.values
gerak = S.body.values * S.atr.values / S.px.values * 100 * (-ar)
hari = (S.masuk_h.values // 24 + 3) % 7
ok = ~(((ar == -1) & (gerak >= 12)) | ((ar == 1) & (gerak >= 10)) | ((ar == 1) & (hari >= 5)))          # filter candle dan akhir pekan v149
kel_ms = (S.masuk_h.values + B["hrs"]) * 3600000
out = {}
for i in np.nonzero(ok)[0]:
    k = f"{S.sym.values[i]}|{S.jalur.values[i]}|{'LONG' if ar[i] == 1 else 'SHORT'}"
    out.setdefault(k, []).append([int(kel_ms[i]), round(float(B["R"][i]), 3)])
for k in out:
    out[k].sort()
akhir = int(kel_ms[ok].max())
json.dump(dict(dibuat=f"uji Binance 1 jam sejak listing, {S.sym.nunique()} koin, aturan v149", akhir_ms=akhir, sinyal=out), open("../../profil_koin.json", "w"),
          separators=(",", ":"))
print(len(out), "kunci", sum(len(v) for v in out.values()), "sinyal", akhir)

"""Grup 13 (v149): uji permintaan perombakan pada sinyal jalur robot. Pembanding = robot live sekarang
(otak buang 10% walk-forward + rem harian -3R + maks 4 berisiko searah), walk-forward 2023-2026.
Aturan lolos pra-daftar (sama dengan g10):
  P (pasang): PF naik >= 0.02 di 2023-24 dan 2025-26, dua populasi (SEMUA, NILAI 8+), total R >= 95%, WR tidak turun > 1 poin.
  DD: DD turun >= 15% di dua populasi, total >= 90%, PF tidak turun.
Varian:
  A keluar: batas umur 24 jam (ganti 36), jam ke-8 dinamis (struktur 8 candle, hanya saat melawan, jam 12), tanpa jam ke-8,
    ambil untung saat candle 4J melonjak searah (20% atau 50%), gabungan.
  B masuk: filter kelelahan (SHORT setelah turun jauh, LONG setelah naik jauh), versi balik arah, memori per koin."""
import os, numpy as np, pandas as pd
from numba import njit
import var_lib as V, core as Cx
src = open("latih_otak.py").read().split("pr = np.full")[0]
ns = {}
exec(src, ns)
S, X, y, thn, PARAM = ns["S"], ns["X"].copy(), ns["y"], ns["thn"], dict(ns["PARAM"])
from sklearn.ensemble import HistGradientBoostingClassifier
out = []
def P(s=""):
    print(s, flush=True); out.append(s)


@njit(cache=True)
def sim2(Hh, L, C, O, k0, n, d, e, risk, atrt, tp_r, trail, jmode, jk, jthr, jsl, jstop, spk, spp, tps_lv, tps_por):
    sl = e - d * risk
    best = e
    sisa = 1.0
    real = 0.0
    aman = -1
    lvp = e + d * tps_lv * risk
    has_tp = tp_r > 0
    tp = e + d * tp_r * risk
    for j in range(n):
        hi = Hh[k0 + j]
        lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if aman < 0 and tps_por > 0 and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += tps_por * sisa * tps_lv
            sisa = sisa * (1.0 - tps_por)
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1
        if has_tp and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        if d == 1:
            if hi > best:
                best = hi
        else:
            if lo < best:
                best = lo
        if j % 4 == 3:
            if trail > 0:
                nsl = best - d * trail * atrt
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
            if spk > 0:
                c4 = (C[k0 + j] - O[k0 + j - 3]) * d
                rn = (C[k0 + j] - e) * d / risk
                if c4 >= spk * atrt and rn > 0:
                    real += spp * sisa * rn
                    sisa = sisa * (1.0 - spp)
                    if (d == 1 and e > sl) or (d == -1 and e < sl):
                        sl = e
                    if aman < 0:
                        aman = j + 1
                    if sisa <= 1e-9:
                        return real, j + 1, aman
        if jmode > 0 and aman < 0 and j + 1 == jk:
            rnow = (C[k0 + j] - e) * d / risk
            if rnow <= jthr:
                return real + sisa * rnow, j + 1, aman
            if jmode == 1 or (jmode == 4 and rnow < 0):
                nsl = e + d * jsl * risk
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
            elif jmode == 2:
                a0 = max(k0, k0 + j - 7)
                if d == 1:
                    st = L[a0]
                    for q in range(a0, k0 + j + 1):
                        if L[q] < st:
                            st = L[q]
                    nsl = min(st - 0.1 * risk, C[k0 + j] - 0.3 * risk)
                    if nsl > sl:
                        sl = nsl
                else:
                    st = Hh[a0]
                    for q in range(a0, k0 + j + 1):
                        if Hh[q] > st:
                            st = Hh[q]
                    nsl = max(st + 0.1 * risk, C[k0 + j] + 0.3 * risk)
                    if nsl < sl:
                        sl = nsl
        if jstop > 0 and aman < 0 and j + 1 == jstop:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
        if jstop < 0 and j + 1 == -jstop:          # umur maks untuk SEMUA posisi, termasuk yang sudah aman
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman


@njit(cache=True)
def sim2_semua(Hh, L, C, O, k0, nmax, d, risk, atrt, tp_r, trail, jmode, jk_arr, jthr, jsl, jstop, spk, spp, biaya):
    m = len(k0)
    R = np.zeros(m)
    hrs = np.zeros(m, np.int64)
    am = np.zeros(m, np.int64)
    for i in range(m):
        e = O[k0[i]]
        r, h, a = sim2(Hh, L, C, O, k0[i], nmax[i], d[i], e, risk[i], atrt[i], tp_r[i], trail[i], jmode, jk_arr[i], jthr, jsl, jstop, spk, spp,
                       0.5, 0.20)
        R[i] = r - biaya * e / risk[i]
        hrs[i] = h
        am[i] = a
    return R, hrs, am


def run(arah=None, jmode=1, jk=8, jthr=-0.5, jsl=-0.5, jstop=36, spk=0.0, spp=0.5):
    d = (S.arah.values if arah is None else arah).astype(np.int64)
    jka = np.full(len(S), jk, np.int64) if np.isscalar(jk) else np.asarray(jk, np.int64)
    R, hrs, am = sim2_semua(Cx.H, Cx.L, Cx.C, Cx.O, S.k0.values, S.nmax.values, d, S.risk.values, S.atrt.values, S.tp_r.values,
                            S.trail.values, jmode, jka, jthr, jsl, jstop, spk, spp, Cx.BIAYA)
    return dict(R=R, hrs=hrs, aman=am)


base = run()
cek = Cx.jalankan(S)
P(f"cek sim2 = sim lama: selisih R maks {np.abs(base['R'] - cek['R']).max():.2e}")
masuk = S.masuk_h.values
ar = S.arah.values
# otak walk-forward (target dari aturan lama, sama dengan live)
pA = np.full(len(S), np.nan)
for t in (2023, 2024, 2025, 2026):
    pA[thn == t] = HistGradientBoostingClassifier(**PARAM).fit(X[thn < t], y[thn < t]).predict_proba(X[thn == t])[:, 1]
otak = np.ones(len(S), bool)
for t in (2023, 2024, 2025, 2026):
    mk = thn == t
    otak[mk] = ~(pA[mk] < np.quantile(pA[mk], 0.10))
uji = thn >= 2023
sid = pd.factorize(S.sym.values)[0]


def porto(res, pilih, cap=5, runner=2, jeda_k=3, jeda_jam=24, rugi_hari=3, maks_searah=4, arah=None, memori=None):
    Rr, keluar = res["R"], masuk + res["hrs"]
    am = res["aman"]
    aman_t = np.where(am >= 0, masuk + np.maximum(am, 0), keluar)
    arr = ar if arah is None else arah
    buka, antri, trades = [], [], []
    beruntun, jeda_dari = 0, None
    hist = {}
    selesai = []
    for idx in np.nonzero(pilih)[0]:
        t = masuk[idx]
        if antri:
            antri.sort(); sisa = []
            for k_, r_, s_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and beruntun >= jeda_k:
                        jeda_dari = k_
                    hist.setdefault(s_, []).append(r_)
                else:
                    sisa.append((k_, r_, s_))
            antri = sisa
        if jeda_dari is not None:
            if t >= jeda_dari + jeda_jam:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b[1] > t]
        h0 = (t // 24) * 24
        if sum(x[2] for x in trades if h0 <= x[1] <= t) <= -rugi_hari:
            continue
        if any(b[0] == sid[idx] for b in buka):
            continue
        if memori:
            hh = hist.get(sid[idx], [])[-memori[0]:]
            if len(hh) >= memori[1] and np.mean(hh) < memori[2]:
                continue
        berisiko = [b for b in buka if b[2] > t]
        if len(berisiko) >= cap or len(buka) >= cap + runner:
            continue
        if sum(1 for b in berisiko if b[3] == arr[idx]) >= maks_searah:
            continue
        buka.append((sid[idx], keluar[idx], aman_t[idx], arr[idx]))
        antri.append((keluar[idx], Rr[idx], sid[idx]))
        trades.append((t, keluar[idx], Rr[idx], idx))
    return np.array(trades, float).reshape(-1, 4)


def mt(T):
    r = T[:, 2]
    i = T[:, 3].astype(int)
    o = np.argsort(T[:, 1], kind="stable")
    eq = np.cumsum(r[o])
    m = dict(n=len(r), wr=np.mean(r > 0) * 100, pf=r[r > 0].sum() / -r[r < 0].sum(), tot=r.sum(), dd=float((np.maximum.accumulate(eq) - eq).max()),
             slp=np.mean(r < -0.9) * 100, jam=float(np.median(T[:, 1] - T[:, 0])))
    for nm, mk in (("a", thn[i] <= 2024), ("b", thn[i] >= 2025)):
        x = r[mk]
        m["pf_" + nm], m["tot_" + nm], m["wr_" + nm] = x[x > 0].sum() / -x[x < 0].sum(), x.sum(), np.mean(x > 0) * 100
    return m


def jalan(res, pilih=None, **kw):
    pl = otak & uji if pilih is None else (otak & uji & pilih)
    return {pop: mt(porto(res, V.POP[pop] & pl, **kw)) for pop in V.PRIMER}


def fmt(nm, M, A):
    s = nm
    for pop in V.PRIMER:
        v, a = M[pop], A[pop]
        s += (f"\n    [{pop}] n {v['n']} WR {v['wr']:.1f}/{a['wr']:.1f} PF {v['pf']:.2f}/{a['pf']:.2f} tot {v['tot']:+.0f}/{a['tot']:+.0f} "
              f"DD {v['dd']:.0f}/{a['dd']:.0f} SLpenuh {v['slp']:.1f}/{a['slp']:.1f}% jam {v['jam']:.0f}"
              f" | 23-24 PF {v['pf_a']:.2f}/{a['pf_a']:.2f} {v['tot_a']:+.0f} | 25-26 PF {v['pf_b']:.2f}/{a['pf_b']:.2f} {v['tot_b']:+.0f}")
    pin = all((M[p]["pf_a"] >= A[p]["pf_a"] + 0.02) and (M[p]["pf_b"] >= A[p]["pf_b"] + 0.02) and M[p]["tot"] >= 0.95 * A[p]["tot"]
              and M[p]["wr"] >= A[p]["wr"] - 1 for p in V.PRIMER)
    ddk = all(M[p]["dd"] <= 0.85 * A[p]["dd"] and M[p]["tot"] >= 0.90 * A[p]["tot"] and M[p]["pf"] >= A[p]["pf"] for p in V.PRIMER)
    return s + f"\n    lolos P {pin}  lolos DD {ddk}"


LV = jalan(base)
P(fmt("LIVE sekarang (jam 8, 36 jam, otak, rem, maks 4 searah)", LV, LV))
P("\n== A. KELUAR")
VAR = [("umur maks 24 jam", dict(jstop=24)),
       ("umur maks 24 jam, tanpa jam ke-8", dict(jstop=24, jmode=0)),
       ("tanpa jam ke-8 (36 jam)", dict(jmode=0)),
       ("jam ke-8 dinamis struktur 8 candle", dict(jmode=2)),
       ("jam ke-8 hanya saat harga melawan", dict(jmode=4)),
       ("jam ke-12 (ganti 8)", dict(jk=12)),
       ("jam ke-8 SL -0.7R", dict(jsl=-0.7, jthr=-0.7)),
       ("struktur + umur 24 jam", dict(jmode=2, jstop=24)),
       ("lonjakan 4J >= 1 ATR: TP 50%", dict(spk=1.0, spp=0.5)),
       ("lonjakan 4J >= 1.5 ATR: TP 50%", dict(spk=1.5, spp=0.5)),
       ("lonjakan 4J >= 1 ATR: TP 20%", dict(spk=1.0, spp=0.2)),
       ("lonjakan 4J >= 1.5 ATR: tutup 100%", dict(spk=1.5, spp=1.0)),
       ("lonjakan 4J >= 2 ATR: tutup 100%", dict(spk=2.0, spp=1.0)),
       ("lonjakan 1.5 ATR 50% + umur 24 jam", dict(spk=1.5, spp=0.5, jstop=24)),
       ("lonjakan 1.5 ATR 50% + struktur", dict(spk=1.5, spp=0.5, jmode=2))]
HASIL = {}
for nm, kw in VAR:
    r = run(**kw)
    HASIL[nm] = r
    P(fmt(nm, jalan(r), LV))
P("\n== B. MASUK")
d12, p12 = S.drop12.values, S.pump12.values
for X_ in (6, 8, 10, 12):
    lelah = ((ar == -1) & (d12 >= X_)) | ((ar == 1) & (p12 >= X_))
    P(f"-- kelelahan {X_} ATR 4J dalam 12 candle: {lelah[uji & otak].sum()} sinyal, rata R {base['R'][lelah & uji & otak].mean():+.3f} "
      f"WR {np.mean(base['R'][lelah & uji & otak] > 0) * 100:.1f}")
    P(fmt(f"buang sinyal lelah >= {X_}", jalan(base, ~lelah), LV))
    rb = run(arah=-ar)
    gab = dict(R=np.where(lelah, rb["R"], base["R"]), hrs=np.where(lelah, rb["hrs"], base["hrs"]), aman=np.where(lelah, rb["aman"], base["aman"]))
    P(f"   versi balik arah: rata R sinyal lelah dibalik {rb['R'][lelah & uji & otak].mean():+.3f}")
    P(fmt(f"balik arah sinyal lelah >= {X_}", jalan(gab, arah=np.where(lelah, -ar, ar)), LV))
for mem in ((10, 5, -0.2), (10, 5, 0.0), (6, 4, -0.3), (20, 8, -0.1)):
    P(fmt(f"memori per koin {mem}", jalan(base, memori=mem), LV))
open(f"{Cx.SC}/hasil_g13.txt", "w").write("\n".join(out))

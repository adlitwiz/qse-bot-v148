"""v151 (permintaan 3 Nov 21:36): metrik expectancy, risiko bertingkat, time-decay, mean reversion.
Asal: uji 6 perubahan permintaan user 3 Nov 2026 (11:04 dan 11:06). Data Binance 383 koin 1J, universe 150 likuid, satu orang.
Semua keputusan pakai data sebelum sinyal. Ambang dipilih di 2023-2024, dinilai di 2025-2026. Biaya 0.15% harga.
1. Rem 7 hari jadi mode: saat rem, hanya NILAI 10 (skor 90) dan/atau setengah risiko, bukan tahan total.
   Gerbang profil dilonggarkan (gabungan semua jalur arah sama, min 5). LONG akhir pekan boleh kalau volume 24 jam >= 2x rata 30 hari.
2. TPawal 40-50% di +0.5R, SL ke -0.25R, SL ke entry di +0.8R. Posisi aman tidak dihitung dalam batas 4 (runner).
3. Sapuan likuiditas 1 dan 2 candle 4J + volume >= 2x, di support kuat (disentuh >= 2x) atau divergensi RSI.
   Derivatif BTC (Binance Futures): BTC turun + OI turun + funding sangat minus -> SHORT ditahan (cermin untuk LONG).
4. Masuk koreksi: tunggu koreksi di 1J, Conditional Stop di atas high candle pantulan, SL di ujung ekor pantulan, TP dihitung ulang.
5. Laporan: per bulan 2025-2026, sinyal per minggu, WR, PF, DD, v149 lawan gabungan perubahan yang lolos."""
import os, numpy as np, pandas as pd
from numba import njit
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "v150"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
import core as Cx
DERIV = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/deriv"
CSV = os.path.join(Cx.SC, "data")
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
H_, L_, C_, O_, TS = Cx.H, Cx.L, Cx.C, Cx.O, Cx.TS
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
ar = S.arah.values; jl = S.jalur.values; masuk = S.masuk_h.values; k0 = S.k0.values
dow = pd.to_datetime(S["T"].values, unit="ms", utc=True).dayofweek.values
wkL = (ar == 1) & (dow >= 5)
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
dasar_mask = ok & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
m8 = dasar_mask & izin & ~wkL                         # v149 seperti bot live (akhir pekan LONG ditahan)
lat = thn <= 2024; tes = thn >= 2025
minggu = lambda T: max((T[:, 0].max() - T[:, 0].min()) / 168, 1) if len(T) else 1
def nilai(nm, T, ringkas=True):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]; th_ = thn[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    t2 = T[th_ >= 2025]; r2 = t2[:, 2]
    P(f"   {nm:56s} n {len(r):5d} {len(r) / minggu(T):4.1f}/mgg WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} tot {r.sum():+5.0f}R DD {dd(r[o_]):3.0f}R | "
      f"PF<1 {int((pm < 1).sum()):2d}/{len(pm)} terburuk {tm.min():+5.1f} | 23-24 PF {pf(r[th_ <= 2024]):.2f} | 25-26 n/mgg {len(r2) / minggu(t2):4.1f} "
      f"WR {np.mean(r2 > 0) * 100 if len(r2) else 0:4.1f}% PF {pf(r2):.2f} DD {dd(r2[np.argsort(t2[:, 1], kind='stable')]):3.0f}R")
    return T
# rem 7 hari dari trade kertas semua sinyal m8 yang sudah selesai
def rem_flag(res, pilih, batas=-3.0):
    R = res["R"]; kel = masuk + res["hrs"]; idx = np.nonzero(pilih)[0]
    o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
    f = np.zeros(len(S), bool)
    j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
    f[idx] = (cs[j] - cs[j0]) < batas
    return f
def skala(T, mask_half):
    T = T.copy(); h = mask_half[T[:, 3].astype(int)]; T[h, 2] *= 0.5; return T
P("== DASAR ==")
rem = rem_flag(baru, m8)
B0 = nilai("v149 tanpa rem 7 hari", jalankan(baru, m8, 4, 0))
B1 = nilai("v149 + rem 7 hari TOTAL (terpasang)", jalankan(baru, m8 & ~rem, 4, 0))


P("\nMetrik baru: Expectancy (rata R per trade, sudah ukuran lot), total R, DD, total/DD, WR, sinyal per minggu. Pilih di 2023-24, nilai 2025-26.")
def metrik(nm, T):
    r = T[:, 2]; i = T[:, 3].astype(int); th_ = thn[i]; o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]
    tm = pd.Series(r).groupby(b).sum()
    def blok(m_):
        x = r[m_]; t_ = T[m_]; oo = np.argsort(t_[:, 1], kind="stable"); d_ = dd(x[oo])
        return f"n/mgg {len(x) / minggu(t_):4.1f} WR {np.mean(x > 0) * 100 if len(x) else 0:4.1f}% exp {x.mean() if len(x) else 0:+.3f}R tot {x.sum():+5.0f}R DD {d_:3.0f}R tot/DD {x.sum() / max(d_, 1e-9):4.1f}"
    P(f"   {nm:58s} | 23-24 {blok(th_ <= 2024)} | 25-26 {blok(th_ >= 2025)} | bulan rugi {int((tm < 0).sum())}/{len(tm)} terburuk {tm.min():+.1f}")
    return T
R = baru["R"]; kel = masuk + baru["hrs"]
sid = pd.factorize(S.sym.values)[0]
n10 = S.nilai_n.values >= 8; n9 = S.nilai_n.values >= 5
def mode_rem(T, remf):
    """rem 7 hari menyala: hanya NILAI 10, setengah lot (yang terpasang)."""
    i = T[:, 3].astype(int); keep = ~remf[i] | n10[i]
    T = T[keep].copy(); T[remf[T[:, 3].astype(int)], 2] *= 0.5; return T
def porto_mode(res, pilih, ukuran=None, cap=4, runner=0):
    remf = rem_flag(res, pilih)
    T = jalankan(res, pilih & (~remf | n10), cap, runner)
    if ukuran is not None:
        T = T.copy(); T[:, 2] *= ukuran[T[:, 3].astype(int)]
    T = T.copy(); T[remf[T[:, 3].astype(int)], 2] *= 0.5
    return T

P("\n== 0. DASAR ==")
TA = metrik("v149 terpasang (rem mode NILAI 10 setengah lot), slot 4", porto_mode(baru, m8))
metrik("+ posisi aman di luar slot (maks 2)", porto_mode(baru, m8, runner=2))
metrik("+ posisi aman di luar slot (maks 4)", porto_mode(baru, m8, runner=4))


TB = porto_mode(baru, m8, runner=2)
def tab(T):
    i = T[:, 3].astype(int); r = T[:, 2]; b = bln[i]; rows = []
    for m in sorted(set(b)):
        k = b == m; x = r[k]; ox = np.argsort(T[k, 1], kind="stable")
        rows.append((m, len(x) / 4.33, np.mean(x > 0) * 100, x.mean(), x.sum(), dd(x[ox])))
    return pd.DataFrame(rows, columns=["bulan", "per_mgg", "WR", "exp", "R", "DD"]).set_index("bulan")
G = tab(TA).join(tab(TB), lsuffix="_v149", rsuffix="_aman2", how="outer").fillna(0)
G = G[G.index >= "2025-01"]
pd.set_option("display.width", 250)
P("\nPer bulan 2025-2026: v149 terpasang lawan + posisi aman di luar slot (maks 2)")
P(G.round(2).to_string())
open("hasil_v151_bulan.txt", "w").write("\n".join(out))

"""Mesin uji variasi aturan robot. Simulasi 1 jam (numba) sama dengan riset/porto/pf_slpenuh.py: SL dicek dulu, TP sebagian,
trailing tiap 4 jam, jam ke-8 ketat, batas 36 jam untuk posisi belum aman. Portofolio satu orang sama dengan pf_beruntun.porto2:
5 slot berisiko + 2 slot aman, satu koin satu posisi, jeda 24 jam setelah 3 rugi beruntun. Ditambah entry ulang dan filter."""
import json, heapq, os
import numpy as np, pandas as pd
from numba import njit

SC = os.environ.get("QSE_UJI_DIR", os.path.dirname(os.path.abspath(__file__)))          # tempat h1.npz, off.json, btc_izin.npz (dibuat bt_prep.py)
Z = np.load(f"{SC}/h1.npz")
O, H, L, C, TS = Z["O"], Z["H"], Z["L"], Z["C"], Z["T"]
OFF = json.load(open(f"{SC}/off.json"))
BZ = np.load(f"{SC}/btc_izin.npz")
BIAYA = 0.0015
SL_ATR = {"ema_short": 1.5, "mcginley": 1.5, "ichimoku": 1.5}
TPR = {"snr_vol": 3.0, "smc_choch": 3.0, "mcginley": 4.0, "orderblock": 4.0}
TRL = {"ema_short": 4.0, "msb_hpz": 4.0, "rsi_vol": 3.0, "ichimoku": 4.0}
UMUR = {"ema_short": 8.1, "mcginley": 8.1, "rsi_vol": 8.1, "snr_vol": 6.1, "smc_choch": 2.1, "msb_hpz": 1.0, "ichimoku": 2.1, "orderblock": 1.0}
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}

# jenis keluar
K_SL0, K_SLJ8, K_SLBE, K_SLTR, K_TP, K_J8, K_36, K_END = range(8)


@njit(cache=True)
def sim1(H, L, C, k0, n, d, e, risk, atrt, tp_r, trail, tps_lv, tps_por, sl_aft, jk, jthr, jsl, jstop, ph):
    """Return (R_kotor, jam_keluar, jam_aman atau -1, jenis_keluar, harga_keluar, mfe). Jam dihitung dari awal simulasi."""
    sl = e - d * risk
    slk = 0
    best = e
    sisa = 1.0
    real = 0.0
    aman = -1
    lvp = e + d * tps_lv * risk
    has_tp = tp_r > 0
    tp = e + d * tp_r * risk
    mfe = 0.0
    for j in range(n):
        hi = H[k0 + j]
        lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman, slk, sl, mfe
        fe = (hi - e) / risk if d == 1 else (e - lo) / risk
        if fe > mfe:
            mfe = fe
        if aman < 0 and tps_por > 0 and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += tps_por * sisa * tps_lv
            sisa = sisa * (1.0 - tps_por)
            nsl = e + d * sl_aft * risk
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
                slk = 2
            aman = j + 1
        if has_tp and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman, 4, tp, mfe
        if d == 1:
            if hi > best:
                best = hi
        else:
            if lo < best:
                best = lo
        if trail > 0 and (j + ph) % 4 == 3:
            nsl = best - d * trail * atrt
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
                slk = 3
        if jk > 0 and aman < 0 and j + 1 == jk:
            rnow = (C[k0 + j] - e) * d / risk
            if rnow <= jthr:
                return real + sisa * rnow, j + 1, aman, 5, C[k0 + j], mfe
            nsl = e + d * jsl * risk
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
                slk = 1
        if jstop > 0 and aman < 0 and j + 1 == jstop:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman, 6, C[k0 + j], mfe
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman, 7, C[k0 + n - 1], mfe


@njit(cache=True)
def sim_semua(H, L, C, O, k0, nmax, d, risk, atrt, tp_r, trail, tps_lv, tps_por, sl_aft, jk, jthr, jsl, jstop):
    m = len(k0)
    R = np.zeros(m)
    hrs = np.zeros(m, np.int64)
    am = np.zeros(m, np.int64)
    kd = np.zeros(m, np.int64)
    px = np.zeros(m)
    mf = np.zeros(m)
    en = np.zeros(m)
    for i in range(m):
        e = O[k0[i]]
        en[i] = e
        r, h, a, k, p, f = sim1(H, L, C, k0[i], nmax[i], d[i], e, risk[i], atrt[i], tp_r[i], trail[i], tps_lv, tps_por[i] if False else tps_por,
                                sl_aft, jk, jthr, jsl, jstop, 0)
        R[i] = r - BIAYA * e / risk[i]
        hrs[i] = h
        am[i] = a
        kd[i] = k
        px[i] = p
        mf[i] = f
    return R, hrs, am, kd, px, mf, en


@njit(cache=True)
def sim_semua_por(H, L, C, O, k0, nmax, d, risk, atrt, tp_r, trail, tps_lv, tps_por_arr, sl_aft, jk, jthr, jsl, jstop):
    """Sama dengan sim_semua, tapi porsi TP sebagian berbeda per sinyal (tps_por_arr)."""
    m = len(k0)
    R = np.zeros(m)
    hrs = np.zeros(m, np.int64)
    am = np.zeros(m, np.int64)
    kd = np.zeros(m, np.int64)
    px = np.zeros(m)
    mf = np.zeros(m)
    en = np.zeros(m)
    for i in range(m):
        e = O[k0[i]]
        en[i] = e
        r, h, a, k, p, f = sim1(H, L, C, k0[i], nmax[i], d[i], e, risk[i], atrt[i], tp_r[i], trail[i], tps_lv, tps_por_arr[i],
                                sl_aft, jk, jthr, jsl, jstop, 0)
        R[i] = r - BIAYA * e / risk[i]
        hrs[i] = h
        am[i] = a
        kd[i] = k
        px[i] = p
        mf[i] = f
    return R, hrs, am, kd, px, mf, en


@njit(cache=True)
def reentry_semua(H, L, C, k0, nmax, d, risk, atrt, tp_r, trail, tps_lv, tps_por, sl_aft, jk, jthr, jsl, jstop,
                  ok, x1, px1, offset, jendela):
    """Entry ulang LIMIT di harga keluar trade pertama - d*offset*risk, berlaku sampai `jendela` jam sejak sinyal.
    Terisi kalau harga menyentuh. SL baru = harga isi -/+ risk yang sama. Bar isi: hanya cek SL (pesimis).
    Return (terisi, jam_isi_rel, R_bersih, jam_keluar_rel, jam_aman_rel, jenis)."""
    m = len(k0)
    fil = np.zeros(m, np.int64)
    jf = np.zeros(m, np.int64)
    R = np.zeros(m)
    hk = np.zeros(m, np.int64)
    am = np.full(m, -1, np.int64)
    kd = np.zeros(m, np.int64)
    for i in range(m):
        if not ok[i]:
            continue
        p = px1[i] - d[i] * offset * risk[i]
        akhir = min(jendela[i], nmax[i])
        j = x1[i]
        found = -1
        while j < akhir:
            hi = H[k0[i] + j]
            lo = L[k0[i] + j]
            if (d[i] == 1 and lo <= p) or (d[i] == -1 and hi >= p):
                found = j
                break
            j += 1
        if found < 0:
            continue
        hi = H[k0[i] + found]
        lo = L[k0[i] + found]
        fil[i] = 1
        jf[i] = found + 1
        cost = BIAYA * p / risk[i]
        if (d[i] == 1 and lo <= p - risk[i]) or (d[i] == -1 and hi >= p + risk[i]):
            R[i] = -1.0 - cost
            hk[i] = found + 1
            kd[i] = 0
            continue
        st = found + 1
        n2 = nmax[i] - st
        if n2 < 2:
            fil[i] = 0
            continue
        r, h, a, k, pp, f = sim1(H, L, C, k0[i] + st, n2, d[i], p, risk[i], atrt[i], tp_r[i], trail[i], tps_lv, tps_por, sl_aft,
                                 jk, jthr, jsl, jstop, st)
        R[i] = r - cost
        hk[i] = st + h
        am[i] = (st + a) if a >= 0 else -1
        kd[i] = k
    return fil, jf, R, hk, am, kd


def siapkan(S):
    """Terapkan gerbang yang sama dengan bot (likuid, SL 0.3-10% harga, mutu minus, SHORT lawan pump) lalu tambahkan kolom yang dibutuhkan sim:
    k0 global, nmax, risk, atrt, tp_r, trail, masuk_h, tahun, umur_h."""
    S = S.copy()
    S = S[~(S.jalur.isin(LIK.keys()) & ~(S["rank"] <= S.jalur.map(LIK).fillna(9999)))]
    S = S[(S.mp - S.mm) > -2]
    S = S[~S.pump]
    S["sl_atr"] = S.jalur.map(SL_ATR).fillna(2.0)
    S["risk"] = np.where(S.risk0.notna(), S.risk0, S.sl_atr * S.atr)
    S["atrt"] = S.atr
    pr = S.risk / S.px
    S = S[(pr >= 0.003) & (pr <= 0.10)]
    S["tp_r"] = S.jalur.map(TPR).fillna(0.0)
    S["trail"] = S.jalur.map(TRL).fillna(0.0)
    off = S.sym.map(lambda s: OFF[s][0]).values
    ln = S.sym.map(lambda s: OFF[s][1]).values
    S["k0"] = (off + S.k1.values).astype(np.int64)
    maks = np.where(S.tp_r > 0, 180, 240)
    S["nmax"] = np.minimum(maks, ln - S.k1.values).astype(np.int64)
    S["masuk_h"] = (TS[S.k0.values] // 3600000).astype(np.int64)
    S["tahun"] = pd.to_datetime(TS[S.k0.values], unit="ms", utc=True).year
    S["umur_h"] = (S.jalur.map(UMUR).fillna(1.0) * 4).round().astype(np.int64)
    S = S[S.nmax >= 48].reset_index(drop=True)
    S = S.sort_values(["masuk_h", "sym", "jalur"], kind="stable").reset_index(drop=True)
    return S


def jalankan(S, tps_lv=0.5, tps_por=0.20, sl_aft=0.0, jk=8, jthr=-0.5, jsl=-0.5, jstop=36):
    por = np.full(len(S), float(tps_por)) if np.isscalar(tps_por) else np.asarray(tps_por, float)
    R, hrs, am, kd, px, mf, en = sim_semua_por(H, L, C, O, S.k0.values, S.nmax.values, S.arah.values.astype(np.int64), S.risk.values,
                                               S.atrt.values, S.tp_r.values, S.trail.values, float(tps_lv), por, float(sl_aft), int(jk),
                                               float(jthr), float(jsl), int(jstop))
    return dict(R=R, hrs=hrs, aman=am, kd=kd, px=px, mfe=mf, en=en)


def entry_ulang(S, res, pemicu, offset, **kw):
    """Hitung entry ulang untuk sinyal yang trade pertamanya keluar dengan jenis di `pemicu` (set kode keluar) dan masih dalam masa berlaku."""
    ok = np.isin(res["kd"], list(pemicu)) & (res["hrs"] < S.umur_h.values)
    p = dict(tps_lv=0.5, tps_por=0.20, sl_aft=0.0, jk=8, jthr=-0.5, jsl=-0.5, jstop=36)
    p.update(kw)
    fil, jf, R, hk, am, kd = reentry_semua(H, L, C, S.k0.values, S.nmax.values, S.arah.values.astype(np.int64), S.risk.values, S.atrt.values,
                                           S.tp_r.values, S.trail.values, p["tps_lv"], float(p["tps_por"]), p["sl_aft"], p["jk"], p["jthr"],
                                           p["jsl"], p["jstop"], ok, res["hrs"].astype(np.int64), res["px"], float(offset),
                                           S.umur_h.values.astype(np.int64))
    return dict(fil=fil.astype(bool), jf=jf, R=R, hk=hk, aman=am, kd=kd, ok=ok)


# ---------------- portofolio satu orang ----------------
def portofolio(S, res, pilih=None, re=None, filter_re=None, cap=5, runner=2, jeda_k=3, jeda_jam=24):
    """Pilih trade mengikuti aturan satu orang. pilih = mask sinyal yang boleh diambil. re = hasil entry_ulang (atau None);
    filter_re = mask boolean per sinyal yang membolehkan entry ulang (kondisi pasar). Return dict(daftar trade terambil)."""
    n = len(S)
    masuk = S.masuk_h.values
    keluar = masuk + res["hrs"]
    am = res["aman"]
    aman_t = np.where(am >= 0, masuk + np.maximum(am, 0), keluar)
    R = res["R"]
    sym = S.sym.values
    simbol = {s: i for i, s in enumerate(sorted(set(sym)))}
    sid = np.array([simbol[s] for s in sym])
    # event: (waktu, urutan, jenis, indeks). jenis 0 asli, 1 entry ulang
    pend = []
    buka = []                     # list dict(sym, keluar, aman_t, R, idx, jenis)
    antri = []                    # (keluar, R) belum dihitung beruntun
    beruntun, jeda_dari = 0, None
    trades = []
    i = 0
    while i < n or pend:
        if pend and (i >= n or pend[0][0] <= masuk[i]):
            t, _, idx = heapq.heappop(pend)
            jenis = 1
            kel = masuk[idx] + re["jf"][idx] + re["hk"][idx] - re["jf"][idx]       # hk sudah relatif ke k0
            kel = masuk[idx] + re["hk"][idx]
            ama = masuk[idx] + re["aman"][idx] if re["aman"][idx] >= 0 else kel
            rr = re["R"][idx]
            tt = t
        else:
            idx = i
            i += 1
            if pilih is not None and not pilih[idx]:
                continue
            jenis = 0
            kel, ama, rr, tt = keluar[idx], aman_t[idx], R[idx], masuk[idx]
            t = tt
        if antri:
            antri.sort()
            sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and jeda_k and beruntun >= jeda_k:
                        jeda_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        if jeda_dari is not None:
            if t >= jeda_dari + jeda_jam:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b[1] > t]
        if any(b[0] == sid[idx] for b in buka):
            continue
        berisiko = sum(1 for b in buka if b[2] > t)
        if berisiko >= cap or len(buka) >= cap + runner:
            continue
        buka.append((sid[idx], kel, ama))
        antri.append((kel, rr))
        trades.append((tt, kel, ama, rr, idx, jenis))
        # jadwalkan entry ulang untuk trade asli yang diambil
        if jenis == 0 and re is not None and re["fil"][idx] and (filter_re is None or filter_re[idx]):
            te = masuk[idx] + re["jf"][idx]
            heapq.heappush(pend, (te, idx, idx))
    T = np.array(trades, dtype=float).reshape(-1, 6) if trades else np.zeros((0, 6))
    return T


def pf(x):
    x = np.asarray(x)
    return float(x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)) if len(x) else 0.0


def metrik(T, S, span_jam=None):
    """T = hasil portofolio (waktu_masuk, keluar, aman, R, idx, jenis). Ringkasan total dan per periode (masuk <2024 dan >=2024)."""
    if not len(T):
        return {}
    ent, kel, ama, R = T[:, 0], T[:, 1], T[:, 2], T[:, 3]
    urut = np.argsort(kel, kind="stable")
    x = R[urut]
    eq = np.cumsum(x)
    dd = float((np.maximum.accumulate(eq) - eq).max())
    th = pd.to_datetime(ent * 3600000, unit="ms", utc=True).year.values
    span = (ent.max() - ent.min()) / 24 if span_jam is None else span_jam / 24
    out = dict(n=len(x), per_hari=len(x) / span, wr=float(np.mean(x > 0) * 100), pf=pf(x), total=float(x.sum()), dd=dd,
               rata=float(x.mean()), slp=float(np.mean(x < -0.9) * 100),
               buka=float((kel - ent).sum() / max(ent.max() - ent.min(), 1)), berisiko=float((np.minimum(ama, kel) - ent).sum() / max(ent.max() - ent.min(), 1)))
    for nm, mk in (("a", th < 2024), ("b", th >= 2024)):
        y = R[mk]
        out["n_" + nm] = int(mk.sum())
        out["pf_" + nm] = pf(y)
        out["tot_" + nm] = float(y.sum())
        out["wr_" + nm] = float(np.mean(y > 0) * 100) if len(y) else 0.0
        z = R[mk][np.argsort(kel[mk], kind="stable")]
        e2 = np.cumsum(z)
        out["dd_" + nm] = float((np.maximum.accumulate(e2) - e2).max()) if len(z) else 0.0
    return out


def baris(nm, m, base=None):
    s = (f"{nm:46s} n {m['n']:5d} ({m['per_hari']:.2f}/hari) WR {m['wr']:4.1f} PF {m['pf']:.2f} total {m['total']:+6.0f}R DD {m['dd']:3.0f} "
         f"SLp {m['slp']:4.1f}% buka {m['buka']:.1f} | 21-23: WR {m['wr_a']:4.1f} PF {m['pf_a']:.2f} {m['tot_a']:+5.0f}R DD {m['dd_a']:3.0f} | "
         f"24-26: WR {m['wr_b']:4.1f} PF {m['pf_b']:.2f} {m['tot_b']:+5.0f}R DD {m['dd_b']:3.0f}")
    return s

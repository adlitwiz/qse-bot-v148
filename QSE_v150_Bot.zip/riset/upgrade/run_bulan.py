"""v149 riset bulanan (permintaan 3 Nov 2026), data Binance 383 koin, universe 150 koin likuid, satu orang, aturan v149 lengkap
(jam 12 dinamis, 30 jam, dump 12%, pump 10%, profil koin walk-forward, otak, maks 4 posisi).
1. Rapor per bulan 2023-01 sampai 2026-10: trade, WR, PF, total, DD dalam bulan. NILAI 8+ dan semua.
2. Bedah bulan: fitur pasar per bulan (vol, jarum, korelasi BTC, tren BTC, efisiensi tren alt, sapuan SL) lawan PF bulan (Spearman).
3. Penawar: PF per jalur x arah di bulan merah lawan bulan hijau, dan sinyal dibalik arah di bulan merah.
4. Detektor bergulir (pakai trade kertas yang sudah selesai saja, tanpa melihat masa depan): 10 sinyal terakhir PF < 1, 7 hari terakhir rugi,
   per jalur 10 terakhir. Aksi: kunci, setengah risiko, balik arah. Dinilai per bulan: jumlah bulan PF < 1, bulan terburuk, total, DD."""
import os, numpy as np, pandas as pd
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "bulan"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
pump10 = ns["pump10"]
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
UNI = S["rank"].values <= 150
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
pilih = ok & izin & ~pump10 & otak & uji & UNI
masuk = S.masuk_h.values
keluar = masuk + baru["hrs"]
R = baru["R"]
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
ar = S.arah.values
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
def rapor_bulan(T, judul, cetak=True):
    i = T[:, 3].astype(int); o = np.argsort(T[:, 1], kind="stable")
    r = T[:, 2]; b = bln[i]
    rows = []
    for m in sorted(set(b)):
        k = b == m; x = r[k]; ox = np.argsort(T[k, 1], kind="stable")
        rows.append((m, len(x), np.mean(x > 0) * 100, pf(x), x.sum(), dd(x[ox])))
    D = pd.DataFrame(rows, columns=["bulan", "trade", "WR", "PF", "total_R", "DD_R"])
    if cetak:
        P(f"\n== {judul} ==")
        P(D.round(2).to_string(index=False))
    merah = D[D.PF < 1]
    P(f"   ringkas {judul}: {len(D)} bulan, PF<1: {len(merah)} bulan, PF>=1.5: {int((D.PF >= 1.5).sum())} bulan, terburuk {D.total_R.min():+.1f}R "
      f"({D.bulan[D.total_R.idxmin()]}), total {r.sum():+.0f}R, DD {dd(r[o]):.0f}R, PF {pf(r):.2f}")
    return D
P(f"{S.sym.nunique()} koin, sinyal lolos v149: {int(pilih.sum())}")
T8 = jalankan(baru, V.POP["SEIMBANG"] & pilih, 4, 0)
Ts = jalankan(baru, V.POP["SEMUA"] & pilih, 4, 0)
D8 = rapor_bulan(T8, "1. RAPOR PER BULAN v149, NILAI 8+")
Ds = rapor_bulan(Ts, "1b. RAPOR PER BULAN v149, semua sinyal")

# 2. bedah bulan
P("\n== 2. BEDAH BULAN: fitur pasar lawan PF bulan (NILAI 8+) ==")
OFF = Cx.OFF; TS = Cx.TS
ranks = S.groupby("sym")["rank"].median()
koin = [s for s in OFF if s in ranks.index and ranks[s] <= 150]
b0 = OFF["BTCUSDT"][0]; bl = OFF["BTCUSDT"][1]
bT = TS[b0:b0 + bl]; bC = Cx.C[b0:b0 + bl]
bret = pd.Series(np.r_[0, np.diff(np.log(bC))], index=pd.to_datetime(bT, unit="ms", utc=True))
fit = {}
for s in koin[:150]:
    a, n = OFF[s]
    t = pd.to_datetime(TS[a:a + n], unit="ms", utc=True)
    o_, h_, l_, c_ = Cx.O[a:a + n], Cx.H[a:a + n], Cx.L[a:a + n], Cx.C[a:a + n]
    rg = np.maximum(h_ - l_, 1e-12)
    df = pd.DataFrame(dict(vol=rg / c_ * 100, jarum=(rg - np.abs(c_ - o_)) / rg, ret=np.r_[0, np.diff(np.log(c_))], c=c_), index=t)
    df["btc"] = bret.reindex(t).values
    g = df.groupby(df.index.strftime("%Y-%m"))
    f = pd.DataFrame(dict(vol=g.vol.median(), jarum=g.jarum.mean(),
                          kor=g.apply(lambda x: x.ret.corr(x.btc) if x.btc.notna().sum() > 100 else np.nan),
                          efisiensi=g.c.apply(lambda x: abs(x.iloc[-1] - x.iloc[0]) / max(np.abs(np.diff(x.values)).sum(), 1e-12))))
    fit[s] = f
F = pd.concat(fit).groupby(level=1).median()
bm = pd.Series(bC, index=pd.to_datetime(bT, unit="ms", utc=True))
gb = bm.groupby(bm.index.strftime("%Y-%m"))
F["btc_ret"] = gb.apply(lambda x: (x.iloc[-1] / x.iloc[0] - 1) * 100)
F["btc_vol"] = bret.groupby(bret.index.strftime("%Y-%m")).std() * np.sqrt(24) * 100
# sapuan: trade kena SL yang lalu sampai TPawal dalam 24 jam setelah SL (stop hunt)
i8 = T8[:, 3].astype(int)
sap = np.zeros(len(i8), bool); kena_sl = T8[:, 2] < -0.9
for q, i in enumerate(i8):
    if not kena_sl[q]:
        continue
    a, n = OFF[S.sym.values[i]]
    k1 = int(S.k0.values[i] + baru["hrs"][i]); k2 = min(k1 + 24, a + n)
    e = Cx.O[S.k0.values[i]]; d = ar[i]; lv = e + d * 0.5 * S.risk.values[i]
    sap[q] = (Cx.H[k1:k2].max() >= lv) if d == 1 else (Cx.L[k1:k2].min() <= lv)
tb = pd.DataFrame(dict(b=bln[i8], sl=kena_sl, sap=sap, long=ar[i8] == 1))
F["sl_penuh_%"] = tb.groupby("b").sl.mean() * 100
F["sapuan_%_dari_SL"] = tb[tb.sl].groupby("b").sap.mean() * 100
F["porsi_long_%"] = tb.groupby("b").long.mean() * 100
F = F.join(D8.set_index("bulan")[["PF", "total_R"]], how="inner")
pd.set_option("display.width", 250)
P(F.round(3).to_string())
kol = ["vol", "jarum", "kor", "efisiensi", "btc_ret", "btc_vol", "sapuan_%_dari_SL", "porsi_long_%"]
P("\nKorelasi Spearman fitur bulan yang sama dengan PF bulan (n bulan %d):" % len(F))
for k in kol:
    P(f"   {k:20s} {F[k].corr(F.PF, method='spearman'):+.2f}   bulan sebelumnya -> PF bulan ini {F[k].shift(1).corr(F.PF, method='spearman'):+.2f}")
P(f"   PF bulan lalu -> PF bulan ini {F.PF.shift(1).corr(F.PF, method='spearman'):+.2f}")
for nm, ms in (("Juli 2026", ["2026-07"]), ("Oktober 2026", ["2026-10"]), ("Agustus-September 2026", ["2026-08", "2026-09"])):
    P(f"   {nm}: " + ", ".join(f"{k} {F.loc[F.index.isin(ms), k].mean():.3f}" for k in kol))

# 3. penawar
P("\n== 3. PENAWAR: PF jalur x arah di bulan merah lawan hijau (sinyal lolos v149, NILAI 8+, tingkat sinyal) ==")
merah = set(D8.bulan[D8.PF < 1]); hijau = set(D8.bulan[D8.PF >= 1])
m8 = V.POP["SEIMBANG"] & pilih
jl = S.jalur.values
for j in sorted(set(jl)):
    for a, nm in ((1, "LONG"), (-1, "SHORT")):
        k = m8 & (jl == j) & (ar == a)
        xm = R[k & np.isin(bln, list(merah))]; xh = R[k & np.isin(bln, list(hijau))]
        if len(xm) + len(xh) < 40:
            continue
        P(f"   {j:11s} {nm:5s} bulan merah n {len(xm):4d} PF {pf(xm):.2f} | bulan hijau n {len(xh):4d} PF {pf(xh):.2f}")
bal = run(arah=-ar, jk=12, jmode=4, jstop=30)
Rb = bal["R"]
xm = Rb[m8 & np.isin(bln, list(merah))]; xh = Rb[m8 & np.isin(bln, list(hijau))]
P(f"   SEMUA DIBALIK ARAH: bulan merah n {len(xm)} PF {pf(xm):.2f} | bulan hijau n {len(xh)} PF {pf(xh):.2f}")
# konsistensi: jalur x arah yang menang di satu bulan merah, apakah menang juga di bulan merah berikutnya
P("   Konsistensi penawar: PF jalur x arah terbaik di bulan merah sebelumnya, dipakai di bulan merah berikutnya:")
urut = sorted(merah)
hasil = []
for q in range(1, len(urut)):
    lalu, kini = urut[q - 1], urut[q]
    best, bpf = None, 0
    for j in set(jl):
        for a in (1, -1):
            x = R[m8 & (jl == j) & (ar == a) & (bln == lalu)]
            if len(x) >= 8 and pf(x) > bpf:
                best, bpf = (j, a), pf(x)
    if best:
        x = R[m8 & (jl == best[0]) & (ar == best[1]) & (bln == kini)]
        hasil.append(x)
        P(f"      {lalu} terbaik {best[0]} {'LONG' if best[1] == 1 else 'SHORT'} PF {bpf:.2f} -> {kini} n {len(x)} PF {pf(x):.2f}")
if hasil:
    z = np.concatenate(hasil); P(f"      gabungan n {len(z)} PF {pf(z):.2f} rata {z.mean():+.3f}R")

# 4. detektor bergulir
P("\n== 4. DETEKTOR BERGULIR (trade kertas semua sinyal lolos v149 NILAI 8+, hanya yang sudah selesai sebelum sinyal baru) ==")
idx = np.nonzero(m8)[0]
o = idx[np.argsort(keluar[idx], kind="stable")]
kk = keluar[o]; rr = R[o]; jj = jl[o]
def flag_n(n, batas=1.0, per_jalur=False):
    f = np.zeros(len(S), bool)
    for i in idx:
        j = np.searchsorted(kk, masuk[i], side="right")
        if per_jalur:
            sel = np.nonzero(jj[:j] == jl[i])[0][-n:]
            x = rr[sel]
        else:
            x = rr[max(0, j - n):j]
        f[i] = len(x) >= n and pf(x) < batas
    return f
def flag_hari(h, batas=0.0):
    f = np.zeros(len(S), bool)
    cs = np.r_[0, np.cumsum(rr)]
    for i in idx:
        j = np.searchsorted(kk, masuk[i], side="right"); j0 = np.searchsorted(kk, masuk[i] - h, side="right")
        f[i] = (cs[j] - cs[j0]) < batas
    return f
def nilai(nm, T):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    th_ = thn[i]
    P(f"   {nm:52s} n {len(r):5d} PF {pf(r):.2f} total {r.sum():+6.0f}R DD {dd(r[o_]):4.0f}R | bulan PF<1: {int((pm < 1).sum()):2d} dari {len(pm)}, "
      f"terburuk {tm.min():+5.1f}R | " + " ".join(f"{t}:{pf(r[th_ == t]):.2f}" for t in (2023, 2024, 2025, 2026)))
dasar = jalankan(baru, m8, 4, 0)
nilai("Tanpa detektor (v149 sekarang)", dasar)
F10 = flag_n(10); F20 = flag_n(20); FJ = flag_n(10, per_jalur=True); F7 = flag_hari(168); F7b = flag_hari(168, -3.0)
for nm, fl in (("10 sinyal terakhir PF<1", F10), ("20 sinyal terakhir PF<1", F20), ("per jalur 10 terakhir PF<1", FJ),
               ("7 hari terakhir rugi", F7), ("7 hari terakhir rugi > 3R", F7b)):
    nilai(f"{nm}: KUNCI", jalankan(baru, m8 & ~fl, 4, 0))
    T = dasar.copy(); h = fl[T[:, 3].astype(int)]; T[h, 2] *= 0.5
    nilai(f"{nm}: SETENGAH RISIKO", T)
    # balik arah saat terdeteksi: hasil sinyal dibalik untuk yang ditandai
    res_mix = dict(R=np.where(fl, Rb, R), hrs=np.where(fl, bal["hrs"], baru["hrs"]), aman=np.where(fl, bal["aman"], baru["aman"]))
    nilai(f"{nm}: BALIK ARAH", jalankan(res_mix, m8, 4, 0))
open(f"{Cx.SC}/hasil_bulan.txt", "w").write("\n".join(out))
open("hasil_bulan.txt", "w").write("\n".join(out))

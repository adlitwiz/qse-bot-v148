"""v149 riset: jarak TPawal dan SL diuji di candle 5 menit (20 koin likuid Binance, 2024-01 sampai 2026-10), sinyal lolos v149 NILAI 8+.
Fase sebelum TPawal disimulasikan penuh di 5 menit: SL, TPawal (porsi tutup), jam ke-12 dinamis, batas 30 jam. SL dan TPawal di candle 5m
yang sama = SL. Setelah TPawal: SL di entry, sisa keluar di waktu keluar simulasi 1J v149 (harga close candle 1J itu) kecuali harga
balik ke entry lebih dulu (5m). Risiko uang per trade tetap: SL lebih rapat = posisi lebih besar. Biaya 0.15% harga.
Dicek per bulan: jumlah bulan PF < 1 dan bulan terburuk. Pilih di 2024-2025, konfirmasi di 2026."""
import os, numpy as np, pandas as pd
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "m5"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "profil"))
import core as Cx
D5 = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v3/d5"
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
pilih = ok & izin & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
TS = Cx.TS
M5 = {f[:-4]: np.load(f"{D5}/{f}") for f in os.listdir(D5)}
idx = [i for i in np.nonzero(pilih)[0] if S.sym.values[i] in M5 and TS[S.k0.values[i]] >= M5[S.sym.values[i]]["t"][0]]
P(f"sinyal NILAI 8+ lolos v149 di {len(M5)} koin 5m: {len(idx)}")
H5 = 12 * 12; H30 = 30 * 12
def sim(i, tps, por, ksl):
    z = M5[S.sym.values[i]]; t5, o5, h5, l5, c5 = z["t"], z["o"], z["h"], z["l"], z["c"]
    k0 = S.k0.values[i]; t0 = TS[k0]
    a = np.searchsorted(t5, t0)
    if a >= len(t5) or t5[a] != t0:
        return None
    d = S.arah.values[i]; e = o5[a]; r0 = S.risk.values[i]; risk = ksl * r0
    sl = e - d * risk; lv = e + d * tps * risk
    t_akhir = t0 + int(baru["hrs"][i]) * 3600000
    b_akhir = min(np.searchsorted(t5, t_akhir), len(t5) - 1)
    k_akhir = min(k0 + int(baru["hrs"][i]) - 1, len(Cx.C) - 1)
    px_akhir = Cx.C[k_akhir]
    real, sisa, aman = 0.0, 1.0, False
    j = a
    nmax = min(len(t5), a + max(H30, b_akhir - a + 1) + 1)
    while j < nmax:
        hi, lo = h5[j], l5[j]
        if (lo <= sl) if d == 1 else (hi >= sl):
            real += sisa * (sl - e) * d / risk; sisa = 0; break
        if not aman and ((hi >= lv) if d == 1 else (lo <= lv)):
            real += por * tps; sisa = 1 - por; aman = True
            sl = e
            if j >= b_akhir:
                real += sisa * (px_akhir - e) * d / risk; sisa = 0; break
            j += 1; continue
        if not aman:
            if j - a == H5:                                       # jam ke-12 dinamis
                g = (c5[j] - e) * d / r0
                if g <= -0.5:
                    real += sisa * (c5[j] - e) * d / risk; sisa = 0; break
                if g < 0:
                    nsl = e - d * 0.5 * r0
                    if (nsl > sl) if d == 1 else (nsl < sl):
                        sl = nsl
            if j - a >= H30:
                real += sisa * (c5[j] - e) * d / risk; sisa = 0; break
        elif j >= b_akhir:
            real += sisa * (px_akhir - e) * d / risk; sisa = 0; break
        j += 1
    if sisa > 0:
        real += sisa * (c5[min(j, len(c5) - 1)] - e) * d / risk
    return real - 0.0015 * e / risk, aman
bl = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
th = thn
def nilai(nm, tps, por, ksl):
    rr, ii, am = [], [], []
    for i in idx:
        x = sim(i, tps, por, ksl)
        if x is None:
            continue
        rr.append(x[0]); ii.append(i); am.append(x[1])
    r = np.array(rr); ii = np.array(ii); b = bl[ii]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    s = (f"{nm:34s} n {len(r)} WR {np.mean(r > 0) * 100:4.1f}% kena TPawal {np.mean(am) * 100:4.1f}% PF {pf(r):.2f} total {r.sum():+6.0f}R | "
         f"bulan PF<1 {int((pm < 1).sum())}/{len(pm)}, PF>=1.5 {int((pm >= 1.5).sum())}, terburuk {tm.min():+.1f}R | "
         + " ".join(f"{t}:{pf(r[th[ii] == t]):.2f}" for t in (2024, 2025, 2026)))
    P(s)
    return r, ii
r1 = baru["R"][np.array(idx)]
P(f"Pembanding simulasi 1J v149 (sinyal sama): WR {np.mean(r1 > 0) * 100:.1f}% PF {pf(r1):.2f} total {r1.sum():+.0f}R")
for tps in (0.25, 0.33, 0.5, 0.75):
    for por in (0.2, 0.5):
        for ksl in (0.75, 1.0, 1.25):
            nilai(f"TPawal {tps:.2f} tutup {int(por * 100)}% SL x{ksl:.2f}", tps, por, ksl)
open("hasil_5m.txt", "w").write("\n".join(out))

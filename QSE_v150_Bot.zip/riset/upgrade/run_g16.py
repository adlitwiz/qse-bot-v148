"""Grup 16: LIMIT koreksi hanya untuk sinyal yang candle 4J-nya sudah lari besar (searah sinyal), sisanya tetap MARKET.
Ide: sinyal biasa paling bagus MARKET (g15), tapi sinyal sesudah candle besar mungkin lebih baik menunggu pantulan.
Ukuran candle sinyal dalam persen harga. LIMIT di entry -x R (x 0.25, 0.5, 0.75), berlaku W jam, SL tetap di level sinyal.
Keluar v149. Pembanding = v149 MARKET + filter dump 12%. Per sinyal dan portofolio NILAI 8+ dan semua, 2021-23 lawan 2024-26."""
import numpy as np
src = open("run_g15.py").read().split("B = run(")[0]
ns = {"__name__": "g16"}
exec(src, ns)
S, run, jalan, fmt, P, out, Cx, limit_semua = (ns[k] for k in ("S", "run", "jalan", "fmt", "P", "out", "Cx", "limit_semua"))
out.clear()
ar = S.arah.values
thn = S.tahun.values
gerak = S.body.values * S.atr.values / S.px.values * 100 * (-ar)          # persen candle sinyal searah sinyal
dump12 = (ar == -1) & (gerak >= 12)
B = run(jk=12, jmode=4, jstop=30)
base_ok = ~dump12
LV = jalan(B, base_ok)
P(fmt("v149 MARKET + filter dump 12%", LV, LV))
for lo in (3, 5, 8):
    grp = base_ok & (gerak >= lo)
    P(f"\n-- sinyal dengan candle searah >= {lo}%: {grp.sum()} sinyal, MARKET rata {B['R'][grp].mean():+.3f} "
      f"(21-23 {B['R'][grp & (thn < 2024)].mean():+.3f}, 24-26 {B['R'][grp & (thn >= 2024)].mean():+.3f})")
    for x in (0.25, 0.5, 0.75):
        for W in (4, 8, 12):
            R, hrs, am, isi = limit_semua(Cx.H, Cx.L, Cx.C, Cx.O, S.k0.values, S.nmax.values, ar.astype(np.int64), S.risk.values,
                                          S.atrt.values, S.tp_r.values, S.trail.values, x, W, True, Cx.BIAYA)
            gab = dict(R=np.where(grp, R, B["R"]), hrs=np.where(grp, hrs, B["hrs"]), aman=np.where(grp, am, B["aman"]))
            pilih = base_ok & (~grp | isi)
            rg = np.where(isi, R, 0.0)[grp]
            P(f"   LIMIT {x}R {W}j: terisi {isi[grp].mean() * 100:.0f}%, rata R per sinyal grup {rg.mean():+.3f} lawan MARKET "
              f"{B['R'][grp].mean():+.3f} | 21-23 {np.where(isi, R, 0.0)[grp & (thn < 2024)].mean():+.3f} "
              f"24-26 {np.where(isi, R, 0.0)[grp & (thn >= 2024)].mean():+.3f}")
            M = jalan(gab, pilih)
            P("      " + " | ".join(f"{k}: PF {M[k]['pf']:.2f}/{LV[k]['pf']:.2f} tot {M[k]['tot']:+.0f}/{LV[k]['tot']:+.0f} DD {M[k]['dd']:.0f}/{LV[k]['dd']:.0f} "
                                   f"PF 23-24 {M[k]['pf_a']:.2f}/{LV[k]['pf_a']:.2f} 25-26 {M[k]['pf_b']:.2f}/{LV[k]['pf_b']:.2f}" for k in M))
open(f"{Cx.SC}/hasil_g16.txt", "w").write("\n".join(out))

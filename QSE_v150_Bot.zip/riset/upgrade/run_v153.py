"""v153 (permintaan 3 Nov 22:27): slot aman dinamis + 4 mesin sinyal mandiri.
Asal: uji 6 perubahan permintaan user 3 Nov 2026 (11:04 dan 11:06). Data Binance 383 koin 1J, universe 150 likuid, satu orang.
Semua keputusan pakai data sebelum sinyal. Ambang dipilih di 2023-2024, dinilai di 2025-2026. Biaya 0.15% harga.
1. Rem 7 hari jadi mode: saat rem, hanya NILAI 10 (skor 90) dan/atau setengah risiko, bukan tahan total.
   Gerbang profil dilonggarkan (gabungan semua jalur arah sama, min 5). LONG akhir pekan boleh kalau volume 24 jam >= 2x rata 30 hari.
2. TPawal 40-50% di +0.5R, SL ke -0.25R, SL ke entry di +0.8R. Posisi aman tidak dihitung dalam batas 4 (runner).
3. Sapuan likuiditas 1 dan 2 candle 4J + volume >= 2x, di support kuat (disentuh >= 2x) atau divergensi RSI.
   Derivatif BTC (Binance Futures): BTC turun + OI turun + funding sangat minus -> SHORT ditahan (cermin untuk LONG).
4. Masuk koreksi: tunggu koreksi di 1J, Conditional Stop di atas high candle pantulan, SL di ujung ekor pantulan, TP dihitung ulang.
5. Laporan: per bulan 2025-2026, sinyal per minggu, WR, PF, DD, v149 lawan gabungan perubahan yang lolos."""
import os, numpy as np, pandas as pd
from numba import njit
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "v150"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
import core as Cx
DERIV = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/deriv"
CSV = os.path.join(Cx.SC, "data")
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
H_, L_, C_, O_, TS = Cx.H, Cx.L, Cx.C, Cx.O, Cx.TS
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
ar = S.arah.values; jl = S.jalur.values; masuk = S.masuk_h.values; k0 = S.k0.values
dow = pd.to_datetime(S["T"].values, unit="ms", utc=True).dayofweek.values
wkL = (ar == 1) & (dow >= 5)
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
dasar_mask = ok & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
m8 = dasar_mask & izin & ~wkL                         # v149 seperti bot live (akhir pekan LONG ditahan)
lat = thn <= 2024; tes = thn >= 2025
minggu = lambda T: max((T[:, 0].max() - T[:, 0].min()) / 168, 1) if len(T) else 1
def nilai(nm, T, ringkas=True):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]; th_ = thn[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    t2 = T[th_ >= 2025]; r2 = t2[:, 2]
    P(f"   {nm:56s} n {len(r):5d} {len(r) / minggu(T):4.1f}/mgg WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} tot {r.sum():+5.0f}R DD {dd(r[o_]):3.0f}R | "
      f"PF<1 {int((pm < 1).sum()):2d}/{len(pm)} terburuk {tm.min():+5.1f} | 23-24 PF {pf(r[th_ <= 2024]):.2f} | 25-26 n/mgg {len(r2) / minggu(t2):4.1f} "
      f"WR {np.mean(r2 > 0) * 100 if len(r2) else 0:4.1f}% PF {pf(r2):.2f} DD {dd(r2[np.argsort(t2[:, 1], kind='stable')]):3.0f}R")
    return T
# rem 7 hari dari trade kertas semua sinyal m8 yang sudah selesai
def rem_flag(res, pilih, batas=-3.0):
    R = res["R"]; kel = masuk + res["hrs"]; idx = np.nonzero(pilih)[0]
    o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
    f = np.zeros(len(S), bool)
    j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
    f[idx] = (cs[j] - cs[j0]) < batas
    return f
def skala(T, mask_half):
    T = T.copy(); h = mask_half[T[:, 3].astype(int)]; T[h, 2] *= 0.5; return T
P("== DASAR ==")
rem = rem_flag(baru, m8)
B0 = nilai("v149 tanpa rem 7 hari", jalankan(baru, m8, 4, 0))
B1 = nilai("v149 + rem 7 hari TOTAL (terpasang)", jalankan(baru, m8 & ~rem, 4, 0))


P("\nMetrik: per minggu, WR, expectancy, total, DD, total/DD. Latih 2023-2024, uji 2025-2026. Lulus: uji expectancy >= +0.15R, n >= 100.")
@njit(cache=False)
def sim3(Hh, L, C, k0, n, d, e, risk, atrt, tp_r, trail, tps_lv, por, sl_aft, be_lv, jk, jstop):
    sl = e - d * risk; best = e; sisa = 1.0; real = 0.0; aman = -1; tpsd = False
    lvp = e + d * tps_lv * risk; lvb = e + d * be_lv * risk
    has_tp = tp_r > 0; tp = e + d * tp_r * risk
    for j in range(n):
        hi = Hh[k0 + j]; lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if not tpsd and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += por * tps_lv; sisa = 1.0 - por; tpsd = True
            nsl = e + d * sl_aft * risk
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if tpsd and aman < 0 and ((d == 1 and hi >= lvb) or (d == -1 and lo <= lvb)):
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1
        if tpsd and aman < 0 and sl_aft >= 0:
            aman = j + 1
        if has_tp and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        if d == 1:
            if hi > best: best = hi
        else:
            if lo < best: best = lo
        if j % 4 == 3 and trail > 0:
            nsl = best - d * trail * atrt
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if not tpsd and j + 1 == jk:
            rn = (C[k0 + j] - e) * d / risk
            if rn <= -0.5:
                return real + sisa * rn, j + 1, aman
            if rn < 0:
                nsl = e - d * 0.5 * risk
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
        if not tpsd and j + 1 == jstop:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman
def jalan3(tps_lv, por, sl_aft, be_lv, k0a=None, ea=None, riska=None, nmaxa=None, pilih=None):
    pilih = m8 if pilih is None else pilih
    Rn = np.full(len(S), np.nan); hn = np.zeros(len(S), np.int64); an = np.full(len(S), -1, np.int64)
    k0a = k0 if k0a is None else k0a; nmaxa = S.nmax.values if nmaxa is None else nmaxa
    for i in np.nonzero(pilih)[0]:
        if k0a[i] < 0:
            continue
        e = O_[k0a[i]] if ea is None else ea[i]; rk = S.risk.values[i] if riska is None else riska[i]
        r, h, a = sim3(H_, L_, C_, k0a[i], nmaxa[i], ar[i], e, rk, S.atrt.values[i], S.tp_r.values[i], S.trail.values[i],
                       tps_lv, por, sl_aft, be_lv, 12, 30)
        Rn[i] = r - Cx.BIAYA * e / rk; hn[i] = h + (k0a[i] - k0[i]); an[i] = a + (k0a[i] - k0[i]) if a >= 0 else -1
    return dict(R=Rn, hrs=hn, aman=an)

R = baru["R"]; sid = pd.factorize(S.sym.values)[0]
def porto2(ev, cap=4, runner=None, jeda=True):
    """ev: DataFrame masuk, keluar, aman, sym, arah, R, (runner boleh). Satu orang, maks cap berisiko + runner aman, jeda 24 jam setelah 3 rugi."""
    ev = ev.sort_values("masuk", kind="stable")
    buka, trades = [], []; beruntun = 0; jeda_dari = None; antri = []
    for z in ev.itertuples():
        t = z.masuk
        if antri:
            antri.sort(); sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and beruntun >= 3:
                        jeda_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        if jeda and jeda_dari is not None:
            if t >= jeda_dari + 24:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b[1] > t]
        if any(b[0] == z.sym for b in buka):
            continue
        rn = int(getattr(z, "runner", 0)) if runner is None else runner
        berisiko = [b for b in buka if b[2] > t]
        if len(berisiko) >= cap or len(buka) >= cap + rn:
            continue
        if sum(1 for b in berisiko if b[3] == z.arah) >= 4:
            continue
        buka.append((z.sym, z.keluar, z.aman, z.arah)); antri.append((z.keluar, z.R)); trades.append((t, z.keluar, z.R, z.bulan))
    return pd.DataFrame(trades, columns=["masuk", "keluar", "R", "bulan"])
def ukur(nm, T, cetak=True):
    T = T.copy(); T["th"] = T.bulan.str[:4].astype(int)
    hasil = {}
    for per, m_ in (("23-24", (T.th >= 2023) & (T.th <= 2024)), ("25-26", T.th >= 2025)):
        x = T[m_].sort_values("keluar"); r = x.R.values; d_ = dd(r)
        mg = max((x.masuk.max() - x.masuk.min()) / 168, 1) if len(x) else 1
        hasil[per] = dict(n=len(r), mg=len(r) / mg, wr=np.mean(r > 0) * 100 if len(r) else 0, exp=r.mean() if len(r) else 0, tot=r.sum(), dd=d_)
    if cetak:
        tm = T[T.th >= 2025].groupby("bulan").R.sum()
        P(f"   {nm:60s} | " + " | ".join(f"{p} {h['mg']:4.1f}/mgg WR {h['wr']:4.1f}% exp {h['exp']:+.3f}R tot {h['tot']:+5.0f}R DD {h['dd']:3.0f}R tot/DD {h['tot'] / max(h['dd'], 1e-9):4.1f}"
                                         for p, h in hasil.items()) + f" | 25-26 bulan rugi {int((tm < 0).sum())}/{len(tm)}")
    return hasil
bulan_of = lambda tms: pd.to_datetime(tms, unit="ms", utc=True).strftime("%Y-%m")
ev_v149 = pd.DataFrame(dict(masuk=masuk[m8], keluar=masuk[m8] + baru["hrs"][m8],
                            aman=np.where(baru["aman"][m8] >= 0, masuk[m8] + np.maximum(baru["aman"][m8], 0), masuk[m8] + baru["hrs"][m8]),
                            sym=sid[m8], arah=ar[m8], R=R[m8], bulan=bln[m8]))
P("\n== 1. SLOT AMAN DINAMIS ==")
ukur("v149 slot 4 (tanpa rem 7 hari, pembanding mesin)", porto2(ev_v149, runner=0))
ukur("v149 slot 4+2 selalu", porto2(ev_v149, runner=2))
# kertas 7 hari dan efisiensi BTC 20 candle 4J saat sinyal
idx = np.nonzero(m8)[0]; kel = masuk + baru["hrs"]
o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
k7 = cs[j] - cs[j0]
b0, bl = Cx.OFF["BTCUSDT"]; bT = TS[b0:b0 + bl]; bC = C_[b0:b0 + bl]
jb = np.searchsorted(bT, TS[k0[idx]]) - 1
erb = np.array([abs(bC[q] - bC[q - 80]) / max(np.abs(np.diff(bC[q - 80:q + 1:4])).sum(), 1e-12) if q >= 80 else 0 for q in jb])
for ambang in (0.1, 0.2, 0.3):
    fl = (k7 > 0) & (erb >= ambang)
    ev = ev_v149.copy(); ev["runner"] = np.where(fl, 2, 0)
    ukur(f"slot +2 hanya saat kertas 7 hari positif & efisiensi BTC >= {ambang}", porto2(ev))
ev = ev_v149.copy(); ev["runner"] = np.where(k7 > 0, 2, 0)
ukur("slot +2 hanya saat kertas 7 hari positif", porto2(ev))

# ---------- data per koin untuk mesin baru ----------
ranks = S.groupby("sym")["rank"].median()
koin = [s for s in Cx.OFF if s in ranks.index and ranks[s] <= 150]
DATA = {}
for s in koin:
    a, n = Cx.OFF[s]
    f = os.path.join(CSV, f"{s}_60.csv")
    if not os.path.exists(f):
        continue
    vv = pd.read_csv(f, usecols=["volume"]).volume.values.astype(float)
    if len(vv) != n:
        continue
    t = TS[a:a + n]; g = t // 14400000; ix = np.r_[0, np.nonzero(np.diff(g))[0] + 1]
    h4 = np.maximum.reduceat(H_[a:a + n], ix); l4 = np.minimum.reduceat(L_[a:a + n], ix)
    c4 = C_[a + np.r_[ix[1:] - 1, n - 1]]; o4 = O_[a + ix]; v4 = np.add.reduceat(vv, ix)
    DATA[s] = dict(a=a, n=n, v=vv, ix=ix, h4=h4, l4=l4, c4=c4, o4=o4, v4=v4, t4=t[ix],
                   at4=pd.Series(h4 - l4).rolling(14).mean().values)
# tren BTC 4J: close di atas EMA 50
bd = DATA.get("BTCUSDT")
btc_e50 = pd.Series(bd["c4"]).ewm(span=50, adjust=False).mean().values
def btc_arah(tms):
    q = np.searchsorted(bd["t4"], np.asarray(tms) - 14400000, "right") - 1          # candle 4J BTC yang sudah TUTUP sebelum waktu tms
    q = np.clip(q, 0, len(bd["c4"]) - 1)
    return np.where(bd["c4"][q] > btc_e50[q], 1, -1)
def nilai_mesin(nm, sig):
    """sig: list (sym, k_global_entry, arah, risk, atrt). Simulasi aturan keluar v149 di 1J. Satu posisi per koin."""
    rows = []; terakhir = {}
    for s, k, d, rk, at in sorted(sig, key=lambda z: z[1]):
        a, n = Cx.OFF[s]
        if k >= a + n - 2 or rk <= 0 or not np.isfinite(at):
            continue
        if terakhir.get(s, -1) >= k:
            continue
        e = O_[k]
        nmax = min(240, a + n - k - 1)
        r, h, am = sim3(H_, L_, C_, k, nmax, d, e, rk, at, 0.0, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
        terakhir[s] = k + h
        mh = TS[k] // 3600000
        rows.append((mh, mh + h, mh + (am if am >= 0 else h), s, d, r - Cx.BIAYA * e / rk, bulan_of([TS[k]])[0]))
    ev = pd.DataFrame(rows, columns=["masuk", "keluar", "aman", "sym", "arah", "R", "bulan"])
    ev["th"] = ev.bulan.str[:4].astype(int)
    la = ev[(ev.th >= 2023) & (ev.th <= 2024)].R.values; te = ev[ev.th >= 2025].R.values
    mg = lambda x: len(x) / max((x.masuk.max() - x.masuk.min()) / 168, 1) if len(x) else 0
    P(f"   {nm:62s} latih n {len(la):5d} ({mg(ev[(ev.th >= 2023) & (ev.th <= 2024)]):4.1f}/mgg) WR {np.mean(la > 0) * 100 if len(la) else 0:4.1f}% exp {la.mean() if len(la) else 0:+.3f}R"
      f" | uji n {len(te):5d} ({mg(ev[ev.th >= 2025]):4.1f}/mgg) WR {np.mean(te > 0) * 100 if len(te) else 0:4.1f}% exp {te.mean() if len(te) else 0:+.3f}R tot/DD "
      f"{te.sum() / max(dd(ev[ev.th >= 2025].sort_values('keluar').R.values), 1e-9):4.1f}")
    return ev, (la.mean() if len(la) >= 100 else -9)
LULUS = {}
def pilih_terbaik(judul, hasil):
    best = max(hasil, key=lambda z: z[2])
    ev = best[1]; te = ev[ev.th >= 2025].R.values
    ok_ = len(te) >= 100 and te.mean() >= 0.15
    P(f"   >> dipilih di latih: {best[0]} | uji exp {te.mean() if len(te) else 0:+.3f}R n {len(te)} -> {'LULUS' if ok_ else 'TIDAK LULUS'}")
    if ok_:
        LULUS[judul] = ev


TAKER = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/taker"
for s_, D in DATA.items():
    f = f"{TAKER}/{s_}.npz"
    D["dl1"] = None
    if not os.path.exists(f):
        continue
    z = np.load(f); a, n = D["a"], D["n"]; t1 = TS[a:a + n]
    j = np.searchsorted(z["t"], t1); j = np.clip(j, 0, len(z["t"]) - 1); okm = z["t"][j] == t1
    v_ = np.where(okm, z["v"][j], np.nan); tb = np.where(okm, z["tb"][j], np.nan)
    net = 2 * tb - v_
    D["dl1"] = (pd.Series(net).rolling(20, min_periods=15).sum() / pd.Series(v_).rolling(20, min_periods=15).sum()).values
    ix = D["ix"]
    net4 = np.add.reduceat(np.nan_to_num(net), ix); v4 = np.add.reduceat(np.nan_to_num(v_), ix)
    D["dl4"] = (pd.Series(net4).rolling(20).sum() / pd.Series(v4).rolling(20).sum()).values
    D["tbr4"] = np.add.reduceat(np.nan_to_num(tb), ix) / np.maximum(v4, 1e-12)
P(f"   koin dengan data taker buy: {sum(1 for D in DATA.values() if D.get('dl1') is not None)} dari {len(DATA)}")
def nilai_sig(nm, sig, cetak=True):
    ev, ex = nilai_mesin(nm, [z[:5] for z in sig]) if cetak else (None, None)
    return ev
# ---------- mesin dasar: impuls (rng 4%, vol 4x, badan 70%) dan squeeze (4J N50 vol 2x), simpan delta di sinyal ----------
def sinyal_impuls(rng=0.04, vk=4.0):
    sig = []
    for s_, D in DATA.items():
        a, n = D["a"], D["n"]; h, l, c, o, v = H_[a:a + n], L_[a:a + n], C_[a:a + n], O_[a:a + n], D["v"]
        hh = pd.Series(h).rolling(72).max().shift(1).values; ll = pd.Series(l).rolling(72).min().shift(1).values
        va = pd.Series(v).rolling(20).mean().shift(1).values; at = D["at4"]; ix = D["ix"]
        c1 = np.r_[c[0], c[:-1]]
        with np.errstate(invalid="ignore", divide="ignore"):
            hit = ((hh - ll) / c1 <= rng) & (v >= vk * va) & ((h - l) > 0) & (np.abs(c - o) / np.maximum(h - l, 1e-12) >= 0.7) & \
                  (((c > o) & (c > hh)) | ((c < o) & (c < ll)))
        lewat = -1
        for i in np.nonzero(hit)[0]:
            if i < 100 or i <= lewat or i >= n - 2:
                continue
            d = 1 if c[i] > o[i] else -1
            k = a + i + 1; e = O_[k]; sl = l[i] if d == 1 else h[i]; rk = (e - sl) * d
            i4 = min(np.searchsorted(ix, i, "right") - 1, len(at) - 1)
            if 0.004 * e <= rk <= 0.08 * e:
                dl = D["dl1"][i] * d if D.get("dl1") is not None else np.nan
                sig.append((s_, k, d, rk, at[i4], dl))
            lewat = i + 72
    return sig
def sinyal_squeeze(N=50, vk=2.0):
    sig = []
    for s_, D in DATA.items():
        a = D["a"]; h, l, c, v = D["h4"], D["l4"], D["c4"], D["v4"]; ix = D["ix"]; tms = D["t4"]
        cs = pd.Series(c); bw = (4 * cs.rolling(20).std() / cs.rolling(20).mean()).values
        bwmin = pd.Series(bw).rolling(N).min().values; va = pd.Series(v).rolling(20).mean().shift(1).values
        arah_b = btc_arah(tms + 14400000)
        cand = np.nonzero(np.isfinite(bw) & (bw <= bwmin * 1.0001))[0]; lewat = -1
        for i in cand:
            if i < N + 20 or i <= lewat or i >= len(c) - 1:
                continue
            top = h[i - 9:i + 1].max(); bot = l[i - 9:i + 1].min()
            for j in range(i + 1, min(i + 13, len(c) - 1)):
                d = 1 if c[j] > top else (-1 if c[j] < bot else 0)
                if d == 0:
                    continue
                if v[j] >= vk * va[j] and d == arah_b[j] and j + 1 < len(ix):
                    k = a + ix[j + 1]; e = O_[k]; sl = bot if d == 1 else top; rk = (e - sl) * d
                    if 0.004 * e <= rk <= 0.08 * e:
                        dl = D["dl4"][j] * d if D.get("dl4") is not None else np.nan
                        sig.append((s_, k, d, rk, D["at4"][j], dl))
                break
            lewat = i + 12
    return sig

P("\n== 2. ORDER FLOW DELTA 20 CANDLE (taker buy - taker sell) SEBAGAI SARINGAN ==")
SIG = {"impuls": sinyal_impuls(), "squeeze": sinyal_squeeze()}
EVF = {}
for nm, sig in SIG.items():
    sig = [z for z in sig if np.isfinite(z[5])]
    th_sig = np.array([int(bulan_of([TS[z[1]]])[0][:4]) for z in sig])
    best = None
    for thr in (-1.0, 0.0, 0.02, 0.05, 0.1):
        ss = [z for z in sig if z[5] >= thr]
        ev, ex = nilai_mesin(f"{nm}, delta searah >= {thr}", [z[:5] for z in ss])
        if ex is not None and (best is None or ex > best[0]):
            best = (ex, thr, ev)
    te = best[2][best[2].th >= 2025].R.values
    P(f"   >> {nm}: ambang dipilih di latih {best[1]} -> uji exp {te.mean():+.3f}R WR {np.mean(te > 0) * 100:.1f}% n {len(te)} "
      f"({'LULUS' if len(te) >= 100 and te.mean() >= 0.15 else 'TIDAK LULUS'})")
    EVF[nm] = best

P("\n== 1. SLOT PRIORITAS UNTUK IMPULS (masuk hanya kalau >= 2 slot kosong, lot kecil, ditutup paksa untuk sinyal v149) ==")
def porto3(ev_v, ev_i, ukuran, cap=4):
    """ev_v: sinyal v149 (dengan runner). ev_i: impuls (k, e, risk, d, R, masuk, keluar, aman). Kembali DataFrame trade (R sudah ukuran)."""
    E = pd.concat([ev_v.assign(jenis="v"), ev_i.assign(jenis="i")]).sort_values(["masuk", "jenis"], kind="stable")
    buka = []; trades = []; antri = []; beruntun = 0; jeda_dari = None; n_paksa = 0
    for z in E.itertuples():
        t = z.masuk
        if antri:
            antri.sort(); sisa = []
            for k_, r_ in antri:
                if k_ <= t:
                    beruntun = beruntun + 1 if r_ <= 0 else 0
                    if jeda_dari is None and beruntun >= 3:
                        jeda_dari = k_
                else:
                    sisa.append((k_, r_))
            antri = sisa
        if jeda_dari is not None:
            if t >= jeda_dari + 24:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if b["keluar"] > t]
        if any(b["sym"] == z.sym for b in buka):
            continue
        berisiko = [b for b in buka if b["aman"] > t]
        if z.jenis == "v":
            rn = int(getattr(z, "runner", 0) or 0)
            if len(berisiko) >= cap or len(buka) >= cap + rn:
                kor = [b for b in berisiko if b["jenis"] == "i"]
                if not kor:
                    continue
                b = kor[0]; dt = int(t - b["masuk"]); kk = int(b["k"]) + dt
                r_paksa = ((O_[kk] - b["e"]) * b["d"] / b["risk"] - Cx.BIAYA * b["e"] / b["risk"]) * ukuran
                trades[b["no"]][2] = r_paksa; trades[b["no"]][1] = t; buka.remove(b); n_paksa += 1
                antri = [(k_, r_) for k_, r_ in antri if k_ != b["keluar"]] + [(t, r_paksa)]
                berisiko = [x for x in buka if x["aman"] > t]
                if len(berisiko) >= cap or len(buka) >= cap + rn:
                    continue
            if sum(1 for x in berisiko if x["arah"] == z.arah) >= 4:
                continue
            r = z.R
        else:
            if cap - len(berisiko) < 2 or len(buka) >= cap:
                continue
            r = z.R * ukuran
        buka.append(dict(sym=z.sym, keluar=z.keluar, aman=z.aman, arah=z.arah, jenis=z.jenis, masuk=t, k=getattr(z, "k", -1),
                         e=getattr(z, "e", 0.0), risk=getattr(z, "risk", 1.0), d=getattr(z, "d", 1), no=len(trades)))
        antri.append((z.keluar, r)); trades.append([t, z.keluar, r, z.bulan, z.jenis])
    T = pd.DataFrame(trades, columns=["masuk", "keluar", "R", "bulan", "jenis"])
    return T, n_paksa
# sinyal impuls dengan detail entry (tanpa saringan delta dan dengan saringan terbaik)
def ev_detail(sig):
    rows = []; terakhir = {}
    for s_, k, d, rk, at, dl in sorted(sig, key=lambda z: z[1]):
        a, n = Cx.OFF[s_]
        if k >= a + n - 2 or terakhir.get(s_, -1) >= k or not np.isfinite(at):
            continue
        e = O_[k]; nmax = min(240, a + n - k - 1)
        r, h, am = sim3(H_, L_, C_, k, nmax, d, e, rk, at, 0.0, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
        terakhir[s_] = k + h; mh = TS[k] // 3600000
        rows.append(dict(masuk=mh, keluar=mh + h, aman=mh + (am if am >= 0 else h), sym=s_, arah=d, R=r - Cx.BIAYA * e / rk,
                         bulan=bulan_of([TS[k]])[0], k=k, e=e, risk=rk, d=d))
    return pd.DataFrame(rows)
EI = {"impuls tanpa delta": ev_detail(SIG["impuls"]),
      "impuls + delta": ev_detail([z for z in SIG["impuls"] if np.isfinite(z[5]) and z[5] >= EVF["impuls"][1]])}
evv = ev_v149.copy(); evv["runner"] = np.where((k7 > 0) & (erb >= 0.1), 2, 0)
evv["sym"] = S.sym.values[m8]
TV, _ = porto3(evv, EI["impuls tanpa delta"].iloc[0:0], 1.0)
ukur("v149 + slot aman dinamis (pembanding)", TV)
for nm, ei in EI.items():
    for uk in (0.5, 0.75):
        T, npk = porto3(evv, ei, uk)
        h = ukur(f"+ {nm}, lot {uk}x, slot prioritas", T)
        P(f"      impuls diambil {int((T.jenis == 'i').sum())}, ditutup paksa {npk}, sinyal v149 diambil {int((T.jenis == 'v').sum())} (pembanding {len(TV)})")

P("\n== 3. TOKEN UNLOCK ==")
U = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/berita/riset/unlock_kejadian.pkl")
P(f"   kolom data unlock: {list(U.columns)}, {len(U)} kejadian, {U.sym.nunique()} koin")
U = U[U.pct >= 1.0].copy(); U["ms"] = pd.to_datetime(U.t, utc=True).astype("datetime64[ms, UTC]").astype("int64")
tsig = TS[k0]
for jam in (48, 168):
    dk = np.zeros(len(S), bool)
    for s_, g in U.groupby("sym"):
        ts = np.sort(g.ms.values); ii = np.nonzero(S.sym.values == s_)[0]
        q = np.searchsorted(ts, tsig[ii], side="right"); okq = q < len(ts)
        dk[ii[okq]] = (ts[q[okq]] - tsig[ii[okq]]) <= jam * 3600000
    koin_u = S.sym.isin(set(U.sym)).values
    for nm, m_ in (("LONG dengan unlock dekat", m8 & (ar == 1) & dk), ("LONG lain di koin yang punya data unlock", m8 & (ar == 1) & ~dk & koin_u)):
        P(f"   jendela {jam} jam, {nm}: latih n {int((m_ & lat).sum())} exp {np.nanmean(R[m_ & lat]) if (m_ & lat).any() else 0:+.3f}R | "
          f"uji n {int((m_ & tes).sum())} exp {np.nanmean(R[m_ & tes]) if (m_ & tes).any() else 0:+.3f}R")
sig = []
for z in U.itertuples():
    D = DATA.get(z.sym)
    if D is None:
        continue
    i0 = np.searchsorted(D["t4"], z.ms)
    va = pd.Series(D["v4"]).rolling(20).mean().shift(1).values
    for j in range(max(i0, 11), min(i0 + 18, len(D["c4"]) - 1)):
        if D["c4"][j] < D["l4"][j - 10:j].min() and D["v4"][j] >= 1.5 * va[j]:
            k = D["a"] + D["ix"][j + 1]; e = O_[k]; sl = D["h4"][j - 2:j + 1].max(); rk = sl - e
            if 0.004 * e <= rk <= 0.08 * e:
                sig.append((z.sym, k, -1, rk, D["at4"][j]))
            break
nilai_mesin("SHORT patah struktur 4J dalam 72 jam sesudah unlock >= 1%, volume >= 1.5x", sig)

P("\n== 4. SEKTOR ASLI (riset/orderblock/sektor.py) PEMIMPIN-PENGIKUT + TAKER BUY ==")
SEK = {}
for sec, cs in {"L1": "ADA ALGO APT ATOM AVAX BCH CELO CFX CKB DOT EGLD ETC HBAR ICP ICX IOTA KAVA KSM LTC MINA NEAR NEO ONE ONT QTUM ROSE SEI SOL SUI TRX VET XLM XRP XTZ ZIL DASH RVN ZEC TIA INJ",
                "L2": "ARB OP IMX LRC SKL STX", "DEFI": "1INCH AAVE COMP CRV DYDX GMX JUP KNC LDO PENDLE SNX SUSHI UNI YFI ZRX RUNE ENA WOO UMA",
                "ORACLE": "API3 BAND LINK PYTH TRB GRT", "MEME": "1000BONK 1000FLOKI 1000PEPE 1000SHIB DOGE WIF BONK FLOKI PEPE SHIB", "AI": "FET WLD NMR ARPA IOTX",
                "GAME": "ALICE APE AXS ENJ GALA GMT MANA SAND HOOK CHZ THETA", "DEPIN": "AR FIL STORJ ANKR JASMY"}.items():
    for c_ in cs.split():
        SEK[c_ + "USDT"] = sec
kol = [s_ for s_ in DATA if s_ in SEK]
P(f"   {len(kol)} koin di data punya sektor: " + ", ".join(f"{g} {sum(1 for s_ in kol if SEK[s_] == g)}" for g in sorted(set(SEK.values()))))
t4all = sorted(set(np.concatenate([DATA[s_]["t4"] for s_ in kol]))); pos = {t: q for q, t in enumerate(t4all)}
RET = np.full((len(t4all), len(kol)), np.nan); VR = RET.copy(); HI20 = RET.copy(); LO20 = RET.copy(); CL = RET.copy(); TBR = RET.copy()
for jj, s_ in enumerate(kol):
    D = DATA[s_]; q = np.array([pos[t] for t in D["t4"]])
    RET[q, jj] = D["c4"] / D["o4"] - 1; VR[q, jj] = D["v4"] / pd.Series(D["v4"]).rolling(20).mean().shift(1).values
    HI20[q, jj] = pd.Series(D["h4"]).rolling(20).max().shift(1).values; LO20[q, jj] = pd.Series(D["l4"]).rolling(20).min().shift(1).values
    CL[q, jj] = D["c4"]; TBR[q, jj] = D.get("tbr4", np.full(len(D["c4"]), np.nan))
gv = np.array([SEK[s_] for s_ in kol])
for tbm in (0.0, 0.55):
    for lead_r in (0.05, 0.08):
        sig = []
        for q in range(25, len(t4all) - 3):
            for g in np.unique(gv):
                m_ = np.nonzero(gv == g)[0]
                if len(m_) < 3:
                    continue
                for d in (1, -1):
                    rr_ = RET[q, m_] * d
                    if not np.nanmax(rr_) >= lead_r:
                        continue
                    li = m_[np.nanargmax(rr_)]
                    tb_ok = tbm == 0 or (TBR[q, li] >= tbm if d == 1 else TBR[q, li] <= 1 - tbm)
                    if not (VR[q, li] >= 3 and tb_ok):
                        continue
                    for jj in m_:
                        if jj == li or not abs(RET[q, jj]) < 0.015:
                            continue
                        for q2 in (q + 1, q + 2):
                            if np.isnan(CL[q2, jj]):
                                break
                            tembus = CL[q2, jj] > HI20[q2, jj] if d == 1 else CL[q2, jj] < LO20[q2, jj]
                            if tembus and VR[q2, jj] >= 1.5:
                                s_ = kol[jj]; D = DATA[s_]; i4 = np.searchsorted(D["t4"], t4all[q2])
                                if i4 + 1 < len(D["ix"]):
                                    k = D["a"] + D["ix"][i4 + 1]; e = O_[k]; rk = 1.5 * D["at4"][i4]
                                    if np.isfinite(rk) and 0.004 * e <= rk <= 0.08 * e:
                                        sig.append((s_, k, d, rk, D["at4"][i4]))
                                break
        nilai_mesin(f"pemimpin sektor >= {lead_r * 100:.0f}%, vol 3x, taker buy {'>= ' + str(tbm) if tbm else 'bebas'}", sig)

P("\n== 5. SCALE-IN: posisi kedua di koin yang sudah aman (sudah TPawal) ==")
ok_si = m8 & (baru["aman"] >= 0)
def scale_in(nk, lebar):
    sig = []
    for i in np.nonzero(ok_si)[0]:
        d = ar[i]; r0 = S.risk.values[i]; a0 = k0[i] + baru["aman"][i]; akhir = k0[i] + baru["hrs"][i]
        for j in range(a0 + nk, min(a0 + 24, akhir)):
            hi = H_[j - nk:j].max(); lo = L_[j - nk:j].min()
            if hi - lo > lebar * r0:
                continue
            if (C_[j] > hi) if d == 1 else (C_[j] < lo):
                e = O_[j + 1]; sl = lo if d == 1 else hi; rk = (e - sl) * d
                if rk >= 0.003 * e:
                    sig.append((S.sym.values[i], j + 1, d, rk, S.atrt.values[i]))
                break
    return sig
for nk in (3, 5):
    for lebar in (0.3, 0.6):
        nilai_mesin(f"konsolidasi {nk} candle 1J, lebar <= {lebar} x jarak SL awal, tembus searah", scale_in(nk, lebar))
open("hasil_v153.txt", "w").write("\n".join(out))

"""Grup 13c: pemenang g13b (jam 12, geser SL ke -0.5R hanya kalau harga melawan) digabung batas umur 24 jam.
Umur 24 jam dua versi: hanya posisi belum aman (seperti 36 jam sekarang) dan semua posisi. Plus tetangga untuk cek kestabilan."""
import numpy as np
src = open("run_g13.py").read().split("LV = jalan(base)")[0].replace("cache=True", "cache=False")
ns = {"__name__": "g13c"}
exec(src, ns)
for k in ("run", "jalan", "fmt", "base", "Cx", "P", "out"):
    globals()[k] = ns[k]
out.clear()
LV = jalan(base)
P(fmt("LIVE sekarang", LV, LV))
J = dict(jk=12, jmode=4)
P(fmt("PEMENANG jam 12 hanya melawan", jalan(run(**J)), LV))
for nm, kw in (("+ umur 24 jam (belum aman)", dict(jstop=24)), ("+ umur 24 jam (semua posisi)", dict(jstop=-24)),
               ("+ umur 30 jam (belum aman)", dict(jstop=30)), ("+ umur 36 jam semua posisi", dict(jstop=-36)),
               ("tetangga jam 10 hanya melawan", dict(jk=10)), ("tetangga jam 14 hanya melawan", dict(jk=14)),
               ("tetangga jam 12 melawan SL -0.6R", dict(jsl=-0.6, jthr=-0.6)), ("tetangga jam 12 melawan SL -0.4R", dict(jsl=-0.4, jthr=-0.4)),
               ("jam 8 hanya melawan + umur 24 jam", dict(jk=8, jstop=24))):
    k = dict(J); k.update(kw)
    P(fmt(nm, jalan(run(**k)), LV))
open(f"{Cx.SC}/hasil_g13c.txt", "w").write("\n".join(out))

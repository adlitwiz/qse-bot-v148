"""v149 rapor per bulan FINAL: v149 sekarang lawan v149 + rem 7 hari (yang dipasang). Dari run_struktur2.
Asal: riset struktur tahap 3 (5 usulan user 3 Nov 2026). Data sebelum sinyal saja. Ambang dipilih di 2023-2024, dicek 2025-2026 dan per bulan.
1. Efisiensi tren 20 candle 4J koin saat sinyal: rendah -> kunci jalur tren, izinkan strategi pantulan (strategi B, dari run_struktur).
2. SHORT dipisah: syarat lebih ketat (sudah ada pantulan naik: jarak dari low 50 candle) dan TPawal lebih dekat, keluar lebih cepat.
3. Saat rem 7 hari menyala: SHORT dimatikan, hanya LONG jalur rsi_vol dan orderblock (pilihan ini diambil dari data yang sama, jadi diuji
   ulang: jalur LONG yang tahan dipilih dari bulan merah 2023-2024 saja, dicek 2025-2026).
4. Kekuatan relatif harian terhadap BTC: LONG hanya koin terkuat X%, SHORT hanya terlemah X% (return 24 jam dan 7 hari).
5. TPawal sebelum support/resistance terdekat (FVG tidak ada di data uji), digabung rem 7 hari."""
import os, numpy as np, pandas as pd
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "struktur2"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
def cari(d, k):
    while k not in d:
        d = d["ns"]
    return d[k]
sim2 = cari(ns, "sim2")
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
m8 = ok & izin & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
R = baru["R"]; masuk = S.masuk_h.values; keluar = masuk + baru["hrs"]; ar = S.arah.values; jl = S.jalur.values
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
idx = np.nonzero(m8)[0]
def nilai(nm, T):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    th_ = thn[i]
    P(f"   {nm:52s} n {len(r):5d} WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} total {r.sum():+6.0f}R DD {dd(r[o_]):4.0f}R | PF<1 {int((pm < 1).sum()):2d}/{len(pm)} "
      f"PF>=2 {int((pm >= 2).sum()):2d} terburuk {tm.min():+5.1f}R | 23-24 {pf(r[th_ <= 2024]):.2f} 25-26 {pf(r[th_ >= 2025]):.2f} | "
      f"2026-04 {tm.get('2026-04', 0):+.1f} 07 {tm.get('2026-07', 0):+.1f} 10 {tm.get('2026-10', 0):+.1f}")
    return tm
# rem 7 hari (sudah terbukti di run_bulan)
o = idx[np.argsort(keluar[idx], kind="stable")]; kk = keluar[o]; rr = R[o]; cs = np.r_[0, np.cumsum(rr)]
rem7 = np.zeros(len(S), bool)
for i in idx:
    j = np.searchsorted(kk, masuk[i], side="right"); j0 = np.searchsorted(kk, masuk[i] - 168, side="right")
    rem7[i] = (cs[j] - cs[j0]) < -3.0

def tabel(T):
    i = T[:, 3].astype(int); r = T[:, 2]; b = bln[i]; rows = []
    for m in sorted(set(b)):
        k = b == m; x = r[k]; ox = np.argsort(T[k, 1], kind="stable")
        rows.append((m, len(x), np.mean(x > 0) * 100, pf(x), x.sum(), dd(x[ox])))
    return pd.DataFrame(rows, columns=["bulan", "trade", "WR", "PF", "R", "DD"]).set_index("bulan")
A = tabel(jalankan(baru, m8, 4, 0)); Bt = tabel(jalankan(baru, m8 & ~rem7, 4, 0))
G = A.join(Bt, lsuffix="_lama", rsuffix="_rem7", how="outer").fillna(0)
G = G[G.index >= "2023-01"]
P("Rapor per bulan NILAI 8+, satu orang, maks 4 posisi. R = kali risiko per trade. Persen modal di risiko 0.5% per trade = R x 0.5")
P(G.round(2).to_string())
for c in ("lama", "rem7"):
    r = G["R_" + c]
    P(f"{c}: bulan rugi {int((r < 0).sum())}/{len(r)}, rugi > 5R {int((r < -5).sum())}, terburuk {r.min():+.1f}R, total {r.sum():+.0f}R, "
      f"PF>=1.5 {int((G['PF_' + c] >= 1.5).sum())} bulan")
open("hasil_bulan_final.txt", "w").write("\n".join(out))

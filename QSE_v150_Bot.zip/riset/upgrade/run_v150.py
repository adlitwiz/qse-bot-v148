"""Uji 6 perubahan permintaan user 3 Nov 2026 (11:04 dan 11:06). Data Binance 383 koin 1J, universe 150 likuid, satu orang.
Semua keputusan pakai data sebelum sinyal. Ambang dipilih di 2023-2024, dinilai di 2025-2026. Biaya 0.15% harga.
1. Rem 7 hari jadi mode: saat rem, hanya NILAI 10 (skor 90) dan/atau setengah risiko, bukan tahan total.
   Gerbang profil dilonggarkan (gabungan semua jalur arah sama, min 5). LONG akhir pekan boleh kalau volume 24 jam >= 2x rata 30 hari.
2. TPawal 40-50% di +0.5R, SL ke -0.25R, SL ke entry di +0.8R. Posisi aman tidak dihitung dalam batas 4 (runner).
3. Sapuan likuiditas 1 dan 2 candle 4J + volume >= 2x, di support kuat (disentuh >= 2x) atau divergensi RSI.
   Derivatif BTC (Binance Futures): BTC turun + OI turun + funding sangat minus -> SHORT ditahan (cermin untuk LONG).
4. Masuk koreksi: tunggu koreksi di 1J, Conditional Stop di atas high candle pantulan, SL di ujung ekor pantulan, TP dihitung ulang.
5. Laporan: per bulan 2025-2026, sinyal per minggu, WR, PF, DD, v149 lawan gabungan perubahan yang lolos."""
import os, numpy as np, pandas as pd
from numba import njit
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "v150"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
import core as Cx
DERIV = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/deriv"
CSV = os.path.join(Cx.SC, "data")
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
H_, L_, C_, O_, TS = Cx.H, Cx.L, Cx.C, Cx.O, Cx.TS
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
ar = S.arah.values; jl = S.jalur.values; masuk = S.masuk_h.values; k0 = S.k0.values
dow = pd.to_datetime(S["T"].values, unit="ms", utc=True).dayofweek.values
wkL = (ar == 1) & (dow >= 5)
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
dasar_mask = ok & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
m8 = dasar_mask & izin & ~wkL                         # v149 seperti bot live (akhir pekan LONG ditahan)
lat = thn <= 2024; tes = thn >= 2025
minggu = lambda T: max((T[:, 0].max() - T[:, 0].min()) / 168, 1) if len(T) else 1
def nilai(nm, T, ringkas=True):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]; th_ = thn[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    t2 = T[th_ >= 2025]; r2 = t2[:, 2]
    P(f"   {nm:56s} n {len(r):5d} {len(r) / minggu(T):4.1f}/mgg WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} tot {r.sum():+5.0f}R DD {dd(r[o_]):3.0f}R | "
      f"PF<1 {int((pm < 1).sum()):2d}/{len(pm)} terburuk {tm.min():+5.1f} | 23-24 PF {pf(r[th_ <= 2024]):.2f} | 25-26 n/mgg {len(r2) / minggu(t2):4.1f} "
      f"WR {np.mean(r2 > 0) * 100 if len(r2) else 0:4.1f}% PF {pf(r2):.2f} DD {dd(r2[np.argsort(t2[:, 1], kind='stable')]):3.0f}R")
    return T
# rem 7 hari dari trade kertas semua sinyal m8 yang sudah selesai
def rem_flag(res, pilih, batas=-3.0):
    R = res["R"]; kel = masuk + res["hrs"]; idx = np.nonzero(pilih)[0]
    o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
    f = np.zeros(len(S), bool)
    j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
    f[idx] = (cs[j] - cs[j0]) < batas
    return f
def skala(T, mask_half):
    T = T.copy(); h = mask_half[T[:, 3].astype(int)]; T[h, 2] *= 0.5; return T
P("== DASAR ==")
rem = rem_flag(baru, m8)
B0 = nilai("v149 tanpa rem 7 hari", jalankan(baru, m8, 4, 0))
B1 = nilai("v149 + rem 7 hari TOTAL (terpasang)", jalankan(baru, m8 & ~rem, 4, 0))

P("\n== 1a. REM JADI MODE ==")
n10 = S.nilai_n.values >= 8
nilai("rem: setengah risiko, sinyal tetap jalan", skala(jalankan(baru, m8, 4, 0), rem))
nilai("rem: hanya NILAI 10 (skor 90)", jalankan(baru, m8 & (~rem | n10), 4, 0))
nilai("rem: hanya NILAI 10, setengah risiko", skala(jalankan(baru, m8 & (~rem | n10), 4, 0), rem))
x = baru["R"][m8 & rem & n10]; y = baru["R"][m8 & rem & ~n10]
P(f"   sinyal saat rem menyala: NILAI 10 n {len(x)} PF {pf(x):.2f} | lainnya n {len(y)} PF {pf(y):.2f} | 25-26 NILAI 10 PF {pf(baru['R'][m8 & rem & n10 & tes]):.2f}")
P("   (catatan: rem lepas begitu total 7 hari kembali di atas -3R. Lama rem menyala:)")
P(f"   porsi sinyal yang jatuh saat rem: {np.mean(rem[m8]) * 100:.0f}%")

P("\n== 1b. GERBANG PROFIL DILONGGARKAN ==")
R = baru["R"]; kel = masuk + baru["hrs"]
sid = pd.factorize(S.sym.values)[0]
def profil_gab(nmin, pmin, baru_ok):
    gid = sid * 3 + ar + 1
    iz = np.ones(len(S), bool)
    for g in np.unique(gid[dasar_mask]):
        ix = np.nonzero((gid == g))[0]
        ko = ix[np.argsort(kel[ix], kind="stable")]
        cp, cn = np.r_[0, np.cumsum(np.maximum(R[ko], 0))], np.r_[0, np.cumsum(np.maximum(-R[ko], 0))]
        j = np.searchsorted(kel[ko], masuk[ix], side="right")
        iz[ix] = np.where(j >= nmin, cp[j] / np.maximum(cn[j], 1e-9) >= pmin, baru_ok)
    return iz
for a_ in ((5, 1.3, False), (5, 1.3, True), (5, 1.0, True)):
    iz = profil_gab(*a_)
    nilai(f"profil gabungan semua jalur arah sama {a_}", jalankan(baru, dasar_mask & iz & ~wkL, 4, 0))
nilai("tanpa gerbang profil sama sekali", jalankan(baru, dasar_mask & ~wkL, 4, 0))

P("\n== 1c. LONG AKHIR PEKAN ==")
volr = np.full(len(S), np.nan)
for s in np.unique(S.sym.values[dasar_mask & wkL]):
    f = os.path.join(CSV, f"{s}_60.csv")
    if not os.path.exists(f):
        continue
    v = pd.read_csv(f, usecols=["t", "volume"]); t = pd.to_datetime(v.t, utc=True).astype("int64").values // 10**6
    vv = v.volume.values; cs = np.r_[0, np.cumsum(vv)]
    for i in np.nonzero(dasar_mask & wkL & (S.sym.values == s))[0]:
        j = np.searchsorted(t, TS[k0[i]])
        if j >= 24 * 31:
            volr[i] = (cs[j] - cs[j - 24]) / max((cs[j - 24] - cs[j - 24 * 31]) / 30, 1e-12)
for nm, mk in (("LONG hari kerja", dasar_mask & izin & (ar == 1) & ~wkL), ("LONG akhir pekan semua", dasar_mask & izin & wkL),
               ("LONG akhir pekan volume >= 2x", dasar_mask & izin & wkL & (volr >= 2)), ("LONG akhir pekan volume < 2x", dasar_mask & izin & wkL & ~(volr >= 2))):
    P(f"   {nm:34s} latih n {int((mk & lat).sum()):4d} PF {pf(R[mk & lat]):.2f} | uji n {int((mk & tes).sum()):4d} PF {pf(R[mk & tes]):.2f}")
nilai("LONG akhir pekan dibuka semua", jalankan(baru, dasar_mask & izin, 4, 0))
nilai("LONG akhir pekan dibuka kalau volume >= 2x", jalankan(baru, dasar_mask & izin & ~(wkL & ~(volr >= 2)), 4, 0))

P("\n== 2. TPawal 40-50%, SL -0.25R, SL ke entry di +0.8R, posisi aman tidak dihitung slot ==")
@njit(cache=False)
def sim3(Hh, L, C, k0, n, d, e, risk, atrt, tp_r, trail, tps_lv, por, sl_aft, be_lv, jk, jstop):
    sl = e - d * risk; best = e; sisa = 1.0; real = 0.0; aman = -1; tpsd = False
    lvp = e + d * tps_lv * risk; lvb = e + d * be_lv * risk
    has_tp = tp_r > 0; tp = e + d * tp_r * risk
    for j in range(n):
        hi = Hh[k0 + j]; lo = L[k0 + j]
        if (d == 1 and lo <= sl) or (d == -1 and hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if not tpsd and ((d == 1 and hi >= lvp) or (d == -1 and lo <= lvp)):
            real += por * tps_lv; sisa = 1.0 - por; tpsd = True
            nsl = e + d * sl_aft * risk
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if tpsd and aman < 0 and ((d == 1 and hi >= lvb) or (d == -1 and lo <= lvb)):
            if (d == 1 and e > sl) or (d == -1 and e < sl):
                sl = e
            aman = j + 1
        if tpsd and aman < 0 and sl_aft >= 0:
            aman = j + 1
        if has_tp and ((d == 1 and hi >= tp) or (d == -1 and lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        if d == 1:
            if hi > best: best = hi
        else:
            if lo < best: best = lo
        if j % 4 == 3 and trail > 0:
            nsl = best - d * trail * atrt
            if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                sl = nsl
        if not tpsd and j + 1 == jk:
            rn = (C[k0 + j] - e) * d / risk
            if rn <= -0.5:
                return real + sisa * rn, j + 1, aman
            if rn < 0:
                nsl = e - d * 0.5 * risk
                if (d == 1 and nsl > sl) or (d == -1 and nsl < sl):
                    sl = nsl
        if not tpsd and j + 1 == jstop:
            return real + sisa * (C[k0 + j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[k0 + n - 1] - e) * d / risk, n, aman
def jalan3(tps_lv, por, sl_aft, be_lv, k0a=None, ea=None, riska=None, nmaxa=None, pilih=None):
    pilih = m8 if pilih is None else pilih
    Rn = np.full(len(S), np.nan); hn = np.zeros(len(S), np.int64); an = np.full(len(S), -1, np.int64)
    k0a = k0 if k0a is None else k0a; nmaxa = S.nmax.values if nmaxa is None else nmaxa
    for i in np.nonzero(pilih)[0]:
        if k0a[i] < 0:
            continue
        e = O_[k0a[i]] if ea is None else ea[i]; rk = S.risk.values[i] if riska is None else riska[i]
        r, h, a = sim3(H_, L_, C_, k0a[i], nmaxa[i], ar[i], e, rk, S.atrt.values[i], S.tp_r.values[i], S.trail.values[i],
                       tps_lv, por, sl_aft, be_lv, 12, 30)
        Rn[i] = r - Cx.BIAYA * e / rk; hn[i] = h + (k0a[i] - k0[i]); an[i] = a + (k0a[i] - k0[i]) if a >= 0 else -1
    return dict(R=Rn, hrs=hn, aman=an)
c0 = jalan3(0.5, 0.2, 0.0, 0.5)
P(f"   cek sim3 = v149: selisih maks {np.nanmax(np.abs(c0['R'][m8] - baru['R'][m8])):.3f}R")
for runner in (0, 2, 4):
    nilai(f"v149 TPawal 20% + rem, posisi aman di luar slot maks {runner}", jalankan(baru, m8 & ~rem, 4, runner))
VAR = {}
for por in (0.4, 0.5):
    res = jalan3(0.5, por, -0.25, 0.8)
    VAR[por] = res
    rm = rem_flag(res, m8)
    for runner in (0, 2, 4):
        nilai(f"TPawal {int(por * 100)}% SL-0.25 BE 0.8 + rem, aman di luar slot {runner}", jalankan(res, m8 & ~rm, 4, runner))

P("\n== 3a. DERIVATIF BTC (Binance Futures): turun + OI turun + funding minus -> SHORT ditahan, cermin LONG ==")
F = pd.read_csv(f"{DERIV}/btc_funding.csv"); F = F.sort_values("calc_time")
M = pd.read_csv(f"{DERIV}/btc_metrics.csv", usecols=["create_time", "sum_open_interest"])
M["t"] = pd.to_datetime(M.create_time, utc=True).astype("datetime64[ms, UTC]").astype("int64"); M = M.sort_values("t")
b0, bl = Cx.OFF["BTCUSDT"]; bT = TS[b0:b0 + bl]; bC = C_[b0:b0 + bl]
t_sig = TS[k0]
jb = np.searchsorted(bT, t_sig) - 1
btc24 = np.where(jb >= 24, bC[np.maximum(jb, 0)] / bC[np.maximum(jb - 24, 0)] - 1, np.nan) * 100
mo = np.searchsorted(M.t.values, t_sig) - 1; mo2 = np.searchsorted(M.t.values, t_sig - 86400000) - 1
oi = M.sum_open_interest.values
oi24 = np.where((mo >= 0) & (mo2 >= 0), oi[np.maximum(mo, 0)] / oi[np.maximum(mo2, 0)] - 1, np.nan) * 100
fi = np.searchsorted(F.calc_time.values, t_sig) - 1
fund = np.where(fi >= 0, F.last_funding_rate.values[np.maximum(fi, 0)], np.nan) * 100
ada = ~np.isnan(oi24) & ~np.isnan(fund)
P(f"   sinyal m8 dengan data derivatif: {int((m8 & ada).sum())} dari {int(m8.sum())}")
qlo = np.nanquantile(fund[m8 & lat & ada], [0.1, 0.2, 0.3]); qhi = np.nanquantile(fund[m8 & lat & ada], [0.7, 0.8, 0.9])
cal = []
for q in list(qlo) + [0.0]:
    tahanS = (ar == -1) & (btc24 < 0) & (oi24 < 0) & (fund <= q)
    a_ = R[m8 & lat & tahanS]; b_ = R[m8 & tes & tahanS]
    P(f"   SHORT saat BTC turun, OI turun, funding <= {q:.4f}%: latih n {len(a_)} PF {pf(a_):.2f} | uji n {len(b_)} PF {pf(b_):.2f}")
    cal.append((pf(a_), q, tahanS, "SHORT"))
for q in list(qhi) + [0.01]:
    tahanL = (ar == 1) & (btc24 > 0) & (oi24 < 0) & (fund >= q)
    a_ = R[m8 & lat & tahanL]; b_ = R[m8 & tes & tahanL]
    P(f"   LONG saat BTC naik, OI turun, funding >= {q:.4f}%: latih n {len(a_)} PF {pf(a_):.2f} | uji n {len(b_)} PF {pf(b_):.2f}")
    cal.append((pf(R[m8 & lat & tahanL]), q, tahanL, "LONG"))
cal = [c for c in cal if (m8 & lat & c[2]).sum() >= 30]
if cal:
    worst = min(cal, key=lambda z: z[0])
    P(f"   dipilih di latih (PF terendah, n>=30): {worst[3]} ambang {worst[1]:.4f}%, PF latih {worst[0]:.2f}")
    nilai(f"tahan {worst[3]} saat derivatif BTC berlawanan + rem", jalankan(baru, m8 & ~rem & ~worst[2], 4, 0))

P("\n== 3b. SAPUAN LIKUIDITAS 4J + VOLUME + SUPPORT KUAT / DIVERGENSI RSI ==")
ranks = S.groupby("sym")["rank"].median()
koin = [s for s in Cx.OFF if s in ranks.index and ranks[s] <= 150]
def rsi(c, n=14):
    d = np.diff(c, prepend=c[0]); u = pd.Series(np.maximum(d, 0)).ewm(alpha=1 / n, adjust=False).mean().values
    w = pd.Series(np.maximum(-d, 0)).ewm(alpha=1 / n, adjust=False).mean().values
    return 100 - 100 / (1 + u / np.maximum(w, 1e-12))
sw_rows = []
for s in koin:
    a, n = Cx.OFF[s]
    f = os.path.join(CSV, f"{s}_60.csv")
    if not os.path.exists(f):
        continue
    vv = pd.read_csv(f, usecols=["volume"]).volume.values
    if len(vv) != n:
        continue
    t = TS[a:a + n]; g = t // 14400000
    ix = np.r_[0, np.nonzero(np.diff(g))[0] + 1]
    if len(ix) < 80:
        continue
    h4 = np.maximum.reduceat(H_[a:a + n], ix); l4 = np.minimum.reduceat(L_[a:a + n], ix)
    c4 = C_[a + np.r_[ix[1:] - 1, n - 1]]; v4 = np.add.reduceat(vv, ix)
    at = pd.Series(h4 - l4).rolling(14).mean().values; rs = rsi(c4)
    va = pd.Series(v4).rolling(20).mean().shift(1).values
    for i in range(52, len(ix) - 2):
        for d in (1, -1):
            for pola in (1, 2):
                q = i + pola - 1                     # candle konfirmasi
                if d == 1:
                    lv = l4[i - 20:i].min(); j0 = i - 20 + int(np.argmin(l4[i - 20:i]))
                    if not (l4[i] < lv and c4[q] > lv and (pola == 1 or c4[i] <= lv)):
                        continue
                    sentuh = int(np.sum(np.abs(l4[i - 50:i] - lv) <= 0.3 * at[i]))
                    div = rs[i] > rs[j0]
                    sl = min(l4[i], l4[q]) - 0.05 * at[i]
                else:
                    lv = h4[i - 20:i].max(); j0 = i - 20 + int(np.argmax(h4[i - 20:i]))
                    if not (h4[i] > lv and c4[q] < lv and (pola == 1 or c4[i] >= lv)):
                        continue
                    sentuh = int(np.sum(np.abs(h4[i - 50:i] - lv) <= 0.3 * at[i]))
                    div = rs[i] < rs[j0]
                    sl = max(h4[i], h4[q]) + 0.05 * at[i]
                vol = max(v4[i], v4[q]) / max(va[i], 1e-12)
                k = a + ix[q + 1]; e = O_[k]; risk = (e - sl) * d
                if not (0.004 * e <= risk <= 0.08 * e):
                    continue
                hasil = {}
                for tpk in (1.0, 1.5, 2.0):
                    tp = e + d * tpk * risk; r_ = None
                    for j in range(k, min(k + 48, a + n)):
                        if (L_[j] <= sl) if d == 1 else (H_[j] >= sl):
                            r_ = -1.0; break
                        if (H_[j] >= tp) if d == 1 else (L_[j] <= tp):
                            r_ = tpk; break
                    if r_ is None:
                        j = min(k + 47, a + n - 1); r_ = (C_[j] - e) * d / risk
                    hasil[tpk] = r_ - 0.0015 * e / risk
                sw_rows.append((TS[k], s, d, pola, vol, sentuh, div, hasil[1.0], hasil[1.5], hasil[2.0]))
W = pd.DataFrame(sw_rows, columns=["t", "sym", "arah", "pola", "vol", "sentuh", "div", "R1", "R15", "R2"])
W["th"] = pd.to_datetime(W.t, unit="ms", utc=True).dt.year
grid = []
for pola in (1, 2):
    for vmin in (1.0, 2.0, 3.0):
        for syarat in ("support kuat", "divergensi RSI", "salah satu", "keduanya"):
            for d, an in ((1, "LONG"), (-1, "SHORT")):
                m = (W.pola == pola) & (W.vol >= vmin) & (W.arah == d)
                m &= {"support kuat": W.sentuh >= 2, "divergensi RSI": W["div"], "salah satu": (W.sentuh >= 2) | W["div"],
                      "keduanya": (W.sentuh >= 2) & W["div"]}[syarat]
                for tp in ("R1", "R15", "R2"):
                    a_ = W[m & (W.th >= 2021) & (W.th <= 2024)][tp].values; b_ = W[m & (W.th >= 2025)][tp].values
                    grid.append((pf(a_), len(a_), pf(b_), len(b_), pola, vmin, syarat, an, tp))
G = pd.DataFrame(grid, columns=["pf_latih", "n_latih", "pf_uji", "n_uji", "pola", "vol_min", "syarat", "arah", "tp"])
G = G[G.n_latih >= 100].sort_values("pf_latih", ascending=False)
P(f"   {len(W)} kejadian sapuan. 10 aturan terbaik di latih 2021-2024 (min 100 trade), lalu PF di 2025-2026:")
P(G.head(10).round(2).to_string(index=False))
P(f"   aturan dengan PF latih >= 1.2: {int((G.pf_latih >= 1.2).sum())}, yang juga PF uji >= 1.2: {int(((G.pf_latih >= 1.2) & (G.pf_uji >= 1.2)).sum())}")

P("\n== 4. MASUK KOREKSI: Conditional Stop di atas candle pantulan 1J, SL di ujung ekor pantulan, TP dihitung ulang ==")
def koreksi(p, W_=12, tunggu=4):
    k0n = np.full(len(S), -1, np.int64); en = np.full(len(S), np.nan); rn = np.full(len(S), np.nan); nm = S.nmax.values.copy()
    for i in np.nonzero(m8)[0]:
        d = ar[i]; e0 = O_[k0[i]]; r0 = S.risk.values[i]; sl0 = e0 - d * r0; a_ = k0[i]
        cuk = False; ext = e0; b = -1
        for j in range(a_, a_ + W_):
            if (L_[j] <= sl0) if d == 1 else (H_[j] >= sl0):
                break
            ext = min(ext, L_[j]) if d == 1 else max(ext, H_[j])
            if not cuk and (e0 - ext) * d >= p * r0:
                cuk = True
            if cuk and j > a_ and ((C_[j] > O_[j] and C_[j] > H_[j - 1]) if d == 1 else (C_[j] < O_[j] and C_[j] < L_[j - 1])):
                b = j; break
        if b < 0:
            continue
        stop = H_[b] if d == 1 else L_[b]
        sl = ext                                   # ujung ekor pantulan (titik ekstrem koreksi)
        for j in range(b + 1, b + 1 + tunggu):
            if (L_[j] <= sl) if d == 1 else (H_[j] >= sl):
                break
            if (H_[j] >= stop) if d == 1 else (L_[j] <= stop):
                e = max(stop, O_[j]) if d == 1 else min(stop, O_[j])
                rk = (e - sl) * d
                if rk >= 0.003 * e:
                    k0n[i], en[i], rn[i] = j, e, rk; nm[i] = max(nm[i] - (j - a_), 8)
                break
    return k0n, en, rn, nm
for p in (0.3, 0.5):
    k0n, en, rn, nm = koreksi(p)
    pil = m8 & (k0n >= 0)
    res = jalan3(0.5, 0.2, 0.0, 0.5, k0a=k0n, ea=en, riska=rn, nmaxa=nm, pilih=pil)
    rr = res["R"]
    P(f"   koreksi >= {p}R lalu pantulan: terisi {int(pil.sum())} dari {int(m8.sum())} sinyal ({pil.sum() / m8.sum() * 100:.0f}%), "
      f"jarak SL baru median {np.nanmedian(rn[pil] / S.risk.values[pil]) * 100:.0f}% dari SL lama")
    P(f"      sinyal sama, MARKET (v149): PF {pf(baru['R'][pil]):.2f} | koreksi: PF {pf(rr[pil]):.2f} latih {pf(rr[pil & lat]):.2f} uji {pf(rr[pil & tes]):.2f}")
    rm = rem_flag(res, pil)
    nilai(f"masuk koreksi {p}R + rem (hanya yang terisi)", jalankan(dict(R=np.nan_to_num(rr), hrs=res["hrs"], aman=res["aman"]), pil & ~rm, 4, 0))

open("hasil_v150.txt", "w").write("\n".join(out))
import pickle
pickle.dump(dict(m8=m8, rem=rem, lat=lat, tes=tes, VAR={k: v for k, v in VAR.items()}), open(os.path.join(Cx.SC, "v150_state.pkl"), "wb"))

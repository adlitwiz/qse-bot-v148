"""v149 riset struktur tahap 3 (5 usulan user 3 Nov 2026). Data sebelum sinyal saja. Ambang dipilih di 2023-2024, dicek 2025-2026 dan per bulan.
1. Efisiensi tren 20 candle 4J koin saat sinyal: rendah -> kunci jalur tren, izinkan strategi pantulan (strategi B, dari run_struktur).
2. SHORT dipisah: syarat lebih ketat (sudah ada pantulan naik: jarak dari low 50 candle) dan TPawal lebih dekat, keluar lebih cepat.
3. Saat rem 7 hari menyala: SHORT dimatikan, hanya LONG jalur rsi_vol dan orderblock (pilihan ini diambil dari data yang sama, jadi diuji
   ulang: jalur LONG yang tahan dipilih dari bulan merah 2023-2024 saja, dicek 2025-2026).
4. Kekuatan relatif harian terhadap BTC: LONG hanya koin terkuat X%, SHORT hanya terlemah X% (return 24 jam dan 7 hari).
5. TPawal sebelum support/resistance terdekat (FVG tidak ada di data uji), digabung rem 7 hari."""
import os, numpy as np, pandas as pd
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "struktur2"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
def cari(d, k):
    while k not in d:
        d = d["ns"]
    return d[k]
sim2 = cari(ns, "sim2")
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
m8 = ok & izin & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
R = baru["R"]; masuk = S.masuk_h.values; keluar = masuk + baru["hrs"]; ar = S.arah.values; jl = S.jalur.values
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
idx = np.nonzero(m8)[0]
def nilai(nm, T):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    th_ = thn[i]
    P(f"   {nm:52s} n {len(r):5d} WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} total {r.sum():+6.0f}R DD {dd(r[o_]):4.0f}R | PF<1 {int((pm < 1).sum()):2d}/{len(pm)} "
      f"PF>=2 {int((pm >= 2).sum()):2d} terburuk {tm.min():+5.1f}R | 23-24 {pf(r[th_ <= 2024]):.2f} 25-26 {pf(r[th_ >= 2025]):.2f} | "
      f"2026-04 {tm.get('2026-04', 0):+.1f} 07 {tm.get('2026-07', 0):+.1f} 10 {tm.get('2026-10', 0):+.1f}")
    return tm
# rem 7 hari (sudah terbukti di run_bulan)
o = idx[np.argsort(keluar[idx], kind="stable")]; kk = keluar[o]; rr = R[o]; cs = np.r_[0, np.cumsum(rr)]
rem7 = np.zeros(len(S), bool)
for i in idx:
    j = np.searchsorted(kk, masuk[i], side="right"); j0 = np.searchsorted(kk, masuk[i] - 168, side="right")
    rem7[i] = (cs[j] - cs[j0]) < -3.0
P("== DASAR ==")
nilai("v149 sekarang", jalankan(baru, m8, 4, 0))
nilai("v149 + rem 7 hari", jalankan(baru, m8 & ~rem7, 4, 0))
def simulasi(tps=None, por=None, tpr=None, jstop=None):
    """Simulasi ulang sinyal m8 dengan TPawal, porsi, TP, batas waktu per sinyal (array)."""
    Rn, hn, an = R.copy(), baru["hrs"].copy(), baru["aman"].copy()
    k0 = S.k0.values; nmax = S.nmax.values; rk = S.risk.values; at = S.atrt.values; tr_ = S.tp_r.values; tl = S.trail.values
    for i in idx:
        e = Cx.O[k0[i]]
        r, h, a = sim2(Cx.H, Cx.L, Cx.C, Cx.O, k0[i], nmax[i], ar[i], e, rk[i], at[i], tr_[i] if tpr is None else tpr[i], tl[i], 4, 12, -0.5, -0.5,
                       30 if jstop is None else int(jstop[i]), 0.0, 0.5, 0.5 if tps is None else tps[i], 0.2 if por is None else por[i])
        Rn[i] = r - Cx.BIAYA * e / rk[i]; hn[i] = h; an[i] = a
    return dict(R=Rn, hrs=hn, aman=an)
cek = simulasi()
P(f"   cek simulasi ulang = v149: selisih maks {np.abs(cek['R'][idx] - R[idx]).max():.2e}")

# 1. efisiensi tren 20 candle 4J (80 jam) koin
H_, L_, C_, O_ = Cx.H, Cx.L, Cx.C, Cx.O
k0 = S.k0.values
er = np.full(len(S), np.nan)
for i in idx:
    c = C_[k0[i] - 80:k0[i]:4]
    er[i] = abs(c[-1] - c[0]) / max(np.abs(np.diff(c)).sum(), 1e-12)
P("\n== 1. EFISIENSI TREN 20 CANDLE 4J SAAT SINYAL ==")
lat = m8 & (thn <= 2024); tes = m8 & (thn >= 2025)
q = np.nanquantile(er[lat], [0.2, 0.4, 0.6, 0.8])
gr = np.digitize(er, q)
P("   PF per kelompok 20% (latih 2023-24 / uji 2025-26): " + " | ".join(f"k{g + 1} {pf(R[lat & (gr == g)]):.2f}/{pf(R[tes & (gr == g)]):.2f}" for g in range(5)))
best = max(((pf(R[lat & (er >= qq)]), qq) for qq in q), key=lambda z: z[0])
P(f"   ambang terbaik di latih: efisiensi >= {best[1]:.3f} (PF latih {best[0]:.2f})")
tren_ok = er >= best[1]
tmT = nilai(f"A hanya saat efisiensi >= {best[1]:.3f}", jalankan(baru, m8 & tren_ok, 4, 0))
nilai("A efisiensi + rem 7 hari", jalankan(baru, m8 & tren_ok & ~rem7, 4, 0))

# 2. SHORT dipisah
P("\n== 2. SHORT DIPISAH ==")
sh = ar == -1
dl = S.dist_lo50.values
q2 = np.nanquantile(dl[lat & sh], [0.2, 0.4, 0.6, 0.8])
P("   SHORT PF per jarak dari low 50 candle (ATR), latih/uji: " + " | ".join(
    f"k{g + 1} {pf(R[lat & sh & (np.digitize(dl, q2) == g)]):.2f}/{pf(R[tes & sh & (np.digitize(dl, q2) == g)]):.2f}" for g in range(5)))
bs = max(((pf(R[lat & sh & (dl >= qq)]), qq) for qq in q2), key=lambda z: z[0])
short_ok = ~sh | (dl >= bs[1])
P(f"   SHORT syarat jarak dari low 50 >= {bs[1]:.2f} ATR (dipilih latih, PF {bs[0]:.2f})")
nilai("SHORT ketat (sudah memantul dari low)", jalankan(baru, m8 & short_ok, 4, 0))
for tps_s, por_s, js in ((0.33, 0.2, 30), (0.33, 0.5, 30), (0.33, 0.5, 18), (0.25, 0.5, 18)):
    tps = np.where(sh, tps_s, 0.5); por = np.where(sh, por_s, 0.2); jst = np.where(sh, js, 30)
    tpr = np.where(sh, np.where(S.tp_r.values > 0, np.minimum(S.tp_r.values, 2.0), 2.0), S.tp_r.values)
    res = simulasi(tps, por, tpr, jst)
    nilai(f"SHORT TPawal {tps_s} tutup {int(por_s * 100)}%, TP<=2R, {js} jam", jalankan(res, m8, 4, 0))
    nilai(f"   + SHORT ketat + rem 7 hari", jalankan(res, m8 & short_ok & ~rem7, 4, 0))

# 3. rem menyala: hanya LONG jalur tahan banting, dipilih dari bulan merah 2023-2024
P("\n== 3. SAAT REM 7 HARI MENYALA: HANYA LONG JALUR TAHAN BANTING ==")
Tb = jalankan(baru, m8, 4, 0); rb = pd.Series(Tb[:, 2]).groupby(bln[Tb[:, 3].astype(int)]).sum()
merah_lat = set(rb.index[(rb < 0) & (rb.index <= "2024-12")])
cand = []
for j in sorted(set(jl)):
    x = R[m8 & (jl == j) & (ar == 1) & np.isin(bln, list(merah_lat))]
    if len(x) >= 20:
        cand.append((pf(x), j, len(x)))
cand.sort(reverse=True)
P("   LONG per jalur di bulan merah 2023-2024: " + ", ".join(f"{j} PF {p:.2f} (n {n})" for p, j, n in cand))
tahan = [j for p, j, n in cand if p >= 1.2]
P(f"   dipilih (PF >= 1.2 di bulan merah latih): {tahan}")
x = R[m8 & np.isin(jl, tahan) & (ar == 1) & (thn >= 2025)]
P(f"   jalur itu LONG di 2025-2026: n {len(x)} PF {pf(x):.2f}")
boleh_rem = (ar == 1) & np.isin(jl, tahan)
nilai("rem 7 hari menyala: hanya LONG jalur tahan", jalankan(baru, m8 & (~rem7 | boleh_rem), 4, 0))

# 4. kekuatan relatif harian terhadap BTC
P("\n== 4. KEKUATAN RELATIF HARIAN TERHADAP BTC ==")
OFF, TS = Cx.OFF, Cx.TS
ranks = S.groupby("sym")["rank"].median()
koin = [s for s in OFF if s in ranks.index and ranks[s] <= 150]
hari = {}
for s in koin + ["BTCUSDT"]:
    a, n = OFF[s]
    t = TS[a:a + n] // 86400000
    ix = np.r_[np.nonzero(np.diff(t))[0], n - 1]
    hari[s] = pd.Series(C_[a + ix], index=t[ix])
Dc = pd.DataFrame(hari)
for lb in (1, 7):
    rel = Dc.pct_change(lb).sub(Dc["BTCUSDT"].pct_change(lb), axis=0).drop(columns="BTCUSDT")
    pct = rel.rank(axis=1, pct=True)
    p_sig = np.full(len(S), np.nan)
    day = (TS[k0] // 86400000) - 1          # hari yang sudah tutup
    for i in idx:
        s = S.sym.values[i]
        if s in pct.columns and day[i] in pct.index:
            p_sig[i] = pct.at[day[i], s]
    P(f"   return {lb} hari relatif BTC, PF per kelompok persentil (latih/uji):")
    for a_, nm in ((1, "LONG"), (-1, "SHORT")):
        m_ = ar == a_
        ss = "      " + nm + ": "
        for lo, hi in ((0, 0.1), (0.1, 0.3), (0.3, 0.7), (0.7, 0.9), (0.9, 1.01)):
            g = (p_sig >= lo) & (p_sig < hi)
            ss += f" {lo:.1f}-{min(hi, 1):.1f} {pf(R[lat & m_ & g]):.2f}/{pf(R[tes & m_ & g]):.2f} (n {int((tes & m_ & g).sum())}) |"
        P(ss)
    for X in (0.1, 0.3, 0.5):
        rs_ok = ((ar == 1) & (p_sig >= 1 - X)) | ((ar == -1) & (p_sig <= X))
        nilai(f"RS {lb} hari: LONG terkuat {int(X * 100)}%, SHORT terlemah {int(X * 100)}%", jalankan(baru, m8 & rs_ok, 4, 0))

# 5. TPawal sebelum support/resistance terdekat
P("\n== 5. TPawal SEBELUM SUPPORT/RESISTANCE TERDEKAT ==")
dist = np.where(ar == 1, S.dist_res.values, S.dist_sup.values) * S.atr.values
for f, lo in ((0.9, 0.2), (0.8, 0.25)):
    tps = np.clip(f * dist / S.risk.values, lo, 0.5)
    tps = np.where(np.isfinite(tps), tps, 0.5)
    res = simulasi(tps=tps)
    P(f"   TPawal = min(0.5R, {f} x jarak ke S/R), minimal {lo}R: TPawal dipendekkan di {np.mean(tps[idx] < 0.5) * 100:.0f}% sinyal")
    nilai(f"TPawal sebelum S/R ({f})", jalankan(res, m8, 4, 0))
    nilai("   + rem 7 hari", jalankan(res, m8 & ~rem7, 4, 0))
open("hasil_struktur2.txt", "w").write("\n".join(out))

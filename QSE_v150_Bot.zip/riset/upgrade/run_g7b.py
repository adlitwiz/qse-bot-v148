"""Grup 7b: walk-forward tahunan, cara yang sama dengan pemakaian live. Model dilatih ulang tiap tahun hanya dari data
sebelumnya (2021-22 -> 2023, 2021-23 -> 2024, 2021-24 -> 2025, 2021-25 -> 2026). Buang q% peluang terendah tiap tahun uji."""
import numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score
import var_lib as V, core as Cx
src = open("run_g7.py").read().split("X = fitur(S)")[0]
ns = {}
exec(src, ns)
S, base, Rb = ns["S"], ns["base"], ns["Rb"]
X = ns["fitur"](S)
import os
if os.environ.get("G7_FITUR") == "live":
    X = X[["jalur", "arah", "vp", "drop6", "pump6", "drop12", "pump12", "body", "dist_lo50", "dist_hi50", "pos50", "atr_pct",
           "jam", "hari", "btc24", "btc168", "koin168", "mp", "mm"]]
y = (Rb > 0).astype(int)
thn = S.tahun.values
out = []
def P(s=""):
    print(s, flush=True); out.append(s)
pr = np.full(len(S), np.nan)
for t in (2023, 2024, 2025, 2026):
    tr_, te_ = thn < t, thn == t
    m = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=200, min_samples_leaf=200, l2_regularization=1.0,
                                       categorical_features=[0], random_state=0).fit(X[tr_], y[tr_])
    pr[te_] = m.predict_proba(X[te_])[:, 1]
    P(f"{t}: AUC {roc_auc_score(y[te_], pr[te_]):.3f}")
uji = thn >= 2023
pop_uji = {p: V.POP[p] & uji for p in V.PRIMER}
for q in (0.0, 0.1, 0.2, 0.3):
    buang = np.zeros(len(S), bool)
    for t in (2023, 2024, 2025, 2026):
        mk = thn == t
        buang[mk] = pr[mk] < np.quantile(pr[mk], q) if q > 0 else False
    s = ""
    for pop in V.PRIMER:
        T = Cx.portofolio(S, base, pilih=pop_uji[pop] & ~buang)
        mm = Cx.metrik(T, S)
        per = ""
        try:
            for t in (2023, 2024, 2025, 2026):
                r = T[:, 3][thn[T[:, 4].astype(int)] == t]
                pf = r[r > 0].sum() / -r[r < 0].sum()
                per += f" {t} PF {pf:.2f} tot {r.sum():+4.0f} WR {np.mean(r > 0) * 100:3.0f} |"
        except Exception as ex:
            per = f" ({ex})"
        s += f"\n    [{pop}] WR {mm['wr']:4.1f} PF {mm['pf']:.2f} tot {mm['total']:+4.0f} DD {mm['dd']:3.0f} |{per}"
    P(f"buang {int(q * 100)}%{s}")
open(f"{Cx.SC}/hasil_g7b" + ("_live" if os.environ.get("G7_FITUR") == "live" else "") + ".txt", "w").write("\n".join(out))

"""Unduh candle 1 jam Binance spot (pengganti Bybit yang diblokir) 2021-2026 untuk ~120 koin likuid."""
import os, sys, time, json, urllib.request
from concurrent.futures import ThreadPoolExecutor
D = os.environ.get("QSE_UJI_DATA", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"))
os.makedirs(D, exist_ok=True)
B = "https://data-api.binance.vision/api/v3"
def get(u, tries=5):
    for k in range(tries):
        try:
            with urllib.request.urlopen(u, timeout=20) as r:
                return json.loads(r.read())
        except Exception as e:
            time.sleep(1 + k)
    return None
tk = get(B + "/ticker/24hr")
bad = ("UP", "DOWN", "BULL", "BEAR")
stab = {"USDC", "FDUSD", "TUSD", "USDP", "DAI", "EUR", "AEUR", "USDE", "XUSD", "PYUSD", "BFUSD", "USD1", "UST", "BUSD", "EURI"}
rows = []
for t in tk:
    s = t["symbol"]
    if not s.endswith("USDT"): continue
    b = s[:-4]
    if b in stab or any(b.endswith(x) for x in bad) or b.startswith("USD"): continue
    rows.append((float(t["quoteVolume"]), s))
rows.sort(reverse=True)
SY = [s for _, s in rows[:130]]
print(len(SY), SY[:10], flush=True)
START = int(time.mktime(time.strptime("2021-01-01", "%Y-%m-%d"))) * 1000
def dl(s):
    p = f"{D}/{s}_60.csv"
    if os.path.exists(p): return s, -1
    out, st = [], START
    while True:
        r = get(f"{B}/klines?symbol={s}&interval=1h&startTime={st}&limit=1000")
        if not r: break
        out += r
        if len(r) < 1000: break
        st = r[-1][0] + 3600000
    if len(out) < 3000: return s, 0
    import pandas as pd
    df = pd.DataFrame([[pd.Timestamp(x[0], unit="ms", tz="UTC"), float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5])] for x in out],
                      columns=["t", "open", "high", "low", "close", "volume"]).drop_duplicates("t")
    df.to_csv(p, index=False)
    return s, len(df)
t0 = time.time()
with ThreadPoolExecutor(6) as ex:
    for s, n in ex.map(dl, SY):
        print(s, n, round(time.time() - t0), flush=True)
print("SELESAI", flush=True)

"""Grup 21: bedah otomatis semua kelompok sinyal yang rugi, LONG dan SHORT terpisah. Tiap fitur dipotong 10 desil (plus ambang candle
persen). Kelompok dianggap BOCOR kalau rata R < -0.05 di 2021-2023 DAN di 2024-2026, minimal 30 sinyal per periode. Aturan v149."""
import numpy as np, pandas as pd
src = open("run_g15.py").read().split("B = run(")[0]
ns = {"__name__": "g21"}
exec(src, ns)
S, run, Cx = ns["S"], ns["run"], ns["Cx"]
B = run(jk=12, jmode=4, jstop=30)
R = B["R"]; ar = S.arah.values; th = S.tahun.values
X = ns["ns"]["X"].copy()
X["candle_pct"] = S.body.values * S.atr.values / S.px.values * 100 * (-ar)
X["nilai_n"] = S.nilai_n.values
for k in ("dist_sup", "dist_res", "rank"):
    X[k] = S[k].values
out = []
for a, nm in ((1, "LONG"), (-1, "SHORT")):
    m0 = ar == a
    for kol in X.columns:
        if kol in ("arah",):
            continue
        x = X[kol].values.astype(float)
        if kol == "jalur":
            bins = [(v - 0.5, v + 0.5) for v in np.unique(x[m0])]
        else:
            q = np.nanquantile(x[m0], np.linspace(0, 1, 11))
            bins = list(zip(q[:-1], q[1:])) + [(q[0], q[3]), (q[7], q[10])]
            if kol == "candle_pct":
                bins += [(t, 99) for t in (5, 8, 10, 12, 15)]
        for lo, hi in bins:
            g = m0 & (x >= lo) & (x <= hi)
            a1, a2 = R[g & (th < 2024)], R[g & (th >= 2024)]
            if len(a1) >= 30 and len(a2) >= 30 and a1.mean() < -0.05 and a2.mean() < -0.05:
                out.append((nm, kol, round(lo, 3), round(hi, 3), len(a1), round(a1.mean(), 3), len(a2), round(a2.mean(), 3)))
D = pd.DataFrame(out, columns=["arah", "fitur", "dari", "sampai", "n_21_23", "rata_21_23", "n_24_26", "rata_24_26"])
pd.set_option("display.width", 200)
txt = f"Kelompok rugi konsisten di dua periode (dari {len(X.columns) - 1} fitur x 2 arah):\n" + (D.to_string(index=False) if len(D) else "tidak ada")
for a, nm in ((1, "LONG"), (-1, "SHORT")):
    m0 = ar == a
    txt += f"\n{nm} semua: n {m0.sum()} rata {R[m0].mean():+.3f} (21-23 {R[m0 & (th < 2024)].mean():+.3f}, 24-26 {R[m0 & (th >= 2024)].mean():+.3f})"
print(txt)
open(f"{Cx.SC}/hasil_g21.txt", "w").write(txt)

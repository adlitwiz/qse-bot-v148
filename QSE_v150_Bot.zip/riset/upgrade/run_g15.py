"""Grup 15: masuk saat koreksi. Sinyal jalur tidak dieksekusi MARKET, tapi LIMIT di harga koreksi
(entry - x R untuk LONG, + x R untuk SHORT), berlaku W jam. Tidak terisi = tidak ada trade.
Dua versi SL: tetap di level SL sinyal (risk mengecil, R per trade membesar) dan ikut harga isi (risk sama).
Keluar aturan v149 (jam 12 hanya melawan, umur 30 jam). Pembanding = MARKET (bot sekarang), otak + rem + maks 4 searah, 2023-2026.
Aturan lolos sama dengan g13 (P dan DD)."""
import numpy as np, pandas as pd
from numba import njit
src = open("run_g13.py").read().split("LV = jalan(base)")[0].replace("cache=True", "cache=False")
ns = {"__name__": "g15"}
exec(src, ns)
for k in ("S", "run", "jalan", "fmt", "base", "Cx", "P", "out", "porto", "mt", "otak", "uji", "V", "thn"):
    globals()[k] = ns[k]
sim2 = ns["sim2"]
out.clear()


@njit(cache=False)
def limit_semua(Hh, L, C, O, k0, nmax, d, risk, atrt, tp_r, trail, x, W, sl_tetap, biaya):
    m = len(k0)
    R = np.zeros(m)
    hrs = np.zeros(m, np.int64)
    am = np.full(m, -1, np.int64)
    isi = np.zeros(m, np.bool_)
    for i in range(m):
        e0 = O[k0[i]]
        lim = e0 - d[i] * x * risk[i]
        sl = e0 - d[i] * risk[i]
        j = -1
        for q in range(min(W, nmax[i] - 2)):
            if (d[i] == 1 and L[k0[i] + q] <= lim) or (d[i] == -1 and Hh[k0[i] + q] >= lim):
                j = q
                break
        if j < 0:
            continue
        isi[i] = True
        rk = (lim - sl) * d[i] if sl_tetap else risk[i]
        slx = lim - d[i] * rk
        if (d[i] == 1 and L[k0[i] + j] <= slx) or (d[i] == -1 and Hh[k0[i] + j] >= slx):
            R[i] = -1.0 - biaya * lim / rk
            hrs[i] = j + 1
            continue
        r, h, a = sim2(Hh, L, C, O, k0[i] + j + 1, nmax[i] - j - 1, d[i], lim, rk, atrt[i], tp_r[i], trail[i], 4, 12, -0.5, -0.5, 30,
                       0.0, 0.5, 0.5, 0.20)
        R[i] = r - biaya * lim / rk
        hrs[i] = j + 1 + h
        am[i] = (j + 1 + a) if a >= 0 else -1
    return R, hrs, am, isi


B = run(jk=12, jmode=4, jstop=30)
LV = jalan(B)
P(fmt("v149 MARKET (pembanding: jam 12 melawan, 30 jam)", LV, LV))
for x in (0.25, 0.5):
    for W in (4, 8, 12):
        for tetap in (True, False):
            R, hrs, am, isi = limit_semua(Cx.H, Cx.L, Cx.C, Cx.O, S.k0.values, S.nmax.values, S.arah.values.astype(np.int64), S.risk.values,
                                          S.atrt.values, S.tp_r.values, S.trail.values, x, W, tetap, Cx.BIAYA)
            res = dict(R=R, hrs=hrs, aman=am)
            mk = isi & uji & otak
            P(f"-- LIMIT {x}R {W} jam SL {'tetap' if tetap else 'ikut'}: terisi {isi[uji & otak].mean() * 100:.0f}% sinyal, rata R terisi {R[mk].mean():+.3f}, "
              f"rata R MARKET sinyal yang sama {B['R'][mk].mean():+.3f}, yang tidak terisi (MARKET) {B['R'][~isi & uji & otak].mean():+.3f}")
            P(fmt(f"LIMIT koreksi {x}R, {W} jam, SL {'tetap' if tetap else 'ikut'}", jalan(res, isi), LV))
open(f"{Cx.SC}/hasil_g15.txt", "w").write("\n".join(out))

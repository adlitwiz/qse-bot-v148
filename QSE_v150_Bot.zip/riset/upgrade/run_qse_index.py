"""Indikator QSE (permintaan 4 Nov 06:45). Dirakit dari nol dari data, bukan dari indikator pasaran.
1. Bedah DNA: semua candle 1J, kedua arah. Menang murni = harga capai +3R sebelum -1R dalam 24 jam (R = 1.5 x rata rentang 14 candle 1J).
   Rugi = -1R tersentuh lebih dulu. Bandingkan ciri 1 sampai 10 candle sebelum masuk antara menang murni dan semua candle.
2. Lima komponen: percepatan harga per rentang candle, ketimpangan taker buy, kompresi, efisiensi arah, sinkron dengan BTC.
3. QSE Index -100..+100 = persentil peluang menang murni (regresi logistik) arah LONG atau SHORT. Pemicu saat menembus ambang dari bawah.
   Batal kalau harga sudah lari > 20% dari titik terendah/tertinggi 72 jam.
4. Kill-switch: model kedua dari ciri sumbu candle dan penyusutan volume, dilatih pada pemicu yang berujung rugi.
5. Latih: Jul 2022 sampai Des 2024 (data taker buy Binance baru mulai Jun 2022). Uji murni: Jan 2025 sampai Okt 2026.
   Aturan keluar v149. Biaya 0.15% harga."""
import os, numpy as np, pandas as pd
from numba import njit
from sklearn.linear_model import LogisticRegression
import core as Cx
H_, L_, C_, O_, TS = Cx.H, Cx.L, Cx.C, Cx.O, Cx.TS
SC = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad"
src = open("run_v153.py").read(); a0 = src.index("@njit(cache=False)"); a1 = src.index("def jalan3")
exec(src[a0:a1])                                   # sim3: aturan keluar v149
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
S = pd.read_pickle(f"{SC}/k10/S.pkl"); ranks = S.groupby("sym")["rank"].median()
koin = [s for s in Cx.OFF if s in ranks.index and ranks[s] <= 150 and os.path.exists(f"{SC}/taker/{s}.npz")]
MS = lambda s: int(pd.Timestamp(s, tz="UTC").value // 10**6)
T_LAT0, T_UJI0, T_AKHIR = MS("2022-07-01"), MS("2025-01-01"), MS("2026-11-01")

@njit(cache=False)
def label(h, l, o, rk, n_h):
    n = len(h); y = np.zeros((n, 2), np.int8)              # kolom 0 LONG, 1 SHORT. 1 menang murni, -1 rugi, 0 waktu habis
    for i in range(n - 1):
        e = o[i + 1]; r = rk[i]
        if not (r > 0):
            continue
        for di in range(2):
            d = 1 if di == 0 else -1
            for j in range(i + 1, min(i + 1 + n_h, n)):
                rugi = (l[j] <= e - r) if d == 1 else (h[j] >= e + r)
                if rugi:
                    y[i, di] = -1; break
                untung = (h[j] >= e + 3 * r) if d == 1 else (l[j] <= e - 3 * r)
                if untung:
                    y[i, di] = 1; break
    return y

b0, bl = Cx.OFF["BTCUSDT"]; bT = TS[b0:b0 + bl]; bC = pd.Series(C_[b0:b0 + bl])
b_ret6 = (bC / bC.shift(6) - 1).values; b_atrp = (pd.Series(H_[b0:b0 + bl] - L_[b0:b0 + bl]).rolling(14).mean() / bC).values
FIT = ["percepatan", "percepatan2", "taker3", "taker20", "kompresi", "kompresi_atr", "efisiensi", "lawan_btc", "btc_searah"]
KILL = ["sumbu_lawan", "volume_susut", "badan_besar", "jauh_ema"]
blok = []
for s in koin:
    a, n = Cx.OFF[s]
    t = TS[a:a + n]; m = (t >= T_LAT0 - 200 * 3600000) & (t < T_AKHIR)
    if m.sum() < 1000:
        continue
    i0 = np.argmax(m); i1 = len(m) - np.argmax(m[::-1])
    t = t[i0:i1]; h, l, c, o = H_[a + i0:a + i1], L_[a + i0:a + i1], C_[a + i0:a + i1], O_[a + i0:a + i1]
    z = np.load(f"{SC}/taker/{s}.npz"); j = np.clip(np.searchsorted(z["t"], t), 0, len(z["t"]) - 1); okm = z["t"][j] == t
    v = np.where(okm, z["v"][j], np.nan); tb = np.where(okm, z["tb"][j], np.nan)
    cs, hs, ls, vs = pd.Series(c), pd.Series(h), pd.Series(l), pd.Series(v)
    rg = hs - ls; atr = rg.rolling(14).mean(); rk = (1.5 * atr).values
    y = label(h, l, o, np.nan_to_num(rk, nan=-1.0), 24)
    m3 = (cs - cs.shift(3)) / atr
    net = pd.Series(2 * tb - v)
    jb = np.clip(np.searchsorted(bT, t, "right") - 1, 0, len(bT) - 1)
    ret6 = (cs / cs.shift(6) - 1).values; atrp = (atr / cs).values
    F = pd.DataFrame(dict(
        t=t, sym=s, i=np.arange(len(t)) + a + i0,
        percepatan=m3.values, percepatan2=(m3 - m3.shift(3)).values,
        taker3=(net.rolling(3).sum() / vs.rolling(3).sum()).values, taker20=(net.rolling(20).sum() / vs.rolling(20).sum()).values,
        kompresi=((hs.rolling(10).max() - ls.rolling(10).min()) / (hs.rolling(50).max() - ls.rolling(50).min())).values,
        kompresi_atr=(rg.rolling(5).mean() / rg.rolling(50).mean()).values,
        efisiensi=((cs - cs.shift(10)) / cs.diff().abs().rolling(10).sum()).values,
        lawan_btc=(ret6 - b_ret6[jb]) / atrp, btc_searah=b_ret6[jb] / b_atrp[jb],
        atas=((hs - np.maximum(cs, pd.Series(o))) / rg.replace(0, np.nan)).values, bawah=((np.minimum(cs, pd.Series(o)) - ls) / rg.replace(0, np.nan)).values,
        volume_susut=(vs.rolling(3).mean() / vs.rolling(20).mean()).values,
        badan_besar=((cs - pd.Series(o)).abs() / atr).values,
        jauh_ema=((cs - cs.ewm(span=20, adjust=False).mean()) / atr).values,
        lari_naik=(cs / ls.rolling(72).min() - 1).values, lari_turun=(1 - cs / hs.rolling(72).max()).values,
        yL=y[:, 0], yS=y[:, 1], rk=rk, e=np.r_[o[1:], np.nan]))
    F = F[(F.t >= T_LAT0) & np.isfinite(F.rk)]
    blok.append(F)
F = pd.concat(blok, ignore_index=True); del blok
for k_ in F.columns:
    if F[k_].dtype == np.float64 and k_ not in ("rk", "e"):
        F[k_] = F[k_].astype(np.float32)
F["sym"] = F.sym.astype("category")
F = F.replace([np.inf, -np.inf], np.nan).dropna(subset=FIT + ["volume_susut", "jauh_ema", "atas", "bawah"])
P(f"Data: {len(koin)} koin, {len(F):,} candle 1J (Jul 2022 sampai Okt 2026), kedua arah dihitung.")

def arah(F, d):
    """Fitur ditandai arah: komponen berarah dikali d, komponen netral tetap."""
    X = pd.DataFrame(index=F.index)
    for k_ in ("percepatan", "percepatan2", "taker3", "taker20", "efisiensi", "lawan_btc", "btc_searah", "jauh_ema"):
        X[k_] = F[k_] * d
    X["kompresi"] = F.kompresi; X["kompresi_atr"] = F.kompresi_atr; X["volume_susut"] = F.volume_susut; X["badan_besar"] = F.badan_besar
    X["sumbu_lawan"] = F.atas if d == 1 else F.bawah
    X["lari"] = F.lari_naik if d == 1 else F.lari_turun
    X["y"] = F.yL if d == 1 else F.yS
    return X
XL, XS = arah(F, 1), arah(F, -1)
lat = (F.t < T_UJI0).values; uji = ~lat

P("\n== 1. DNA MENANG MURNI (latih Jul 2022 sampai Des 2024) ==")
A = pd.concat([XL[lat], XS[lat]])
P(f"   candle x arah: {len(A):,}. Menang murni (+3R sebelum -1R, <24 jam): {(A.y == 1).mean() * 100:.2f}%. Rugi -1R lebih dulu: {(A.y == -1).mean() * 100:.1f}%.")
P(f"   {'komponen':14s} {'median semua':>13s} {'median menang':>14s} {'median rugi':>12s} {'beda baku':>10s}")
for k_ in FIT + KILL:
    sd = A[k_].std(); mw = A[A.y == 1][k_].median(); ma = A[k_].median(); ml = A[A.y == -1][k_].median()
    P(f"   {k_:14s} {ma:13.3f} {mw:14.3f} {ml:12.3f} {(A[A.y == 1][k_].mean() - A[k_].mean()) / sd:+10.2f}")

P("\n== 2. RUMUS QSE INDEX (regresi logistik, bobot dari latih saja) ==")
def siap(X):
    Z = X[FIT].clip(X[FIT].quantile(0.005), X[FIT].quantile(0.995), axis=1) if False else X[FIT]
    return Z
qlo = A[FIT].quantile(0.005); qhi = A[FIT].quantile(0.995)
mu = A[FIT].clip(qlo, qhi, axis=1).mean(); sg = A[FIT].clip(qlo, qhi, axis=1).std()
std = lambda X: ((X[FIT].clip(qlo, qhi, axis=1) - mu) / sg).values.astype(np.float32)
rng = np.random.default_rng(7); pick = rng.choice(len(A), size=min(len(A), 2_000_000), replace=False)
mdl = LogisticRegression(C=1.0, max_iter=300).fit(std(A.iloc[pick]), (A.y.values[pick] == 1).astype(int))
for k_, w in zip(FIT, mdl.coef_[0]):
    P(f"   bobot {k_:14s} {w:+.3f}")
P(f"   intersep {mdl.intercept_[0]:+.3f}")
pL = mdl.predict_proba(std(XL))[:, 1]; pS = mdl.predict_proba(std(XS))[:, 1]
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import HistGradientBoostingClassifier
P("   Pembanding non-linear (gradient boosting, 9 komponen + 4 ciri kill-switch), dilatih di data latih saja:")
FX = FIT + KILL
hgb = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, max_leaf_nodes=31, min_samples_leaf=500, random_state=7)
hgb.fit(A[FX].values[pick].astype(np.float32), (A.y.values[pick] == 1).astype(int))
hL = hgb.predict_proba(XL[FX].values.astype(np.float32))[:, 1]; hS = hgb.predict_proba(XS[FX].values.astype(np.float32))[:, 1]
yy_l = np.r_[XL.y[lat], XS.y[lat]] == 1; yy_u = np.r_[XL.y[uji], XS.y[uji]] == 1
auc_lin = roc_auc_score(yy_l, np.r_[pL[lat], pS[lat]]); auc_hgb = roc_auc_score(yy_l, np.r_[hL[lat], hS[lat]])
P(f"   AUC latih: logistik {auc_lin:.3f}, boosting {auc_hgb:.3f}. AUC uji boosting {roc_auc_score(yy_u, np.r_[hL[uji], hS[uji]]):.3f}")
if auc_hgb > auc_lin:
    P("   >> boosting dipakai untuk QSE Index (dipilih dari AUC latih)")
    pL, pS = hL, hS
ref = np.sort(np.r_[pL[lat], pS[lat]])
pct = lambda p: np.searchsorted(ref, p) / len(ref) * 100
F["qL"] = pct(pL); F["qS"] = pct(pS)
F["QSE"] = np.where(F.qL >= F.qS, F.qL, -F.qS)
from sklearn.metrics import roc_auc_score
P(f"   daya pisah (AUC) menang murni: latih {roc_auc_score(np.r_[XL.y[lat], XS.y[lat]] == 1, np.r_[pL[lat], pS[lat]]):.3f}, "
  f"uji {roc_auc_score(np.r_[XL.y[uji], XS.y[uji]] == 1, np.r_[pL[uji], pS[uji]]):.3f} (0.5 = acak)")
for lo_, hi_ in ((0, 50), (50, 80), (80, 90), (90, 95), (95, 98), (98, 99), (99, 100.1)):
    for nm, mm in (("latih", lat), ("uji", uji)):
        q = np.r_[F.qL[mm], F.qS[mm]]; yy = np.r_[XL.y[mm], XS.y[mm]]; s_ = (q >= lo_) & (q < hi_)
        P(f"   persentil {lo_:>3}-{min(hi_, 100):<5} {nm:5s}: menang murni {np.mean(yy[s_] == 1) * 100:5.2f}% rugi dulu {np.mean(yy[s_] == -1) * 100:5.1f}% n {s_.sum():,}")

P("\n== 3 dan 4. PEMICU + KILL-SWITCH, AKSI DENGAN ATURAN KELUAR v149 ==")
# ATR 4J untuk trailing v149
AT4 = {}
for s in koin:
    a, n = Cx.OFF[s]; t = TS[a:a + n]; g = t // 14400000; ix = np.r_[0, np.nonzero(np.diff(g))[0] + 1]
    h4 = np.maximum.reduceat(H_[a:a + n], ix); l4 = np.minimum.reduceat(L_[a:a + n], ix)
    AT4[s] = (t[ix], pd.Series(h4 - l4).rolling(14).mean().values)
F = F.sort_values(["sym", "t"]).reset_index(drop=True)
XL, XS = arah(F, 1), arah(F, -1)
prev = F.groupby("sym").QSE.shift(1).values
def pemicu(amb):
    up = (F.QSE.values >= amb) & ~(prev >= amb) & (F.lari_naik.values <= 0.20)
    dn = (F.QSE.values <= -amb) & ~(prev <= -amb) & (F.lari_turun.values <= 0.20)
    return up, dn
def simulasi(idx_d):
    rows = []; terakhir = {}
    for r_, d in idx_d:
        s = F.sym.values[r_]; k = int(F.i.values[r_]) + 1; a, n = Cx.OFF[s]
        if k >= a + n - 2 or terakhir.get(s, -1) >= k:
            continue
        e = O_[k]; rk = F.rk.values[r_]
        t4, at4 = AT4[s]; q = np.searchsorted(t4, TS[k], "right") - 2; at = at4[max(q, 0)]
        if not (np.isfinite(at) and 0.003 * e <= rk <= 0.08 * e):
            continue
        r, hh, am = sim3(H_, L_, C_, k, min(240, a + n - k - 1), d, e, rk, at, 0.0, 3.0, 0.5, 0.2, 0.0, 0.5, 12, 30)
        terakhir[s] = k + hh; mh = TS[k] // 3600000
        rows.append((mh, mh + hh, mh + (am if am >= 0 else hh), s, d, r - Cx.BIAYA * e / rk, r_))
    ev = pd.DataFrame(rows, columns=["masuk", "keluar", "aman", "sym", "arah", "R", "baris"])
    ev["bulan"] = pd.to_datetime(ev.masuk.values * 3600000, unit="ms", utc=True).strftime("%Y-%m"); ev["uji"] = ev.masuk * 3600000 >= T_UJI0
    return ev
def ringkas(x):
    if not len(x):
        return "n    0"
    mg = max((x.masuk.max() - x.masuk.min()) / 168, 1); r = x.sort_values("keluar").R.values
    return f"n {len(x):5d} ({len(x) / mg:5.1f}/mgg) WR {np.mean(r > 0) * 100:4.1f}% exp {r.mean():+.3f}R tot {r.sum():+7.1f}R DD {dd(r):5.1f}R"
HAS = {}
for amb in (90, 95, 98, 99, 99.5):
    up, dn = pemicu(amb)
    idx = sorted([(r_, 1) for r_ in np.nonzero(up)[0]] + [(r_, -1) for r_ in np.nonzero(dn)[0]], key=lambda z: F.t.values[z[0]])
    ev = simulasi(idx); HAS[amb] = ev
    P(f"   ambang {amb:5.1f} tanpa kill-switch | latih {ringkas(ev[~ev.uji])} | uji {ringkas(ev[ev.uji])}")
# kill-switch: model rugi dari ciri sumbu dan volume, dilatih pada pemicu latih
P("   Kill-switch: model kedua (sumbu lawan, volume menyusut, badan candle, jarak dari EMA20) dilatih pada pemicu latih yang rugi.")
pilihan = []
for amb, ev in HAS.items():
    Xk = pd.DataFrame([(XL if d == 1 else XS).loc[r_, KILL].values for r_, d in zip(ev.baris, ev.arah)], columns=KILL).astype(float)
    Xk = Xk.fillna(Xk[~ev.uji.values].median())
    yk = (ev.R.values <= 0).astype(int); la = ~ev.uji.values
    if la.sum() < 200:
        continue
    mk_mu = Xk[la].mean(); mk_sd = Xk[la].std().replace(0, 1)
    mk = LogisticRegression(max_iter=300).fit(((Xk[la] - mk_mu) / mk_sd).values, yk[la])
    pr = mk.predict_proba(((Xk - mk_mu) / mk_sd).values)[:, 1]
    for qk in (None, 0.8, 0.6):
        if qk is None:
            keep = np.ones(len(ev), bool); nm = "tanpa kill"
        else:
            cut = np.quantile(pr[la], qk); keep = pr < cut; nm = f"tahan {int((1 - qk) * 100)}% paling mirip pola rugi"
        x = ev[keep]
        P(f"   ambang {amb:5.1f} {nm:34s} | latih {ringkas(x[~x.uji])} | uji {ringkas(x[x.uji])}")
        xl = x[~x.uji]; mg = max((xl.masuk.max() - xl.masuk.min()) / 168, 1) if len(xl) else 1
        if len(xl) >= 200:
            pilihan.append((xl.R.mean(), amb, nm, x, len(xl) / mg, dict(zip(KILL, mk.coef_[0]))))
best = max(pilihan, key=lambda z: z[0])
te = best[3][best[3].uji]
lulus = len(te) >= 100 and te.R.mean() >= 0.15 and np.mean(te.R > 0) >= 0.60
P(f"\n   >> dipilih di latih: ambang {best[1]} {best[2]} (latih exp {best[0]:+.3f}R, {best[4]:.1f}/mgg)")
P(f"   >> uji 2025-2026: {ringkas(te)} -> {'LULUS' if lulus else 'TIDAK LULUS'} (syarat exp >= +0.15R, WR >= 60%, n >= 100)")
P(f"   bobot kill-switch: " + ", ".join(f"{k_} {w:+.2f}" for k_, w in best[5].items()))
tm = te.groupby("bulan").R.sum()
P(f"   per bulan uji: " + " ".join(f"{b[2:]} {v:+.1f}" for b, v in tm.items()))
P(f"   per arah uji: " + ", ".join(f"{'LONG' if d == 1 else 'SHORT'} {ringkas(g)}" for d, g in te.groupby("arah")))
best[3].to_pickle(f"{SC}/qse_index_ev.pkl")
open("hasil_qse_index.txt", "w").write("\n".join(out))

"""Cari celah paling kokoh: kandidat harus positif di SETIAP tahun 2022 (Jun-Des), 2023, 2024, 2025.
Peringkat = expectancy tahun terburuk (bukan rata-rata, bukan tahun terbaik). 2026 tidak dipakai memilih: uji murni.
Lalu uji kantong pelengkap (slot sendiri maks 2, lot 0.5x) bersama v149 di 2026."""
import numpy as np, pandas as pd
SRC154 = open("run_v154.py").read()
src = open("run_v153.py").read().split('P("\\n== 2. ORDER FLOW')[0]
exec(src)
exec(SRC154[SRC154.index("NAMA = "):SRC154.index("SEMUA = []")])
exec(SRC154[SRC154.index("def ringkas"):SRC154.index("LATIH = ")])
exec(SRC154[SRC154.index("# ---------- v149 sebagai"):SRC154.index('P("\\n== 2. MESIN')])
exec(SRC154[SRC154.index("def kantong"):SRC154.index('for nm, x in (("squeeze N50')])
out.clear()
TV = porto_isi(pd.DataFrame(columns=evv.columns).assign(jenis="x", runner=0), "sepi", 1.0)
EV = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/v154_ev.pkl")
pf = lambda r: r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9)
TH = [2022, 2023, 2024, 2025]
def opsi(g):
    for var, gg in g.groupby("varian"):
        for fn, fm in (("semua", np.ones(len(gg), bool)), ("killzone", gg.kz.values), ("Top 50", gg.tier.values < 50),
                       ("luar Top 50", gg.tier.values >= 50), ("killzone + luar Top 50", gg.kz.values & (gg.tier.values >= 50))):
            yield f"{gg.mesin.iloc[0]} | {var} | {fn}", gg[fm]
P("== 1. KONSISTENSI PER TAHUN (pilih tanpa melihat 2026) ==")
P("   v149 pembanding per tahun: " + " ".join(f"{t}: exp {TV[TV.th == t].R.mean():+.3f}R PF {pf(TV[TV.th == t].R.values):.2f}" for t in (2023, 2024, 2025, 2026)))
K = []
for mesin, g in EV.groupby("mesin", sort=False):
    for nm, x in opsi(g):
        per = [x[x.th == t].R.values for t in TH]
        if min(len(p) for p in per) < 20:
            continue
        ex = [p.mean() for p in per]
        K.append(dict(nama=nm, mesin=mesin, terburuk=min(ex), ex=ex, pf=[pf(p) for p in per], x=x))
K = sorted(K, key=lambda z: -z["terburuk"])
P(f"   {len(K)} kandidat dengan >= 20 trade tiap tahun. Yang positif di keempat tahun: {sum(1 for k in K if k['terburuk'] > 0)}")
P("   15 teratas menurut tahun terburuk, lalu hasil murni 2026:")
for k in K[:15]:
    te = k["x"][k["x"].th == 2026]; r = te.R.values; mg = max((te.masuk.max() - te.masuk.min()) / 168, 1) if len(te) else 1
    P(f"   {k['nama']:58s} terburuk {k['terburuk']:+.3f}R | " + " ".join(f"{t % 100}:{e:+.2f}" for t, e in zip(TH, k["ex"])) +
      f" | 2026 n {len(r):3d} ({len(r) / mg:3.1f}/mgg) WR {np.mean(r > 0) * 100 if len(r) else 0:4.1f}% exp {r.mean() if len(r) else 0:+.3f}R PF {pf(r):.2f}")
# satu terbaik per mesin, hanya yang positif di semua tahun
TOP = {}
for k in K:
    if k["terburuk"] > 0 and k["mesin"] not in TOP:
        TOP[k["mesin"]] = k
P("\n== 2. KANTONG PELENGKAP DI 2026 (slot sendiri maks 2, lot 0.5x, tidak memakan slot v149) ==")
dasar = TV[TV.th == 2026]; tm0 = dasar.groupby("bulan").R.sum()
P(f"   v149 saja 2026: n {len(dasar)} exp {dasar.R.mean():+.3f}R PF {pf(dasar.R.values):.2f} tot {dasar.R.sum():+.1f}R DD {dd(dasar.sort_values('keluar').R.values):.1f}R bulan rugi {int((tm0 < 0).sum())}/{len(tm0)}")
def uji_kantong(nm, x):
    Kt = kantong(x[x.th >= 2025]); Kt = Kt[Kt.th == 2026]
    G = pd.concat([dasar, Kt]); tm = G.groupby("bulan").R.sum().reindex(tm0.index, fill_value=0)
    mg = max((G.masuk.max() - G.masuk.min()) / 168, 1)
    P(f"   + {nm:56s} kantong n {len(Kt):3d} exp {Kt.R.mean() / 0.5 if len(Kt) else 0:+.3f}R(1x) | gabungan {len(G) / mg:4.1f}/mgg "
      f"PF {pf(G.R.values):.2f} tot {G.R.sum():+6.1f}R ({G.R.sum() - dasar.R.sum():+.1f}R) DD {dd(G.sort_values('keluar').R.values):.1f}R "
      f"bulan rugi {int((tm < 0).sum())}/{len(tm)}, hijau jadi merah {int(((tm0 >= 0) & (tm < 0)).sum())}")
for m_, k in TOP.items():
    uji_kantong(k["nama"], k["x"])
if len(TOP) > 1:
    uji_kantong("gabungan semua mesin terpilih", pd.concat([k["x"] for k in TOP.values()]))
open("hasil_bukti.txt", "w").write("\n".join(out))

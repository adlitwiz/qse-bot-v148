"""v157 (permintaan 4 Nov 22:22): mesin kombinasi otomatis (grid) + inversi + whitelist koin/jam + jalur kilat 15m.
10 pemicu x arah x inversi x 5 saringan x 5 aturan keluar cepat = 1000 kombinasi per kerangka waktu.
1J: 184 koin (data taker buy asli Binance). 15m: 20 koin likuid (dari candle 5m Binance).
Aturan pilih ditetapkan SEBELUM melihat 2025-2026: latih 2023-2024 (15m: 2024), n >= 150, harapan >= +0.08R, PF >= 1.15,
dua tahun latih sama-sama positif. Lalu kombinasi terpilih dinilai di 2025-2026 apa adanya.
Satu koin satu posisi per kombinasi (tidak tumpang tindih). Biaya 0.15% harga per trade. Entry di open candle berikut.
SL dan TP di candle yang sama = SL."""
import os, sys, json, numpy as np, pandas as pd
from numba import njit
SC = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad"
K10 = f"{SC}/k10"; TK = f"{SC}/taker"; D5 = f"{SC}/v3/d5"; OUT = f"{SC}/v157"
BIAYA = 0.0015
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0

# ---------------- data ----------------
def data_1j():
    Z = np.load(f"{K10}/h1.npz"); OFF = json.load(open(f"{K10}/off.json"))
    fr = {}
    for f in sorted(os.listdir(TK)):
        s = f[:-4]
        if s not in OFF:
            continue
        a, n = OFF[s]; t = Z["T"][a:a + n]; z = np.load(f"{TK}/{f}")
        q = np.searchsorted(z["t"], t); q = np.clip(q, 0, len(z["t"]) - 1); hit = z["t"][q] == t
        v = np.where(hit, z["v"][q], np.nan); tb = np.where(hit, z["tb"][q], np.nan)
        m = ~np.isnan(v)
        if m.sum() < 3000:
            continue
        fr[s] = pd.DataFrame(dict(t=t[m], o=Z["O"][a:a + n][m], h=Z["H"][a:a + n][m], l=Z["L"][a:a + n][m], c=Z["C"][a:a + n][m], v=v[m], tb=tb[m]))
    return fr

def data_15m():
    fr = {}
    for f in sorted(os.listdir(D5)):
        z = np.load(f"{D5}/{f}")
        d = pd.DataFrame(dict(t=z["t"], o=z["o"], h=z["h"], l=z["l"], c=z["c"], v=z["v"]))
        g = d.groupby(d.t // 900000 * 900000)
        x = pd.DataFrame(dict(o=g.o.first(), h=g.h.max(), l=g.l.min(), c=g.c.last(), v=g.v.sum())).reset_index().rename(columns={"t": "t"})
        x["tb"] = np.nan
        fr[f[:-4]] = x
    return fr

# ---------------- fitur ----------------
@njit(cache=True)
def fvg_isi(o, h, l, c, arah):
    """1 jika candle ini masuk ke FVG searah (belum tertutup, umur <= 20) lalu close searah keluar dari gap."""
    n = len(c); res = np.zeros(n, np.bool_)
    top = np.nan; bot = np.nan; umur = 999
    for i in range(2, n):
        if arah == 1:
            if not np.isnan(bot) and umur <= 20:
                if l[i] < bot:
                    bot = np.nan
                elif l[i] <= top and c[i] > top and c[i] > o[i]:
                    res[i] = True; bot = np.nan
            if l[i] > h[i - 2]:
                top = l[i]; bot = h[i - 2]; umur = 0
        else:
            if not np.isnan(bot) and umur <= 20:
                if h[i] > top:
                    bot = np.nan
                elif h[i] >= bot and c[i] < bot and c[i] < o[i]:
                    res[i] = True; bot = np.nan
            if h[i] < l[i - 2]:
                top = l[i - 2]; bot = h[i]; umur = 0
        umur += 1
    return res

def fitur(d):
    o, h, l, c, v = (d[k].values for k in "ohlcv")
    pc = np.r_[c[0], c[:-1]]
    tr_ = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    F = {}
    F["atr"] = pd.Series(tr_).rolling(14).mean().values
    e = lambda n: pd.Series(c).ewm(span=n, adjust=False).mean().values
    F["e20"], F["e50"], F["e200"] = e(20), e(50), e(200)
    dc = np.diff(c, prepend=c[0]); up = pd.Series(np.maximum(dc, 0)).ewm(alpha=1 / 14, adjust=False).mean().values
    dn = pd.Series(np.maximum(-dc, 0)).ewm(alpha=1 / 14, adjust=False).mean().values
    F["rsi"] = 100 - 100 / (1 + up / np.maximum(dn, 1e-12))
    F["vr"] = v / np.maximum(pd.Series(v).shift(1).rolling(24).mean().values, 1e-12)
    F["tr"] = d.tb.values / np.maximum(v, 1e-12)
    m20 = pd.Series(c).rolling(20).mean().values; s20 = pd.Series(c).rolling(20).std().values
    F["z"] = (c - m20) / np.maximum(s20, 1e-12)
    F["hh"] = pd.Series(h).shift(1).rolling(20).max().values; F["ll"] = pd.Series(l).shift(1).rolling(20).min().values
    bbw = pd.Series(4 * s20 / m20)
    F["sqz"] = (bbw.shift(1) <= bbw.shift(1).rolling(120).quantile(0.1)).values
    F["fvgL"] = fvg_isi(o, h, l, c, 1); F["fvgS"] = fvg_isi(o, h, l, c, -1)
    F["mom3"] = (c - np.r_[[np.nan] * 3, c[:-3]]) / F["atr"]
    F["pos"] = (c - l) / np.maximum(h - l, 1e-12)
    return F

PEMICU = ["BREAK", "VOLUME", "EMA", "RSI", "ZSCORE", "SWEEP", "FVG", "SQUEEZE", "TAKER", "IMPULS"]
SARING = ["-", "TREN", "BTC_AKTIF", "PASAR_RAMAI", "TAKER_SEARAH"]

def pemicu(F, d, o, h, l, c, p):
    L = d == 1
    if p == "BREAK":   return c > F["hh"] if L else c < F["ll"]
    if p == "VOLUME":  return (F["vr"] >= 3) & ((c > o) & (F["pos"] >= 0.7) if L else (c < o) & (F["pos"] <= 0.3))
    if p == "EMA":     return (F["e20"] > F["e50"]) & (l <= F["e20"]) & (c > F["e20"]) & (c > o) if L else (F["e20"] < F["e50"]) & (h >= F["e20"]) & (c < F["e20"]) & (c < o)
    if p == "RSI":     r1 = np.r_[50, F["rsi"][:-1]]; return (r1 < 30) & (F["rsi"] >= 30) if L else (r1 > 70) & (F["rsi"] <= 70)
    if p == "ZSCORE":  return F["z"] <= -2 if L else F["z"] >= 2
    if p == "SWEEP":   return (l < F["ll"]) & (c > F["ll"]) if L else (h > F["hh"]) & (c < F["hh"])
    if p == "FVG":     return F["fvgL"] if L else F["fvgS"]
    if p == "SQUEEZE": return F["sqz"] & (c > F["hh"] if L else c < F["ll"])
    if p == "TAKER":   return (F["vr"] >= 2) & ((F["tr"] >= 0.6) & (c > o) if L else (F["tr"] <= 0.4) & (c < o))
    if p == "IMPULS":  return F["mom3"] >= 3 if L else F["mom3"] <= -3

def saring(F, d, s, btc, ramai):
    if s == "-":            return np.ones(len(F["atr"]), bool)
    if s == "TREN":         return F["e50"] > F["e200"] if d == 1 else F["e50"] < F["e200"]
    if s == "BTC_AKTIF":    return btc * d >= 2
    if s == "PASAR_RAMAI":  return ramai >= 1.5
    if s == "TAKER_SEARAH": return F["tr"] >= 0.55 if d == 1 else F["tr"] <= 0.45

@njit(cache=True)
def sim(O, H, L, C, ev, d, risk, ujung, tp, mx):
    """ev global index candle sinyal (urut). Masuk open candle berikut. Tidak tumpang tindih per koin. Keluar: SL, TP, atau close candle ke-mx."""
    R = np.full(len(ev), np.nan); B = np.full(len(ev), np.nan); bebas = -1
    for q in range(len(ev)):
        i = ev[q]
        if i + 1 >= ujung[i] or i < bebas:
            continue
        e = O[i + 1]; rk = risk[q]
        if not (rk >= 0.004 * e) or not (rk <= 0.1 * e):
            continue
        sl = e - d * rk; t = e + d * tp * rk; r = np.nan; j = i + 1
        last = min(i + mx, ujung[i] - 1)
        while j <= last:
            if (d == 1 and L[j] <= sl) or (d == -1 and H[j] >= sl):
                r = -1.0; break
            if (d == 1 and H[j] >= t) or (d == -1 and L[j] <= t):
                r = tp; break
            j += 1
        if np.isnan(r):
            j = last; r = d * (C[j] - e) / rk
        R[q] = r - BIAYA * e / rk; B[q] = BIAYA * e / rk; bebas = j
    return R, B

def siapkan(fr, btc_sym="BTCUSDT"):
    syms = list(fr); FF = {s: fitur(fr[s]) for s in syms}
    b = fr[btc_sym]; bF = FF[btc_sym]
    bmom = pd.Series((b.c.values - np.r_[[np.nan] * 4, b.c.values[:-4]]) / bF["atr"], index=b.t.values)
    allvr = pd.concat([pd.Series(np.clip(FF[s]["vr"], 0, 20), index=fr[s].t.values) for s in syms], axis=1)
    ramai = allvr.median(axis=1)
    G = dict(O=[], H=[], L=[], C=[], T=[], U=[], S=[])
    pos = 0; idx = {}
    for s in syms:
        d = fr[s]; n = len(d); idx[s] = pos
        for k, kk in (("O", "o"), ("H", "h"), ("L", "l"), ("C", "c"), ("T", "t")):
            G[k].append(d[kk].values)
        G["U"].append(np.full(n, pos + n)); G["S"].append(np.full(n, s, object)); pos += n
    G = {k: np.concatenate(v) for k, v in G.items()}
    BT = bmom.reindex(G["T"]).values; RM = ramai.reindex(G["T"]).values
    return syms, FF, G, idx, np.nan_to_num(BT), np.nan_to_num(RM)

def grid(fr, KELUAR, lat_th, uji_dari):
    syms, FF, G, idx, BT, RM = siapkan(fr)
    th = pd.to_datetime(G["T"], unit="ms", utc=True).year.values
    jam = pd.to_datetime(G["T"], unit="ms", utc=True).hour.values
    ATR = np.concatenate([FF[s]["atr"] for s in syms])
    hasil = []; EV = {}
    for p in PEMICU:
        for dp in (1, -1):
            trig = np.concatenate([pemicu(FF[s], dp, *(fr[s][k].values for k in "ohlc"), p) for s in syms])
            for inv in (0, 1):
                d = -dp if inv else dp
                for sf in SARING:
                    fl = np.concatenate([saring(FF[s], d, sf, BT[idx[s]:idx[s] + len(fr[s])], RM[idx[s]:idx[s] + len(fr[s])]) for s in syms])
                    ev = np.nonzero(trig & fl & (th >= min(lat_th)) & np.isfinite(ATR))[0]
                    for ek, (tp, slm, mx) in KELUAR.items():
                        R, B = sim(G["O"], G["H"], G["L"], G["C"], ev, d, slm * ATR[ev], G["U"], tp, mx)
                        ok_ = ~np.isnan(R); e2 = ev[ok_]; R2 = R[ok_]; B2 = B[ok_]
                        nm = f"{p}{'L' if dp == 1 else 'S'}{'-INV' if inv else ''} {sf} {ek}"
                        t_ = th[e2]; la = np.isin(t_, lat_th); te = t_ >= uji_dari
                        row = dict(nm=nm, p=p, dp=dp, inv=inv, d=d, sf=sf, ek=ek, n_l=la.sum(), ex_l=R2[la].mean() if la.any() else 0,
                                   pf_l=pf(R2[la]), n_t=te.sum(), ex_t=R2[te].mean() if te.any() else 0, pf_t=pf(R2[te]), wr_t=(R2[te] > 0).mean() if te.any() else 0,
                                   tot_t=R2[te].sum(), biaya=B2.mean() if len(B2) else 0,
                                   ex_l_mk=(R2[la] + B2[la] * 0.5).mean() if la.any() else 0, ex_t_mk=(R2[te] + B2[te] * 0.5).mean() if te.any() else 0)
                        for y in lat_th:
                            row[f"ex{y}"] = R2[t_ == y].mean() if (t_ == y).any() else -9
                        hasil.append(row); EV[nm] = (e2, R2)
    return pd.DataFrame(hasil), EV, G, th, jam

def laporan(nama, H, EV, G, th, jam, lat_th, uji_dari, minggu_uji):
    P(f"\n== {nama}: {len(H)} kombinasi ==")
    sel = (H.n_l >= 150) & (H.ex_l >= 0.08) & (H.pf_l >= 1.15)
    for y in lat_th:
        sel &= H[f"ex{y}"] > 0
    S_ = H[sel].sort_values("ex_l", ascending=False)
    P(f"lolos aturan latih: {len(S_)}")
    for _, r in S_.head(40).iterrows():
        P(f"   {r.nm:40s} latih n {r.n_l:5d} ex {r.ex_l:+.3f} PF {r.pf_l:.2f} | uji n {r.n_t:5d} ({r.n_t / minggu_uji:4.1f}/mgg) WR {r.wr_t * 100:4.1f}% ex {r.ex_t:+.3f} PF {r.pf_t:.2f} tot {r.tot_t:+6.1f}R")
    if len(S_):
        lulus = S_[(S_.ex_t >= 0.08) & (S_.n_t >= 100)]
        P(f"lolos latih DAN uji (ex >= +0.08R, n >= 100): {len(lulus)} dari {len(S_)}. Rata harapan uji semua yang lolos latih: {S_.ex_t.mean():+.3f}R")
    # pembanding jujur: 40 kombinasi terbaik kalau dipilih dari data UJI (dilarang, hanya untuk menunjukkan jebakan)
    P("rata harapan uji kombinasi acak (semua 1000): " f"{H[H.n_t >= 100].ex_t.mean():+.3f}R, rata biaya per trade {H.biaya.mean():.3f}R")
    m = (H.n_l >= 150) & (H.ex_l_mk >= 0.08) & (H.pf_l >= 1.0)
    for y in lat_th:
        m &= H[f"ex{y}"] > -0.05
    M = H[m].sort_values("ex_l_mk", ascending=False)
    P(f"BIAYA LIMIT (separuh biaya, masuk dan TP pakai limit order): lolos latih {len(M)}, lolos uji juga {int(((M.ex_t_mk >= 0.08) & (M.n_t >= 100)).sum())}")
    for _, r in M.head(15).iterrows():
        P(f"   {r.nm:40s} latih ex {r.ex_l_mk:+.3f} | uji n {r.n_t:5d} ex {r.ex_t_mk:+.3f}")
    return S_

def whitelist(nama, H, EV, G, th, jam, lat_th, uji_dari):
    """Hafalan sampel: per kombinasi (n latih >= 300), simpan koin dan blok jam 4 jam yang harapan latihnya >= +0.30R (n >= 10). Nilai di uji."""
    P(f"\n== {nama}: WHITELIST koin dan jam dipelajari di latih ==")
    rows = []
    for _, r in H[H.n_l >= 300].iterrows():
        e2, R2 = EV[r.nm]; t_ = th[e2]; la = np.isin(t_, lat_th); te = t_ >= uji_dari
        sy = G["S"][e2]; bj = jam[e2] // 4
        df = pd.DataFrame(dict(sy=sy, bj=bj, R=R2))
        gk = df[la].groupby("sy").R.agg(["count", "mean"]); wk = set(gk[(gk["count"] >= 10) & (gk["mean"] >= 0.30)].index)
        gj = df[la].groupby("bj").R.agg(["count", "mean"]); wj = set(gj[(gj["count"] >= 30) & (gj["mean"] >= 0.05)].index)
        mk = df.sy.isin(wk).values & df.bj.isin(wj).values
        a, b = R2[la & mk], R2[te & mk]
        if len(a) >= 50:
            rows.append((r.nm, len(wk), len(a), a.mean(), len(b), b.mean() if len(b) else 0, pf(b)))
    W = pd.DataFrame(rows, columns=["nm", "koin", "n_l", "ex_l", "n_t", "ex_t", "pf_t"])
    if len(W):
        P(f"kombinasi diuji: {len(W)}. Latih rata {W.ex_l.mean():+.3f}R (dibuat dari sampel menang). Uji rata {W.ex_t.mean():+.3f}R. "
          f"Uji positif >= +0.08R dan n >= 100: {int(((W.ex_t >= 0.08) & (W.n_t >= 100)).sum())}")
        for _, r in W.sort_values("ex_l", ascending=False).head(15).iterrows():
            P(f"   {r.nm:40s} koin {r.koin:3d} latih n {r.n_l:4d} ex {r.ex_l:+.3f} | uji n {r.n_t:4d} ex {r.ex_t:+.3f} PF {r.pf_t:.2f}")
    return W

if __name__ == "__main__":
    tf = sys.argv[1] if len(sys.argv) > 1 else "1j"
    if tf == "1j":
        fr = data_1j(); KEL = {"E1 0.5R/3j": (0.5, 1.0, 3), "E2 0.8R/4j": (0.8, 1.0, 4), "E3 1R/8j": (1.0, 1.5, 8), "E4 1.5R/12j": (1.5, 1.5, 12), "E5 2R/24j": (2.0, 2.0, 24)}
        LAT = (2023, 2024); UJI = 2025; MG = 95
    else:
        fr = data_15m(); KEL = {"E1 0.4R/1j": (0.4, 1.0, 4), "E2 0.6R/2j": (0.6, 1.0, 8), "E3 0.8R/3j": (0.8, 1.0, 12), "E4 1R/4j": (1.0, 1.5, 16), "E5 1.5R/6j": (1.5, 1.5, 24)}
        LAT = (2024,); UJI = 2025; MG = 95
        SARING[4] = "PASAR_RAMAI"  # tanpa data taker 15m: saringan taker diganti duplikat ramai (dibuang di bawah)
    P(f"TF {tf}: {len(fr)} koin")
    H, EV, G, th, jam = grid(fr, KEL, LAT, UJI)
    if tf != "1j":
        H = H.drop_duplicates("nm")
    H.to_pickle(f"{OUT}/grid_{tf}.pkl")
    S_ = laporan(f"GRID {tf}", H, EV, G, th, jam, LAT, UJI, MG)
    # inversi: pasangan kombinasi rugi di latih lalu dibalik
    inv = H[(H.inv == 1)]; asal = H[H.inv == 0].set_index(["p", "dp", "sf", "ek"])
    P(f"\n== {tf}: INVERSI (anti-sinyal) ==")
    k = inv.join(asal[["ex_l", "ex_t"]], on=["p", "dp", "sf", "ek"], rsuffix="_asal")
    kk = k[(k.ex_l_asal <= -0.15) & (k.n_l >= 150)]
    P(f"kombinasi asal rugi <= -0.15R di latih: {len(kk)}. Setelah dibalik: latih rata {kk.ex_l.mean():+.3f}R, uji rata {kk.ex_t.mean():+.3f}R, "
      f"uji >= +0.08R: {int((kk.ex_t >= 0.08).sum())}")
    W = whitelist(f"{tf}", H, EV, G, th, jam, LAT, UJI)
    import pickle
    pickle.dump(dict(S=S_, W=W), open(f"{OUT}/pilih_{tf}.pkl", "wb"))
    open(f"hasil_v157_{tf}.txt", "w").write("\n".join(out))

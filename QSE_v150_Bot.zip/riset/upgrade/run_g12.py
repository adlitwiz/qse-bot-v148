import numpy as np
import var_lib as V
import core as Cx
out = []
def P(s=""):
    print(s, flush=True); out.append(s)

base = V.run()
BM = {pop: V.port(base, pop)[0] for pop in V.POP}
P("== DASAR (aturan final: TP 20% di +0.5R lalu SL ke entry, jam 8 SL -0.5R, 36 jam, jeda 3 rugi/24 jam)")
for pop in V.POP:
    P(V.fmt(pop, BM[pop]))
P()
P("== GRUP 1. Letak SL setelah TP 20% kena (R dari entry; 0 = entry)")
for sa in (0.0, 0.1, -0.25, -0.5):
    res = V.run(sl_aft=sa)
    for pop in V.PRIMER:
        m, _ = V.port(res, pop)
        d = V.pasangan(res, base, pop)
        P(V.fmt(f"SL setelah TP20 = {sa:+.2f}R [{pop}]", m, BM[pop], f" | per sinyal dR {d[0]:+.4f} t {d[1]:+.1f} ({d[2]:+.4f}/{d[3]:+.4f}) lolosP {V.lolos(m, BM[pop], 'P')} lolosW {V.lolos(m, BM[pop], 'W')}"))
P()
P("== GRUP 2. Porsi dan level TP sebagian")
for lv in (0.3, 0.4, 0.5, 0.75):
    for por in (0.10, 0.20, 0.30, 0.50):
        res = V.run(tps_lv=lv, tps_por=por)
        for pop in V.PRIMER:
            m, _ = V.port(res, pop)
            d = V.pasangan(res, base, pop)
            P(V.fmt(f"TP {por * 100:.0f}% di +{lv}R [{pop}]", m, BM[pop], f" | dR {d[0]:+.4f} t {d[1]:+.1f} lolosP {V.lolos(m, BM[pop], 'P')} lolosW {V.lolos(m, BM[pop], 'W')}"))
open(f"{Cx.SC}/hasil_g12.txt", "w").write("\n".join(out))

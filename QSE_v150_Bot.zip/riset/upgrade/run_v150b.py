"""Uji 6 perubahan permintaan user 3 Nov 2026 (11:04 dan 11:06). Data Binance 383 koin 1J, universe 150 likuid, satu orang.
Semua keputusan pakai data sebelum sinyal. Ambang dipilih di 2023-2024, dinilai di 2025-2026. Biaya 0.15% harga.
1. Rem 7 hari jadi mode: saat rem, hanya NILAI 10 (skor 90) dan/atau setengah risiko, bukan tahan total.
   Gerbang profil dilonggarkan (gabungan semua jalur arah sama, min 5). LONG akhir pekan boleh kalau volume 24 jam >= 2x rata 30 hari.
2. TPawal 40-50% di +0.5R, SL ke -0.25R, SL ke entry di +0.8R. Posisi aman tidak dihitung dalam batas 4 (runner).
3. Sapuan likuiditas 1 dan 2 candle 4J + volume >= 2x, di support kuat (disentuh >= 2x) atau divergensi RSI.
   Derivatif BTC (Binance Futures): BTC turun + OI turun + funding sangat minus -> SHORT ditahan (cermin untuk LONG).
4. Masuk koreksi: tunggu koreksi di 1J, Conditional Stop di atas high candle pantulan, SL di ujung ekor pantulan, TP dihitung ulang.
5. Laporan: per bulan 2025-2026, sinyal per minggu, WR, PF, DD, v149 lawan gabungan perubahan yang lolos."""
import os, numpy as np, pandas as pd
from numba import njit
src = open("run_rapor2.py").read().split("\nlama = run()")[0]
ns = {"__name__": "v150"}
exec(src, ns)
S, V, thn, otak, uji, ok, run, jalankan, profil = (ns[k] for k in ("S", "V", "thn", "otak", "uji", "ok", "run", "jalankan", "profil"))
import core as Cx
DERIV = "/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/deriv"
CSV = os.path.join(Cx.SC, "data")
out = []
def P(s=""):
    print(s, flush=True); out.append(str(s))
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9) if len(x) else 0.0
def dd(r):
    eq = np.cumsum(r); return float((np.maximum.accumulate(eq) - eq).max()) if len(r) else 0.0
H_, L_, C_, O_, TS = Cx.H, Cx.L, Cx.C, Cx.O, Cx.TS
baru = run(jk=12, jmode=4, jstop=30)
izin = profil(baru)
ar = S.arah.values; jl = S.jalur.values; masuk = S.masuk_h.values; k0 = S.k0.values
dow = pd.to_datetime(S["T"].values, unit="ms", utc=True).dayofweek.values
wkL = (ar == 1) & (dow >= 5)
bln = pd.to_datetime(S["T"].values, unit="ms", utc=True).strftime("%Y-%m").values
dasar_mask = ok & ~ns["pump10"] & otak & uji & (S["rank"].values <= 150) & V.POP["SEIMBANG"]
m8 = dasar_mask & izin & ~wkL                         # v149 seperti bot live (akhir pekan LONG ditahan)
lat = thn <= 2024; tes = thn >= 2025
minggu = lambda T: max((T[:, 0].max() - T[:, 0].min()) / 168, 1) if len(T) else 1
def nilai(nm, T, ringkas=True):
    r = T[:, 2]; i = T[:, 3].astype(int); o_ = np.argsort(T[:, 1], kind="stable"); b = bln[i]; th_ = thn[i]
    pm = pd.Series(r).groupby(b).apply(lambda x: pf(x.values)); tm = pd.Series(r).groupby(b).sum()
    t2 = T[th_ >= 2025]; r2 = t2[:, 2]
    P(f"   {nm:56s} n {len(r):5d} {len(r) / minggu(T):4.1f}/mgg WR {np.mean(r > 0) * 100:4.1f}% PF {pf(r):.2f} tot {r.sum():+5.0f}R DD {dd(r[o_]):3.0f}R | "
      f"PF<1 {int((pm < 1).sum()):2d}/{len(pm)} terburuk {tm.min():+5.1f} | 23-24 PF {pf(r[th_ <= 2024]):.2f} | 25-26 n/mgg {len(r2) / minggu(t2):4.1f} "
      f"WR {np.mean(r2 > 0) * 100 if len(r2) else 0:4.1f}% PF {pf(r2):.2f} DD {dd(r2[np.argsort(t2[:, 1], kind='stable')]):3.0f}R")
    return T
# rem 7 hari dari trade kertas semua sinyal m8 yang sudah selesai
def rem_flag(res, pilih, batas=-3.0):
    R = res["R"]; kel = masuk + res["hrs"]; idx = np.nonzero(pilih)[0]
    o = idx[np.argsort(kel[idx], kind="stable")]; kk = kel[o]; cs = np.r_[0, np.cumsum(R[o])]
    f = np.zeros(len(S), bool)
    j = np.searchsorted(kk, masuk[idx], side="right"); j0 = np.searchsorted(kk, masuk[idx] - 168, side="right")
    f[idx] = (cs[j] - cs[j0]) < batas
    return f
def skala(T, mask_half):
    T = T.copy(); h = mask_half[T[:, 3].astype(int)]; T[h, 2] *= 0.5; return T
P("== DASAR ==")
rem = rem_flag(baru, m8)
B0 = nilai("v149 tanpa rem 7 hari", jalankan(baru, m8, 4, 0))
B1 = nilai("v149 + rem 7 hari TOTAL (terpasang)", jalankan(baru, m8 & ~rem, 4, 0))

P("\n== 3a. DERIVATIF BTC (Binance Futures): turun + OI turun + funding minus -> SHORT ditahan, cermin LONG ==")
R = baru["R"]
F = pd.read_csv(f"{DERIV}/btc_funding.csv"); F = F.sort_values("calc_time")
M = pd.read_csv(f"{DERIV}/btc_metrics.csv", usecols=["create_time", "sum_open_interest"])
M["t"] = pd.to_datetime(M.create_time, utc=True).astype("datetime64[ms, UTC]").astype("int64"); M = M.sort_values("t")
b0, bl = Cx.OFF["BTCUSDT"]; bT = TS[b0:b0 + bl]; bC = C_[b0:b0 + bl]
t_sig = TS[k0]
jb = np.searchsorted(bT, t_sig) - 1
btc24 = np.where(jb >= 24, bC[np.maximum(jb, 0)] / bC[np.maximum(jb - 24, 0)] - 1, np.nan) * 100
mo = np.searchsorted(M.t.values, t_sig) - 1; mo2 = np.searchsorted(M.t.values, t_sig - 86400000) - 1
oi = M.sum_open_interest.values
oi24 = np.where((mo >= 0) & (mo2 >= 0), oi[np.maximum(mo, 0)] / oi[np.maximum(mo2, 0)] - 1, np.nan) * 100
fi = np.searchsorted(F.calc_time.values, t_sig) - 1
fund = np.where(fi >= 0, F.last_funding_rate.values[np.maximum(fi, 0)], np.nan) * 100
ada = ~np.isnan(oi24) & ~np.isnan(fund)
P(f"   sinyal m8 dengan data derivatif: {int((m8 & ada).sum())} dari {int(m8.sum())}")
qlo = np.nanquantile(fund[m8 & lat & ada], [0.1, 0.2, 0.3]); qhi = np.nanquantile(fund[m8 & lat & ada], [0.7, 0.8, 0.9])
cal = []
for q in list(qlo) + [0.0]:
    tahanS = (ar == -1) & (btc24 < 0) & (oi24 < 0) & (fund <= q)
    a_ = R[m8 & lat & tahanS]; b_ = R[m8 & tes & tahanS]
    P(f"   SHORT saat BTC turun, OI turun, funding <= {q:.4f}%: latih n {len(a_)} PF {pf(a_):.2f} | uji n {len(b_)} PF {pf(b_):.2f}")
    cal.append((pf(a_), q, tahanS, "SHORT"))
for q in list(qhi) + [0.01]:
    tahanL = (ar == 1) & (btc24 > 0) & (oi24 < 0) & (fund >= q)
    a_ = R[m8 & lat & tahanL]; b_ = R[m8 & tes & tahanL]
    P(f"   LONG saat BTC naik, OI turun, funding >= {q:.4f}%: latih n {len(a_)} PF {pf(a_):.2f} | uji n {len(b_)} PF {pf(b_):.2f}")
    cal.append((pf(R[m8 & lat & tahanL]), q, tahanL, "LONG"))
cal = [c for c in cal if (m8 & lat & c[2]).sum() >= 30]
if cal:
    worst = min(cal, key=lambda z: z[0])
    P(f"   dipilih di latih (PF terendah, n>=30): {worst[3]} ambang {worst[1]:.4f}%, PF latih {worst[0]:.2f}")
    nilai(f"tahan {worst[3]} saat derivatif BTC berlawanan + rem", jalankan(baru, m8 & ~rem & ~worst[2], 4, 0))


P("\n== 5. PERBANDINGAN PER BULAN 2025-2026: v149 terpasang (rem total) lawan v149 + rem jadi mode (NILAI 10 saja, setengah risiko) ==")
n10 = S.nilai_n.values >= 8
TA = jalankan(baru, m8 & ~rem, 4, 0)
TB = skala(jalankan(baru, m8 & (~rem | n10), 4, 0), rem)
def tab(T):
    i = T[:, 3].astype(int); r = T[:, 2]; b = bln[i]; rows = []
    for m in sorted(set(b)):
        k = b == m; x = r[k]; ox = np.argsort(T[k, 1], kind="stable")
        rows.append((m, len(x), len(x) / 4.33, np.mean(x > 0) * 100, pf(x), x.sum(), dd(x[ox])))
    return pd.DataFrame(rows, columns=["bulan", "n", "per_mgg", "WR", "PF", "R", "DD"]).set_index("bulan")
G = tab(TA).join(tab(TB), lsuffix="_v149", rsuffix="_baru", how="outer").fillna(0)
G = G[G.index >= "2025-01"]
pd.set_option("display.width", 250)
P(G.round(2).to_string())
for c in ("v149", "baru"):
    P(f"   {c}: rata {G['per_mgg_' + c].mean():.1f} sinyal/minggu, bulan rugi {int((G['R_' + c] < 0).sum())}/{len(G)}, terburuk {G['R_' + c].min():+.1f}R, "
      f"total {G['R_' + c].sum():+.1f}R, bulan PF>=1.8: {int((G['PF_' + c] >= 1.8).sum())}")
open("hasil_v150b.txt", "w").write("\n".join(out))

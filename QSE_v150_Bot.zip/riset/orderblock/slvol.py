import sys, warnings, pandas as pd, numpy as np
warnings.filterwarnings("ignore"); sys.path.insert(0, ".")
import sim, smc_core as K
T = pd.read_pickle("base.pkl"); Y = pd.concat(T.values()); Y = Y[Y.R < -0.9]
V = {}; rows = []
for s, g in Y.groupby("sym"):
    df = pd.read_csv(f"../data/{s}_240.csv"); o, h, l, c, v = (df[k].values for k in ("open", "high", "low", "close", "volume"))
    d = K.cdv_delta(o, h, l, c, v)
    for _, t in g.iterrows():
        j = int(t.xb); f = int(t.fb); a = t.arah
        if j + 13 >= len(c) or j < 25: continue
        rv = v[j] / v[j - 20:j].mean()
        fl = d[f:j + 1].sum() / max(v[f:j + 1].sum(), 1e-12) * a          # aliran selama posisi, + = searah posisi
        e = c[f - 1] if False else (t.top if a == 1 else t.bot)
        ent = o[f]
        back = (h[j + 1:j + 13].max() >= ent) if a == 1 else (l[j + 1:j + 13].min() <= ent)
        # lanjut jauh: harga bergerak 1R lagi melawan
        risk = abs(ent - (t.bot - 0.3 * t.atr if a == 1 else t.top + 0.3 * t.atr))
        far = (l[j + 1:j + 13].min() <= ent - 2 * risk) if a == 1 else (h[j + 1:j + 13].max() >= ent + 2 * risk)
        wick = ((min(o[j], c[j]) - l[j]) if a == 1 else (h[j] - max(o[j], c[j]))) / max(h[j] - l[j], 1e-12)
        rows.append(dict(rv=rv, fl=fl, back=back, far=far, wick=wick, closed_beyond=(c[j] < t.bot - 0.3 * t.atr) if a == 1 else (c[j] > t.top + 0.3 * t.atr)))
R = pd.DataFrame(rows); print(len(R), "rata balik ke entry 12 candle:", R.back.mean().round(3), "lanjut 1R lagi:", R.far.mean().round(3))
R["vk"] = pd.cut(R.rv, [0, 1, 2, 99], labels=["vol<1x", "1-2x", ">2x"])
print(R.groupby("vk")[["back", "far"]].mean().round(3), R.vk.value_counts().to_dict())
R["kel"] = np.where(R.closed_beyond, "tutup tembus", "cuma sumbu")
print(R.groupby(["kel", "vk"])[["back", "far"]].agg(["mean", "size"]).round(3))
R["fk"] = pd.cut(R.fl, [-2, -0.15, 0.15, 2], labels=["lawan", "netral", "searah"])
print(R.groupby(["fk","kel"])[["back", "far"]].agg(["mean","size"]).round(3))

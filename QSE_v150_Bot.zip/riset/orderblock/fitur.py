import pandas as pd, numpy as np, os, warnings; warnings.filterwarnings("ignore")
R=pd.read_pickle("cb3.pkl")
def ema(x,n): return pd.Series(x).ewm(span=n,adjust=False).mean().values
def atr(h,l,c,n=14):
    tr=np.maximum(h[1:]-l[1:],np.maximum(abs(h[1:]-c[:-1]),abs(l[1:]-c[:-1]))); tr=np.r_[h[0]-l[0],tr]
    return pd.Series(tr).ewm(alpha=1/n,adjust=False).mean().values
def adx(h,l,c,n=14):
    up=np.r_[0,h[1:]-h[:-1]]; dn=np.r_[0,l[:-1]-l[1:]]
    pdm=np.where((up>dn)&(up>0),up,0); mdm=np.where((dn>up)&(dn>0),dn,0)
    a=atr(h,l,c,n); sm=lambda x:pd.Series(x).ewm(alpha=1/n,adjust=False).mean().values
    pdi=100*sm(pdm)/a; mdi=100*sm(mdm)/a; dx=100*abs(pdi-mdi)/np.maximum(pdi+mdi,1e-9)
    return sm(dx),pdi,mdi
def load(s,tf):
    p=f"../data/{s}_{tf}.csv"
    return pd.read_csv(p,index_col=0,parse_dates=True) if os.path.exists(p) else None
B=load("BTCUSDT","240"); E=load("ETHUSDT","240")
be=B.close.values-ema(B.close.values,50); ee=E.close.values-ema(E.close.values,50)
bS=pd.Series(np.sign(be),B.index); eS=pd.Series(np.sign(ee),E.index)
out=[]
for s,Z in R.groupby("sym"):
    h4=load(s,"240"); D=load(s,"D"); W=load(s,"W")
    o,h,l,c=(h4[x].values for x in ("open","high","low","close")); ix=h4.index
    A=atr(h,l,c); e20,e50,e200=ema(c,20),ema(c,50),ema(c,200)
    m=ema(c,12)-ema(c,26); sg=ema(m,9); hist=m-sg
    ad,pdi,mdi=adx(h,l,c)
    if D is not None: Dc=D.close.values; De=ema(Dc,50); Dt=D.index+pd.Timedelta(days=1)
    if W is not None: Wc=W.close.values; We=ema(Wc,20); Wt=W.index+pd.Timedelta(days=7)
    for r in Z.itertuples():
        k=ix.searchsorted(r.t)
        if k>=len(ix) or ix[k]!=r.t or k<120: continue
        d=int(r.arah); px=c[k]; a=A[k]; f={"i":r.Index}
        step=10**np.floor(np.log10(px))/2
        nxt=(np.floor(px/step)+1)*step if d==1 else (np.ceil(px/step)-1)*step
        prv=(np.floor(px/step))*step if d==1 else (np.ceil(px/step))*step
        f["bulat_depan"]=int(abs(nxt-px)<=1.5*a)            # angka bulat menghalangi dalam 1R (SL 1.5 ATR)
        f["bulat_belakang"]=int(abs(px-prv)<=1.0*a)         # angka bulat jadi lantai dekat
        hh=h[k-20:k].max(); ll=l[k-20:k].min()
        lev=hh if d==1 else ll; lebih=(px-lev)*d
        f["tembus_kuat"]=int(lebih>=0.25*a); f["tembus_tipis"]=int(0<lebih<0.25*a)
        f["gagal_tembus"]=int(((h[k]>hh) and px<hh) if d==1 else ((l[k]<ll) and px>ll))
        f["jebakan_lawan"]=int(((l[k]<ll) and px>ll) if d==1 else ((h[k]>hh) and px<hh))
        y=c[k-99:k+1]; x=np.arange(100); b1,b0=np.polyfit(x,y,1); res=y-(b0+b1*x); sd=res.std() or 1e-9
        z=res[-1]/sd*d
        f["channel_bawah"]=int(z<-1); f["channel_atas"]=int(z>1)
        y2=c[k-49:k+1]; f["trendline_dalam"]=int(np.polyfit(np.arange(50),y2,1)[0]*d>0)
        # Dow: pivot 3 kiri kanan, dua pivot high dan low terakhir yang terkonfirmasi
        ph=[i for i in range(k-60,k-3) if h[i]==h[i-3:i+4].max()]; pl=[i for i in range(k-60,k-3) if l[i]==l[i-3:i+4].min()]
        if len(ph)>=2 and len(pl)>=2:
            up=h[ph[-1]]>h[ph[-2]] and l[pl[-1]]>l[pl[-2]]; dn=h[ph[-1]]<h[ph[-2]] and l[pl[-1]]<l[pl[-2]]
            f["dow_searah"]=int(up if d==1 else dn); f["dow_lawan"]=int(dn if d==1 else up)
        else: f["dow_searah"]=f["dow_lawan"]=0
        tc=r.t+pd.Timedelta(hours=4)
        f["dow_btc_eth"]=int(bS.get(r.t,0)*d>0 and eS.get(r.t,0)*d>0)
        if D is not None:
            j=Dt.searchsorted(tc,side="right")-1
            f["harian_searah"]=int(j>=50 and (Dc[j]-De[j])*d>0)
        else: f["harian_searah"]=0
        if W is not None:
            j=Wt.searchsorted(tc,side="right")-1
            f["mingguan_searah"]=int(j>=20 and (Wc[j]-We[j])*d>0)
        else: f["mingguan_searah"]=0
        f["harian_mingguan"]=f["harian_searah"]*f["mingguan_searah"]
        g=[(o[i]-c[i-1])*d/A[i] for i in range(k-5,k+1)]
        f["gap_searah"]=int(max(g)>0.3); f["gap_lawan"]=int(min(g)<-0.3)
        hi=h[k-50:k+1].max(); lo=l[k-50:k+1].min(); rg=hi-lo or 1e-9
        ret=(hi-px)/rg if d==1 else (px-lo)/rg
        f["fib_0.5_0.65"]=int(0.5<=ret<=0.65); f["fib_dekat_puncak"]=int(ret<0.236)
        f["macd_searah_nol"]=int(m[k]*d>0); f["macd_hist_searah"]=int(hist[k]*d>0); f["macd_hist_naik"]=int((hist[k]-hist[k-1])*d>0)
        f["adx_25"]=int(ad[k]>25); f["adx_20_kurang"]=int(ad[k]<20); f["di_searah"]=int((pdi[k]-mdi[k])*d>0)
        out.append(f)
F=pd.DataFrame(out).set_index("i"); R=R.join(F,how="inner"); R.to_pickle("fitur.pkl"); print(len(R))

"""GZH (Golden Zone Hunter) aturan robot persis (qse_pola.gz_hunter, konf=True) di 111 koin perp 4J, Jul 2020 - Okt 2026.
Semua sentuhan pertama 0.618 yang candle-nya tutup kembali di sisi 0. Banyak cara keluar diuji. Biaya 0.15%."""
import os, sys, numpy as np, pandas as pd, numba as nb, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot"); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("QSE_STATE_DIR", os.path.abspath("st"))
import qse_pola as PL, sbt
D = sbt.D


@nb.njit(cache=True)
def keluar(o, h, l, c, a, t, L, e, sl, lv0, lvx, mode, RR, H):
    """mode 0 asli (separuh di titik 0, SL ke entry, sisa di -0.236), 1 penuh di titik 0, 2 TP tetap RR,
    3 trailing 3 ATR, 4 penuh di extension -0.236."""
    s = 1 if L else -1; risk = (e - sl) * s; n = len(c)
    if risk <= 0: return np.nan, -1
    r1 = (lv0 - e) * s / risk; r2 = (lvx - e) * s / risk
    tp1 = False; stop = sl; best = e
    for j in range(t + 1, min(n, t + 1 + H)):
        if (s == 1 and l[j] <= stop) or (s == -1 and h[j] >= stop):
            if mode == 0 and tp1: return 0.5 * r1, j
            if mode == 3: return (stop - e) * s / risk, j
            return -1.0, j
        if mode == 0:
            if not tp1 and ((s == 1 and h[j] >= lv0) or (s == -1 and l[j] <= lv0)):
                tp1 = True; stop = e
            if tp1 and ((s == 1 and h[j] >= lvx) or (s == -1 and l[j] <= lvx)):
                return 0.5 * r1 + 0.5 * r2, j
        elif mode == 1:
            if (s == 1 and h[j] >= lv0) or (s == -1 and l[j] <= lv0): return r1, j
        elif mode == 4:
            if (s == 1 and h[j] >= lvx) or (s == -1 and l[j] <= lvx): return r2, j
        elif mode == 2:
            if (s == 1 and h[j] >= e + RR * risk) or (s == -1 and l[j] <= e - RR * risk): return RR, j
        else:
            if not np.isnan(a[j]):
                if s == 1:
                    best = max(best, h[j]); stop = max(stop, best - 3 * a[j])
                else:
                    best = min(best, l[j]); stop = min(stop, best + 3 * a[j])
    j = t + H
    if j >= n: return np.nan, -1
    g = (c[j] - e) * s / risk
    return (0.5 * r1 + 0.5 * g if (mode == 0 and tp1) else g), j


EXITS = {"asli": (0, 0.0, 90), "tp_titik0": (1, 0.0, 60), "R1": (2, 1.0, 30), "R1.5": (2, 1.5, 45), "R2": (2, 2.0, 60),
         "R3": (2, 3.0, 60), "trail": (3, 0.0, 60), "tp_ext": (4, 0.0, 90)}


def jalan():
    b = pd.read_csv(f"{D}/BTCUSDT_240.csv", index_col=0, parse_dates=True)
    btc_up = pd.Series((b.close.values > sbt.ema(b.close.values, 50)).astype(float), index=b.index)
    rows = []; TV = {}
    for s in sbt.SYMS:
        df = pd.read_csv(f"{D}/{s}_240.csv", index_col=0, parse_dates=True)
        F = sbt.fitur(df, None, btc_up); TV[s] = pd.Series(F["turn"], index=df.index)
        h, l, c, o = F["h"], F["l"], F["c"], F["o"]
        kaki, atr = PL._gz_pivots(h, l, c, 10, 4.0)
        n = len(c); dipakai = set(); t = 1; last_exit = -1
        while t < n - 1:
            k = kaki[t - 1]
            if not k or np.isnan(atr[t - 1]):
                t += 1; continue
            start, end, i0 = k
            if (start, end) in dipakai or t <= i0:
                t += 1; continue
            L = start > end
            e618 = PL._gz_level(start, end, 0.618)
            if not ((l[t] <= e618 < c[t - 1]) if L else (h[t] >= e618 > c[t - 1])):
                t += 1; continue
            dipakai.add((start, end))
            if not ((c[t] > e618) if L else (c[t] < e618)):
                t += 1; continue
            e = c[t]; a = atr[t - 1]
            sl = end - 0.2 * a if L else end + 0.2 * a
            lvx = PL._gz_level(start, end, -0.236)
            if (start <= e) if L else (start >= e):
                t += 1; continue
            risk = abs(e - sl)
            row = dict(sym=s, t=df.index[t], arah=1 if L else -1, risk_pct=risk / e, kaki_atr=abs(start - end) / a,
                       vp=F["vp"][t], tren=float((c[t] > F["e200"][t]) == L), btc=float(F["btc"][t] == L),
                       r1=abs(start - e) / risk, rsi=F["rsi14"][t], i=t)
            for nm, (m, RR, H) in EXITS.items():
                R, j = keluar(o, h, l, c, F["atr"], t, L, e, sl, start, lvx, m, RR, H)
                row[nm] = R - 0.0015 * e / risk if not np.isnan(R) else np.nan
                row["xb_" + nm] = j
            rows.append(row)
            t += 1
        print(s, len(rows), flush=True)
    X = pd.DataFrame(rows)
    RK = pd.DataFrame(TV).rank(axis=1, ascending=False).stack().rename("rank").reset_index(); RK.columns = ["t", "sym", "rank"]
    X = X.merge(RK, on=["t", "sym"], how="left")
    X.to_pickle(os.path.join(os.path.dirname(os.path.abspath(__file__)), "gzh.pkl"))


if __name__ == "__main__":
    jalan()

import pandas as pd, numpy as np, os, warnings; warnings.filterwarnings("ignore")
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
S = pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
S = S[(S.t >= "2021-01-01") & (S["rank"] <= S.jalur.map(LIK).fillna(999))].copy(); S["longgar"] = 0
G = pd.read_pickle("longgar.pkl"); G = G[G.t >= "2021-01-01"]
LIK2 = {"rsi_vol": 50, "snr_vol": 50, "msb_hpz": 50, "smc_choch": 50, "ichimoku": 40, "orderblock": 80}
G = G[G["rank"] <= G.jalur.map(LIK2).fillna(999)]
kunci = set(zip(S.jalur, S.sym, S.t))
G = G[[k not in kunci for k in zip(G.jalur, G.sym, G.t)]].copy()
fr = {}
for s in G.sym.unique():
    f = f"../data/{s}_FUND.csv"
    if os.path.exists(f):
        F = pd.read_csv(f); fr[s] = (F.ts.values, np.cumsum(F.rate.values))
def fcost(r):
    if r.sym not in fr: return 0.0
    ts, cs = fr[r.sym]; a = r.t.value // 10**6 + 4 * 3600000; b = r.t_out.value // 10**6 + 4 * 3600000
    i, j = np.searchsorted(ts, a, "right"), np.searchsorted(ts, b, "right")
    return r.arah * ((cs[j - 1] if j > 0 else 0) - (cs[i - 1] if i > 0 else 0)) * r.er
G["fund"] = [fcost(r) for r in G.itertuples()]; G["Rf"] = G.R - G.fund; G["longgar"] = 1
print("kandidat longgar semua (tanpa syarat sepi):", len(G), "PF", pf(G.Rf), G.groupby("jalur").Rf.apply(pf).to_dict())
X = pd.concat([S, G], ignore_index=True).sort_values(["t", "longgar", "rank"]).reset_index(drop=True)
X["wib"] = X.t + pd.Timedelta(hours=11); X["hari"] = X.wib.dt.floor("D")
L = ("smc_choch", "GZH", "msb_hpz")
def sim(jam=None, maks_hari=0, nm=""):
    op = []; keep = []; hari_ada = {}; hari_lg = {}
    for k, r in zip(X.index, X.itertuples()):
        op = [o for o in op if o[0] > r.t]
        na = sum(o[3] == r.arah for o in op)
        if sum(o[1] == r.jalur for o in op) >= 8 or na >= 8: continue
        if r.jalur in L and na >= 4: continue
        if any(o[2] == r.sym for o in op): continue
        if r.longgar:
            if jam is None or r.wib.hour < jam or hari_ada.get(r.hari, 0) > hari_lg.get(r.hari, 0) or hari_lg.get(r.hari, 0) >= maks_hari: continue
            hari_lg[r.hari] = hari_lg.get(r.hari, 0) + 1
        hari_ada[r.hari] = hari_ada.get(r.hari, 0) + 1
        op.append((r.t_out, r.jalur, r.sym, r.arah)); keep.append(k)
    P = X.loc[keep].copy(); P["w"] = np.where(P.jalur == "GZH", 0.5, 1.0)
    P = P.sort_values("t_out"); eq = pk = 0.0; e = []; rg = 0; ws = []
    for x, w in zip(P.Rf.values, P.w.values):
        risk = 0.5 * w * (0.5 if (pk - eq > 8 or rg >= 8) else 1)
        eq += x * risk; pk = max(pk, eq); e.append(eq); ws.append(risk); rg = rg + 1 if x < 0 else 0
    e = np.array(e); dd = (np.maximum.accumulate(e) - e).max()
    hari = pd.date_range("2021-01-01", "2026-10-10", freq="D")
    n = P.hari.dt.tz_localize(None).value_counts().reindex(hari, fill_value=0)
    lg = P[P.longgar == 1]; dv = lg.t < "2024-01-01"
    print(f"{nm:26s} n={len(P)} PF {pf(P.Rf)} total {e[-1]:+.0f}% DD {dd:.0f}% rasio {e[-1]/dd:.1f} | hari kosong {(n==0).mean()*100:.0f}% | "
          f"longgar {len(lg)} PF {pf(lg.Rf)} (2021-23 {pf(lg[dv].Rf)}, 2024-26 {pf(lg[~dv].Rf)})")
sim(nm="BARU tanpa longgar")
for jam in (12, 18):
    for mh in (1, 2):
        sim(jam, mh, f"longgar jam {jam}, maks {mh}/hari")

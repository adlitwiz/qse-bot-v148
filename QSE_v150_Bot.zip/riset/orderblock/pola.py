"""Uji pola chart: double top/bottom, triangle breakout, head and shoulders, divergence RSI, wedge.
111 koin perp 4J 2020-2026, entry open candle berikut, SL 2 ATR, keluar trailing 3 ATR atau TP 3R. Biaya 0.15%."""
import os, sys, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import sbt, mcg
EX = {"trail": (0, 2.0, 3.0, 0.0, 60), "tp3": (1, 2.0, 0.0, 3.0, 45)}
K = 5

def pivots(h, l):
    n = len(h); ph = np.zeros(n, bool); pl = np.zeros(n, bool)
    for i in range(K, n - K):
        w = slice(i - K, i + K + 1)
        if h[i] == h[w].max(): ph[i] = True
        if l[i] == l[w].min(): pl[i] = True
    return ph, pl

def deteksi(F):
    o, h, l, c, a, r = F["o"], F["h"], F["l"], F["c"], F["atr"], F["rsi14"]; n = len(c)
    ph, pl = pivots(h, l)
    S = {k: [] for k in ("double", "triangle", "hns", "div_rsi", "wedge")}
    H, Lw = [], []         # pivot terkonfirmasi (index)
    neck_db = neck_dt = None; tri = None; hs = ihs = None; wd = None
    for i in range(K, n):
        j = i - K
        if ph[j]: H.append(j)
        if pl[j]: Lw.append(j)
        newh, newl = ph[j], pl[j]
        # DIVERGENSI RSI (saat pivot terkonfirmasi)
        if newl and len(Lw) >= 2:
            p1, p2 = Lw[-2], Lw[-1]
            if 5 <= p2 - p1 <= 60 and l[p2] < l[p1] and r[p2] > r[p1] + 3 and r[p2] < 40: S["div_rsi"].append((i, 1))
        if newh and len(H) >= 2:
            p1, p2 = H[-2], H[-1]
            if 5 <= p2 - p1 <= 60 and h[p2] > h[p1] and r[p2] < r[p1] - 3 and r[p2] > 60: S["div_rsi"].append((i, -1))
        # DOUBLE BOTTOM / TOP: set neckline saat pivot ke-2 terkonfirmasi
        if newl and len(Lw) >= 2 and H:
            p1, p2 = Lw[-2], Lw[-1]; hh = [x for x in H if p1 < x < p2]
            if hh and 10 <= p2 - p1 <= 80 and abs(l[p2] - l[p1]) <= 0.5 * a[p2]:
                neck_db = (max(h[x] for x in hh), i + 30)
        if newh and len(H) >= 2 and Lw:
            p1, p2 = H[-2], H[-1]; ll = [x for x in Lw if p1 < x < p2]
            if ll and 10 <= p2 - p1 <= 80 and abs(h[p2] - h[p1]) <= 0.5 * a[p2]:
                neck_dt = (min(l[x] for x in ll), i + 30)
        if neck_db and i <= neck_db[1] and c[i] > neck_db[0] and c[i - 1] <= neck_db[0]: S["double"].append((i, 1)); neck_db = None
        if neck_dt and i <= neck_dt[1] and c[i] < neck_dt[0] and c[i - 1] >= neck_dt[0]: S["double"].append((i, -1)); neck_dt = None
        # HEAD AND SHOULDERS
        if newh and len(H) >= 3 and len(Lw) >= 2:
            a1, b1, c1 = H[-3], H[-2], H[-1]
            if h[b1] > h[a1] and h[b1] > h[c1] and abs(h[a1] - h[c1]) <= 1.0 * a[c1] and c1 - a1 <= 100:
                ll = [x for x in Lw if a1 < x < c1]
                if len(ll) >= 1: hs = (min(l[x] for x in ll), i + 30)
        if newl and len(Lw) >= 3 and len(H) >= 2:
            a1, b1, c1 = Lw[-3], Lw[-2], Lw[-1]
            if l[b1] < l[a1] and l[b1] < l[c1] and abs(l[a1] - l[c1]) <= 1.0 * a[c1] and c1 - a1 <= 100:
                hh = [x for x in H if a1 < x < c1]
                if len(hh) >= 1: ihs = (max(h[x] for x in hh), i + 30)
        if hs and i <= hs[1] and c[i] < hs[0] and c[i - 1] >= hs[0]: S["hns"].append((i, -1)); hs = None
        if ihs and i <= ihs[1] and c[i] > ihs[0] and c[i - 1] <= ihs[0]: S["hns"].append((i, 1)); ihs = None
        # TRIANGLE / WEDGE: 2 pivot high + 2 pivot low terakhir dalam 80 candle
        if (newh or newl) and len(H) >= 2 and len(Lw) >= 2:
            h1, h2, l1, l2 = H[-2], H[-1], Lw[-2], Lw[-1]
            if min(h1, l1) >= i - 80:
                sh = (h[h2] - h[h1]) / (h2 - h1); sl_ = (l[l2] - l[l1]) / (l2 - l1)
                lebar0 = h[h1] - l[l1]
                if sh < 0 < sl_: tri = (h2, h[h2], sh, l2, l[l2], sl_, i + 40)               # simetris menyempit
                elif sh < 0 and sl_ < 0 and sl_ < sh: wd = ("turun", h2, h[h2], sh, l2, l[l2], sl_, i + 40)   # falling wedge
                elif sh > 0 and sl_ > 0 and sl_ > sh: wd = ("naik", h2, h[h2], sh, l2, l[l2], sl_, i + 40)   # rising wedge
        if tri and i <= tri[6]:
            up = tri[1] + tri[2] * (i - tri[0]); dn = tri[4] + tri[5] * (i - tri[3])
            if up > dn:
                if c[i] > up and c[i - 1] <= tri[1] + tri[2] * (i - 1 - tri[0]): S["triangle"].append((i, 1)); tri = None
                elif c[i] < dn and c[i - 1] >= tri[4] + tri[5] * (i - 1 - tri[3]): S["triangle"].append((i, -1)); tri = None
        if wd and i <= wd[7]:
            up = wd[2] + wd[3] * (i - wd[1]); dn = wd[5] + wd[6] * (i - wd[4])
            if wd[0] == "turun" and c[i] > up and c[i - 1] <= wd[2] + wd[3] * (i - 1 - wd[1]): S["wedge"].append((i, 1)); wd = None
            elif wd[0] == "naik" and c[i] < dn and c[i - 1] >= wd[5] + wd[6] * (i - 1 - wd[4]): S["wedge"].append((i, -1)); wd = None
    return S

T = []; TV = {}
b = pd.read_csv(f"{sbt.D}/BTCUSDT_240.csv", index_col=0, parse_dates=True)
btc_up = pd.Series((b.close.values > sbt.ema(b.close.values, 50)).astype(float), index=b.index)
for s in sbt.SYMS:
    df = pd.read_csv(f"{sbt.D}/{s}_240.csv", index_col=0, parse_dates=True)
    F = sbt.fitur(df, None, btc_up); TV[s] = pd.Series(F["turn"], index=df.index)
    o, h, l, c, a = F["o"], F["h"], F["l"], F["c"], F["atr"]; ix = df.index
    for nm, cand in deteksi(F).items():
        cand = [(i, sd) for i, sd in cand if 250 <= i < len(c) - 1]
        if not cand: continue
        idx = np.array([x[0] for x in cand], np.int64); side = np.array([x[1] for x in cand], np.int64)
        for ex, (m, slk, trk, RR, H) in EX.items():
            R, fb, xb = mcg.sim(o, h, l, c, a, np.zeros(len(c)), idx, side, m, slk, trk, RR, H)
            for k in np.nonzero(fb >= 0)[0]:
                i = idx[k]; sd = side[k]
                T.append((nm, ex, s, ix[i], ix[min(xb[k], len(ix) - 1)], float(R[k]), int(sd),
                          float((c[i] > F["e200"][i]) == (sd == 1)), float((F["btc"][i] == 1) == (sd == 1)), float(F["vp"][i])))
X = pd.DataFrame(T, columns=["pola", "ex", "sym", "t", "t_out", "R", "arah", "tren", "btc", "vp"])
RK = pd.DataFrame(TV).rank(axis=1, ascending=False).stack().rename("rank").reset_index(); RK.columns = ["t", "sym", "rank"]
X = X.merge(RK, on=["t", "sym"], how="left")
X.to_pickle(os.path.join(HERE, "pola.pkl")); print("selesai", len(X))

import pandas as pd, numpy as np, os, warnings; warnings.filterwarnings("ignore")
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
X = pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = X[(X["rank"] <= X.jalur.map(LIK).fillna(999)) & (X.t >= "2021-01-01")].reset_index(drop=True)
rows = []
for s, Z in X.groupby("sym"):
    f1 = f"../data/{s}_60.csv"
    if not os.path.exists(f1): continue
    h = pd.read_csv(f1, index_col=0, parse_dates=True)
    for r in Z.itertuples():
        t0 = r.t + pd.Timedelta(hours=4)
        if t0 not in h.index: continue
        e = h.open.loc[t0]; risk = e / r.er; L = r.arah == 1; cost = 0.0015 * r.er
        seg = h.loc[t0:t0 + pd.Timedelta(days=10)]
        sl = e - risk if L else e + risk; tp1 = e + 0.8 * risk * r.arah; tp2 = e + 1.8 * risk * r.arah
        res = None; sisa = 1.0; real = 0.0; stop = sl
        for hi, lo, cl in zip(seg.high.values, seg.low.values, seg.close.values):
            kena_sl = lo <= stop if L else hi >= stop
            if kena_sl:
                res = real + sisa * ((stop - e) / risk * r.arah); break
            if sisa == 1.0 and ((hi >= tp1) if L else (lo <= tp1)):
                real += 0.5 * 0.8; sisa = 0.5; stop = e
            if sisa == 0.5 and ((hi >= tp2) if L else (lo <= tp2)):
                res = real + 0.5 * 1.8; break
        if res is None: res = real + sisa * ((seg.close.values[-1] - e) / risk * r.arah)
        rows.append((r.jalur, r.t, r.Rf, res - cost - 0.01))
R = pd.DataFrame(rows, columns=["jalur", "t", "aturan_jalur", "tp1_tp2_dasbor"])
for nm, Z in (("SEMUA", R), ("2021-2023", R[R.t < "2024"]), ("2024-2026", R[R.t >= "2024"])):
    print(nm, {k: (pf(Z[k]), round(Z[k].sum())) for k in ("aturan_jalur", "tp1_tp2_dasbor")})
print({j: (pf(z.aturan_jalur), pf(z.tp1_tp2_dasbor)) for j, z in R.groupby("jalur")})

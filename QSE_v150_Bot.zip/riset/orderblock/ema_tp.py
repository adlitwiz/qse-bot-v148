import os, sys, numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE); sys.path.insert(0,os.path.join(HERE,"..","smc"))
sys.path.insert(0,"/mnt/user-data/outputs/QSE_v148_Bot"); os.environ.setdefault("QSE_STATE_DIR",os.path.join(HERE,"st"))
import sbt, mcg
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2) if len(x) else 0
for D,nm in ((os.path.join(HERE,"..","data"),"2020-26"),(os.path.join(HERE,"..","data17"),"2017-20")):
    if not os.path.isdir(D): continue
    b=pd.read_csv(f"{D}/BTCUSDT_240.csv",index_col=0,parse_dates=True)
    btc_up=pd.Series((b.close.values>sbt.ema(b.close.values,50)).astype(float),index=b.index)
    G={"trail sl1.5 t4":(0,1.5,4.0,0.0,60),"trail sl2 t3 (lama)":(0,2.0,3.0,0.0,60)}
    for rr in (1.0,1.5,2.0,3.0): G[f"TP {rr}R sl1.5"]=(1,1.5,0.0,rr,60)
    T={k:[] for k in G}
    for fn in sorted(os.listdir(D)):
        if not fn.endswith("_240.csv"): continue
        df=pd.read_csv(f"{D}/{fn}",index_col=0,parse_dates=True); F=sbt.fitur(df,None,btc_up)
        o,h,l,c,a=F["o"],F["h"],F["l"],F["c"],F["atr"]; S=sbt.sinyal(F); e_s=S["ema20x50"][1]
        cand=[(i,-1) for i in np.nonzero(e_s)[0] if F["btc"][i]==0 and 250<=i<len(c)-1]
        if not cand: continue
        idx=np.array([x[0] for x in cand]); side=np.array([x[1] for x in cand]); md=np.zeros(len(c))
        for k,g in G.items():
            R,fb,xb=mcg.sim(o,h,l,c,a,md,idx,side,*g); last=-1
            for j in np.nonzero(fb>=0)[0]:
                if fb[j]<=last: continue
                last=xb[j]
                if g[1]*a[idx[j]]/o[idx[j]+1]>0.10: continue
                T[k].append((df.index[idx[j]],float(R[j])))
    for k,v in T.items():
        Z=pd.DataFrame(v,columns=["t","R"])
        if nm=="2020-26":
            print(nm,k,len(Z),"WR",round((Z.R>0).mean()*100),"PF",f(Z.R.values),"dev",f(Z[Z.t<"2024"].R.values),"uji",f(Z[Z.t>="2024"].R.values),"total",round(Z.R.sum()))
        else:
            print(nm,k,len(Z),"WR",round((Z.R>0).mean()*100),"PF",f(Z.R.values),"total",round(Z.R.sum()))

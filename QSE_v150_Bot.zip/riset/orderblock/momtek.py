import os, sys, numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import sbt, mcg
def s_(m):
    sd=pd.Series(m).rolling(100).std().values
    return 2*sd
s=pd.Series
def sma(x,n): return s(x).rolling(n).mean().values
def wma(x,n):
    w=np.arange(1,n+1); return s(x).rolling(n).apply(lambda z:(z*w).sum()/w.sum(),raw=True).values
def cross_up(a,b): return np.r_[False,(a[1:]>b[1:])&(a[:-1]<=b[:-1])]
def cross_dn(a,b): return np.r_[False,(a[1:]<b[1:])&(a[:-1]>=b[:-1])]
def psar(h,l,af0=0.02,mx=0.2):
    n=len(h); ps=np.zeros(n); up=True; af=af0; ep=h[0]; ps[0]=l[0]; tr=np.ones(n)
    for i in range(1,n):
        p=ps[i-1]+af*(ep-ps[i-1])
        if up:
            p=min(p,l[i-1],l[i-2] if i>1 else l[i-1])
            if l[i]<p: up=False; p=ep; ep=l[i]; af=af0
            else:
                if h[i]>ep: ep=h[i]; af=min(af+af0,mx)
        else:
            p=max(p,h[i-1],h[i-2] if i>1 else h[i-1])
            if h[i]>p: up=True; p=ep; ep=h[i]; af=af0
            else:
                if l[i]<ep: ep=l[i]; af=min(af+af0,mx)
        ps[i]=p; tr[i]=1 if up else -1
    return tr
EX={"trail":(0,1.5,4.0,0.0,60),"tp3":(1,1.5,0.0,3.0,60)}
T=[]
for D,era in ((os.path.join(HERE,"..","data"),"perp"),(os.path.join(HERE,"..","data17"),"lama")):
    b=pd.read_csv(f"{D}/BTCUSDT_240.csv",index_col=0,parse_dates=True)
    btc_up=pd.Series((b.close.values>sbt.ema(b.close.values,50)).astype(float),index=b.index)
    for fn in sorted(os.listdir(D)):
        if not fn.endswith("_240.csv"): continue
        sym=fn[:-8]; df=pd.read_csv(f"{D}/{fn}",index_col=0,parse_dates=True)
        if len(df)<400: continue
        F=sbt.fitur(df,None,btc_up); o,h,l,c,a,v=F["o"],F["h"],F["l"],F["c"],F["atr"],F["v"]
        tren=np.sign(c-F["e200"]); vp=F["vp"]
        sig={}
        mom=c-np.r_[np.full(10,np.nan),c[:-10]]
        z=np.zeros(len(c))
        sig["mom_nol"]=(cross_up(mom,z),cross_dn(mom,z))
        q=s_(mom)
        sig["mom_ekstrem"]=(cross_up(mom,-q),cross_dn(mom,q))
        md0=np.zeros(len(c))
        for nm,(L,S) in sig.items():
            L=np.nan_to_num(L).astype(bool); S=np.nan_to_num(S).astype(bool)
            for fv in ("polos","tren","tren_vol"):
                idx=[];side=[]
                for i in np.nonzero(L|S)[0]:
                    if i<250 or i>=len(c)-1: continue
                    sd=1 if L[i] else -1
                    if fv!="polos" and tren[i]!=sd: continue
                    if fv=="tren_vol" and not vp[i]>=80: continue
                    idx.append(i); side.append(sd)
                if not idx: continue
                idx=np.array(idx); side=np.array(side)
                for ex,g in EX.items():
                    R,fb,xb=mcg.sim(o,h,l,c,a,md0,idx,side,*g); last=-1
                    for j in np.nonzero(fb>=0)[0]:
                        if fb[j]<=last: continue
                        last=xb[j]
                        if g[1]*a[idx[j]]/o[idx[j]+1]>0.10: continue
                        T.append((era,nm,fv,ex,sym,df.index[idx[j]],float(R[j]),int(side[j]),F["turn"][idx[j]]))
    print(era,"selesai",len(T),flush=True)
X=pd.DataFrame(T,columns=["era","tek","filter","exit","sym","t","R","arah","turn"])
X["rank"]=X.groupby(["era","t"]).turn.rank(ascending=False)
X.to_pickle(os.path.join(HERE,"momtek.pkl")); print("ok",len(X))

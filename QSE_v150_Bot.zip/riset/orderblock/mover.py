import os, sys, numpy as np, pandas as pd
sys.path.insert(0,"."); import mcg
D="../data"; C={};O={};H={};L={};V={}
for fn in os.listdir(D):
    if fn.endswith("_240.csv"):
        x=pd.read_csv(f"{D}/{fn}",index_col=0,parse_dates=True); s=fn[:-8]
        C[s],O[s],H[s],L[s],V[s]=x.close,x.open,x.high,x.low,x.volume
C=pd.DataFrame(C).sort_index(); O=pd.DataFrame(O).reindex(C.index); H=pd.DataFrame(H).reindex(C.index); L=pd.DataFrame(L).reindex(C.index); V=pd.DataFrame(V).reindex(C.index)
ch=(C/O-1)*100; turn=(C*V).rolling(180,min_periods=60).sum(); rk=turn.rank(axis=1,ascending=False)
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
res={"ikut":[],"lawan":[]}
for s in C.columns:
    v0=C[s].first_valid_index(); v1=C[s].last_valid_index()
    sl_=(C.index>=v0)&(C.index<=v1)
    c,o,h,l=[X[s].values[sl_] for X in (C,O,H,L)]
    c=pd.Series(c).ffill().values; o=pd.Series(o).fillna(pd.Series(c)).values; h=pd.Series(h).fillna(pd.Series(c)).values; l=pd.Series(l).fillna(pd.Series(c)).values
    if len(c)<400: continue
    tr=np.maximum(h-l,np.maximum(abs(h-np.r_[c[0],c[:-1]]),abs(l-np.r_[c[0],c[:-1]]))); a=pd.Series(tr).ewm(alpha=1/14,adjust=False).mean().values
    top=((ch.abs().where(rk<=50).rank(axis=1,ascending=False)[s]<=3).values & (rk[s]<=50).values)[sl_]
    chs=ch[s].values[sl_]; ti=C.index[sl_]
    idx=np.nonzero(top)[0]; idx=idx[(idx>250)&(idx<len(c)-1)]
    if not len(idx): continue
    side=np.sign(chs[idx]).astype(int)
    for nm,sd in (("ikut",side),("lawan",-side)):
        R,fb,xb=mcg.sim(o,h,l,c,a,np.zeros(len(c)),idx,sd,0,1.5,4.0,0.0,60)
        last=-1
        for j in np.nonzero(fb>=0)[0]:
            if fb[j]<=last or np.isnan(R[j]): continue
            last=xb[j]; res[nm].append((ti[idx[j]],R[j],abs(chs[idx[j]])))
for nm,v in res.items():
    Z=pd.DataFrame(v,columns=["t","R","gerak"]); Z=Z[Z.t>="2021-01-01"]
    print(nm,len(Z),"PF",f(Z.R.values),"dev",f(Z[Z.t<"2024"].R.values),"uji",f(Z[Z.t>="2024"].R.values),"exp",round(Z.R.mean(),3))
    for lo,hi in ((0,5),(5,8),(8,100)):
        z=Z[(Z.gerak>=lo)&(Z.gerak<hi)]; print("   gerak",lo,"-",hi,"%",len(z),"PF",f(z.R.values))

import pandas as pd, numpy as np, itertools, warnings; warnings.filterwarnings("ignore")
R=pd.read_pickle("cb4.pkl")
F=pd.read_pickle("fitur.pkl")
G=["jebakan_lawan","channel_atas","macd_hist_searah","adx_20_kurang"]; Bd=["bulat_depan","adx_25","macd_searah_nol","channel_bawah","tembus_tipis"]
R=R.join(F[G+Bd],how="inner")
R["plus"]=R[G].sum(axis=1); R["s2"]=R["plus"]-R[Bd].sum(axis=1)
A=pd.read_pickle("semua_f.pkl")[["jalur","sym","t","t_out","rank"]].drop_duplicates(["jalur","sym","t"])
R=R.drop(columns=[c for c in ("rank",) if c in R.columns]).merge(A,on=["jalur","sym","t"],how="left")
EM={("GZH","smc_choch"),("ema_short","msb_hpz"),("ema_short","rsi_vol"),("ichimoku","ema_short"),("ichimoku","mcginley"),("ichimoku","rsi_vol"),("mcginley","GZH"),("mcginley","ema_short"),("mcginley","ichimoku"),("mcginley","msb_hpz"),("msb_hpz","ema_short"),("msb_hpz","ichimoku"),("rsi_vol","ichimoku"),("rsi_vol","mcginley"),("rsi_vol","msb_hpz"),("rsi_vol","smc_choch"),("smc_choch","ema_short"),("snr_vol","smc_choch"),("ema_short","mcginley"),("mcginley","smc_choch"),("orderblock","smc_choch"),("smc_choch","ichimoku")}
FX={("msb_hpz",frozenset({"ema_short","smc_choch"})),("ema_short",frozenset({"mcginley","msb_hpz"})),("rsi_vol",frozenset({"mcginley","smc_choch"})),("smc_choch",frozenset({"ichimoku","mcginley"})),("ichimoku",frozenset({"mcginley","smc_choch"})),("rsi_vol",frozenset({"mcginley","msb_hpz"})),("ichimoku",frozenset({"mcginley","rsi_vol"})),("rsi_vol",frozenset({"msb_hpz","smc_choch"})),("rsi_vol",frozenset({"ichimoku","mcginley"})),("ichimoku",frozenset({"rsi_vol","smc_choch"}))}
R["emas"]=[any((j,p) in EM for p in ps) for j,ps in zip(R.jalur,R.par)]
R["fix"]=[any((j,frozenset(c)) in FX for c in itertools.combinations(sorted(ps),2)) for j,ps in zip(R.jalur,R.par)]
R["ncb"]=R.par.apply(len)
PFJ={"orderblock":1.45,"ema_short":1.42,"rsi_vol":1.34,"snr_vol":1.33,"ichimoku":1.29,"msb_hpz":1.27,"smc_choch":1.25,"mcginley":1.24,"GZH":1.24}
R["prio"]=-(3*R.fix+2*R.emas+(R.ncb>=1)+(R.ncb>=2)+(R.plus>=3)+R.jalur.map(PFJ)/10)
R["te"]=pd.to_datetime(R.t,utc=True)+pd.Timedelta(hours=4); R["t"]=pd.to_datetime(R.t,utc=True); R["t_out"]=pd.to_datetime(R.t_out,utc=True)
R["dw"]=R.te.dt.dayofweek
LEMAH={"smc_choch","GZH","msb_hpz"}
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
def sim(nm,mutu=False,senin=False,wkend=False,urut=True):
    X=R.copy()
    if mutu: X=X[X.s2>-2]
    if senin: X=X[(X.dw!=0)|X.emas|X.fix|(X.ncb>=2)]
    X=X.sort_values(["t","prio" if urut else "rank"])
    op=[];keep=[]
    for k,r in zip(X.index,X.itertuples()):
        op=[o for o in op if o[0]>r.t]
        if sum(o[1]==r.jalur for o in op)>=8: continue
        na=sum(o[3]==r.arah for o in op)
        if na>=16: continue
        if r.jalur in LEMAH and na>=8: continue
        if any(o[2]==r.sym for o in op): continue
        op.append((r.t_out,r.jalur,r.sym,r.arah)); keep.append(k)
    P=X.loc[keep].copy()
    P["w"]=np.where(P.jalur=="GZH",0.5,1.0)*np.where(wkend&P.dw.isin([5,6]),0.5,1.0)
    P=P.sort_values("t_out"); eq=pk=0.0; e=[]; rg=0; ws=[]
    for x,w in zip(P.R.values,P.w.values):
        risk=0.25*w*(0.5 if (pk-eq>8 or rg>=8) else 1)
        eq+=x*risk; pk=max(pk,eq); e.append(eq); ws.append(risk); rg=rg+1 if x<0 else 0
    P["pnl"]=P.R.values*np.array(ws); e=np.array(e); dd=(np.maximum.accumulate(e)-e).max()
    hari=pd.date_range("2021-01-01","2026-10-10",freq="D",tz="UTC")
    n=P.te.dt.floor("D").value_counts().reindex(hari,fill_value=0)
    d=P.t<"2024"
    def r_(z):
        c=z.pnl.cumsum().values; return round(z.pnl.sum()/max((np.maximum.accumulate(c)-c).max(),1e-9),1)
    print(f"{nm:38s} sinyal/hari {n.mean():.1f} (median {n.median():.0f}, hari kosong {(n==0).mean()*100:.0f}%) | WR {(P.R>0).mean()*100:.0f}% PF {f(P.R.values)} "
          f"dev {f(P[d].R.values)} uji {f(P[~d].R.values)} | total {e[-1]:+.0f}% modal DD {dd:.1f}% rasio {e[-1]/dd:.1f} (dev {r_(P[d])} uji {r_(P[~d])}) "
          f"| exp {P.R.mean():.3f}R bulan terburuk {P.groupby(P.t_out.dt.to_period('M')).pnl.sum().min():.1f}%")
    return P
sim("A sebelum (urut likuid)",urut=False)
sim("B urut prioritas label")
sim("C + filter mutu",mutu=True)
sim("D + Senin hanya combo",mutu=True,senin=True)
P=sim("E + akhir pekan lot 1/2 (SEKARANG)",mutu=True,senin=True,wkend=True)
for nm,m in (("COMBO FIX",P.fix),("COMBO EMAS",P.emas&~P.fix),("COMBO 3+",(P.ncb>=2)&~P.emas&~P.fix),("lainnya",~P.fix&~P.emas&(P.ncb<2))):
    print("   ",nm,"per hari",round(m.sum()/2110,2),"PF",f(P[m].R.values),"exp",round(P[m].R.mean(),3))

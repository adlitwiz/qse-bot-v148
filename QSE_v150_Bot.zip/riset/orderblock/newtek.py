import os, sys, numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import sbt, mcg
s=pd.Series
def sma(x,n): return s(x).rolling(n).mean().values
def wma(x,n):
    w=np.arange(1,n+1); return s(x).rolling(n).apply(lambda z:(z*w).sum()/w.sum(),raw=True).values
def cross_up(a,b): return np.r_[False,(a[1:]>b[1:])&(a[:-1]<=b[:-1])]
def cross_dn(a,b): return np.r_[False,(a[1:]<b[1:])&(a[:-1]>=b[:-1])]
def psar(h,l,af0=0.02,mx=0.2):
    n=len(h); ps=np.zeros(n); up=True; af=af0; ep=h[0]; ps[0]=l[0]; tr=np.ones(n)
    for i in range(1,n):
        p=ps[i-1]+af*(ep-ps[i-1])
        if up:
            p=min(p,l[i-1],l[i-2] if i>1 else l[i-1])
            if l[i]<p: up=False; p=ep; ep=l[i]; af=af0
            else:
                if h[i]>ep: ep=h[i]; af=min(af+af0,mx)
        else:
            p=max(p,h[i-1],h[i-2] if i>1 else h[i-1])
            if h[i]>p: up=True; p=ep; ep=h[i]; af=af0
            else:
                if l[i]<ep: ep=l[i]; af=min(af+af0,mx)
        ps[i]=p; tr[i]=1 if up else -1
    return tr
EX={"trail":(0,1.5,4.0,0.0,60),"tp3":(1,1.5,0.0,3.0,60)}
T=[]
for D,era in ((os.path.join(HERE,"..","data"),"perp"),(os.path.join(HERE,"..","data17"),"lama")):
    b=pd.read_csv(f"{D}/BTCUSDT_240.csv",index_col=0,parse_dates=True)
    btc_up=pd.Series((b.close.values>sbt.ema(b.close.values,50)).astype(float),index=b.index)
    for fn in sorted(os.listdir(D)):
        if not fn.endswith("_240.csv"): continue
        sym=fn[:-8]; df=pd.read_csv(f"{D}/{fn}",index_col=0,parse_dates=True)
        if len(df)<400: continue
        F=sbt.fitur(df,None,btc_up); o,h,l,c,a,v=F["o"],F["h"],F["l"],F["c"],F["atr"],F["v"]
        tren=np.sign(c-F["e200"]); vp=F["vp"]
        sig={}
        # stochastic
        ll=s(l).rolling(14).min().values; hh=s(h).rolling(14).max().values
        k=sma(100*(c-ll)/np.maximum(hh-ll,1e-12),3); d=sma(k,3)
        sig["stoch"]=(cross_up(k,d)&(np.r_[np.nan,k[:-1]]<20), cross_dn(k,d)&(np.r_[np.nan,k[:-1]]>80))
        for nm,f in (("sma",sma),("ema",lambda x,n: sbt.ema(x,n)),("wma",wma)):
            f9,f21=f(c,9),f(c,21); sig[f"dma_{nm}"]=(cross_up(f9,f21),cross_dn(f9,f21))
        e5,e10,e20=sbt.ema(c,5),sbt.ema(c,10),sbt.ema(c,20)
        al_up=(e5>e10)&(e10>e20); al_dn=(e5<e10)&(e10<e20)
        sig["tma"]=(al_up&~np.r_[False,al_up[:-1]], al_dn&~np.r_[False,al_dn[:-1]])
        wr=-100*(hh-c)/np.maximum(hh-ll,1e-12)
        sig["willr"]=(cross_up(wr,np.full(len(c),-80.0)),cross_dn(wr,np.full(len(c),-20.0)))
        ps=psar(h,l); sig["psar"]=(np.r_[False,(ps[1:]==1)&(ps[:-1]==-1)],np.r_[False,(ps[1:]==-1)&(ps[:-1]==1)])
        bb=b.close.reindex(df.index).ffill().values; ratio=c/bb; re=sbt.ema(ratio,50)
        sig["crs"]=(cross_up(ratio,re),cross_dn(ratio,re))
        tp=(h+l+c)/3; m=sma(tp,20); md=s(tp).rolling(20).apply(lambda z:np.abs(z-z.mean()).mean(),raw=True).values
        cci=(tp-m)/(0.015*np.maximum(md,1e-12))
        sig["cci"]=(cross_up(cci,np.full(len(c),100.0)),cross_dn(cci,np.full(len(c),-100.0)))
        r14=F["rsi14"]; sig["rsi_3070"]=(cross_up(r14,np.full(len(c),30.0)),cross_dn(r14,np.full(len(c),70.0)))
        md0=np.zeros(len(c))
        for nm,(L,S) in sig.items():
            L=np.nan_to_num(L).astype(bool); S=np.nan_to_num(S).astype(bool)
            for fv in ("polos","tren","tren_vol"):
                idx=[];side=[]
                for i in np.nonzero(L|S)[0]:
                    if i<250 or i>=len(c)-1: continue
                    sd=1 if L[i] else -1
                    if fv!="polos" and tren[i]!=sd: continue
                    if fv=="tren_vol" and not vp[i]>=80: continue
                    idx.append(i); side.append(sd)
                if not idx: continue
                idx=np.array(idx); side=np.array(side)
                for ex,g in EX.items():
                    R,fb,xb=mcg.sim(o,h,l,c,a,md0,idx,side,*g); last=-1
                    for j in np.nonzero(fb>=0)[0]:
                        if fb[j]<=last: continue
                        last=xb[j]
                        if g[1]*a[idx[j]]/o[idx[j]+1]>0.10: continue
                        T.append((era,nm,fv,ex,sym,df.index[idx[j]],float(R[j]),int(side[j]),F["turn"][idx[j]]))
    print(era,"selesai",len(T),flush=True)
X=pd.DataFrame(T,columns=["era","tek","filter","exit","sym","t","R","arah","turn"])
X["rank"]=X.groupby(["era","t"]).turn.rank(ascending=False)
X.to_pickle(os.path.join(HERE,"newtek.pkl")); print("ok",len(X))

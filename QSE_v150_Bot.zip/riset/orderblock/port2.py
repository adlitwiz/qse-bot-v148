import sys, warnings, pandas as pd, numpy as np
warnings.filterwarnings("ignore")
Y = pd.read_pickle("ob_final.pkl"); Y = Y[Y.arah == 1].sort_values("t_in")
def porto(Y, cap=8):
    open_ = []; keep = []
    for k, r in Y.iterrows():
        open_ = [t for t in open_ if t > r.t_in]
        if len(open_) >= cap: continue
        open_.append(r.t_out); keep.append(k)
    P = Y.loc[keep].sort_values("t_out")
    eq = peak = 0.0; rg = 0; out = []
    for r in P.R.values:
        risk = 0.25 if (peak - eq > 8 or rg >= 6) else 0.5
        eq += r * risk; peak = max(peak, eq); out.append(eq); rg = rg + 1 if r < 0 else 0
    e = np.array(out); dd = (np.maximum.accumulate(e) - e).max()
    r = P.R.values; pf = r[r > 0].sum() / -r[r < 0].sum()
    q = P.groupby(P.t_in.dt.to_period("Q")).R.sum()
    print("cap", cap, "n", len(P), "per hari", round(len(P) / ((P.t_in.max() - P.t_in.min()).days), 2), "pf", round(pf, 3), "wr", round((r > 0).mean(), 3),
          "avgR", round(r.mean(), 3), "total%", round(e[-1], 1), "dd%", round(dd, 1), "q+", f"{(q > 0).sum()}/{len(q)}",
          {k: round(v, 2) for k, v in P.groupby(P.t_in.dt.year).R.apply(lambda s: s[s > 0].sum() / -s[s < 0].sum()).items()})
    return P
for cap in (4, 8): porto(Y, cap)
P = porto(Y[Y.t_in >= "2024-01-01"], 8)
print("rata hold candle", (Y.xb - Y.fb).mean().round(1), "exit:", "SL", round((Y.R < -0.9).mean(), 3), "TP", round((Y.R > 3.5).mean(), 3))

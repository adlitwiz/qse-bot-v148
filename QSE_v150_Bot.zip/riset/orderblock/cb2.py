import pandas as pd, numpy as np, os, warnings; warnings.filterwarnings("ignore")
A = pd.read_pickle("semua_f.pkl"); A=A[A.t>="2020-06-01"]
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = A[(A["rank"] <= A.jalur.map(LIK).fillna(999)) & (A.t >= "2021-01-01")].reset_index(drop=True)
def ema(s,n): return s.ewm(span=n,adjust=False).mean()
def feat(df):
    c=df.close; f=pd.DataFrame(index=df.index)
    f["e200"]=np.sign(c-ema(c,200)); f["e50"]=np.sign(c-ema(c,50)); f["e2050"]=np.sign(ema(c,20)-ema(c,50))
    t=(df.high.rolling(9).max()+df.low.rolling(9).min())/2; k=(df.high.rolling(26).max()+df.low.rolling(26).min())/2
    sa=((t+k)/2).shift(26); sb=((df.high.rolling(52).max()+df.low.rolling(52).min())/2).shift(26)
    f["ichi"]=np.where(c>np.maximum(sa,sb),1,np.where(c<np.minimum(sa,sb),-1,0))
    d=c.diff(); up=d.clip(lower=0).ewm(alpha=1/14,adjust=False).mean(); dn=(-d.clip(upper=0)).ewm(alpha=1/14,adjust=False).mean()
    f["rsi"]=np.sign(100-100/(1+up/dn)-50)
    f["slope"]=np.sign(ema(c,50)-ema(c,50).shift(6))
    return f
btc=feat(pd.read_csv("../data/BTCUSDT_240.csv",index_col=0,parse_dates=True))
rows=[]
for s,Z in X.groupby("sym"):
    p=f"../data/{s}_240.csv"
    if not os.path.exists(p): continue
    F=feat(pd.read_csv(p,index_col=0,parse_dates=True))
    P=A[A.sym==s]
    for r in Z.itertuples():
        if r.t not in F.index: continue
        v=F.loc[r.t]*r.arah; b=btc.loc[r.t]*r.arah if r.t in btc.index else None
        d=dict(jalur=r.jalur,sym=s,t=r.t,R=r.Rf)
        for w in (24,48,72,120):
            m=(P.arah==r.arah)&(P.t>=r.t-pd.Timedelta(hours=w))&(P.t<=r.t)&(P.jalur!=r.jalur)
            d[f"cb{w}"]=P[m].jalur.nunique()
            d[f"cbL{w}"]=X[(X.sym==s)&(X.arah==r.arah)&(X.t>=r.t-pd.Timedelta(hours=w))&(X.t<=r.t)&(X.jalur!=r.jalur)].jalur.nunique()
        for k in F.columns: d[k]=v[k]
        d["btc"]=b["e50"] if b is not None else 0
        d["st"]=int((v>0).sum())
        rows.append(d)
R=pd.DataFrame(rows); R.to_pickle("cb2.pkl"); print(len(R))

import pandas as pd, numpy as np, glob, os
C={}
for f in glob.glob("data15/*_15.csv"):
    C[os.path.basename(f)[:-7]]=pd.read_csv(f,index_col=0,parse_dates=True).close
C=pd.DataFrame(C); C=C[C.index>="2022-01-01"]
alt=[c for c in C.columns if c!="BTCUSDT"]
# pemicu 3 jam per bar
r12=C.pct_change(12,fill_method=None)*100; r2=C.pct_change(2,fill_method=None)*100
def trig(r,bt,at):
    a=r[alt]; return (r.BTCUSDT.abs()>=bt)|((a>=at).mean(axis=1)>=0.7)|((a<=-at).mean(axis=1)>=0.7)
T=trig(r2,2,3)|trig(r12,3,5)
# hari WIB mulai 06:00 = 23:00 UTC
day=(C.index-pd.Timedelta(hours=23)).floor("D")
D=pd.DataFrame({"ser":T.groupby(day).any()})
o=C.groupby(day).first(); c=C.groupby(day).last()
ret=(c/o-1)*100
D["btc"]=ret.BTCUSDT; D["altikut"]=(np.sign(ret[alt]).eq(np.sign(ret.BTCUSDT),axis=0)).mean(axis=1)
hi=C.BTCUSDT.groupby(day).max(); lo=C.BTCUSDT.groupby(day).min(); D["rng"]=(hi/lo-1)*100
D["rng_kemarin"]=D.rng.shift(); D["ser_kemarin"]=D.ser.shift(); D["btc_kemarin"]=D.btc.shift()
D["rng7"]=D.rng.shift().rolling(7).mean(); D["dw"]=pd.to_datetime(D.index).dayofweek
D=D.dropna()
dev=D.index<"2024-07-01"
def st(nm,m):
    a=D[m&dev]; b=D[m&~dev]
    print(f"{nm:34s} n {len(a):4d}/{len(b):4d} hari serentak {a.ser.mean()*100:3.0f}%/{b.ser.mean()*100:3.0f}%")
st("semua",D.ser.notna())
q=D.rng7.quantile([.33,.66]).values
st("rentang 7h rendah",D.rng7<q[0]); st("rentang 7h sedang",D.rng7.between(q[0],q[1])); st("rentang 7h tinggi",D.rng7>q[1])
st("kemarin serentak",D.ser_kemarin==True); st("kemarin tidak",D.ser_kemarin==False)
for i,n in enumerate("Sen Sel Rab Kam Jum Sab Min".split()): st("hari "+n,D.dw==(i if True else 0))
st("tinggi + kemarin serentak",(D.rng7>q[1])&(D.ser_kemarin==True)); st("rendah + kemarin tidak",(D.rng7<q[0])&(D.ser_kemarin==False))
print("alt ikut arah BTC (rata hari):",round(D.altikut.mean()*100),"%  saat serentak:",round(D[D.ser].altikut.mean()*100),"%")
print("arah BTC hari ini sama dengan kemarin:",round((np.sign(D.btc)==np.sign(D.btc_kemarin)).mean()*100),"%")
D.to_pickle("pagi.pkl")

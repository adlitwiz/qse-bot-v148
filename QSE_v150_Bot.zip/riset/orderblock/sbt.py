"""Uji banyak strategi umum di 111 koin perp 4J, Jul 2020 - Okt 2026. Aturan dipilih di 2020-2023, diuji di 2024-2026.
Entry open candle setelah sinyal. Biaya 0.15% notional. Satu posisi per koin per strategi."""
import os, sys, numpy as np, pandas as pd, numba as nb, warnings, pickle
warnings.filterwarnings("ignore")
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
SYMS = sorted(f[:-8] for f in os.listdir(D) if f.endswith("_240.csv"))
H4 = 4 * 3600000


def ema(x, n):
    return pd.Series(x).ewm(span=n, adjust=False).mean().values


def rma(x, n):
    return pd.Series(x).ewm(alpha=1 / n, adjust=False).mean().values


def rsi(c, n):
    d = np.diff(c, prepend=c[0]); up = rma(np.maximum(d, 0), n); dn = rma(np.maximum(-d, 0), n)
    return 100 - 100 / (1 + up / np.maximum(dn, 1e-12))


def fitur(df, fund, btc_up):
    o, h, l, c, v = (df[k].values.astype(float) for k in ("open", "high", "low", "close", "volume"))
    pc = np.r_[c[0], c[:-1]]
    tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    a = rma(tr, 14)
    s = pd.Series
    F = dict(o=o, h=h, l=l, c=c, v=v, atr=a, e20=ema(c, 20), e50=ema(c, 50), e200=ema(c, 200), e5=s(c).rolling(5).mean().values,
             dh20=s(h).rolling(20).max().shift(1).values, dl20=s(l).rolling(20).min().shift(1).values,
             dh55=s(h).rolling(55).max().shift(1).values, dl55=s(l).rolling(55).min().shift(1).values,
             rsi2=rsi(c, 2), rsi14=rsi(c, 14),
             vp=s(v).rolling(101).apply(lambda w: (w[:-1] <= w[-1]).mean() * 100, raw=True).values)
    m20 = s(c).rolling(20).mean().values; sd = s(c).rolling(20).std(ddof=0).values
    F["bbu"], F["bbl"], F["bbm"] = m20 + 2 * sd, m20 - 2 * sd, m20
    bw = (4 * sd) / np.maximum(m20, 1e-12)
    F["bwp"] = s(bw).rolling(101).apply(lambda w: (w[:-1] <= w[-1]).mean() * 100, raw=True).values
    # supertrend 10,3
    hl2 = (h + l) / 2; a10 = rma(tr, 10); up = hl2 - 3 * a10; dn = hl2 + 3 * a10
    st = np.zeros(len(c)); fu = up.copy(); fd = dn.copy()
    for i in range(1, len(c)):
        fu[i] = max(up[i], fu[i - 1]) if c[i - 1] > fu[i - 1] else up[i]
        fd[i] = min(dn[i], fd[i - 1]) if c[i - 1] < fd[i - 1] else dn[i]
        st[i] = 1 if c[i] > fd[i - 1] else (-1 if c[i] < fu[i - 1] else st[i - 1])
    F["st"] = st
    ts = df.index.as_unit("ms").asi8
    fr = np.zeros(len(c))
    if fund is not None and len(fund):
        k = np.searchsorted(fund.ts.values, ts + H4, side="right") - 1
        ok = k >= 0; fr[ok] = fund.rate.values[k[ok]]
    F["fund"] = fr
    F["fpct"] = s(fr).rolling(540, min_periods=200).apply(lambda w: (w[:-1] <= w[-1]).mean() * 100, raw=True).values
    F["btc"] = btc_up.reindex(df.index).ffill().fillna(0.5).values
    F["turn"] = s(c * v).rolling(180, min_periods=60).sum().values
    F["ret30"] = c / np.r_[np.full(180, np.nan), c[:-180]] - 1
    return F


def sinyal(F):
    """Return dict nama -> (L array bool, S array bool, mode exit)."""
    c, h, l, o = F["c"], F["h"], F["l"], F["o"]
    up = c > F["e200"]; dn = c < F["e200"]
    out = {}
    out["donchian20"] = (c > F["dh20"], c < F["dl20"], "trail")
    out["donchian55"] = (c > F["dh55"], c < F["dl55"], "trail")
    x = (F["e20"] > F["e50"]) & (np.r_[True, F["e20"][:-1] <= F["e50"][:-1]])
    y = (F["e20"] < F["e50"]) & (np.r_[True, F["e20"][:-1] >= F["e50"][:-1]])
    out["ema20x50"] = (x & up, y & dn, "trail")
    stp = np.r_[0, F["st"][:-1]]
    out["supertrend"] = ((F["st"] == 1) & (stp == -1), (F["st"] == -1) & (stp == 1), "trail")
    out["squeeze"] = ((np.r_[100, F["bwp"][:-1]] <= 10) & (c > F["bbu"]), (np.r_[100, F["bwp"][:-1]] <= 10) & (c < F["bbl"]), "trail")
    out["vol_breakout"] = ((c > F["dh20"]) & (F["vp"] >= 90), (c < F["dl20"]) & (F["vp"] >= 90), "trail")
    out["rsi2_mr"] = ((F["rsi2"] < 5) & up, (F["rsi2"] > 95) & dn, "mr")
    out["bb_mr"] = ((c < F["bbl"]) & up, (c > F["bbu"]) & dn, "mrbb")
    dd3 = (c < np.r_[np.inf, c[:-1]]) & (np.r_[np.inf, c[:-1]] < np.r_[np.inf, np.inf, c[:-2]]) & (np.r_[np.inf, np.inf, c[:-2]] < np.r_[np.inf, np.inf, np.inf, c[:-3]])
    uu3 = (c > np.r_[-np.inf, c[:-1]]) & (np.r_[-np.inf, c[:-1]] > np.r_[-np.inf, -np.inf, c[:-2]]) & (np.r_[-np.inf, -np.inf, c[:-2]] > np.r_[-np.inf, -np.inf, -np.inf, c[:-3]])
    out["pullback3"] = (dd3 & (F["e50"] > F["e200"]) & up, uu3 & (F["e50"] < F["e200"]) & dn, "mr")
    out["funding_kontra"] = ((F["fpct"] <= 3) & (F["fund"] < 0), (F["fpct"] >= 97) & (F["fund"] > 0), "fix2")
    out["funding_searah"] = ((F["fpct"] >= 97) & (F["fund"] > 0), (F["fpct"] <= 3) & (F["fund"] < 0), "fix2")
    ib = (h < np.r_[np.inf, h[:-1]]) & (l > np.r_[-np.inf, l[:-1]])
    ibp = np.r_[False, ib[:-1]]
    out["insidebar"] = (ibp & (c > np.r_[np.inf, h[:-1]]) & up, ibp & (c < np.r_[-np.inf, l[:-1]]) & dn, "fix2")
    rsi_p = np.r_[50, F["rsi14"][:-1]]
    out["rsi_cross50"] = ((F["rsi14"] > 50) & (rsi_p <= 50) & up & (F["e50"] > F["e200"]), (F["rsi14"] < 50) & (rsi_p >= 50) & dn & (F["e50"] < F["e200"]), "trail")
    out["ret30_mom"] = ((F["ret30"] > 0.3) & (c > F["dh20"]), (F["ret30"] < -0.3) & (c < F["dl20"]), "trail")
    return out


@nb.njit(cache=True)
def sim(o, h, l, c, a, sma5, bbm, sig_i, side, mode, slk, trk, RR, H):
    n = len(sig_i); R = np.full(n, np.nan); fb = np.full(n, -1); xb = np.full(n, -1); N = len(c)
    for k in range(n):
        i = sig_i[k]; s = side[k]
        if i + 1 >= N or np.isnan(a[i]): continue
        e = o[i + 1]; risk = slk * a[i]
        if risk <= 0 or risk / e < 0.003: continue
        sl = e - s * risk; best = e; done = False
        fb[k] = i + 1
        for j in range(i + 1, min(N, i + 1 + H)):
            if (s == 1 and l[j] <= sl) or (s == -1 and h[j] >= sl):
                R[k] = (sl - e) * s / risk; xb[k] = j; done = True; break
            if mode == 1 and j > i + 1 and ((s == 1 and h[j] >= e + RR * risk) or (s == -1 and l[j] <= e - RR * risk)):
                R[k] = RR; xb[k] = j; done = True; break
            if mode == 0 and not np.isnan(a[j]):
                if s == 1:
                    best = max(best, h[j]); sl = max(sl, best - trk * a[j])
                else:
                    best = min(best, l[j]); sl = min(sl, best + trk * a[j])
            if mode == 2 and ((s == 1 and c[j] > sma5[j]) or (s == -1 and c[j] < sma5[j])):
                R[k] = (c[j] - e) * s / risk; xb[k] = j; done = True; break
            if mode == 3 and ((s == 1 and c[j] > bbm[j]) or (s == -1 and c[j] < bbm[j])):
                R[k] = (c[j] - e) * s / risk; xb[k] = j; done = True; break
        if not done:
            j = i + H
            if j >= N: fb[k] = -1; continue
            R[k] = (c[j] - e) * s / risk; xb[k] = j
        R[k] -= 0.0015 * e / risk
    return R, fb, xb


MODE = {"trail": (0, 2.0, 3.0, 0.0, 60), "fix2": (1, 1.5, 0.0, 2.0, 30), "mr": (2, 2.0, 0.0, 0.0, 10), "mrbb": (3, 2.0, 0.0, 0.0, 15)}


def jalan():
    b = pd.read_csv(f"{D}/BTCUSDT_240.csv", index_col=0, parse_dates=True)
    btc_up = pd.Series((b.close.values > ema(b.close.values, 50)).astype(float), index=b.index)
    rows = []; TV = {}
    for s in SYMS:
        df = pd.read_csv(f"{D}/{s}_240.csv", index_col=0, parse_dates=True)
        fu = pd.read_csv(f"{D}/{s}_FUND.csv") if os.path.exists(f"{D}/{s}_FUND.csv") else None
        F = fitur(df, fu, btc_up); TV[s] = pd.Series(F["turn"], index=df.index)
        for nm, (Lm, Sm, md) in sinyal(F).items():
            idx = np.nonzero(Lm | Sm)[0]; idx = idx[idx >= 250]
            if not len(idx): continue
            side = np.where(Lm[idx], 1, -1).astype(np.int64)
            m, slk, trk, RR, H = MODE[md]
            R, fb, xb = sim(F["o"], F["h"], F["l"], F["c"], F["atr"], F["e5"], F["bbm"], idx.astype(np.int64), side, m, slk, trk, RR, H)
            ok = fb >= 0
            last = -1
            for k in np.nonzero(ok)[0]:
                if fb[k] <= last: continue
                last = xb[k]
                i = idx[k]
                rows.append((nm, s, df.index[i], int(side[k]), float(R[k]), float(F["vp"][i]), float(F["btc"][i] == (side[k] == 1)),
                             float((F["c"][i] > F["e200"][i]) == (side[k] == 1)), int(xb[k] - fb[k])))
        print(s, len(rows), flush=True)
    X = pd.DataFrame(rows, columns=["strat", "sym", "t", "arah", "R", "vp", "btc", "tren", "hold"])
    RK = pd.DataFrame(TV).rank(axis=1, ascending=False)
    X["rank"] = [RK.at[t, s] for t, s in zip(X.t, X.sym)]
    X.to_pickle(os.path.join(os.path.dirname(os.path.abspath(__file__)), "hasil.pkl"))


if __name__ == "__main__":
    jalan()

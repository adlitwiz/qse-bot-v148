"""Uji independen semua jalur terbukti di data yang BELUM PERNAH dipakai: Binance spot 4J, 40 koin, Agu 2017 - Jun 2020.
Aturan persis sama, tidak ada yang diubah. Portofolio maks 8 posisi per jalur, biaya 0.15%."""
import os, sys, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "..", "smc"))
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot"); os.environ.setdefault("QSE_STATE_DIR", os.path.join(HERE, "st"))
import sbt, mcg, mcg2, smc_core as K, gzh_bt as G, qse_pola as PL
D = os.path.join(HERE, "..", "data")
SY = sorted(f[:-7] for f in os.listdir(D) if f.endswith("_60.csv") and os.path.exists(os.path.join(D, f[:-7] + "_60.csv")))
AKHIR = pd.Timestamp("2030-01-01", tz="UTC")
b = pd.read_csv(f"{D}/BTCUSDT_60.csv", index_col=0, parse_dates=True)
btc_up = pd.Series((b.close.values > sbt.ema(b.close.values, 50)).astype(float), index=b.index)
TV = {}; T = []
EX = {"trail": (0, 2.0, 3.0, 0.0, 60), "tp3": (1, 2.0, 0.0, 3.0, 45)}


def tambah(nm, s, idx, side, R, fb, xb, ix, er=None):
    last = -1
    for k in np.nonzero(fb >= 0)[0]:
        if fb[k] <= last: continue
        last = xb[k]
        T.append((nm, s, ix[idx[k]], ix[min(xb[k], len(ix) - 1)], float(R[k]), int(side[k]), float(er[k]) if er is not None else np.nan))


for s in SY:
    df = pd.read_csv(f"{D}/{s}_60.csv", index_col=0, parse_dates=True)
    F = sbt.fitur(df, None, btc_up); TV[s] = pd.Series(F["turn"], index=df.index)
    o, h, l, c, v, a = F["o"], F["h"], F["l"], F["c"], F["v"], F["atr"]; ix = df.index
    md0 = np.zeros(len(c))
    tren = lambda i, sd: (c[i] > F["e200"][i]) == (sd == 1)
    btc = lambda i, sd: (F["btc"][i] == 1) == (sd == 1)

    def jalan(nm, cand, ex, md=md0):
        cand = [(i, sd) for i, sd in cand if 250 <= i < len(c) - 1]
        if not cand: return
        idx = np.array([x[0] for x in cand], np.int64); side = np.array([x[1] for x in cand], np.int64)
        m, slk, trk, RR, H = EX[ex] if isinstance(ex, str) else ex
        R, fb, xb = mcg.sim(o, h, l, c, a, md, idx, side, m, slk, trk, RR, H)
        er = o[np.minimum(idx + 1, len(o) - 1)] / (slk * a[idx])
        tambah(nm, s, idx, side, R, fb, xb, ix, er)

    S = sbt.sinyal(F)
    e_s = S["ema20x50"][1]
    jalan("ema_short", [(i, -1) for i in np.nonzero(e_s)[0] if F["btc"][i] == 0], "trail")
    rl, rs = S["rsi_cross50"][:2]
    jalan("rsi_vol", [(i, 1 if rl[i] else -1) for i in np.nonzero((rl | rs) & (F["vp"] >= 80))[0]], "trail")
    md, mdp = mcg2.mcg_win(c, 34, 0.6, 600)
    up = c > md; pu = np.r_[False, c[:-1] > mdp[1:]]
    jalan("mcginley", [(i, 1 if up[i] else -1) for i in np.nonzero((up != pu) & ~np.isnan(md) & (F["vp"] >= 80))[0]
                       if tren(i, 1 if up[i] else -1)], "tp3")
    vp = F["vp"]
    jalan("snr_vol", [(i, sd) for i, sd, *_ in K.snr(h, l, c, 20) if tren(i, sd) and btc(i, sd) and vp[i] >= 80], "tp3")
    jalan("msb_hpz", [(x[0], x[1]) for x in K.msb(o, h, l, c, v, 7, 0.5, K.volpct(v)) if x[5]["skor"] > 80 and tren(x[0], x[1])], "trail")
    jalan("smc_choch", [(x[0], x[1]) for x in K.smc(o, h, l, c, 5, 50) if x[5]["tag"] == "choch" and tren(x[0], x[1])], "tp3")
    # Ichimoku
    import qse_ichimoku as I
    tk = (I._hh(h, 9) + I._ll(l, 9)) / 2; kj = (I._hh(h, 26) + I._ll(l, 26)) / 2
    sa = np.r_[np.full(26, np.nan), ((tk + kj) / 2)[:-26]]; sb = np.r_[np.full(26, np.nan), ((I._hh(h, 52) + I._ll(l, 52)) / 2)[:-26]]
    ic = []
    for i in range(120, len(c)):
        if np.isnan(sa[i]) or np.isnan(sb[i]): continue
        if c[i] > max(sa[i], sb[i]) and tk[i] > kj[i] and tk[i - 1] <= kj[i - 1]: ic.append((i, 1))
        elif c[i] < min(sa[i], sb[i]) and tk[i] < kj[i] and tk[i - 1] >= kj[i - 1]: ic.append((i, -1))
    jalan("ichimoku", ic, "trail")
    # Order Block LONG: SL di bawah low OB - 0.3 ATR, TP 4R, 60 candle
    for i, sd, top, bot, jn in K.obf(o, h, l, c, 5, 2.0):
        if sd != 1 or not (250 <= i < len(c) - 1) or not tren(i, 1) or vp[i] < 80 or F["btc"][i] != 1: continue
        e = o[i + 1]; sl = bot - 0.3 * a[i]; risk = e - sl
        if risk <= 0 or not (0.004 <= risk / e <= 0.15): continue
        res = None
        for j in range(i + 1, min(len(c), i + 61)):
            if l[j] <= sl: res = -1.0; break
            if j > i + 1 and h[j] >= e + 4 * risk: res = 4.0; break
        if res is None:
            j = min(len(c) - 1, i + 60); res = (c[j] - e) / risk
        T.append(("orderblock", s, ix[i], ix[j], res - 0.0015 * e / risk, 1, e / risk))
    # GZH searah tren dan BTC, trailing
    kaki, atr10 = PL._gz_pivots(h, l, c, 10, 4.0); dip = set(); t = 1
    while t < len(c) - 1:
        kk = kaki[t - 1]
        if not kk or np.isnan(atr10[t - 1]) or t < 250: t += 1; continue
        st_, en, i0 = kk
        if (st_, en) in dip or t <= i0: t += 1; continue
        L = st_ > en; e618 = PL._gz_level(st_, en, 0.618)
        if not ((l[t] <= e618 < c[t - 1]) if L else (h[t] >= e618 > c[t - 1])): t += 1; continue
        dip.add((st_, en))
        if not ((c[t] > e618) if L else (c[t] < e618)) or ((st_ <= c[t]) if L else (st_ >= c[t])): t += 1; continue
        sd = 1 if L else -1
        if tren(t, sd) and btc(t, sd):
            sl = en - 0.2 * atr10[t - 1] if L else en + 0.2 * atr10[t - 1]
            R, j = G.keluar(o, h, l, c, a, t, L, c[t], sl, st_, PL._gz_level(st_, en, -0.236), 3, 0.0, 60)
            if not np.isnan(R): T.append(("GZH", s, ix[t], ix[j], R - 0.0015 * c[t] / abs(c[t] - sl), sd, c[t] / abs(c[t] - sl)))
        t += 1

X = pd.DataFrame(T, columns=["jalur", "sym", "t", "t_out", "R", "arah", "er"])
RK = pd.DataFrame(TV).rank(axis=1, ascending=False).stack().rename("rank").reset_index(); RK.columns = ["t", "sym", "rank"]
X = X.merge(RK, on=["t", "sym"], how="left"); X = X[X.t < AKHIR]
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
pf = lambda r: round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
for jl, Z in X.groupby("jalur"):
    Z = Z[Z["rank"] <= LIK.get(jl, 999)].sort_values(["t", "rank"]); op = []; keep = []
    for k, r in zip(Z.index, Z.itertuples()):
        op = [x for x in op if x > r.t]
        if len(op) >= 8: continue
        op.append(r.t_out); keep.append(k)
    P = Z.loc[keep]; R = P.R.values; e = np.cumsum(R * 0.5); dd = (np.maximum.accumulate(e) - e).max()
    print(f"{jl:11s} n={len(P):4d} WR {(R > 0).mean() * 100:3.0f}% PF {pf(R)} total {e[-1]:+.0f}% DD {dd:.0f}% "
          f"th {P.groupby(P.t.dt.year).R.apply(lambda q: pf(q.values)).to_dict()}")
X.to_pickle(os.path.join(HERE, "semua1j.pkl"))

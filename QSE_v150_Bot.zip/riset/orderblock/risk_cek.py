import pickle, glob, os, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
B = {}
for f in glob.glob("pre_all/*.pkl"):
    s = os.path.basename(f)[:-4]; P = pickle.load(open(f, "rb"))
    B[s] = {k: (v.get("bias"), v.get("izin")) for k, v in P.items()}
H = pd.read_pickle("strat/hasil.pkl"); M = pd.read_pickle("strat/mcg2.pkl"); S = pd.read_pickle("strat/smc2.pkl"); G = pd.read_pickle("strat/gzh.pkl")
J = {"EMA Cross SHORT": H[(H.strat == "ema20x50") & (H.arah == -1) & (H.btc == 1)],
     "RSI 50 + Volume": H[(H.strat == "rsi_cross50") & (H.vp >= 80) & (H["rank"] <= 30)],
     "McGinley": M[(M.strat == "md34_cross|tp3") & (M.tren == 1) & (M.vp >= 80)],
     "SnR + Volume": S[(S.strat == "snr|tp3") & (S.tren == 1) & (S.btc == 1) & (S.vp >= 80) & (S["rank"] <= 30)],
     "MSB HPZ": S[(S.strat == "msb|trail") & (S.skor > 80) & (S.tren == 1) & (S["rank"] <= 30)],
     "SMC CHoCH": S[(S.strat == "smc|tp3") & (S.tag == "choch") & (S.tren == 1) & (S["rank"] <= 30)],
     "GZH": G[(G.tren == 1) & (G.btc == 1)].rename(columns={"trail": "R"})}
pf = lambda r: round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
for nm, Z in J.items():
    Z = Z[Z.t >= "2021-07-01"].copy()
    ks = [(s, int(t.value // 10**6)) for s, t in zip(Z.sym, Z.t)]
    bi = [B.get(s, {}).get(k, (None, None)) for s, k in ks]
    ar = np.where(Z.arah == 1, "LONG", "SHORT")
    Z["bias_lawan"] = [b[0] is not None and b[0] != a for b, a in zip(bi, ar)]
    Z["izin_lawan"] = [b[1] is not None and not (b[1] == "LONG dan SHORT" or b[1].startswith(a)) for b, a in zip(bi, ar)]
    Z["ada"] = [b[0] is not None for b in bi]
    Z = Z[Z.ada]
    risk = Z.bias_lawan | Z.izin_lawan
    d = Z.t < "2024"
    print(f"{nm:16s} n={len(Z):5d} | aman PF {pf(Z[~risk].R.values)} (dev {pf(Z[~risk & d].R.values)} uji {pf(Z[~risk & ~d].R.values)}) n={(~risk).sum()} "
          f"| BERISIKO PF {pf(Z[risk].R.values)} (dev {pf(Z[risk & d].R.values)} uji {pf(Z[risk & ~d].R.values)}) n={risk.sum()} "
          f"| bias lawan {pf(Z[Z.bias_lawan].R.values)} izin lawan {pf(Z[Z.izin_lawan].R.values)} n={Z.izin_lawan.sum()} dev {pf(Z[Z.izin_lawan & d].R.values)} uji {pf(Z[Z.izin_lawan & ~d].R.values)}")

"""Uji McGinley Dynamic di 111 koin perp 4J, Jul 2020 - Okt 2026. Dev 2020-2023, uji 2024-2026. Biaya 0.15%."""
import os, sys, numpy as np, pandas as pd, numba as nb, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sbt
D = sbt.D


@nb.njit(cache=True)
def mcginley(c, n, k):
    md = np.empty(len(c)); md[0] = c[0]
    for i in range(1, len(c)):
        r = c[i] / md[i - 1]
        md[i] = md[i - 1] + (c[i] - md[i - 1]) / (k * n * r ** 4)
    return md


@nb.njit(cache=True)
def sim(o, h, l, c, a, md, sig_i, side, mode, slk, trk, RR, H):
    """mode 0 trailing ATR, 1 TP tetap RR, 2 keluar saat close menembus balik McGinley (plus SL awal)."""
    n = len(sig_i); R = np.full(n, np.nan); fb = np.full(n, -1); xb = np.full(n, -1); N = len(c)
    for k in range(n):
        i = sig_i[k]; s = side[k]
        if i + 1 >= N or np.isnan(a[i]): continue
        e = o[i + 1]; risk = slk * a[i]
        if risk <= 0 or risk / e < 0.003: continue
        sl = e - s * risk; best = e; done = False; fb[k] = i + 1
        for j in range(i + 1, min(N, i + 1 + H)):
            if (s == 1 and l[j] <= sl) or (s == -1 and h[j] >= sl):
                R[k] = (sl - e) * s / risk; xb[k] = j; done = True; break
            if mode == 1 and j > i + 1 and ((s == 1 and h[j] >= e + RR * risk) or (s == -1 and l[j] <= e - RR * risk)):
                R[k] = RR; xb[k] = j; done = True; break
            if mode == 0:
                if s == 1:
                    best = max(best, h[j]); sl = max(sl, best - trk * a[j])
                else:
                    best = min(best, l[j]); sl = min(sl, best + trk * a[j])
            if mode == 2 and ((s == 1 and c[j] < md[j]) or (s == -1 and c[j] > md[j])):
                R[k] = (c[j] - e) * s / risk; xb[k] = j; done = True; break
        if not done:
            j = i + H
            if j >= N: fb[k] = -1; continue
            R[k] = (c[j] - e) * s / risk; xb[k] = j
        R[k] -= 0.0015 * e / risk
    return R, fb, xb


@nb.njit(cache=True)
def mcg_win(c, n, k, W):
    """McGinley yang dihitung ulang dari jendela W candle terakhir (sama dengan robot live 600 candle).
    Return md sekarang dan md candle sebelumnya, keduanya dari jendela yang sama."""
    N = len(c); cur = np.full(N, np.nan); prv = np.full(N, np.nan)
    for i in range(W - 1, N):
        m = c[i - W + 1]; mp = m
        for j in range(i - W + 2, i + 1):
            mp = m
            m = m + (c[j] - m) / max(k * n * (c[j] / m) ** 4, 1.0)
        cur[i] = m; prv[i] = mp
    return cur, prv


EXIT = {"trail": (0, 2.0, 3.0, 0.0, 60), "tp2": (1, 1.5, 0.0, 2.0, 30), "tp3": (1, 2.0, 0.0, 3.0, 45), "mdx": (2, 2.0, 0.0, 0.0, 60)}


def jalan():
    b = pd.read_csv(f"{D}/BTCUSDT_240.csv", index_col=0, parse_dates=True)
    btc_up = pd.Series((b.close.values > sbt.ema(b.close.values, 50)).astype(float), index=b.index)
    rows = []; TV = {}
    for s in sbt.SYMS:
        df = pd.read_csv(f"{D}/{s}_240.csv", index_col=0, parse_dates=True)
        F = sbt.fitur(df, None, btc_up); TV[s] = pd.Series(F["turn"], index=df.index)
        c = F["c"]
        for N in (14, 20, 34):
            md, mdp = mcg_win(c, N, 0.6, 600)
            up = c > md; pu = np.r_[False, (c[:-1] > mdp[1:])]
            sig = {
                f"md{N}_cross": (up & ~pu & ~np.isnan(md), ~up & pu & ~np.isnan(md)),
                # pullback: tren searah McGinley naik, low menyentuh MD lalu close di atasnya
                f"md{N}_pullback": ((md > mdp) & (F["l"] <= md) & (c > md), (md < mdp) & (F["h"] >= md) & (c < md)),
            }
            for nm, (Lm, Sm) in sig.items():
                idx = np.nonzero(Lm | Sm)[0]; idx = idx[idx >= 250]
                if not len(idx): continue
                side = np.where(Lm[idx], 1, -1).astype(np.int64)
                for ex, (m, slk, trk, RR, H) in EXIT.items():
                    R, fb, xb = sim(F["o"], F["h"], F["l"], c, F["atr"], md, idx.astype(np.int64), side, m, slk, trk, RR, H)
                    last = -1
                    for k in np.nonzero(fb >= 0)[0]:
                        if fb[k] <= last: continue
                        last = xb[k]; i = idx[k]
                        rows.append((f"{nm}|{ex}", s, df.index[i], int(side[k]), float(R[k]), float(F["vp"][i]),
                                     float(F["btc"][i] == (side[k] == 1)), float((c[i] > F["e200"][i]) == (side[k] == 1)), int(xb[k] - fb[k])))
        print(s, len(rows), flush=True)
    X = pd.DataFrame(rows, columns=["strat", "sym", "t", "arah", "R", "vp", "btc", "tren", "hold"])
    RK = pd.DataFrame(TV).rank(axis=1, ascending=False).stack().rename("rank").reset_index()
    RK.columns = ["t", "sym", "rank"]
    X = X.merge(RK, on=["t", "sym"], how="left")
    X.to_pickle(os.path.join(os.path.dirname(os.path.abspath(__file__)), "mcg2.pkl"))


if __name__ == "__main__":
    jalan()

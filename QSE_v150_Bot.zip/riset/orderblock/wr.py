import pandas as pd, numpy as np, os, warnings; warnings.filterwarnings("ignore")
def st(r):
    r=np.asarray(r); return (len(r), round((r>0).mean()*100), round(r[r>0].sum()/max(-r[r<0].sum(),1e-9),2), round(r.sum()))
X = pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = X[(X["rank"] <= X.jalur.map(LIK).fillna(999)) & (X.t >= "2021-01-01")].reset_index(drop=True)
# combo: jalur lain searah di koin sama dalam 24 jam terakhir
X = X.sort_values("t").reset_index(drop=True); cb=np.zeros(len(X),int)
for (s,a),Z in X.groupby(["sym","arah"]):
    tt=Z.t.values; jj=Z.jalur.values
    for i,ix in enumerate(Z.index):
        m=(tt>=tt[i]-np.timedelta64(24,'h'))&(tt<=tt[i])&(jj!=jj[i]); cb[ix]=len(set(jj[m]))
X["cb"]=cb
VAR={"tp0.5":(1,0.5),"tp1":(1,1.0),"tp1.5":(1,1.5),"sl2_tp0.5":(2,0.5),"sl2_tp1":(2,1.0),"sl3_tp0.5":(3,0.5)}
rows=[]
for s, Z in X.groupby("sym"):
    f1 = f"../data/{s}_60.csv"
    if not os.path.exists(f1): continue
    h = pd.read_csv(f1, index_col=0, parse_dates=True)
    H,Lo,C=h.high.values,h.low.values,h.close.values; idx=h.index
    for r in Z.itertuples():
        t0 = r.t + pd.Timedelta(hours=4)
        k=idx.searchsorted(t0)
        if k>=len(idx) or idx[k]!=t0: continue
        e=h.open.values[k]; risk=e/r.er; d=r.arah; cost=0.0015*r.er
        seg=slice(k,min(k+240,len(idx)))
        hh,ll,cc=H[seg],Lo[seg],C[seg]
        out={}
        for nm,(m,tp) in VAR.items():
            sl=e-d*m*risk; t=e+d*tp*risk; res=None
            for a,b in zip(hh,ll):
                if (b<=sl if d==1 else a>=sl): res=-m; break
                if (a>=t if d==1 else b<=t): res=tp; break
            if res is None: res=(cc[-1]-e)/risk*d
            out[nm]=res-cost*1-0.01   # biaya dalam R sesuai risiko 1R awal
        rows.append(dict(jalur=r.jalur,t=r.t,cb=r.cb,jalur_rule=r.Rf,**out))
R=pd.DataFrame(rows); R.to_pickle("wr.pkl")
for nm,Z in (("2021-2023",R[R.t<"2024"]),("2024-2026",R[R.t>="2024"]),("SEMUA",R),("SEMUA combo>=1",R[R.cb>=1]),("SEMUA combo>=2",R[R.cb>=2])):
    print(nm); [print("  ",k,st(Z[k])) for k in ["jalur_rule"]+list(VAR)]

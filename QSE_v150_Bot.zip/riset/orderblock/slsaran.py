import pandas as pd, numpy as np, os
X=pd.read_pickle("semua_f.pkl")
LIK={"rsi_vol":30,"snr_vol":30,"msb_hpz":30,"smc_choch":30,"ichimoku":20,"orderblock":50}
X=X[(X["rank"]<=X.jalur.map(LIK).fillna(999))&(X.t>="2021-01-01")].sample(12000,random_state=1)
TPR={"snr_vol":3.0,"smc_choch":3.0,"mcginley":4.0,"orderblock":4.0}
TRL={"ichimoku":4.0,"ema_short":4.0,"msb_hpz":4.0,"rsi_vol":3.0,"GZH":3.0}
rows=[]
for s,Z in X.groupby("sym"):
    p=f"../data/{s}_60.csv"
    if not os.path.exists(p): continue
    h=pd.read_csv(p,index_col=0,parse_dates=True); ix=h.index; O,H,L,C=(h[c].values for c in ("open","high","low","close"))
    for r in Z.itertuples():
        k0=ix.searchsorted(r.t+pd.Timedelta(hours=4))
        if k0>=len(ix) or ix[k0]!=r.t+pd.Timedelta(hours=4): continue
        e=O[k0]; risk=e/r.er; d=int(r.arah); atr=risk/2.0; cost=0.0015*e/risk; end=min(k0+240,len(ix))
        res={}
        for v,step,buf in (("base",None,0),("sl_per_1pct",1.0,0.12),("sl_per_2pct",2.0,0.12)):
            sl=e-d*risk; best=e; tp=e+d*TPR[r.jalur]*risk if r.jalur in TPR else None; tr=TRL.get(r.jalur); out=None; hw=0
            for j in range(k0,end):
                if (L[j]<=sl if d==1 else H[j]>=sl): out=(sl-e)*d/risk; break
                if tp is not None and (H[j]>=tp if d==1 else L[j]<=tp): out=(tp-e)*d/risk; break
                best=max(best,H[j]) if d==1 else min(best,L[j])
                if tr is not None and (j-k0)%4==3:
                    sl=max(sl,best-tr*atr) if d==1 else min(sl,best+tr*atr)
                if step:
                    fav=(best-e)*d/e*100; lvl=int(fav//step)
                    if lvl>hw and lvl>=1:
                        hw=lvl; tgt=buf if lvl==1 else (lvl-1)*step
                        nsl=e*(1+d*tgt/100)
                        sl=max(sl,nsl) if d==1 else min(sl,nsl)
            if out is None: out=(C[end-1]-e)*d/risk
            res[v]=out-cost
        rows.append(dict(t=r.t,**res))
R=pd.DataFrame(rows); f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),3); dev=R.t<"2024"
for v in ("base","sl_per_1pct","sl_per_2pct"):
    print(v,"PF",f(R.loc[dev,v].values),f(R.loc[~dev,v].values),"total",round(R.loc[dev,v].sum()),round(R.loc[~dev,v].sum()),"WR",round((R.loc[dev,v]>0).mean()*100),round((R.loc[~dev,v]>0).mean()*100))

import pandas as pd, numpy as np, glob, os
# BTC harian 2017-2026, hari WIB (06:00-06:00) dari data 1 jam
a=pd.read_csv("data17/BTCUSDT_60.csv",index_col=0,parse_dates=True); b=pd.read_csv("data/BTCUSDT_60.csv",index_col=0,parse_dates=True)
h=pd.concat([a,b[b.index>a.index[-1]]]); h=h[~h.index.duplicated()]
day=(h.index-pd.Timedelta(hours=23)).floor("D")
D=pd.DataFrame({"o":h.open.groupby(day).first(),"c":h.close.groupby(day).last()})
D["r"]=(D.c/D.o-1)*100; D.index=D.index+pd.Timedelta(days=1)   # label = tanggal WIB
D["dw"]=D.index.dayofweek; D["dm"]=D.index.day; D["wk"]=(D.index.day-1)//7+1; D["bln"]=D.index.month
P=[("2017-21",D.index<"2022-01-01"),("2022-26",D.index>="2022-01-01")]
def show(col,labels):
    print("==",col)
    for v in sorted(D[col].unique()):
        s=[]
        for nm,m in P:
            x=D.loc[m&(D[col]==v),"r"]; s.append(f"naik {(x>0).mean()*100:3.0f}% rata {x.mean():+.2f}%")
        print(f"  {labels(v):10s} "+" | ".join(s))
show("dw",lambda v:"Sen Sel Rab Kam Jum Sab Min".split()[v])
show("wk",lambda v:f"minggu {v}")
show("bln",lambda v:f"bulan {v}")
# tanggal: hanya tampilkan yang konsisten
print("== tanggal konsisten (naik>=58% atau <=42% di dua periode)")
for v in range(1,32):
    r=[D.loc[m&(D.dm==v),"r"] for _,m in P]
    p=[(x>0).mean()*100 for x in r]
    if (p[0]>=58 and p[1]>=58) or (p[0]<=42 and p[1]<=42): print(f"  tgl {v}: naik {p[0]:.0f}% / {p[1]:.0f}%, rata {r[0].mean():+.2f}/{r[1].mean():+.2f}%")
# besok lawan hari ini (pump lalu dump)
D["r_next"]=D.r.shift(-1)
for nm,m in P:
    x=D[m]
    print(nm,"hari ini naik >3%: besok naik",round((x[x.r>3].r_next>0).mean()*100),"% | turun >3%: besok naik",round((x[x.r<-3].r_next>0).mean()*100),"% | biasa",round((x.r_next>0).mean()*100),"%")

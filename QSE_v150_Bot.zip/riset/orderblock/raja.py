import pandas as pd, numpy as np, itertools
R=pd.read_pickle("cb4.pkl"); F=pd.read_pickle("fitur.pkl"); C2=pd.read_pickle("cb2.pkl")
G=["jebakan_lawan","channel_atas","macd_hist_searah","adx_20_kurang"]
R=R.join(F[G],how="left"); R["plus"]=R[G].sum(axis=1)
R=R.drop(columns=[c for c in ("e200","e2050") if c in R.columns]).merge(C2[["jalur","sym","t","e200","e2050"]].drop_duplicates(["jalur","sym","t"]),on=["jalur","sym","t"],how="left")
FX={("msb_hpz",frozenset({"ema_short","smc_choch"})),("ema_short",frozenset({"mcginley","msb_hpz"})),("rsi_vol",frozenset({"mcginley","smc_choch"})),("smc_choch",frozenset({"ichimoku","mcginley"})),("ichimoku",frozenset({"mcginley","smc_choch"})),("rsi_vol",frozenset({"mcginley","msb_hpz"})),("ichimoku",frozenset({"mcginley","rsi_vol"})),("rsi_vol",frozenset({"msb_hpz","smc_choch"})),("rsi_vol",frozenset({"ichimoku","mcginley"})),("ichimoku",frozenset({"rsi_vol","smc_choch"}))}
R["fix"]=[any((j,frozenset(c)) in FX for c in itertools.combinations(sorted(ps),2)) for j,ps in zip(R.jalur,R.par)]
R["n"]=R.par.apply(len); R["pull"]=(R.e200>0)&(R.e2050<0)
R["te"]=pd.to_datetime(R.t,utc=True)+pd.Timedelta(hours=4); R["dw"]=R.te.dt.dayofweek
hari=(R.t.max()-R.t.min()).days
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2) if len(x) else 0
def st(nm,m):
    Z=R[m]; d=Z[Z.t<"2024"]; u=Z[Z.t>="2024"]
    print(f"{nm:40s} /minggu {len(Z)/hari*7:5.2f} WR {(Z.R>0).mean()*100:3.0f}% PF {f(Z.R.values)} dev {f(d.R.values)} uji {f(u.R.values)} exp {Z.R.mean():.3f} n {len(Z)}")
st("COMBO FIX",R.fix)
st("FIX + mutu>=2",R.fix&(R.plus>=2))
st("FIX + mutu>=3",R.fix&(R.plus>=3))
st("FIX + Sel-Jum",R.fix&R.dw.isin([1,2,3,4]))
st("FIX + n>=3",R.fix&(R.n>=3))
st("FIX + pullback",R.fix&R.pull)
st("n>=4 jalur",R.n>=4); st("n>=5 jalur",R.n>=5)
st("n>=3 + mutu>=3",(R.n>=3)&(R.plus>=3))
st("FIX + mutu>=2 + Sel-Jum",R.fix&(R.plus>=2)&R.dw.isin([1,2,3,4]))
st("mcg pullback + n>=2",(R.jalur=="mcginley")&R.pull&(R.n>=2))
st("mcg pullback + mutu>=3",(R.jalur=="mcginley")&R.pull&(R.plus>=3))
R.to_pickle("raja.pkl")

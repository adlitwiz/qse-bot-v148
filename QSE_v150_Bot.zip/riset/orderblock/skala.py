import pandas as pd, numpy as np, warnings; warnings.filterwarnings("ignore")
src = open("frek.py").read().split('L = ("smc_choch"')[0]
exec(src)
L = ("smc_choch", "GZH", "msb_hpz")
import io, contextlib
for cap in (8, 12, 16, 24):
    for rem_ in (8, 16):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            P = sim(nm="", ret=True, cap_arah=cap, rem=rem_, lemah=L, cap_lemah=cap // 2)
        line = buf.getvalue().strip()
        per = len(P) / 2110
        print(f"cap {cap:2d} rem {rem_:2d} | {per:.1f}/hari | " + line[30:])

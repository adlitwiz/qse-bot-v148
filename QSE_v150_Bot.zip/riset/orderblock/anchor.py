import pandas as pd, numpy as np
a=pd.read_csv("data17/BTCUSDT_60.csv",index_col=0,parse_dates=True); b=pd.read_csv("data/BTCUSDT_60.csv",index_col=0,parse_dates=True)
h=pd.concat([a,b[b.index>a.index[-1]]]); h=h[~h.index.duplicated()]
X=pd.read_pickle("strat/semua_f.pkl")
LIK={"rsi_vol":30,"snr_vol":30,"msb_hpz":30,"smc_choch":30,"ichimoku":20,"orderblock":50}
X=X[(X["rank"]<=X.jalur.map(LIK).fillna(999))&(X.t>="2021-01-01")].copy()
X["te"]=pd.to_datetime(X.t,utc=True)+pd.Timedelta(hours=4)
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
TH=dict(r7=-0.0921,e20=0.0994,rsi=70.96,cp=0.1851)
for ah,lab in ((23,"06 WIB"),(5,"12 WIB"),(11,"18 WIB")):
    off=pd.Timedelta(hours=ah)
    day=(h.index-off).floor("D")
    D=pd.DataFrame({"o":h.open.groupby(day).first(),"c":h.close.groupby(day).last(),"hi":h.high.groupby(day).max(),"lo":h.low.groupby(day).min()})
    c=D.c; d=c.diff(); up=d.clip(lower=0).ewm(alpha=1/14,adjust=False).mean(); dn=(-d.clip(upper=0)).ewm(alpha=1/14,adjust=False).mean()
    rsi=100-100/(1+up/dn); r7=c/c.shift(7)-1; e20=c/c.ewm(span=20,adjust=False).mean()-1; cp=(D.c-D.lo)/(D.hi-D.lo)
    sig=(r7<=TH["r7"])|(e20>=TH["e20"])|(rsi>=TH["rsi"])|(cp<=TH["cp"])
    nxt=np.sign(D.c.shift(-1)/D.o.shift(-1)-1)
    start=sig.index+pd.Timedelta(days=1)+off        # periode keputusan mulai (anchor)
    S=pd.Series(sig.values,index=start)
    out=[]
    for per,(lo_,hi_) in (("21-23",("2021","2024")),("24-26",("2024","2027"))):
        m=(sig.index>=lo_)&(sig.index<hi_)
        out.append(f"{per}: hari sinyal {sig[m].mean()*100:.0f}% naik {(nxt[m&sig.values]>0).mean()*100:.0f}% (lain {(nxt[m&~sig.values]>0).mean()*100:.0f}%)")
    # sinyal jalur dalam 6 jam setelah anchor dan 24 jam
    for win in (6,24):
        an=X.te.dt.floor("h"); base=(an-off).dt.floor("D")+off      # anchor terakhir sebelum sinyal
        age=(an-base).dt.total_seconds()/3600
        X["s"]=base.map(S).fillna(False).astype(bool)&(age<win)
        sh=X.arah.astype(int)==-1
        res=[]
        for lo_,hi_ in (("2021","2024"),("2024","2027")):
            M=(X.t>=lo_)&(X.t<hi_)
            res.append(f"SHORT {f(X[M&sh&X.s].Rf.values)} (lain {f(X[M&sh&~X.s].Rf.values)}) LONG {f(X[M&~sh&X.s].Rf.values)}")
        out.append(f"sinyal {win} jam: "+" | ".join(res))
    print(lab,"||"," || ".join(out))

def flag(ah,win):
    off=pd.Timedelta(hours=ah); day=(h.index-off).floor("D")
    D=pd.DataFrame({"c":h.close.groupby(day).last(),"hi":h.high.groupby(day).max(),"lo":h.low.groupby(day).min()})
    c=D.c; d=c.diff(); up=d.clip(lower=0).ewm(alpha=1/14,adjust=False).mean(); dn=(-d.clip(upper=0)).ewm(alpha=1/14,adjust=False).mean()
    rsi=100-100/(1+up/dn); sig=(c/c.shift(7)-1<=TH["r7"])|(c/c.ewm(span=20,adjust=False).mean()-1>=TH["e20"])|(rsi>=TH["rsi"])|((D.c-D.lo)/(D.hi-D.lo)<=TH["cp"])
    S=pd.Series(sig.values,index=sig.index+pd.Timedelta(days=1)+off)
    an=X.te.dt.floor("h"); base=(an-off).dt.floor("D")+off; age=(an-base).dt.total_seconds()/3600
    return base.map(S).fillna(False).astype(bool)&(age<win)
pagi=flag(23,24); malam=flag(11,24); siang=flag(5,24)
sh=X.arah.astype(int)==-1
for nm,ban in (("pagi saja",pagi),("pagi atau malam",pagi|malam),("pagi atau siang atau malam",pagi|siang|malam)):
    r=[]
    for lo_,hi_ in (("2021","2024"),("2024","2027")):
        M=(X.t>=lo_)&(X.t<hi_)
        keep=M&~(sh&ban)
        r.append(f"PF {f(X[keep].Rf.values)} total {X[keep].Rf.sum():.0f}R, SHORT dibuang PF {f(X[M&sh&ban].Rf.values)} n {(M&sh&ban).sum()}")
    print(nm," | ".join(r))

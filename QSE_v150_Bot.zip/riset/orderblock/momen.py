"""Uji jalur MOMENTUM 15 dan 30 menit, aturan robot persis (qse_momentum._cek, _rencana, keluar TP1 separuh lalu SL ke entry,
TP2 2R, LIMIT retest berlaku 2 jam, tahan maks 24 jam), 40 koin perp paling likuid, 2021-2026. Plus variasi filter dan keluar."""
import os, sys, glob, pickle, numpy as np, pandas as pd, numba as nb, warnings
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); import sbt
D15 = os.path.join(HERE, "..", "data15")

@nb.njit(cache=True)
def sim(o, h, l, c, sig, side, e_arr, sl_arr, d_arr, berlaku, tahan, mode):
    """mode 0: aturan robot (LIMIT retest, TP1 separuh + BE, TP2 2R). mode 1: MARKET di close, SL sama, TP 2R penuh.
    mode 2: MARKET, trailing 3x jarak SL dari puncak. Return R (nan = tidak terisi), bar keluar."""
    n = len(c); m = len(sig); R = np.full(m, np.nan); X = np.full(m, -1)
    for k in range(m):
        t = sig[k]; L = side[k] == 1; e = e_arr[k]; sl = sl_arr[k]; dist = d_arr[k]
        t1 = e + dist if L else e - dist; t2 = e + 2 * dist if L else e - 2 * dist
        isi = -1
        if mode == 0:
            for j in range(t + 1, min(n, t + 1 + berlaku)):
                if (L and h[j] >= t1) or ((not L) and l[j] <= t1):
                    break
                if (L and l[j] <= e) or ((not L) and h[j] >= e):
                    isi = j; break
            if isi < 0: continue
        else:
            e = c[t]; isi = t + 1
            sl = e - dist if L else e + dist
            t2 = e + 2 * dist if L else e - 2 * dist
        tp1 = False; r = np.nan; best = e; stop = sl
        akhir = min(n, isi + tahan)
        j = isi
        for j in range(isi, akhir):
            if mode == 0:
                lv = e if tp1 else sl
                if (L and l[j] <= lv) or ((not L) and h[j] >= lv):
                    r = 0.5 if tp1 else -1.0; break
                if (not tp1) and ((L and h[j] >= t1) or ((not L) and l[j] <= t1)):
                    tp1 = True
                if tp1 and ((L and h[j] >= t2) or ((not L) and l[j] <= t2)):
                    r = 1.5; break
            elif mode == 1:
                if (L and l[j] <= sl) or ((not L) and h[j] >= sl):
                    r = -1.0; break
                if (L and h[j] >= t2) or ((not L) and l[j] <= t2):
                    r = 2.0; break
            else:
                if (L and l[j] <= stop) or ((not L) and h[j] >= stop):
                    r = (stop - e) / dist if L else (e - stop) / dist; break
                if L:
                    best = max(best, h[j]); stop = max(stop, best - 3 * dist)
                else:
                    best = min(best, l[j]); stop = min(stop, best + 3 * dist)
        if np.isnan(r):
            g = ((c[j] - e) if L else (e - c[j])) / dist
            r = (0.5 + 0.5 * g) if (mode == 0 and tp1) else g
        R[k] = r - 0.0015 * e / dist; X[k] = j
    return R, X

# bias 4J engine robot (pre_all) per koin, plus BTC
BI = {}
for f in glob.glob(os.path.join(HERE, "..", "pre_all", "*.pkl")):
    s = os.path.basename(f)[:-4]; P = pickle.load(open(f, "rb"))
    BI[s] = pd.Series({k: v.get("bias") for k, v in P.items()})
rows = []
for f in sorted(glob.glob(D15 + "/*_15.csv")):
    s = os.path.basename(f)[:-7]
    d15 = pd.read_csv(f, index_col=0, parse_dates=True)
    for iv, rule in (("15", None), ("30", "30min")):
        d = d15 if rule is None else d15.resample(rule).agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna()
        o, h, l, c, v = (d[k].values.astype(float) for k in ("open", "high", "low", "close", "volume"))
        pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
        atr = pd.Series(tr).shift(1).rolling(14).mean().values
        medv = pd.Series(v).shift(1).rolling(50).median().values
        hh = pd.Series(h).shift(1).rolling(20).max().values; ll = pd.Series(l).shift(1).rolling(20).min().values
        e20 = sbt.ema(c, 20)
        vx = v / np.maximum(medv, 1e-12); badan = abs(c - o)
        ok = (vx >= 3) & (badan >= 1.2 * atr) & (atr > 0)
        up = ok & (c > hh); dn = ok & (c < ll)
        idx = np.nonzero(up | dn)[0]; idx = idx[idx > 60]
        if not len(idx): continue
        side = np.where(up[idx], 1, -1)
        # rencana robot
        e = np.where(side == 1, np.maximum(hh[idx], e20[idx]), np.minimum(ll[idx], e20[idx]))
        bad = ((side == 1) & (e >= c[idx])) | ((side == -1) & (e <= c[idx]))
        e = np.where(bad, np.where(side == 1, c[idx] - 0.5 * atr[idx], c[idx] + 0.5 * atr[idx]), e)
        sl0 = np.where(side == 1, np.minimum(l[idx], e - atr[idx]) - 0.2 * atr[idx], np.maximum(h[idx], e + atr[idx]) + 0.2 * atr[idx])
        dist = np.clip(abs(e - sl0), 1.0 * atr[idx], 2.5 * atr[idx])
        sl = np.where(side == 1, e - dist, e + dist)
        # filter
        per1j = 4 if iv == "15" else 2
        c1h = pd.Series(c, index=d.index).resample("1h").last().dropna()
        tr1 = (c1h > pd.Series(sbt.ema(c1h.values, 20), index=c1h.index))
        tr1.index = tr1.index + pd.Timedelta(hours=1)
        t_close = d.index[idx] + pd.Timedelta(minutes=int(iv))
        tren1 = tr1.reindex(t_close, method="ffill").values
        c4 = pd.Series(c, index=d.index).resample("4h").last().dropna()
        e200 = pd.Series(sbt.ema(c4.values, 200), index=c4.index); t4 = (c4 > e200); t4.index = t4.index + pd.Timedelta(hours=4)
        tren4 = t4.reindex(t_close, method="ffill").values
        bs = BI.get(s)
        if bs is not None:
            bsi = pd.Series(bs.values, index=pd.to_datetime(bs.index.astype("int64"), unit="ms", utc=True) + pd.Timedelta(hours=4))
            bias = bsi.sort_index().reindex(t_close, method="ffill").values
        else:
            bias = np.array([None] * len(idx))
        for mode in (0, 1, 2):
            R, X = sim(o, h, l, c, idx.astype(np.int64), side.astype(np.int64), e, sl, dist, 8 if iv == "15" else 4, 96 if iv == "15" else 48, mode)
            for k in np.nonzero(~np.isnan(R))[0]:
                L = side[k] == 1
                rows.append((s, iv, mode, d.index[idx[k]], int(side[k]), R[k], vx[idx[k]],
                             float(tren1[k] == L) if tren1[k] is not None and tren1[k] == tren1[k] else np.nan,
                             float(tren4[k] == L) if tren4[k] is not None and tren4[k] == tren4[k] else np.nan,
                             (bias[k] == ("LONG" if L else "SHORT")) if bias[k] is not None else np.nan))
    print(s, len(rows), flush=True)
X = pd.DataFrame(rows, columns=["sym", "iv", "mode", "t", "arah", "R", "vx", "tren1", "tren4", "bias"])
X.to_pickle(os.path.join(HERE, "momen.pkl"))

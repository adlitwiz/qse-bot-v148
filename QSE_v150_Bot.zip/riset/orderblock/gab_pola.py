import pandas as pd, numpy as np, warnings, io, contextlib; warnings.filterwarnings("ignore")
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
S = pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
S = S[S["rank"] <= S.jalur.map(LIK).fillna(999)]
Q = pd.read_pickle("pola.pkl")
PIL = {"p_double": ("double", "tp3", lambda Z: (Z.tren == 1) & (Z.btc == 1), 30),
       "p_hns": ("hns", "tp3", lambda Z: (Z.arah == -1) & (Z.tren == 1), 999),
       "p_triangle": ("triangle", "trail", lambda Z: (Z.tren == 1) & (Z.btc == 1), 999),
       "p_wedge": ("wedge", "trail", lambda Z: Z.tren == 1, 30)}
add = []
for nm, (pl, ex, f, lk) in PIL.items():
    Z = Q[(Q.pola == pl) & (Q.ex == ex)]; Z = Z[f(Z) & (Z["rank"] <= lk)].copy()
    Z["jalur"] = nm; Z["Rf"] = Z.R - 0.01
    # satu posisi per koin per jalur
    Z = Z.sort_values("t"); keep = []; last = {}
    for k, r in zip(Z.index, Z.itertuples()):
        if last.get(r.sym) is not None and last[r.sym] > r.t: continue
        keep.append(k); last[r.sym] = r.t_out
    add.append(Z.loc[keep][["jalur", "sym", "t", "t_out", "R", "Rf", "arah", "rank"]])
A = pd.concat([S[["jalur", "sym", "t", "t_out", "R", "Rf", "arah", "rank"]]] + add, ignore_index=True)
A = A[A.t >= "2021-01-01"].sort_values(["t", "rank"]).reset_index(drop=True)
def sim(jalur, cap=8, lemah=("smc_choch", "GZH", "msb_hpz"), nm=""):
    X = A[A.jalur.isin(jalur)]
    op = []; keep = []
    for k, r in zip(X.index, X.itertuples()):
        op = [o for o in op if o[0] > r.t]
        na = sum(o[3] == r.arah for o in op)
        if sum(o[1] == r.jalur for o in op) >= 8 or na >= cap: continue
        if r.jalur in lemah and na >= cap // 2: continue
        if any(o[2] == r.sym for o in op): continue
        op.append((r.t_out, r.jalur, r.sym, r.arah)); keep.append(k)
    P = X.loc[keep].copy(); P["w"] = np.where(P.jalur == "GZH", 0.5, 1.0); P = P.sort_values("t_out")
    eq = pk = 0.0; e = []; rg = 0; ws = []
    for x, w in zip(P.Rf.values, P.w.values):
        risk = 0.5 * w * (0.5 if (pk - eq > 8 * cap / 8 or rg >= 8) else 1)
        eq += x * risk; pk = max(pk, eq); e.append(eq); ws.append(risk); rg = rg + 1 if x < 0 else 0
    P["pnl"] = ws * P.Rf.values
    e = np.array(e); dd = (np.maximum.accumulate(e) - e).max(); dv = P.t < "2024-01-01"
    d1 = P[dv].pnl.cumsum().values; d2 = P[~dv].pnl.cumsum().values
    r1 = P[dv].pnl.sum() / (np.maximum.accumulate(d1) - d1).max(); r2 = P[~dv].pnl.sum() / (np.maximum.accumulate(d2) - d2).max()
    hari = pd.date_range("2021-01-01", "2026-10-10", freq="D", tz="UTC")
    n = (P.t + pd.Timedelta(hours=11)).dt.floor("D").value_counts().reindex(hari, fill_value=0)
    print(f"{nm:40s} {len(P)/2110:.1f}/hari kosong {(n==0).mean()*100:.0f}% PF {pf(P.Rf)} total {e[-1]:+.0f}% DD {dd:.0f}% rasio {e[-1]/dd:.1f} (21-23 {r1:.1f}, 24-26 {r2:.1f})")
    return P
J0 = ["ichimoku", "orderblock", "ema_short", "rsi_vol", "GZH", "snr_vol", "msb_hpz", "smc_choch", "mcginley"]
for nm in PIL:
    Z = A[A.jalur == nm]; dv = Z.t < "2024-01-01"
    print(nm, "sendiri 2021-26 PF", pf(Z.Rf), "n", len(Z))
for cap in (8, 16):
    sim(J0, cap, nm=f"SEKARANG cap {cap}")
    for nm in PIL:
        sim(J0 + [nm], cap, nm=f"+ {nm} cap {cap}")
    sim(J0 + list(PIL), cap, nm=f"+ semua pola cap {cap}")

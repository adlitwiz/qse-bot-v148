import pandas as pd, numpy as np, os, warnings; warnings.filterwarnings("ignore")
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
X = pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = X[(X["rank"] <= X.jalur.map(LIK).fillna(999)) & (X.t >= "2021-01-01")].reset_index(drop=True)
rows = []
for s, Z in X.groupby("sym"):
    f1 = f"../data/{s}_60.csv"
    if not os.path.exists(f1): continue
    h = pd.read_csv(f1, index_col=0, parse_dates=True)
    for r in Z.itertuples():
        t0 = r.t + pd.Timedelta(hours=4); t1 = r.t_out + pd.Timedelta(hours=4)
        if t0 not in h.index: continue
        e = h.open.loc[t0]; risk = e / r.er; sd = r.arah; cost = 0.0015 * r.er
        seg = h.loc[t0:t1 - pd.Timedelta(hours=1)]
        g = (seg.close.values - e) / risk * sd
        out = {"diam": r.Rf}
        for lv in (0.4, 0.7):
            k = np.nonzero(g <= -lv)[0]
            if len(k):
                gg = g[k[0]]
                out[f"setengah_{lv}"] = 0.5 * r.Rf + 0.5 * (gg - cost)
                out[f"keluar_{lv}"] = gg - cost
            else:
                out[f"setengah_{lv}"] = out[f"keluar_{lv}"] = r.Rf
        rows.append(dict(out, t=r.t))
R = pd.DataFrame(rows)
for nm, Z in (("SEMUA", R), ("2021-2023", R[R.t < "2024"]), ("2024-2026", R[R.t >= "2024"])):
    print(nm, {k: (pf(Z[k]), round(Z[k].sum())) for k in R.columns if k != "t"})

import sys, warnings, itertools, pandas as pd, numpy as np
warnings.filterwarnings("ignore"); sys.path.insert(0, ".")
import sim
X = pd.read_pickle("setups.pkl"); X = X[(X.t >= "2020-07-01") & (X.jenis == "obf") & (X.thr == 2.0) & (X.tren == 1)]
def pf(r): return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 3)
for vp, rk, fl in itertools.product((70, 80, 90), (150, 50, 30), (-9, 0)):
    g = X[(X.vp >= vp) & (X["rank"] <= rk) & (X.flow > fl)]
    Y = sim.jalan(g, 0.3, 6, 4.0, 60, True); dv = Y.t_in < "2024-01-01"
    yr = Y.groupby(Y.t_in.dt.year).R.apply(pf).round(2).to_dict()
    print(vp, rk, fl, "dev", len(Y[dv]), pf(Y[dv].R.values), "test", len(Y[~dv]), pf(Y[~dv].R.values), yr, flush=True)

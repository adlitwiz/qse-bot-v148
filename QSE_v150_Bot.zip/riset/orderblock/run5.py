import pandas as pd, numpy as np, os
X=pd.read_pickle("semua_f.pkl")
LIK={"rsi_vol":30,"snr_vol":30,"msb_hpz":30,"smc_choch":30,"ichimoku":20,"orderblock":50}
X=X[(X["rank"]<=X.jalur.map(LIK).fillna(999))&(X.t>="2021-01-01")]
TPR={"snr_vol":3.0,"smc_choch":3.0,"mcginley":4.0,"orderblock":4.0}
TRL={"ichimoku":4.0,"ema_short":4.0,"msb_hpz":4.0,"rsi_vol":3.0,"GZH":3.0}
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
rows=[]
for s,Z in X.groupby("sym"):
    p=f"../data/{s}_60.csv"
    if not os.path.exists(p): continue
    h=pd.read_csv(p,index_col=0,parse_dates=True); ix=h.index; O,H,L,C=(h[c].values for c in ("open","high","low","close"))
    for r in Z.itertuples():
        k0=ix.searchsorted(r.t+pd.Timedelta(hours=4))
        if k0>=len(ix) or ix[k0]!=r.t+pd.Timedelta(hours=4): continue
        e=O[k0]; risk=e/r.er; d=r.arah; atr=risk/2.0; cost=0.0015*e
        end=min(k0+240,len(ix))
        def run(mode,trig=None,trk=None):
            sl=e-d*risk; best=e; aktif=False
            tp=e+d*TPR[r.jalur]*risk if r.jalur in TPR else None
            tr0=TRL.get(r.jalur)
            for j in range(k0,end):
                hi,lo=H[j],L[j]
                if (lo<=sl if d==1 else hi>=sl): return (sl-e)*d
                if tp is not None and not aktif and (hi>=tp if d==1 else lo<=tp): return (tp-e)*d
                best=max(best,hi) if d==1 else min(best,lo)
                gain=(best-e)*d
                if mode=="pindah" and not aktif:
                    if (trig[0]=="pct" and gain>=trig[1]*e) or (trig[0]=="R" and gain>=trig[1]*risk): aktif=True
                if tr0 is not None and (j-k0)%4==3 and not (mode=="pindah" and aktif):   # trailing jalur dicek tiap candle 4J
                    sl=max(sl,best-tr0*atr) if d==1 else min(sl,best+tr0*atr)
                if aktif:
                    dist=trk[1]*e if trk[0]=="pct" else trk[1]*atr
                    sl=max(sl,best-dist) if d==1 else min(sl,best+dist)
            return (C[end-1]-e)*d
        o=dict(jalur=r.jalur,t=r.t,base=(run("base")-cost)/risk)
        for tn,trig in (("5%",("pct",0.05)),("2R",("R",2.0))):
            for kn,trk in (("trail3%",("pct",0.03)),("trail5%",("pct",0.05)),("trail2ATR",("atr",2.0)),("trail3ATR",("atr",3.0))):
                o[f"{tn}_{kn}"]=(run("pindah",trig,trk)-cost)/risk
        rows.append(o)
R=pd.DataFrame(rows); R.to_pickle("run5.pkl")
cols=[c for c in R.columns if c not in ("jalur","t")]
for grup,Z in (("JALUR TP",R[R.jalur.isin(TPR)]),("JALUR TRAILING",R[R.jalur.isin(TRL)])):
    print(grup)
    for c in cols:
        print(f"  {c:18s} PF {f(Z[c].values)} dev {f(Z[Z.t<'2024'][c].values)} uji {f(Z[Z.t>='2024'][c].values)} total {Z[c].sum():.0f}R exp {Z[c].mean():.3f}")

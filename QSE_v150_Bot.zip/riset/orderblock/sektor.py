import pandas as pd, numpy as np, os
X=pd.read_pickle("semua_f.pkl")
LIK={"rsi_vol":30,"snr_vol":30,"msb_hpz":30,"smc_choch":30,"ichimoku":20,"orderblock":50}
X=X[(X["rank"]<=X.jalur.map(LIK).fillna(999))&(X.t>="2021-01-01")].copy()
S={}
for sec,cs in {"L1":"ADA ALGO APT ATOM AVAX BCH CELO CFX CKB DOT EGLD ETC HBAR ICP ICX IOTA KAVA KSM LTC MINA NEAR NEO ONE ONT QTUM ROSE SEI SOL SUI TRX VET XLM XRP XTZ ZIL DASH RVN ZEC TIA INJ",
 "L2":"ARB OP IMX LRC SKL STX","DEFI":"1INCH AAVE COMP CRV DYDX GMX JUP KNC LDO PENDLE SNX SUSHI UNI YFI ZRX RUNE ENA WOO UMA",
 "ORACLE":"API3 BAND LINK PYTH TRB GRT","MEME":"1000BONK 1000FLOKI 1000PEPE 1000SHIB DOGE WIF","AI":"FET WLD NMR ARPA IOTX",
 "GAME":"ALICE APE AXS ENJ GALA GMT MANA SAND HOOK CHZ THETA","DEPIN":"AR FIL STORJ ANKR JASMY"}.items():
    for c in cs.split(): S[c+"USDT"]=sec
cl={}
for s in X.sym.unique():
    p=f"../data/{s}_60.csv"
    if os.path.exists(p): cl[s]=pd.read_csv(p,index_col=0,parse_dates=True).close.resample("4h").last()
C=pd.DataFrame(cl).ffill(limit=6)
r7=C.pct_change(42,fill_method=None); r30=C.pct_change(180,fill_method=None)
mkt7=r7.mean(axis=1)
sec7={}
for sec in set(S.values()):
    cols=[c for c in C.columns if S.get(c)==sec]
    sec7[sec]=r7[cols].mean(axis=1)-mkt7
X["sec"]=X.sym.map(S)
def get(df,s,t):
    try: return df.at[t,s]
    except KeyError: return np.nan
X["rs_sec"]=[sec7[s].get(t,np.nan) if isinstance(s,str) else np.nan for s,t in zip(X.sec,X.t)]
rk30=r30.rank(axis=1,pct=True)
X["rk30"]=[get(rk30,s,t) for s,t in zip(X.sym,X.t)]
X["r30"]=[get(r30,s,t) for s,t in zip(X.sym,X.t)]
X["d"]=X.arah.astype(int)
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
def st(nm,m):
    Z=X[m]; a=Z[Z.t<"2024"]; b=Z[Z.t>="2024"]
    print(f"{nm:44s} n {len(a):5d}/{len(b):5d} PF {f(a.Rf.values)}/{f(b.Rf.values)} exp {a.Rf.mean():+.3f}/{b.Rf.mean():+.3f}")
st("semua",X.R.notna())
for d,nm in ((1,"LONG"),(-1,"SHORT")):
    m=X.d==d
    st(f"{nm} sektor kuat (rel7 > +3%)",m&(X.rs_sec>0.03)); st(f"{nm} sektor netral",m&X.rs_sec.between(-0.03,0.03)); st(f"{nm} sektor lemah (< -3%)",m&(X.rs_sec<-0.03))
    st(f"{nm} searah sektor",m&(np.sign(X.rs_sec)==d)); st(f"{nm} lawan sektor",m&(np.sign(X.rs_sec)==-d))
    for lo,hi,lab in ((0,.2,"30h paling lemah 20%"),(.2,.8,"tengah"),(.8,.95,"30h top 20-5%"),(.95,1.01,"30h top 5% (sudah melesat)")):
        st(f"{nm} {lab}",m&(X.rk30>=lo)&(X.rk30<hi))
    st(f"{nm} r30 > +50%",m&(X.r30>0.5)); st(f"{nm} r30 > +100%",m&(X.r30>1.0))
X.to_pickle("sektor.pkl")

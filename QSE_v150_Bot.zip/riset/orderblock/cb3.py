import pandas as pd, numpy as np, os
R=pd.read_pickle("cb2.pkl")
A=pd.read_pickle("semua_f.pkl"); A=A[A.t>="2020-06-01"]
P=pd.read_pickle("pola.pkl"); P=P[P.ex==P.ex.iloc[0]]
W=pd.Timedelta(hours=72)
ar={r:a for r,a in zip(range(len(R)),[0]*len(R))}
# arah trade dari A (gabung)
R=R.merge(A[["jalur","sym","t","arah"]].drop_duplicates(["jalur","sym","t"]),on=["jalur","sym","t"],how="left")
ob,gz,pat,pats=[],[],[],[]
cand={k:[] for k in ("engulf","pin","besar","inside")}
for s,Z in R.groupby("sym"):
    As=A[A.sym==s]; Ps=P[P.sym==s]
    p=f"../data/{s}_240.csv"; h=pd.read_csv(p,index_col=0,parse_dates=True)
    o,hi,lo,c=(h[x].values for x in ("open","high","low","close")); ix=h.index
    for r in Z.itertuples():
        m=(As.arah==r.arah)&(As.t>=r.t-W)&(As.t<=r.t)
        ob.append((r.Index,int(((As.jalur=="orderblock")&m).any()) and r.jalur!="orderblock"))
        gz.append((r.Index,int(((As.jalur=="GZH")&m).any()) and r.jalur!="GZH"))
        mp=(Ps.arah==r.arah)&(Ps.t>=r.t-W)&(Ps.t<=r.t)
        pat.append((r.Index,int(mp.any()))); pats.append((r.Index,",".join(sorted(set(Ps[mp].pola)))))
        k=ix.searchsorted(r.t)
        if k>=len(ix) or ix[k]!=r.t or k<1: 
            for kk in cand: cand[kk].append((r.Index,0)); continue
        d=r.arah; body=(c[k]-o[k])*d; rng=hi[k]-lo[k] or 1e-12
        pb=(c[k-1]-o[k-1])*d
        cand["engulf"].append((r.Index,int(body>0 and pb<0 and abs(c[k]-o[k])>abs(c[k-1]-o[k-1]))))
        ekor=(min(o[k],c[k])-lo[k]) if d==1 else (hi[k]-max(o[k],c[k]))
        cand["pin"].append((r.Index,int(ekor>=0.6*rng)))
        cand["besar"].append((r.Index,int(body>=0.7*rng)))
        cand["inside"].append((r.Index,int(hi[k]<=hi[k-1] and lo[k]>=lo[k-1])))
for nm,v in (("ob",ob),("gzh",gz),("pola",pat),("pola_n",pats)): R[nm]=pd.Series(dict(v))
for kk,v in cand.items(): R[kk]=pd.Series(dict(v))
R.to_pickle("cb3.pkl")
hari=(R.t.max()-R.t.min()).days
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
def st(Z): return f"n/hari {len(Z)/hari:5.2f} PF {f(Z.R.values)} dev {f(Z[Z.t<'2024'].R.values)} uji {f(Z[Z.t>='2024'].R.values)}"
print("semua", st(R)); print("cb72>=1",st(R[R.cb72>=1])); print("cb72==0",st(R[R.cb72==0]))
for c in ("ob","gzh","pola","engulf","pin","besar","inside"):
    print(c,"ya",st(R[R[c]==1]),"| tidak",st(R[R[c]==0]))
    print("   tanpa combo jalur, ya:",st(R[(R[c]==1)&(R.cb72==0)]))
for p in ("double","hns","triangle","wedge","div_rsi"):
    print(p,st(R[R.pola_n.str.contains(p)]))

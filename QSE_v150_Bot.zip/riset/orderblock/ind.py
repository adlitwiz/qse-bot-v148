import pandas as pd, numpy as np
def rd(p): return pd.read_csv(p,index_col=0,parse_dates=True)
a=rd("../data17/BTCUSDT_240.csv"); b=rd("../data/BTCUSDT_240.csv")
h4=pd.concat([a,b[b.index>a.index[-1]]])[["open","high","low","close","volume"]]
h4=h4[~h4.index.duplicated()]
def rs(df,rule,**k):
    return df.resample(rule,label="left",closed="left",**k).agg({"open":"first","high":"max","low":"min","close":"last","volume":"sum"}).dropna()
d1=rs(h4,"1D"); w1=rs(h4,"W-MON")
def ema(x,n): return x.ewm(span=n,adjust=False).mean()
def mcg(c,n=34):
    m=np.empty(len(c)); m[0]=c.iloc[0]
    v=c.values
    for i in range(1,len(v)): m[i]=m[i-1]+(v[i]-m[i-1])/(n*(v[i]/m[i-1])**4)
    return pd.Series(m,c.index)
def ind(df):
    c,h,l=df.close,df.high,df.low; o=pd.DataFrame(index=df.index)
    o["ema50"]=np.sign(c-ema(c,50)); o["ema200"]=np.sign(c-ema(c,200)); o["e2050"]=np.sign(ema(c,20)-ema(c,50))
    m=mcg(c); o["mcg"]=np.sign(m-m.shift(3))
    tk=(h.rolling(9).max()+l.rolling(9).min())/2; kj=(h.rolling(26).max()+l.rolling(26).min())/2
    sa=((tk+kj)/2).shift(26); sb=((h.rolling(52).max()+l.rolling(52).min())/2).shift(26)
    o["ichi"]=np.where(c>np.maximum(sa,sb),1,np.where(c<np.minimum(sa,sb),-1,0))
    d=c.diff(); up=d.clip(lower=0).ewm(alpha=1/14,adjust=False).mean(); dn=(-d.clip(upper=0)).ewm(alpha=1/14,adjust=False).mean()
    rsi=100-100/(1+up/dn); o["rsi"]=np.sign(rsi-50); o["rsi_v"]=rsi
    mac=ema(c,12)-ema(c,26); o["macd"]=np.sign(mac-ema(mac,9))
    tr=pd.concat([h-l,(h-c.shift()).abs(),(l-c.shift()).abs()],axis=1).max(axis=1); atr=tr.ewm(alpha=1/10,adjust=False).mean()
    hl=(h+l)/2; ub=hl+3*atr; lb=hl-3*atr; st=np.zeros(len(c)); fu=ub.values.copy(); fl=lb.values.copy(); cv=c.values
    for i in range(1,len(c)):
        fu[i]=min(ub.iloc[i],fu[i-1]) if cv[i-1]<=fu[i-1] else ub.iloc[i]
        fl[i]=max(lb.iloc[i],fl[i-1]) if cv[i-1]>=fl[i-1] else lb.iloc[i]
        st[i]=1 if cv[i]>fu[i-1] else -1 if cv[i]<fl[i-1] else st[i-1]
    o["st"]=st
    pdm=(h.diff()).where((h.diff()>-l.diff())&(h.diff()>0),0); ndm=(-l.diff()).where((-l.diff()>h.diff())&(-l.diff()>0),0)
    a14=tr.ewm(alpha=1/14,adjust=False).mean(); o["dmi"]=np.sign(pdm.ewm(alpha=1/14,adjust=False).mean()/a14-ndm.ewm(alpha=1/14,adjust=False).mean()/a14)
    K=["ema50","ema200","e2050","mcg","ichi","rsi","macd","st","dmi"]
    o["skor"]=o[K].sum(axis=1); o["close"]=c
    return o
I4,ID,IW=ind(h4),ind(d1),ind(w1)
# selaraskan ke tiap close 4H: pakai bar D/W yang sudah tutup
t=h4.index+pd.Timedelta(hours=4)   # waktu close 4H
def asof(I,dur):
    x=I.copy(); x.index=x.index+dur   # waktu close bar
    return x.reindex(t,method="ffill")
A=pd.DataFrame(index=t)
A["c"]=h4.close.values
for nm,I,dur in (("h4",I4,pd.Timedelta(hours=4)),("d",ID,pd.Timedelta(days=1)),("w",IW,pd.Timedelta(days=7))):
    x=asof(I,dur); A[nm]=x.skor.values; A[nm+"_rsi"]=x.rsi_v.values
for hz,n in (("f1",6),("f3",18),("f7",42),("f30",180)):
    A[hz]=A.c.shift(-n)/A.c-1
A=A[A.index>="2018-08-01"].dropna(subset=["w","d","h4"])
A.to_pickle("A.pkl"); print(len(A),A.index[0],A.index[-1])

import pandas as pd, numpy as np, os
X = pd.read_pickle("semua.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = X[X["rank"] <= X.jalur.map(LIK).fillna(999)].copy()
D = "../data"
# funding: biaya dalam R. LONG bayar rate positif, SHORT terima.
fr = {}
for s in X.sym.unique():
    f = f"{D}/{s}_FUND.csv"
    if os.path.exists(f):
        F = pd.read_csv(f); fr[s] = (F.ts.values, np.cumsum(F.rate.values))
def fcost(r):
    if r.sym not in fr: return 0.0
    ts, cs = fr[r.sym]; a = r.t.value // 10**6 + 4 * 3600000; b = r.t_out.value // 10**6 + 4 * 3600000
    i, j = np.searchsorted(ts, a, "right"), np.searchsorted(ts, b, "right")
    tot = (cs[j - 1] if j > 0 else 0) - (cs[i - 1] if i > 0 else 0)
    return r.arah * tot * r.er
X["fund"] = [fcost(r) for r in X.itertuples()]
X["Rf"] = X.R - X.fund
X.to_pickle("semua_f.pkl")
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
X5 = X[X.t >= "2021-01-01"]
print("FUNDING per jalur (2021-2026): PF tanpa / dengan funding, rata funding R")
for jl, Z in X5.groupby("jalur"):
    print(f"{jl:11s} {pf(Z.R)} -> {pf(Z.Rf)}  funding rata {Z.fund.mean():+.3f}R  LONG {Z[Z.arah==1].fund.mean():+.3f} SHORT {Z[Z.arah==-1].fund.mean():+.3f}")

"""Apakah backtest per pola per koin di dasbor (win, loss, WR, PF dari sejarah SEBELUM candle itu) memprediksi trade berikutnya?
108 koin perp, Jul 2021 - Okt 2026. Semua saran dasbor (status apa pun) diuji dengan level dasbor sendiri."""
import pickle, glob, os, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
H4 = 4 * 3600000
rows = []
for f in sorted(glob.glob("pre_all/*.pkl")):
    s = os.path.basename(f)[:-4]
    P = pickle.load(open(f, "rb"))
    d = pd.read_csv(f"data/{s}_240.csv", index_col=0, parse_dates=True)
    t4 = d.index.as_unit("ms").asi8; o, h, l, c = (d[k].values for k in ("open", "high", "low", "close"))
    import smc.smc_core as KC
    A = KC.atr(h, l, c)
    seen = set()
    for T in sorted(P):
        r = P[T]
        for x in r["saran"]:
            k = (x["pola"], x["arah"], x.get("idx"), round(x["entry"], 8))
            if k in seen: continue
            seen.add(k)
            j0 = np.searchsorted(t4, T + H4)          # candle setelah candle laporan tutup
            if j0 >= len(c) - 1: continue
            L = x["arah"] == "LONG"; sg = 1 if L else -1
            if x["order"] == "TUNGGU": continue
            mk = x["order"] == "MARKET"; stp = x["order"] in ("CONDITIONAL STOP", "STOP")
            e = o[j0] if mk else x["entry"]; sl, t1, t2 = x["sl"], x["tp1"], x["tp2"]
            risk = (e - sl) * sg
            if risk <= 0 or (t1 - e) * sg <= 0: continue
            f_ = j0 if mk else None
            if not mk:
                for j in range(j0, min(len(c), j0 + 6)):
                    if stp:
                        if (c[j] > e) if L else (c[j] < e):
                            if j + 1 < len(c): f_ = j + 1; e = o[j + 1]
                            break
                        continue
                    if (l[j] <= e) if L else (h[j] >= e): f_ = j; break
                    if (h[j] >= t1) if L else (l[j] <= t1): break
            if f_ is None: continue
            risk = (e - sl) * sg
            if risk <= 0 or (t1 - e) * sg <= 0: continue
            res = None; tp1 = False; stop = sl
            for j in range(f_, min(len(c), f_ + 60)):
                if (l[j] <= stop) if L else (h[j] >= stop):
                    res = 0.5 * (t1 - e) * sg / risk if tp1 else -1.0; break
                if not tp1 and ((h[j] >= t1) if L else (l[j] <= t1)): tp1 = True; stop = e
                if tp1 and ((h[j] >= t2) if L else (l[j] <= t2)):
                    res = 0.5 * (t1 - e) * sg / risk + 0.5 * (t2 - e) * sg / risk; break
            if res is None:
                if f_ + 60 > len(c): continue
                g = (c[f_ + 59] - e) * sg / risk
                res = 0.5 * (t1 - e) * sg / risk + 0.5 * g if tp1 else g
            res -= 0.0015 * e / risk
            n = x.get("win", 0) + x.get("loss", 0)
            alt = {}
            for nmR, RR in (("R1", 1.0), ("R1.5", 1.5), ("R2", 2.0), ("R3", 3.0)):
                rr_ = None
                for j in range(f_, min(len(c), f_ + 60)):
                    if (l[j] <= sl) if L else (h[j] >= sl): rr_ = -1.0; break
                    if j > f_ and ((h[j] >= e + RR * risk) if L else (l[j] <= e - RR * risk)): rr_ = RR; break
                if rr_ is None: rr_ = (c[min(len(c) - 1, f_ + 59)] - e) * sg / risk
                alt[nmR] = rr_ - 0.0015 * e / risk
            st_ = sl; best = e; rr_ = None
            for j in range(f_, min(len(c), f_ + 60)):
                if (l[j] <= st_) if L else (h[j] >= st_): rr_ = (st_ - e) * sg / risk; break
                best = max(best, h[j]) if L else min(best, l[j])
                if not np.isnan(A[j]): st_ = max(st_, best - 3 * A[j]) if L else min(st_, best + 3 * A[j])
            if rr_ is None: rr_ = (c[min(len(c) - 1, f_ + 59)] - e) * sg / risk
            alt["trail"] = rr_ - 0.0015 * e / risk
            rows.append(dict(sym=s, t=pd.Timestamp(T, unit="ms"), pola=x["pola"], arah=x["arah"], status=x["status"], mutu=x.get("mutu"),
                             n=n, wr=x.get("wr", 0), pf=x.get("pf", 0), rapor=r["rapor"], R=res, masuk=bool(x.get("sudah_masuk")), sentuh=bool(x.get("tersentuh")), eks=bool(x.get("eksekusi")), tp1k=bool(x.get("tp1_kena")), slk=bool(x.get("sl_kena")), ev=x.get("ev"), mk=mk, **alt))
    print(s, len(rows), flush=True)
X = pd.DataFrame(rows); X.to_pickle("btdas2.pkl"); print(len(X))

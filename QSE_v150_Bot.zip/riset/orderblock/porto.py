import pandas as pd, numpy as np
X = pd.read_pickle("hasil.pkl"); X = X[X.t >= "2020-07-01"].copy()
X["t_out"] = X.t + pd.to_timedelta((X.hold + 1) * 4, unit="h")
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
def porto(Z, cap=8, nm=""):
    Z = Z.sort_values(["t", "rank"]); op = []; keep = []
    for k, r in zip(Z.index, Z.itertuples()):
        op = [t for t in op if t > r.t]
        if len(op) >= cap: continue
        op.append(r.t_out); keep.append(k)
    P = Z.loc[keep].sort_values("t_out")
    eq = peak = 0.0; rg = 0; out = []; mx = 0; s_ = 0
    for x in P.R.values:
        risk = 0.25 if (peak - eq > 8 or rg >= 6) else 0.5
        eq += x * risk; peak = max(peak, eq); out.append(eq); rg = rg + 1 if x < 0 else 0
    e = np.array(out); dd = (np.maximum.accumulate(e) - e).max()
    q = P.groupby(P.t.dt.to_period("Q")).R.sum()
    dv = P.t < "2024-01-01"
    print(f"{nm:28s} n={len(P)} /hari {len(P)/2290:.2f} WR {(P.R>0).mean()*100:.0f}% PF {pf(P.R)} dev {pf(P[dv].R)} uji {pf(P[~dv].R)} "
          f"total {e[-1]:+.0f}% DD {dd:.1f}% kuartal+ {(q>0).sum()}/{len(q)} th {P.groupby(P.t.dt.year).R.apply(pf).to_dict()}")
    return P
C = {"vol_breakout SHORT+btc": (X.strat == "vol_breakout") & (X.arah == -1) & (X.btc == 1),
     "ema20x50 SHORT+btc": (X.strat == "ema20x50") & (X.arah == -1) & (X.btc == 1),
     "rsi_cross50 vp80": (X.strat == "rsi_cross50") & (X.vp >= 80),
     "supertrend tren+btc": (X.strat == "supertrend") & (X.tren == 1) & (X.btc == 1),
     "donchian55 SHORT+btc": (X.strat == "donchian55") & (X.arah == -1) & (X.btc == 1)}
for nm, m in C.items():
    porto(X[m], 8, nm)
    porto(X[m & (X["rank"] <= 30)], 8, nm + " top30")
for nm in ("rsi_cross50 vp80",):
    Z = X[C[nm]]
    for a in (1, -1): print(nm, a, pf(Z[(Z.arah == a) & (Z.t < "2024")].R), pf(Z[(Z.arah == a) & (Z.t >= "2024")].R))

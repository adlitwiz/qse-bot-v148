"""Bangkitkan semua setup OB/MSB/SMC/SnR di 111 koin 4J 2020-2026 + fitur kausal. Simpan setups.pkl"""
import os, sys, numpy as np, pandas as pd, time
sys.path.insert(0, os.path.dirname(__file__))
import smc_core as K
D = os.path.join(os.path.dirname(__file__), "..", "data")
SYMS = sorted(f[:-8] for f in os.listdir(D) if f.endswith("_240.csv"))
def ld(s): return pd.read_csv(f"{D}/{s}_240.csv", index_col=0, parse_dates=True)
b = ld("BTCUSDT"); be = K.ema(b.close.values, 50)
btc_up = pd.Series(b.close.values > be, index=b.index)
tv = {}; rows = []; arr = {}
t0 = time.time()
for s in SYMS:
    df = ld(s); o, h, l, c, v = (df[k].values.astype(float) for k in ("open", "high", "low", "close", "volume"))
    tv[s] = pd.Series(c * v, index=df.index).rolling(180, min_periods=60).sum()
    f = K.fitur(o, h, l, c, v)
    arr[s] = (df.index, o, h, l, c, f["atr"])
    st = []
    for thr in (0.0, 1.0, 2.0):
        st += [x + ({"thr": thr},) for x in K.obf(o, h, l, c, 5, thr)]
    st += K.msb(o, h, l, c, v, 7, 0.5, f["vp"])
    st += K.smc(o, h, l, c, 5, 50)
    st += [x + ({},) for x in K.snr(h, l, c, 20)]
    bu = btc_up.reindex(df.index).ffill().values
    for i, ar, top, bot, jn, ex in st:
        if i < 210 or i >= len(c) - 1 or np.isnan(f["atr"][i]): continue
        r = dict(sym=s, i=i, t=df.index[i], arah=ar, top=top, bot=bot, jenis=jn, atr=f["atr"][i], c=c[i],
                 vp=f["vp"][i], rv=f["rv"][i], flow=f["flow"][i] * ar, tren=float((c[i] > f["e200"][i]) == (ar == 1)),
                 btc=float(bu[i] == (ar == 1)) if not pd.isna(bu[i]) else 0.5)
        r.update(ex); rows.append(r)
    print(s, len(rows), round(time.time() - t0), flush=True)
X = pd.DataFrame(rows)
TV = pd.DataFrame(tv); RK = TV.rank(axis=1, ascending=False)
X["rank"] = [RK.at[t, s] for t, s in zip(X.t, X.sym)]
X.to_pickle(os.path.join(os.path.dirname(__file__), "setups.pkl"))
pd.to_pickle(arr, os.path.join(os.path.dirname(__file__), "arr.pkl"))
print(X.groupby("jenis").size())

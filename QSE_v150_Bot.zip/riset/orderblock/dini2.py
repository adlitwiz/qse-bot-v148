"""Uji peringatan dini: BTC 1J (close vs EMA20) berbalik melawan posisi jalur terbukti.
A geser SL ke entry kalau sedang untung, B tutup setengah, C tutup penuh. Dibanding diam ikut aturan jalur."""
import pandas as pd, numpy as np, os, warnings; warnings.filterwarnings("ignore")
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
X = pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = X[(X["rank"] <= X.jalur.map(LIK).fillna(999)) & (X.t >= "2021-01-01")].reset_index(drop=True)
D = "../data"
b = pd.read_csv(f"{D}/BTCUSDT_60.csv", index_col=0, parse_dates=True).close
bn = (b > b.ewm(span=20, adjust=False).mean())          # di index open candle, diketahui saat candle tutup (+1 jam)
bn.index = bn.index + pd.Timedelta(hours=1)
flip = bn[bn != bn.shift()].iloc[1:]                     # waktu ganti arah
rows = []
cache = {}
for s, Z in X.groupby("sym"):
    f1 = f"{D}/{s}_60.csv"
    if not os.path.exists(f1): continue
    h = pd.read_csv(f1, index_col=0, parse_dates=True)
    for r in Z.itertuples():
        t0 = r.t + pd.Timedelta(hours=4); t1 = r.t_out + pd.Timedelta(hours=4)
        if t0 not in h.index: continue
        e = h.open.loc[t0]; risk = e / r.er; L = r.arah == 1
        fl = flip[(flip.index > t0) & (flip.index < t1) & (flip.values != L)]
        A = B = C = r.Rf; A5 = A10 = r.Rf; ada = len(fl) > 0; untung = False
        if ada:
            tf = fl.index[0]
            px = h.close.asof(tf - pd.Timedelta(hours=1))      # close candle 1J yang baru tutup
            g = (px - e) / risk * (1 if L else -1); cost = 0.0015 * r.er
            B = 0.5 * r.Rf + 0.5 * (g - cost)
            C = g - cost
            if g > 0:
                untung = True
                seg = h.loc[tf:t1 - pd.Timedelta(hours=1)]
                kena = (seg.low <= e).any() if L else (seg.high >= e).any()
                if kena:
                    A = -cost
                    if g >= 0.5: A5 = -cost
                    if g >= 1.0: A10 = -cost
        rows.append((r.jalur, r.t, ada, untung, r.Rf, A, A5, A10, B, C))
R = pd.DataFrame(rows, columns=["jalur", "t", "kena_flip", "untung", "diam", "A_sl_entry", "A_untung05R", "A_untung1R", "B_setengah", "C_tutup"])
print(f"trade {len(R)}, kena BTC 1J berbalik melawan {R.kena_flip.mean()*100:.0f}%, saat itu untung {R.untung.mean()*100:.0f}%")
for nm, Z in (("SEMUA", R), ("2021-2023", R[R.t < "2024"]), ("2024-2026", R[R.t >= "2024"])):
    print(nm, {k: (pf(Z[k]), round(Z[k].sum())) for k in ("diam", "A_sl_entry", "A_untung05R", "A_untung1R", "B_setengah", "C_tutup")})
print("per jalur PF diam vs A:", {j: (pf(z.diam), pf(z.A_sl_entry)) for j, z in R.groupby("jalur")})

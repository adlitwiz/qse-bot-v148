import sys, warnings, pandas as pd, numpy as np
warnings.filterwarnings("ignore"); sys.path.insert(0, ".")
import sim
X = pd.read_pickle("setups.pkl"); X = X[X.t >= "2020-07-01"]
cfg = {"obf": (X[(X.jenis == "obf") & (X.thr == 2.0)], 0.3), "msb": (X[X.jenis == "msb"], 0.6),
       "smc": (X[X.jenis == "smc"], 0.6), "snr": (X[X.jenis == "snr"], 0.3)}
T = {}
for jn, (g, buf) in cfg.items():
    Y = sim.jalan(g, buf, 6, 3.0, 60, True); T[jn] = Y
pd.to_pickle(T, "base.pkl")
def pf(r): return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 3)
for jn, Y in T.items():
    print("=====", jn)
    dv = Y.t_in < "2024-01-01"
    def row(nm, m):
        a = Y[m & dv].R.values; b = Y[m & ~dv].R.values
        print(f"{nm:28s} dev n={len(a):5d} pf={pf(a)}  test n={len(b):5d} pf={pf(b)}")
    row("semua", Y.R.notna())
    for k in ("rank",):
        for n in (20, 50): row(f"rank<={n}", Y[k] <= n)
    for q in (50, 80, 95): row(f"vp>={q}", Y.vp >= q)
    row("vp<50", Y.vp < 50)
    for q in (1.5, 2.5): row(f"rv>={q}", Y.rv >= q)
    row("flow>0", Y.flow > 0); row("flow>0.1", Y.flow > 0.1); row("flow<0", Y.flow < 0)
    row("tren", Y.tren == 1); row("lawan tren", Y.tren == 0)
    row("btc", Y.btc == 1); row("lawan btc", Y.btc == 0)
    row("LONG", Y.arah == 1); row("SHORT", Y.arah == -1)
    if jn == "msb": row("hpz skor>80", Y.skor > 80)
    if jn == "smc":
        row("choch", Y.tag == "choch"); row("bos", Y.tag == "bos"); row("swing searah", Y.swing == 1)
        row("discount/premium", ((Y.arah == 1) & (Y.c < Y.eq)) | ((Y.arah == -1) & (Y.c > Y.eq)))

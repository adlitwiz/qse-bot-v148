import pandas as pd, numpy as np, glob, os
C={}
for d in ("data17","data"):
    for f in glob.glob(f"{d}/*_D.csv"):
        s=os.path.basename(f).split("_")[0]; x=pd.read_csv(f,index_col=0,parse_dates=True).close
        C[s]=pd.concat([C[s],x]) if s in C else x
C=pd.DataFrame({k:v[~v.index.duplicated(keep="last")].sort_index() for k,v in C.items()})
r=C.pct_change(fill_method=None); b=r.pop("BTCUSDT"); alt=r.clip(-0.5,0.5).mean(axis=1)
rel=(1+alt.fillna(0)).cumprod()/(1+b.fillna(0)).cumprod()
turun=(rel>rel.ewm(span=20,adjust=False).mean()).astype(int)   # 1 = alt/BTC di atas EMA20 = BTC.D proxy turun
# state hari D dipakai mulai hari D+1
st=turun.shift(1)
A=pd.read_pickle("strat/semua_f.pkl"); E=pd.read_pickle("strat/era17.pkl")
T=pd.concat([E.assign(src="17"),A.assign(src="20")],ignore_index=True)
T["t"]=pd.to_datetime(T.t,utc=True)
T["hari"]=T.t.dt.floor("D")
T["dom_turun"]=st.reindex(T.hari).values
def pf(x):
    x=np.asarray(x); n=-x[x<0].sum(); return x[x>0].sum()/n if n>0 else np.nan
P=[("2017-20",T.t<"2021"),("2021-23",(T.t>="2021")&(T.t<"2024")),("2024-26",T.t>="2024")]
for arah in (-1,1):
    for nm,m in (("dom turun",T.dom_turun==1),("dom naik",T.dom_turun==0)):
        s=[]
        for pn,pm in P:
            x=T[pm&(T.arah==arah)&m].R
            s.append(f"{pn} n{len(x):5d} PF {pf(x):.2f} exp {x.mean():+.3f}")
        print(f"{arah:+d} {nm:9s} | "+" | ".join(s))
# per jalur SHORT
print()
for j in sorted(T.jalur.unique()):
    s=[]
    for nm,m in (("turun",T.dom_turun==1),("naik",T.dom_turun==0)):
        for pn,pm in P:
            x=T[pm&(T.arah==-1)&m&(T.jalur==j)].R
            s.append(f"{pn[:4]} {nm[:1]} {len(x):4d} {pf(x):.2f}")
    print(f"{j:11s} "+" ".join(s))
# saat ini
print("rel terakhir", rel.index[-1], "turun?", turun.iloc[-1])

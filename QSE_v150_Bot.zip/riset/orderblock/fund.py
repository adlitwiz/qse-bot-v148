import pandas as pd, numpy as np
A=pd.read_pickle("A.pkl")
D=A[A.index.hour==0].copy()   # sekali per hari, close 00 UTC
f=pd.read_csv("../fng.csv",skiprows=4,names=["d","v","k"],on_bad_lines="skip")
f=f[pd.to_numeric(f.v,errors="coerce").notna()]; f["d"]=pd.to_datetime(f.d,format="%d-%m-%Y",utc=True); f["v"]=f.v.astype(int)
f=f.set_index("d").v.sort_index()
D["fng"]=f.reindex(D.index - pd.Timedelta(days=1),method="ffill").values   # nilai kemarin, sudah terbit
fu=pd.read_csv("../data/BTCUSDT_FUND.csv",header=None,names=["ts","x","r"]) if False else None
raw=open("../data/BTCUSDT_FUND.csv").readline(); print("fund head",raw.strip())
F=pd.read_csv("../data/BTCUSDT_FUND.csv"); F.columns=["ts","x","r"]; F["t"]=pd.to_datetime(F.ts//1000,unit="s",utc=True)
F=F.set_index("t").r.sort_index(); f7=F.rolling(21).mean()   # rata 7 hari
D["fund"]=f7.reindex(D.index,method="ffill").values
dev=D.index<"2022-01-01"
def row(nm,m,hz):
    out=[]
    for per,M in (("dev",dev),("uji",~dev)):
        x=D.loc[m&M,hz].dropna(); b=D.loc[M,hz].dropna()
        out.append(f"{per} n{len(x):4d} naik {(x>0).mean()*100:3.0f}% (b {(b>0).mean()*100:2.0f}) rata {x.mean()*100:+5.1f}% (b {b.mean()*100:+4.1f})")
    print(f"{nm:24s} {hz:4s} "+" | ".join(out))
for lab,m in (("FNG <=20",D.fng<=20),("FNG 21-40",D.fng.between(21,40)),("FNG 41-60",D.fng.between(41,60)),("FNG 61-79",D.fng.between(61,79)),("FNG >=80",D.fng>=80)):
    for hz in ("f7","f30"): row(lab,m,hz)
q=D.fund.quantile([.1,.9]); print(q.values)
for lab,m in (("funding negatif",D.fund<0),("funding <=p10",D.fund<=q.iloc[0]),("funding >=p90",D.fund>=q.iloc[1]),("funding normal",D.fund.between(0,q.iloc[1]))):
    for hz in ("f7","f30"): row(lab,m,hz)
D.to_pickle("D.pkl")

"""SMC (BOS/CHoCH LuxAlgo), MSB LuxAlgo, SnR pivot 20, Order Block Finder: entry MARKET candle berikutnya,
SL 2 ATR, keluar trailing 3 ATR / TP 2R / TP 3R. Fitur dari setups.pkl (kausal)."""
import os, sys, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore"); sys.path.insert(0, ".")
import sbt, mcg
X = pd.read_pickle("../smc/setups.pkl"); X = X[X.t >= "2020-07-01"]
X = X[(X.jenis != "obf") | (X.thr == 2.0)]
rows = []
for s, g in X.groupby("sym"):
    df = pd.read_csv(f"{sbt.D}/{s}_240.csv", index_col=0, parse_dates=True)
    o, h, l, c = (df[k].values.astype(float) for k in ("open", "high", "low", "close"))
    pc = np.r_[c[0], c[:-1]]; a = sbt.rma(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc))), 14)
    md = np.zeros(len(c))
    for jn, gg in g.groupby("jenis"):
        gg = gg.sort_values("i")
        idx = gg.i.values.astype(np.int64); side = gg.arah.values.astype(np.int64)
        for ex, (m, slk, trk, RR, H) in {"trail": (0, 2.0, 3.0, 0.0, 60), "tp2": (1, 1.5, 0.0, 2.0, 30), "tp3": (1, 2.0, 0.0, 3.0, 45)}.items():
            R, fb, xb = mcg.sim(o, h, l, c, a, md, idx, side, m, slk, trk, RR, H)
            last = -1
            for k in np.nonzero(fb >= 0)[0]:
                if fb[k] <= last: continue
                last = xb[k]; r = gg.iloc[k]
                rows.append((jn + "|" + ex, s, r.t, int(side[k]), float(R[k]), r.vp, r.btc, r.tren, int(xb[k] - fb[k]), r["rank"],
                             r.get("tag"), r.get("swing"), r.get("skor"), r.flow))
    print(s, len(rows), flush=True)
Y = pd.DataFrame(rows, columns=["strat", "sym", "t", "arah", "R", "vp", "btc", "tren", "hold", "rank", "tag", "swing", "skor", "flow"])
Y.to_pickle("smc2.pkl")

"""Entry telat: sinyal jalur terbukti diikuti 1-8 candle sesudahnya di harga close saat itu, SL jalur saat itu, TP asli.
111 koin perp 4J 2020-2026. Tujuan: kapan sinyal lama masih layak diikuti."""
import os, sys, numpy as np, pandas as pd, numba as nb, warnings
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "..", "smc"))
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot"); os.environ.setdefault("QSE_STATE_DIR", os.path.join(HERE, "st"))
import sbt, mcg2, smc_core as K
EX = {"trail": (0, 2.0, 3.0, 0.0, 60), "tp3": (1, 2.0, 0.0, 3.0, 45)}

@nb.njit(cache=True)
def jalur(o, h, l, c, a, i, s, mode, slk, trk, RR, H, out):
    N = len(c)
    if i + 1 >= N or np.isnan(a[i]): return -1
    e = o[i + 1]; risk = slk * a[i]
    if risk <= 0 or risk / e < 0.003: return -1
    sl = e - s * risk; best = e; tp = e + s * RR * risk; end = min(N - 1, i + H)
    if i + H >= N: return -1
    # simulasi asli sambil mencatat status di tiap close
    m = 0; xo = -1
    for j in range(i + 1, end + 1):
        if (s == 1 and l[j] <= sl) or (s == -1 and h[j] >= sl): xo = j; break
        if mode == 1 and j > i + 1 and ((s == 1 and h[j] >= tp) or (s == -1 and l[j] <= tp)): xo = j; break
        if mode == 0:
            if s == 1:
                best = max(best, h[j]); sl = max(sl, best - trk * a[j])
            else:
                best = min(best, l[j]); sl = min(sl, best + trk * a[j])
        k = j - i
        if k >= 1 and k <= 8 and m < 8:
            # entry telat di close j
            eL = c[j]; rL = (eL - sl) * s
            if rL > 0 and (mode == 0 or (tp - eL) * s > 0):
                sl2 = sl; b2 = best; R = np.nan
                for q in range(j + 1, end + 1):
                    if (s == 1 and l[q] <= sl2) or (s == -1 and h[q] >= sl2):
                        R = (sl2 - eL) * s / rL; break
                    if mode == 1 and ((s == 1 and h[q] >= tp) or (s == -1 and l[q] <= tp)):
                        R = (tp - eL) * s / rL; break
                    if mode == 0:
                        if s == 1:
                            b2 = max(b2, h[q]); sl2 = max(sl2, b2 - trk * a[q])
                        else:
                            b2 = min(b2, l[q]); sl2 = min(sl2, b2 + trk * a[q])
                if np.isnan(R): R = (c[end] - eL) * s / rL
                out[m, 0] = k; out[m, 1] = (eL - e) * s / risk; out[m, 2] = R - 0.0015 * eL / rL
                out[m, 3] = rL / risk; m += 1
    return m

ROWS = []; TV = {}
b = pd.read_csv(f"{sbt.D}/BTCUSDT_240.csv", index_col=0, parse_dates=True)
btc_up = pd.Series((b.close.values > sbt.ema(b.close.values, 50)).astype(float), index=b.index)
for s_ in sbt.SYMS:
    df = pd.read_csv(f"{sbt.D}/{s_}_240.csv", index_col=0, parse_dates=True)
    F = sbt.fitur(df, None, btc_up); TV[s_] = pd.Series(F["turn"], index=df.index)
    o, h, l, c, v, a = F["o"], F["h"], F["l"], F["c"], F["v"], F["atr"]; ix = df.index; vp = F["vp"]
    tren = lambda i, sd: (c[i] > F["e200"][i]) == (sd == 1)
    btc = lambda i, sd: (F["btc"][i] == 1) == (sd == 1)
    S = sbt.sinyal(F); C = {}
    C["ema_short"] = ([(i, -1) for i in np.nonzero(S["ema20x50"][1])[0] if F["btc"][i] == 0], "trail")
    rl, rs = S["rsi_cross50"][:2]
    C["rsi_vol"] = ([(i, 1 if rl[i] else -1) for i in np.nonzero((rl | rs) & (vp >= 80))[0]], "trail")
    md, mdp = mcg2.mcg_win(c, 34, 0.6, 600); up = c > md; pu = np.r_[False, c[:-1] > mdp[1:]]
    C["mcginley"] = ([(i, 1 if up[i] else -1) for i in np.nonzero((up != pu) & ~np.isnan(md) & (vp >= 80))[0] if tren(i, 1 if up[i] else -1)], "tp3")
    C["snr_vol"] = ([(i, sd) for i, sd, *_ in K.snr(h, l, c, 20) if tren(i, sd) and btc(i, sd) and vp[i] >= 80], "tp3")
    C["msb_hpz"] = ([(x[0], x[1]) for x in K.msb(o, h, l, c, v, 7, 0.5, K.volpct(v)) if x[5]["skor"] > 80 and tren(x[0], x[1])], "trail")
    C["smc_choch"] = ([(x[0], x[1]) for x in K.smc(o, h, l, c, 5, 50) if x[5]["tag"] == "choch" and tren(x[0], x[1])], "tp3")
    for nm, (cand, ex) in C.items():
        mo, slk, trk, RR, H = EX[ex]; last = -1
        for i, sd in sorted(cand):
            if i < 250 or i <= last: continue
            out = np.zeros((8, 4)); m = jalur(o, h, l, c, a, i, sd, mo, slk, trk, RR, H, out)
            if m < 0: continue
            last = i + 1
            for r in out[:m]:
                ROWS.append((nm, s_, ix[i], int(r[0]), r[1], r[2], r[3]))
    print(s_, len(ROWS), flush=True)
X = pd.DataFrame(ROWS, columns=["jalur", "sym", "t", "k", "d", "R", "rr"])
RK = pd.DataFrame(TV).rank(axis=1, ascending=False).stack().rename("rank").reset_index(); RK.columns = ["t", "sym", "rank"]
X = X.merge(RK, on=["t", "sym"], how="left")
X.to_pickle(os.path.join(HERE, "telat.pkl"))

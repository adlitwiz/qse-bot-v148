"""Simulasi limit di tepi zona, SL di balik zona + buf*ATR, TP = R kali risiko, tahan maks H candle.
Konservatif: SL dan TP di candle sama dihitung SL. Biaya 0.15% notional."""
import os, numpy as np, pandas as pd, numba as nb
P = os.path.dirname(__file__)
ARR = pd.read_pickle(f"{P}/arr.pkl")
BIAYA = 0.0015


@nb.njit(cache=True)
def _sim(o, h, l, c, si, side, E, SL, Kw, RR, H, mkt):
    n = len(si); fb = np.full(n, -1); xb = np.full(n, -1); res = np.full(n, np.nan)
    N = len(c)
    for k in range(n):
        i = si[k]; s = side[k]; e = E[k]; sl = SL[k]
        f = -1
        if mkt:
            f = i + 1; e = o[i + 1]
            if (s == 1 and e <= sl) or (s == -1 and e >= sl): continue
        else:
            for j in range(i + 1, min(N, i + 1 + Kw)):
                if (s == 1 and l[j] <= e) or (s == -1 and h[j] >= e):
                    f = j
                    if (s == 1 and o[j] < e) or (s == -1 and o[j] > e): e = o[j]
                    break
            if f < 0: continue
        risk = (e - sl) * s
        if risk <= 0: continue
        tp = e + s * RR * risk
        fb[k] = f
        done = False
        for j in range(f, min(N, f + H)):
            if (s == 1 and l[j] <= sl) or (s == -1 and h[j] >= sl):
                res[k] = -1.0; xb[k] = j; done = True; break
            if j > f and ((s == 1 and h[j] >= tp) or (s == -1 and l[j] <= tp)):
                res[k] = RR; xb[k] = j; done = True; break
        if not done:
            j = min(N - 1, f + H - 1)
            if f + H - 1 > N - 1: fb[k] = -1; continue        # belum selesai
            res[k] = (c[j] - e) * s / risk; xb[k] = j
        res[k] -= BIAYA * e / risk
    return fb, xb, res


def jalan(X, buf=0.2, Kw=18, RR=2.0, H=60, mkt=False, entry="tepi"):
    """X: subset setups. Return X + kolom fb, xb, R, risk_pct."""
    outs = []
    for s, g in X.groupby("sym"):
        idx, o, h, l, c, a = ARR[s]
        side = g.arah.values.astype(np.int64)
        if entry == "tepi": E = np.where(side == 1, g.top.values, g.bot.values)
        else: E = (g.top.values + g.bot.values) / 2
        SL = np.where(side == 1, g.bot.values - buf * g.atr.values, g.top.values + buf * g.atr.values)
        fb, xb, r = _sim(o, h, l, c, g.i.values.astype(np.int64), side, E.astype(float), SL.astype(float), Kw, RR, H, mkt)
        g = g.copy(); g["fb"] = fb; g["xb"] = xb; g["R"] = r
        g["risk_pct"] = abs(E - SL) / E
        g["t_in"] = [idx[x] if x >= 0 else pd.NaT for x in fb]
        g["t_out"] = [idx[x] if x >= 0 else pd.NaT for x in xb]
        outs.append(g)
    Y = pd.concat(outs)
    Y = Y[(Y.fb >= 0) & Y.R.notna() & (Y.risk_pct >= 0.004) & (Y.risk_pct <= 0.15)]
    # satu posisi per koin
    Y = Y.sort_values(["sym", "fb"]); keep = np.zeros(len(Y), bool)
    sy = Y.sym.values; fbv = Y.fb.values; xbv = Y.xb.values; last = {}
    for k in range(len(Y)):
        if fbv[k] <= last.get(sy[k], -1): continue
        last[sy[k]] = xbv[k]; keep[k] = True
    return Y[keep].sort_values("t_in")


def stat(Y, nm="", cetak=True):
    if len(Y) == 0: return dict(n=0)
    r = Y.R.values
    pf = r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9)
    eq = np.cumsum(r); dd = (np.maximum.accumulate(eq) - eq).max()
    yr = Y.groupby(Y.t_in.dt.year).R.sum().round(0).astype(int).to_dict()
    q = Y.groupby(Y.t_in.dt.to_period("Q")).R.sum()
    d = dict(n=len(Y), wr=round((r > 0).mean(), 3), pf=round(pf, 3), totR=round(r.sum(), 1), ddR=round(dd, 1),
             q=f"{(q > 0).sum()}/{len(q)}", th=yr)
    if cetak: print(nm, d, flush=True)
    return d

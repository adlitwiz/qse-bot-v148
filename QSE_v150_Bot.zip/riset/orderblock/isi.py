import pandas as pd, numpy as np, sys
sys.path.insert(0,"/mnt/user-data/outputs/QSE_v148_Bot")
from qse_strat import COMBO_EMAS, PF_JALUR
R=pd.read_pickle("strat/raja.pkl"); R=R[R.t>="2021-01-01"].copy(); R["t"]=pd.to_datetime(R.t,utc=True)
h=pd.read_csv("data/BTCUSDT_60.csv",index_col=0,parse_dates=True)
v4=h.volume.resample("4h").sum(); rv=v4/v4.rolling(180).mean()
R["vt"]=(rv.reindex(R.t).values>2.5)
R["emas"]=[any((j,p) in COMBO_EMAS for p in ps) for j,ps in zip(R.jalur,R.par)]
R["skor"]=5*(R.n>=5)+3*R.fix+2*R.emas+(R.n>=1)+(R.n>=2)+(R.plus>=3)+((R.jalur=="mcginley")&R.pull)+2*R.vt
R["pfj"]=R.jalur.map(PF_JALUR).fillna(1.2)
R["hari"]=(R.t+pd.Timedelta(hours=4)-pd.Timedelta(hours=23)).dt.floor("D")
R["jam"]=((R.t+pd.Timedelta(hours=4)+pd.Timedelta(hours=7)).dt.hour)   # jam WIB sinyal
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
ada3=set(R[R.skor>=3].hari)
for per,M in (("21-23",R.t<"2024"),("24-26",R.t>="2024")):
    Z=R[M&~R.hari.isin(ada3)]
    for k in (1,2,3):
        best=Z.sort_values(["skor","pfj"],ascending=False).groupby("hari").head(k)
        print(per,"hari tanpa nilai 8, ambil",k,"terbaik: n",len(best),"PF",f(best.R.values),"WR",round((best.R>0).mean()*100))
    # pilih per jalur terbaik (PF jalur tinggi) saja
    for j in ("ema_short","orderblock","rsi_vol","mcginley","ichimoku"):
        x=Z[Z.jalur==j].R; print("   ",j,len(x),f(x.values))

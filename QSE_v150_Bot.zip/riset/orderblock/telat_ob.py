import pandas as pd, numpy as np, os
X=pd.read_pickle("semua_f.pkl"); X=X[(X.jalur=="orderblock")&(X["rank"]<=50)&(X.t>="2020-06-01")]
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2) if len(x) else None
rows=[]
for s,Z in X.groupby("sym"):
    p=f"../data/{s}_240.csv"
    if not os.path.exists(p): continue
    h=pd.read_csv(p,index_col=0,parse_dates=True); ix=h.index; O,H,L,C=(h[c].values for c in ("open","high","low","close"))
    for r in Z.itertuples():
        k0=ix.searchsorted(r.t+pd.Timedelta(hours=4))
        if k0>=len(ix) or ix[k0]!=r.t+pd.Timedelta(hours=4): continue
        e=O[k0]; risk=e/r.er; sl=e-risk; tp=e+4*risk
        for k in range(0,7):       # k=0 entry asli, k>=1 entry di close candle ke-k
            if k==0: e2=e; st=k0
            else:
                j=k0+k-1
                if j>=len(ix): break
                # sudah kena SL/TP sebelum close candle j?
                if L[k0:j+1].min()<=sl or H[k0:j+1].max()>=tp: break
                e2=C[j]; st=j+1
            d=(e2-e)/risk; res=None
            for j in range(st,min(k0+60,len(ix))):
                if L[j]<=sl: res=(sl-e2); break
                if H[j]>=tp: res=(tp-e2); break
            if res is None: res=C[min(k0+59,len(ix)-1)]-e2
            rows.append((r.t,k,d,res/(e2-sl)-0.0015*e2/(e2-sl)))
R=pd.DataFrame(rows,columns=["t","k","d","R"])
for k,G in R.groupby("k"):
    for lo,hi in ((-9,0.3),(-0.5,0.5)):
        g=G[(G.d>lo)&(G.d<=hi)]
        print(k,f"d({lo},{hi}]",len(g),f(g[g.t<"2024"].R.values),f(g[g.t>="2024"].R.values))

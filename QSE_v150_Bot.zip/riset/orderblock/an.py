import pandas as pd, numpy as np
A=pd.read_pickle("A.pkl")
dev=A.index<"2022-01-01"
def row(nm,m,hz):
    out=[]
    for per,M in (("dev",dev),("uji",~dev)):
        x=A.loc[m&M,hz].dropna(); b=A.loc[M,hz].dropna()
        out.append(f"{per} n{len(x):5d} naik {(x>0).mean()*100:3.0f}% (base {(b>0).mean()*100:3.0f}) rata {x.mean()*100:+5.1f}% (base {b.mean()*100:+4.1f})")
    print(f"{nm:28s} {hz:4s} "+" | ".join(out))
for tf,hzs in (("w",("f7","f30")),("d",("f3","f7","f30")),("h4",("f1","f3"))):
    for lo,hi,lab in ((5,9,"kuat naik >=5"),(1,4,"naik 1-4"),(-4,-1,"turun -1..-4"),(-9,-5,"kuat turun <=-5")):
        for hz in hzs: row(f"{tf} {lab}",(A[tf]>=lo)&(A[tf]<=hi),hz)
    print()
sg=np.sign(A[["w","d","h4"]])
for lab,m in (("3 TF naik",(sg==1).all(axis=1)),("3 TF turun",(sg==-1).all(axis=1)),("W&D naik",(sg.w==1)&(sg.d==1)),("W&D turun",(sg.w==-1)&(sg.d==-1)),
              ("W naik D turun",(sg.w==1)&(sg.d==-1)),("W turun D naik",(sg.w==-1)&(sg.d==1))):
    for hz in ("f7","f30"): row(lab,m,hz)

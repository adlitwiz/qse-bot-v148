import pandas as pd, numpy as np, warnings; warnings.filterwarnings("ignore")
X0 = pd.read_pickle("semua_f.pkl"); X0 = X0[X0.t >= "2021-01-01"]
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
PRI = {"ema_short": 0, "orderblock": 1, "rsi_vol": 2, "snr_vol": 3, "ichimoku": 4, "mcginley": 5, "msb_hpz": 6, "GZH": 7, "smc_choch": 8}
def sim(cap_arah=999, rem=None, pri=False, drop=(), nm="", ret=False):
    X = X0[~X0.jalur.isin(drop)].copy(); X["p"] = X.jalur.map(PRI) if pri else 0
    X = X.sort_values(["t", "p", "rank"])
    op = []; keep = []
    for k, r in zip(X.index, X.itertuples()):
        op = [o for o in op if o[0] > r.t]
        if sum(o[1] == r.jalur for o in op) >= 8: continue
        if sum(o[3] == r.arah for o in op) >= cap_arah: continue
        if any(o[2] == r.sym for o in op): continue
        op.append((r.t_out, r.jalur, r.sym, r.arah)); keep.append(k)
    P = X.loc[keep].copy(); P["w"] = np.where(P.jalur == "GZH", 0.5, 1.0)
    P = P.sort_values("t_out"); eq = pk = 0.0; e = []; rg = 0; ws = []
    for x, w in zip(P.Rf.values, P.w.values):
        risk = 0.5 * w * (0.5 if (rem and (pk - eq > rem or rg >= 8)) else 1)
        eq += x * risk; pk = max(pk, eq); e.append(eq); ws.append(risk); rg = rg + 1 if x < 0 else 0
    P["pnl"] = P.Rf.values * np.array(ws)
    e = np.array(e); dd = (np.maximum.accumulate(e) - e).max()
    dv = P.t < "2024-01-01"
    def dd_(z):
        c = z.pnl.cumsum().values; return (np.maximum.accumulate(c) - c).max()
    m = P.groupby(P.t_out.dt.to_period("M")).pnl.sum()
    print(f"{nm:30s} n={len(P):5d} PF {pf(P.Rf)} dev {pf(P[dv].Rf)}/{P[dv].pnl.sum()/dd_(P[dv]):.1f} uji {pf(P[~dv].Rf)}/{P[~dv].pnl.sum()/dd_(P[~dv]):.1f} total {e[-1]:+.0f}% DD {dd:.0f}% ratio {e[-1]/dd:.1f} bln_buruk {m.min():.0f}% th {P.groupby(P.t.dt.year).pnl.sum().round().astype(int).to_dict()}")
    if ret: return P
sim(nm="sekarang")
for ca in (4, 6, 8):
    sim(cap_arah=ca, nm=f"searah {ca}")
    sim(cap_arah=ca, pri=True, nm=f"searah {ca} prioritas jalur")
    sim(cap_arah=ca, rem=8, nm=f"searah {ca} + rem 8%")
    sim(cap_arah=ca, pri=True, rem=8, nm=f"searah {ca} prio + rem 8%")
print("---- buang jalur lemah")
for d in (("smc_choch",), ("GZH",), ("msb_hpz",), ("smc_choch", "GZH", "msb_hpz")):
    sim(cap_arah=8, rem=8, drop=d, nm=f"searah8+rem tanpa {','.join(d)}")
for r_ in (5, 12):
    sim(cap_arah=8, rem=r_, nm=f"searah 8 + rem {r_}%")

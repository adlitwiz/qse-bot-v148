import pandas as pd, numpy as np, os
X=pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "snr_vol": 30, "msb_hpz": 30, "smc_choch": 30, "ichimoku": 20, "orderblock": 50}
X = X[(X["rank"] <= X.jalur.map(LIK).fillna(999)) & (X.t >= "2021-01-01")]
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
rows=[]
for s,Z in X.groupby("sym"):
    p=f"../data/{s}_60.csv"
    if not os.path.exists(p): continue
    h=pd.read_csv(p,index_col=0,parse_dates=True); ix=h.index; O,H,L,C=(h[c].values for c in ("open","high","low","close"))
    for r in Z.itertuples():
        k0=ix.searchsorted(r.t+pd.Timedelta(hours=4))
        if k0>=len(ix) or ix[k0]!=r.t+pd.Timedelta(hours=4): continue
        e=O[k0]; risk=e/r.er; d=r.arah; sl=e-d*risk; tp=e+d*3*risk; cost=0.0015*e
        def run(e2,st):
            for j in range(st,min(k0+240,len(ix))):
                if (L[j]<=sl if d==1 else H[j]>=sl): return (sl-e2)*d
                if (H[j]>=tp if d==1 else L[j]<=tp): return (tp-e2)*d
            return (C[min(k0+239,len(ix)-1)]-e2)*d
        out=dict(jalur=r.jalur,t=r.t,mkt=(run(e,k0)-cost)/risk)
        for x in (0.2,0.35,0.5):
            lv=e-d*x*risk; res=0.0; isi=False
            for j in range(k0,min(k0+8,len(ix))):      # limit berlaku 8 jam (2 candle 4J)
                if (L[j]<=lv if d==1 else H[j]>=lv):
                    isi=True; res=(run(lv,j)-0.0004*lv-0.0011*lv)/risk; break   # limit fee maker lebih murah
            out[f"lim{x}"]=res; out[f"isi{x}"]=isi
        rows.append(out)
R=pd.DataFrame(rows); R.to_pickle("lim.pkl")
for nm,Z in (("2021-2023",R[R.t<"2024"]),("2024-2026",R[R.t>="2024"]),("SEMUA",R)):
    print(nm,"MARKET",len(Z),f(Z.mkt.values),round(Z.mkt.sum()))
    for x in (0.2,0.35,0.5):
        g=Z[f"lim{x}"].values; print(f"  LIMIT -{x}R terisi {Z[f'isi{x}'].mean()*100:.0f}% PF {f(g[g!=0])} total {g.sum():.0f}")

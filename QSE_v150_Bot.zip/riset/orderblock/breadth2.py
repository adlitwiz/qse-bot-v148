import pandas as pd, numpy as np, glob, os
def load(dirn,iv):
    C={}
    for f in glob.glob(f"{dirn}/*_{iv}.csv"):
        s=os.path.basename(f).split("_")[0]; C[s]=pd.read_csv(f,index_col=0,parse_dates=True).close
    return pd.DataFrame(C)
C4=pd.concat([load("data17","240"),load("data","240")]); C4=C4[~C4.index.duplicated(keep="last")].sort_index()
CD=C4.resample("1D").last()
def above(C,n): e=C.ewm(span=n,adjust=False,min_periods=n).mean(); v=C.notna()&e.notna(); return ((C>e)&v).sum(axis=1)/v.sum(axis=1).replace(0,np.nan)
B=pd.DataFrame({"d50":above(CD,50),"d200":above(CD,200)})
b4=pd.DataFrame({"h50":above(C4,50)})
# arah besok semua koin: rata return harian pasar (equal weight) dan BTC
ret=CD.pct_change(fill_method=None)
B["alt_next"]=ret.drop(columns="BTCUSDT").mean(axis=1).shift(-1)*100; B["btc_next"]=ret.BTCUSDT.shift(-1)*100
B["h50"]=b4.h50.resample("1D").last()
B=B.dropna(); P=[("2018-21",B.index<"2022"),("2022-26",B.index>="2022")]
for col in ("d50","d200","h50"):
    print("==",col)
    for lo,hi in ((0,.2),(.2,.4),(.4,.6),(.6,.8),(.8,1.01)):
        s=[]
        for nm,m in P:
            x=B[m&(B[col]>=lo)&(B[col]<hi)]
            s.append(f"n{len(x):4d} alt naik {(x.alt_next>0).mean()*100:3.0f}% rata {x.alt_next.mean():+.2f}% BTC naik {(x.btc_next>0).mean()*100:3.0f}%")
        print(f"  {lo:.0%}-{hi:.0%} koin di atas: "+" | ".join(s))
B.to_pickle("breadth_d.pkl")

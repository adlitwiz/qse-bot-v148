import pandas as pd, numpy as np
# BTC 1 jam 2017-2026
a=pd.read_csv("data17/BTCUSDT_60.csv",index_col=0,parse_dates=True); b=pd.read_csv("data/BTCUSDT_60.csv",index_col=0,parse_dates=True)
h=pd.concat([a,b[b.index>a.index[-1]]]); h=h[~h.index.duplicated()]
day=(h.index-pd.Timedelta(hours=23)).floor("D")
D=pd.DataFrame({"o":h.open.groupby(day).first(),"c":h.close.groupby(day).last(),"hi":h.high.groupby(day).max(),"lo":h.low.groupby(day).min(),"v":h.volume.groupby(day).sum()})
D["ret"]=D.c/D.o-1; D["y"]=np.sign(D.ret.shift(-1))  # arah HARI BERIKUTNYA (diputuskan di 06:00)
c=D.c
def ema(x,n): return x.ewm(span=n,adjust=False).mean()
F=pd.DataFrame(index=D.index)
F["r1"]=D.ret; F["r3"]=c/c.shift(3)-1; F["r7"]=c/c.shift(7)-1; F["r30"]=c/c.shift(30)-1
F["e20"]=c/ema(c,20)-1; F["e50"]=c/ema(c,50)-1; F["e200"]=c/ema(c,200)-1
d=c.diff(); up=d.clip(lower=0).ewm(alpha=1/14,adjust=False).mean(); dn=(-d.clip(upper=0)).ewm(alpha=1/14,adjust=False).mean(); F["rsi"]=100-100/(1+up/dn)
F["rng"]=D.hi/D.lo-1; F["vol_rel"]=D.v/D.v.rolling(20).mean()
F["close_pos"]=(D.c-D.lo)/(D.hi-D.lo)
F["dw"]=pd.to_datetime((D.index+pd.Timedelta(days=1))).dayofweek   # hari WIB yang ditebak (index = hari sebelumnya)
F["dw"]=pd.to_datetime(D.index).dayofweek  # placeholder diperbaiki di bawah
F["y"]=D.y; F["ynext_ret"]=D.ret.shift(-1)
F=F.dropna()
# hari WIB yang ditebak: index hari X (UTC tanggal t-23h floor) mewakili WIB hari X+1; target = hari berikutnya => WIB X+2
F["dw_target"]=(pd.to_datetime(F.index).dayofweek+2)%7
dev=F.index<"2022-01-01"
def ev(nm,m,arah):
    out=[]
    for M in (dev,~dev):
        x=F[m&M]; 
        out.append((len(x), (x.y==arah).mean()*100 if len(x) else 0, x.ynext_ret.mean()*100*arah if len(x) else 0))
    ok = all(o[1]>=55 and o[0]>=60 for o in out)
    print(f"{'✅' if ok else '  '} {nm:38s} arah {'NAIK' if arah>0 else 'TURUN'}  "+" | ".join(f"n{o[0]:4d} benar {o[1]:3.0f}% rata {o[2]:+.2f}%" for o in out))
print("base naik", (F[dev].y>0).mean().round(3),(F[~dev].y>0).mean().round(3))
for col in ["r1","r3","r7","r30","e20","e50","e200","rsi","rng","vol_rel","close_pos"]:
    q=F[col].quantile([.1,.25,.75,.9]).values
    ev(f"{col} <= p10",F[col]<=q[0],1); ev(f"{col} <= p10 (lanjut)",F[col]<=q[0],-1)
    ev(f"{col} >= p90",F[col]>=q[3],1); ev(f"{col} >= p90 (balik)",F[col]>=q[3],-1)
for i,n in enumerate("Sen Sel Rab Kam Jum Sab Min".split()):
    ev("hari "+n,F.dw_target==i,1); ev("hari "+n,F.dw_target==i,-1)
F.to_pickle("arahhari.pkl")

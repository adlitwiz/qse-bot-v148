"""Trailing jalur terbukti saat kamu tidur 22:00-06:00 WIB. A: SL digeser tiap candle 4J tutup (aturan robot).
B: geser SL terlewat saat tidur (candle tutup 23:00 dan 03:00 WIB). C: Trailing Stop Bybit jarak tetap 3 ATR, bergerak tiap saat."""
import pandas as pd, numpy as np, os, warnings, sys; warnings.filterwarnings("ignore")
sys.path.insert(0, "."); import sbt
def pf(r): r = np.asarray(r); return round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
X = pd.read_pickle("semua_f.pkl")
LIK = {"rsi_vol": 30, "msb_hpz": 30, "ichimoku": 20}
X = X[X.jalur.isin(["ichimoku", "ema_short", "rsi_vol", "msb_hpz"]) & (X["rank"] <= X.jalur.map(LIK).fillna(999)) & (X.t >= "2021-01-01")]
rows = []
for s, Z in X.groupby("sym"):
    f1, f4 = f"../data/{s}_60.csv", f"../data/{s}_240.csv"
    if not os.path.exists(f1): continue
    h = pd.read_csv(f1, index_col=0, parse_dates=True); d4 = pd.read_csv(f4, index_col=0, parse_dates=True)
    o4, h4, l4, c4 = (d4[k].values for k in ("open", "high", "low", "close"))
    pc = np.r_[c4[0], c4[:-1]]; tr = np.maximum(h4 - l4, np.maximum(abs(h4 - pc), abs(l4 - pc))); atr = sbt.rma(tr, 14)
    A4 = pd.Series(atr, index=d4.index)
    for r in Z.itertuples():
        if r.t not in A4.index: continue
        i = A4.index.get_loc(r.t); a0 = A4.iloc[i]; t0 = r.t + pd.Timedelta(hours=4)
        if t0 not in h.index: continue
        e = h.open.loc[t0]; risk = 2 * a0; sd = r.arah; cost = 0.0015 * e / risk
        seg = h.loc[t0:t0 + pd.Timedelta(hours=4 * 60 - 1)]
        if len(seg) < 10: continue
        res = {}
        for mode in "ABC":
            sl = e - sd * risk; best = e; out = None
            for ts, hi, lo, cl in zip(seg.index, seg.high.values, seg.low.values, seg.close.values):
                if (lo <= sl) if sd == 1 else (hi >= sl):
                    out = (sl - e) * sd / risk; break
                best = max(best, hi) if sd == 1 else min(best, lo)
                if mode == "C":
                    sl = max(sl, best - 3 * a0) if sd == 1 else min(sl, best + 3 * a0)
                else:
                    tutup = ts + pd.Timedelta(hours=1)
                    if tutup.hour % 4 == 0:                       # candle 4J tutup
                        jam_wib = (tutup.hour + 7) % 24
                        if mode == "B" and jam_wib in (23, 3):
                            continue
                        a = A4.asof(tutup - pd.Timedelta(hours=4))
                        sl = max(sl, best - 3 * a) if sd == 1 else min(sl, best + 3 * a)
            if out is None: out = (seg.close.values[-1] - e) * sd / risk
            res[mode] = out - cost - 0.01
        rows.append((r.jalur, r.t, res["A"], res["B"], res["C"]))
R = pd.DataFrame(rows, columns=["jalur", "t", "A_robot_4J", "B_terlewat_tidur", "C_trailing_bybit"])
for nm, Z in (("SEMUA", R), ("2021-2023", R[R.t < "2024"]), ("2024-2026", R[R.t >= "2024"])):
    print(nm, len(Z), {k: (pf(Z[k]), round(Z[k].sum())) for k in R.columns[2:]})
print({j: tuple(pf(z[k]) for k in R.columns[2:]) for j, z in R.groupby("jalur")})

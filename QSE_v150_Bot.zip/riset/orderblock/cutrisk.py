"""Apakah keluar lebih awal saat analisa robot BERBALIK (bias mesin melawan posisi dan harga di bawah entry) membantu?"""
import pickle, glob, os, sys, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore"); sys.path.insert(0, "strat")
import sbt
M = pd.read_pickle("strat/mcg2.pkl"); H = pd.read_pickle("strat/hasil.pkl"); S = pd.read_pickle("strat/smc2.pkl")
J = {"McGinley tp3": (M[(M.strat == "md34_cross|tp3") & (M.tren == 1) & (M.vp >= 80)], 1, 3.0, 45),
     "EMA SHORT trail": (H[(H.strat == "ema20x50") & (H.arah == -1) & (H.btc == 1)], 0, 0, 60),
     "SMC CHoCH tp3": (S[(S.strat == "smc|tp3") & (S.tag == "choch") & (S.tren == 1) & (S["rank"] <= 30)], 1, 3.0, 45),
     "MSB trail": (S[(S.strat == "msb|trail") & (S.skor > 80) & (S.tren == 1) & (S["rank"] <= 30)], 0, 0, 60)}
pf = lambda r: round(r[r > 0].sum() / max(-r[r < 0].sum(), 1e-9), 2)
for nm, (Z, mode, RR, Hm) in J.items():
    Z = Z[Z.t >= "2021-07-01"]; a_, b_ = [], []
    for s, g in Z.groupby("sym"):
        f = f"pre_all/{s}.pkl"
        if not os.path.exists(f): continue
        P = pickle.load(open(f, "rb")); bias = {k: v.get("bias") for k, v in P.items()}
        df = pd.read_csv(f"{sbt.D}/{s}_240.csv", index_col=0, parse_dates=True); ix = df.index.as_unit("ms").asi8
        o, h, l, c = (df[k].values.astype(float) for k in ("open", "high", "low", "close"))
        pc = np.r_[c[0], c[:-1]]; A = sbt.rma(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc))), 14)
        for r in g.itertuples():
            i = df.index.get_loc(r.t); sd = r.arah; e = o[i + 1]; risk = 2 * A[i]; sl = e - sd * risk; best = e
            res = {}
            for cut in (False, True):
                stop = sl; best = e; out = None
                for j in range(i + 1, min(len(c), i + 1 + Hm)):
                    if (sd == 1 and l[j] <= stop) or (sd == -1 and h[j] >= stop): out = (stop - e) * sd / risk; break
                    if mode == 1 and j > i + 1 and ((sd == 1 and h[j] >= e + RR * risk) or (sd == -1 and l[j] <= e - RR * risk)): out = RR; break
                    if mode == 0:
                        best = max(best, h[j]) if sd == 1 else min(best, l[j])
                        stop = max(stop, best - 3 * A[j]) if sd == 1 else min(stop, best + 3 * A[j])
                    bj = bias.get(int(ix[j]))
                    if cut and bj is not None and bj != ("LONG" if sd == 1 else "SHORT") and (c[j] - e) * sd < 0:
                        out = (c[j] - e) * sd / risk; break
                if out is None:
                    j = min(len(c) - 1, i + Hm); out = (c[j] - e) * sd / risk
                res[cut] = out - 0.0015 * e / risk
            a_.append(res[False]); b_.append(res[True])
    a_, b_ = np.array(a_), np.array(b_)
    print(f"{nm:16s} n={len(a_)} tahan sesuai aturan PF {pf(a_)} total {a_.sum():+.0f}R | keluar saat BERBALIK PF {pf(b_)} total {b_.sum():+.0f}R")

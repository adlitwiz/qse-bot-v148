import pandas as pd, numpy as np, sys, glob, os
sys.path.insert(0,"/mnt/user-data/outputs/QSE_v148_Bot")
from qse_strat import COMBO_EMAS, PF_JALUR
R=pd.read_pickle("strat/raja.pkl"); R=R[R.t>="2021-01-01"].copy(); R["t"]=pd.to_datetime(R.t,utc=True)
h=pd.read_csv("data/BTCUSDT_60.csv",index_col=0,parse_dates=True)
v4=h.volume.resample("4h").sum(); rv=v4/v4.rolling(180).mean()
R["vt"]=(rv.reindex(R.t).values>2.5)
R["emas"]=[any((j,p) in COMBO_EMAS for p in ps) for j,ps in zip(R.jalur,R.par)]
R["skor"]=5*(R.n>=5)+3*R.fix+2*R.emas+(R.n>=1)+(R.n>=2)+(R.plus>=3)+((R.jalur=="mcginley")&R.pull)+2*R.vt
# dominasi
C={}
for d in ("data17","data"):
    for f in glob.glob(f"{d}/*_D.csv"):
        s=os.path.basename(f).split("_")[0]; x=pd.read_csv(f,index_col=0,parse_dates=True).close
        C[s]=pd.concat([C[s],x]) if s in C else x
C=pd.DataFrame({k:v[~v.index.duplicated(keep="last")].sort_index() for k,v in C.items()})
r=C.pct_change(fill_method=None); b=r.pop("BTCUSDT"); alt=r.clip(-0.5,0.5).mean(axis=1)
rel=(1+alt.fillna(0)).cumprod()/(1+b.fillna(0)).cumprod()
st=(rel>rel.ewm(span=20,adjust=False).mean()).astype(int).shift(1)
R["dom"]=st.reindex(R.t.dt.floor("D")).values==1
print("arah unik", R.arah.unique()[:4])
S=(R.arah==-1)|(R.arah=="SHORT")
f=lambda x:round(x[x>0].sum()/max(-x[x<0].sum(),1e-9),2)
for nm,bon in (("dasar",0),("+1 semua SHORT",1),("+1 tanpa ichimoku",1),("+2 tanpa ichimoku",2)):
    sk=R.skor+bon*(S&R.dom&((R.jalur!="ichimoku") if "tanpa" in nm else True))
    out=[]
    for per,M in (("21-23",R.t<"2024"),("24-26",R.t>="2024")):
        x=R[M&(sk>=3)].R
        hari=R[M].t.dt.floor("D").nunique()
        out.append(f"{per} n {len(x):5d} PF {f(x.values):.2f} total {x.sum():+7.1f}R")
    print(f"{nm:20s} "+" | ".join(out))
# sinyal yang baru masuk karena bonus
for bon in (1,2):
    sk=R.skor+bon*(S&R.dom&(R.jalur!="ichimoku"))
    for per,M in (("21-23",R.t<"2024"),("24-26",R.t>="2024")):
        x=R[M&(sk>=3)&(R.skor<3)].R
        print(f"bonus {bon} {per} sinyal tambahan n {len(x)} PF {f(x.values):.2f} total {x.sum():+.1f}R")
print()
sk=R.skor+2*(S&R.dom)
for j in sorted(R.jalur.unique()):
    o=[]
    for per,M in (("21-23",R.t<"2024"),("24-26",R.t>="2024")):
        x=R[M&(sk>=3)&(R.skor<3)&(R.jalur==j)].R
        o.append(f"{per} n {len(x):4d} PF {f(x.values) if len(x) else 0:.2f}")
    print(f"{j:11s} "+" | ".join(o))
print()
J={"ema_short","mcginley","msb_hpz","rsi_vol","smc_choch","ichimoku"}
for nm,JJ in (("6 jalur",J),("5 jalur tanpa ichimoku",J-{"ichimoku"})):
    sk=R.skor+2*(S&R.dom&R.jalur.isin(JJ))
    o=[]
    for per,M in (("21-23",R.t<"2024"),("24-26",R.t>="2024")):
        x=R[M&(sk>=3)].R; y=R[M&(sk>=3)&(R.skor<3)].R
        hari=R[M].t.dt.floor("D").nunique(); hs=R[M&(sk>=3)].t.dt.floor("D").nunique()
        o.append(f"{per} n {len(x)} PF {f(x.values):.2f} tot {x.sum():+.0f}R tambahan {len(y)} PF {f(y.values):.2f} hari ada sinyal {hs}/{hari}")
    print(nm, " | ".join(o))
sk=R.skor
for per,M in (("21-23",R.t<"2024"),("24-26",R.t>="2024")):
    hari=R[M].t.dt.floor("D").nunique(); hs=R[M&(sk>=3)].t.dt.floor("D").nunique(); print("dasar",per,"hari ada sinyal",hs,"/",hari)
print()
for nm,sk in (("lama",R.skor),("baru",R.skor+2*(S&R.dom&R.jalur.isin(J)))):
    for lo,hi in ((3,4),(5,7),(8,99)):
        o=[]
        for per,M in (("21-23",R.t<"2024"),("24-26",R.t>="2024")):
            x=R[M&(sk>=lo)&(sk<=hi)].R; o.append(f"{per} n {len(x)} PF {f(x.values):.2f} exp {x.mean():+.2f}")
        print(nm,lo,hi," | ".join(o))
print("capped")
d2=S&R.dom&R.jalur.isin(J)
skc=np.where(d2, np.minimum(R.skor+2, np.maximum(R.skor,7)), R.skor)
sk=pd.Series(skc,index=R.index)
for lo,hi in ((3,4),(5,7),(8,99),(3,99)):
    o=[]
    for per,M in (("21-23",R.t<"2024"),("24-26",R.t>="2024")):
        x=R[M&(sk>=lo)&(sk<=hi)].R; o.append(f"{per} n {len(x)} PF {f(x.values):.2f} exp {x.mean():+.2f} tot {x.sum():+.0f}")
    print("cap",lo,hi," | ".join(o))

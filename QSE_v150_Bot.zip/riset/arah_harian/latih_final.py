"""Latih model final arah 24 jam dan perkiraan rentang untuk 4 jam info (23, 5, 11, 17 UTC). Simpan ke arah_model.json.
Statistik uji dari uji maju per tahun 2019-2026 (latih semua hari sebelum tahun uji)."""
import json
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression, LinearRegression

FIT = ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24"]
RFIT = ["l_rng24", "l_rng7", "l_rv30", "pekan", "senin", "l_vrel", "abs_r1"]
C = 0.01
KLIP = 4.0


def zfit(X):
    mu, sd = X.mean(), X.std().replace(0, 1)
    return mu, sd


def z(X, mu, sd):
    return ((X - mu) / sd).clip(-KLIP, KLIP).fillna(0)


def fitur_rentang(F):
    X = pd.DataFrame({"l_rng24": np.log(F.rng24), "l_rng7": np.log(F.rng7), "l_rv30": np.log(F.rv30),
                      "pekan": F.akhir_pekan.astype(float), "senin": (F.dw == 0).astype(float), "l_vrel": F.vrel,
                      "abs_r1": F.r1h.abs()}, index=F.index)
    return X


def per_tingkat(p, y, ya=None):
    k = (p - 0.5).abs()
    benar = (p > 0.5) == (y > 0)
    out = {}
    for nm, lo, hi in (("kuat", 0.03, 1), ("sedang", 0.01, 0.03), ("tipis", 0, 0.01)):
        m = (k >= lo) & (k < hi)
        out[nm] = [round(float(m.mean()) * 100, 1), round(float(benar[m].mean()) * 100, 1)]
    return out


hasil = {"versi": "2026-10-27", "fitur": FIT, "rfitur": RFIT, "klip": KLIP, "sesi": {}}
for H in (23, 5, 11, 17):
    F = pd.read_pickle(f"fitur_{H}b.pkl").replace([np.inf, -np.inf], np.nan)
    D = F[F.y.notna()]
    # ---------------- uji maju arah
    oos = []
    for th in range(2019, 2027):
        a, b = pd.Timestamp(f"{th}-01-01", tz="UTC"), pd.Timestamp(f"{th + 1}-01-01", tz="UTC")
        tr, te = D[D.index < a], D[(D.index >= a) & (D.index < b)]
        mu, sd = zfit(tr[FIT])
        m = LogisticRegression(C=C, max_iter=2000).fit(z(tr[FIT], mu, sd), (tr.y > 0).astype(int))
        oos.append(pd.DataFrame({"p": m.predict_proba(z(te[FIT], mu, sd))[:, 1], "y": te.y, "ya": te.ya}, index=te.index))
    R = pd.concat(oos)
    benar = (R.p > 0.5) == (R.y > 0)
    nk = R.p > 0.5
    uji = dict(n=int(len(R)), dari=str(R.index[0].date()), sampai=str(R.index[-1].date()),
               akurasi=round(float(benar.mean()) * 100, 1), tingkat=per_tingkat(R.p, R.y),
               naik_benar=round(float((R.y[nk] > 0).mean()) * 100, 1), turun_benar=round(float((R.y[~nk] <= 0).mean()) * 100, 1),
               alt_naik_benar=round(float((R.ya[nk] > 0).mean()) * 100, 1), alt_turun_benar=round(float((R.ya[~nk] <= 0).mean()) * 100, 1),
               per_tahun={int(y): round(float(g.mean()) * 100, 1) for y, g in benar.groupby(R.index.year)},
               pekan_naik=round(float((D.y[D.akhir_pekan == 1] > 0).mean()) * 100, 1),
               kerja_naik=round(float((D.y[D.akhir_pekan == 0] > 0).mean()) * 100, 1),
               ikut_rata=round(float((np.where(R.p > 0.5, 1, -1) * R.y).mean()) * 100, 3))
    # ---------------- model final arah (semua data)
    mu, sd = zfit(D[FIT])
    m = LogisticRegression(C=C, max_iter=2000).fit(z(D[FIT], mu, sd), (D.y > 0).astype(int))
    arah = dict(mu=[float(v) for v in mu], sd=[float(v) for v in sd], w=[float(v) for v in m.coef_[0]], b=float(m.intercept_[0]))
    # pasar24 besar: bantu teks alasan (persentil 20 dan 80 data latih)
    arah["pasar_tabel"] = []
    for lo, hi in ((-9, -0.03), (-0.03, -0.01), (-0.01, 0.01), (0.01, 0.03), (0.03, 9)):
        mk = (D.pasar24 > lo) & (D.pasar24 <= hi)
        arah["pasar_tabel"].append([lo, hi, round(float((D.y[mk] > 0).mean()) * 100, 1), int(mk.sum())])
    # ---------------- rentang 24 jam
    X = fitur_rentang(F)
    ok = np.isfinite(X).all(axis=1) & F.yrng.notna() & (F.yrng > 0) & F.yup.notna() & F.ydn.notna()
    X, G = X[ok], F[ok]
    ly = np.log(G.yrng)
    ro = []
    for th in range(2019, 2027):
        a, b = pd.Timestamp(f"{th}-01-01", tz="UTC"), pd.Timestamp(f"{th + 1}-01-01", tz="UTC")
        tr, te = X.index < a, (X.index >= a) & (X.index < b)
        lr = LinearRegression().fit(X[tr], ly[tr])
        s_tr, s_te = np.exp(lr.predict(X[tr])), np.exp(lr.predict(X[te]))
        u, d = G.yup[tr] / s_tr, -G.ydn[tr] / s_tr
        o = pd.DataFrame({"s": s_te, "yrng": G.yrng[te], "yup": G.yup[te], "ydn": G.ydn[te]}, index=X.index[te])
        for q in (0.5, 0.9):
            o[f"u{int(q * 100)}"] = u.quantile(q) * s_te
            o[f"d{int(q * 100)}"] = d.quantile(q) * s_te
        ro.append(o)
    RR = pd.concat(ro)
    isi90 = ((RR.yup <= RR.u90) & (-RR.ydn <= RR.d90))
    lr = LinearRegression().fit(X, ly)
    s_all = np.exp(lr.predict(X))
    u, d = G.yup / s_all, -G.ydn / s_all
    lv = [float(np.quantile(s_all, 1 / 3)), float(np.quantile(s_all, 2 / 3))]
    tg = pd.cut(pd.Series(s_all, index=X.index), [0, lv[0], lv[1], 9], labels=["rendah", "sedang", "tinggi"])
    rentang = dict(w=[float(v) for v in lr.coef_], b=float(lr.intercept_),
                   q=dict(u50=float(u.quantile(0.5)), d50=float(d.quantile(0.5)), u90=float(u.quantile(0.9)), d90=float(d.quantile(0.9))),
                   lv=lv,
                   gerak5={k: round(float((G.yrng[tg == k] > 0.05).mean()) * 100, 1) for k in ("rendah", "sedang", "tinggi")},
                   median={k: round(float(G.yrng[tg == k].median()) * 100, 2) for k in ("rendah", "sedang", "tinggi")},
                   uji=dict(isi90=round(float(isi90.mean()) * 100, 1),
                            isi_per={nm: round(float(isi90[mk].mean()) * 100, 1) for nm, mk in
                                     (("2019-21", RR.index < "2022"), ("2022-23", (RR.index >= "2022") & (RR.index < "2024")), ("2024-26", RR.index >= "2024"))},
                            naik50=round(float((RR.yup <= RR.u50).mean()) * 100, 1), turun50=round(float((-RR.ydn <= RR.d50).mean()) * 100, 1),
                            r2=round(float(1 - ((np.log(RR.yrng) - np.log(RR.s)) ** 2).sum() / ((np.log(RR.yrng) - np.log(RR.yrng).mean()) ** 2).sum()), 3)))
    hasil["sesi"][str(H)] = dict(arah=arah, uji=uji, rentang=rentang)
    print(H, json.dumps(uji), "\n   rentang uji", json.dumps(rentang["uji"]), "lv", [round(v * 100, 2) for v in lv], rentang["gerak5"])
    print("   koef arah", dict(zip(FIT, [round(v, 3) for v in arah["w"]])), "b", round(arah["b"], 3))
json.dump(hasil, open("arah_model.json", "w"), indent=1)
print("tersimpan arah_model.json")

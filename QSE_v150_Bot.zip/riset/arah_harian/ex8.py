import numpy as np, pandas as pd
from wf import *
base = ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24"]
for H in (23, 5, 11, 17):
    F = pd.read_pickle(f"fitur_{H}.pkl").replace([np.inf, -np.inf], np.nan)
    c = F.harga
    F["a_r7"] = ((c / c.shift(7) - 1) <= -0.0921).astype(int)
    F["a_e20"] = ((c / c.ewm(span=20, adjust=False).mean() - 1) >= 0.0994).astype(int)
    F["a_rsi"] = (F.rsi_d >= 70.96).astype(int)
    F["a_cp"] = (F.cp24 <= 0.1851).astype(int)
    F["pasar24"] = F[["eth24", "alt24", "r1h"]].mean(axis=1)
    F.to_pickle(f"fitur_{H}b.pkl")
    print(f"== jam {H} UTC ({(H + 7) % 24:02d}:00 WIB)")
    R = jalan(F, base, model_lr(0.01), tahun=range(2019, 2027))
    nilai(R, "base 24 jam")
    k = (R.p - 0.5).abs()
    print("   kuat (>=0.03):", f"{(k >= 0.03).mean()*100:.0f}% hari, benar {(((R.p > 0.5) == (R.y > 0))[k >= 0.03]).mean()*100:.1f}%")
    R.to_pickle(f"arah_oos_{H}.pkl")
    semua = [x for x in F.columns if x not in SKIP]
    nilai(jalan(F, semua, model_lr(0.003), tahun=range(2019, 2027)), "semua 24 jam", detail=False)

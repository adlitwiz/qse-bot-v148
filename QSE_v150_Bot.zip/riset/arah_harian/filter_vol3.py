import numpy as np, pandas as pd
src = open("wr_kelas.py").read().split("pf = lambda")[0]
exec(src)
RR = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/ah/rentang_oos_semua.pkl")
s = (D.t + pd.Timedelta(hours=4)).values
idx = RR.index.values
k = np.searchsorted(idx, s, side="right") - 1
D["s"] = np.where(k >= 0, RR.s.values[np.clip(k, 0, None)], np.nan)
S = D[(D.skor2 >= 3) & D.s.notna()].copy().sort_values("t")
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
def streak(x):
    m = c = 0
    for v in x:
        c = c + 1 if v <= 0 else 0; m = max(m, c)
    return m
S["kelas"] = np.where(S.skor2 >= 8, "N10", np.where(S.skor2 >= 5, "N9", "N8"))
for bs in (0.0458, 0.05):
    for ba in (3.868, 3.5, 4.5):
        S["tahan"] = (S.s > bs) & (S.atr_pct >= ba)
        o = []
        for per, pm in (("21-23", S.t < "2024"), ("24-26", S.t >= "2024")):
            g = S[pm]; x = g.baru.values; y = g.baru[~g.tahan].values; z = g.baru[g.tahan].values
            o.append(f"{per}: ditahan {g.tahan.mean()*100:4.1f}% (PF {pf(z):.2f}) | WR {np.mean(x>0)*100:.1f}->{np.mean(y>0)*100:.1f} PF {pf(x):.2f}->{pf(y):.2f} total {x.sum():+.0f}->{y.sum():+.0f} DD {dd(x):.0f}->{dd(y):.0f}")
        print(f"gerak>{bs} atr>={ba}: " + " || ".join(o))
S["tahan"] = (S.s > 0.0458) & (S.atr_pct >= 3.868)
print("per kelas / jalur / arah (sinyal yang ditahan):")
for col in ("kelas", "jalur", "arah"):
    for nm, g in S[S.tahan].groupby(col):
        o = []
        for per, pm in (("21-23", g.t < "2024"), ("24-26", g.t >= "2024")):
            z = g.loc[pm, "baru"].values
            o.append(f"{per} n {len(z):4d} WR {np.mean(z>0)*100:4.1f} PF {pf(z):.2f}" if len(z) else f"{per} n 0")
        print(f"   {col} {str(nm):12s} | " + " | ".join(o))
print("== SHORT saja")
for bs in (0.0458, 0.05):
    for ba in (3.868, 3.5, 4.5):
        S["tahan"] = (S.s > bs) & (S.atr_pct >= ba) & (S.arah == -1)
        o = []
        for per, pm in (("21-23", S.t < "2024"), ("24-26", S.t >= "2024")):
            g = S[pm]; x = g.baru.values; y = g.baru[~g.tahan].values; z = g.baru[g.tahan].values
            o.append(f"{per}: ditahan {g.tahan.mean()*100:4.1f}% (PF {pf(z):.2f}) | WR {np.mean(x>0)*100:.1f}->{np.mean(y>0)*100:.1f} PF {pf(x):.2f}->{pf(y):.2f} total {x.sum():+.0f}->{y.sum():+.0f} DD {dd(x):.0f}->{dd(y):.0f} beruntun {streak(x)}->{streak(y)}")
        print(f"gerak>{bs} atr>={ba}: " + " || ".join(o))
S["tahan"] = (S.s > 0.0458) & (S.atr_pct >= 3.868) & (S.arah == -1)
for nm, g in S[S.tahan].groupby("kelas"):
    o = []
    for per, pm in (("21-23", g.t < "2024"), ("24-26", g.t >= "2024")):
        z = g.loc[pm, "baru"].values
        o.append(f"{per} n {len(z):4d} WR {np.mean(z>0)*100:4.1f} PF {pf(z):.2f}" if len(z) else f"{per} n 0")
    print(f"   SHORT ditahan kelas {nm:4s} | " + " | ".join(o))
# per tahun
S["th"] = S.t.dt.year
print("per tahun PF SHORT ditahan:", {int(y): round(pf(g.baru.values), 2) for y, g in S[S.tahan].groupby("th")}, "n", S[S.tahan].groupby("th").size().to_dict())
# sinyal per hari
hari = S.t.dt.floor("D").nunique()
print("sinyal per hari: semua %.2f, setelah tahan %.2f" % (len(S) / hari, (~S.tahan).sum() / hari))
print("== 3 periode, SHORT ditahan (gerak>0.0458, atr>=3.868)")
for nm, (a, b) in (("21-22", ("2021", "2023")), ("23-24", ("2023", "2025")), ("25-26", ("2025", "2027"))):
    g = S[(S.t >= a) & (S.t < b)]
    x = g.baru.values; y = g.baru[~g.tahan].values; z = g.baru[g.tahan].values
    print(f"{nm}: ditahan n {g.tahan.sum()} PF {pf(z):.2f} | PF {pf(x):.2f}->{pf(y):.2f} WR {np.mean(x>0)*100:.1f}->{np.mean(y>0)*100:.1f} total {x.sum():+.0f}->{y.sum():+.0f}")
# bandingkan: SHORT gerak tinggi tanpa syarat ATR, dan SHORT ATR tinggi tanpa syarat gerak
for nm, m in (("SHORT gerak tinggi semua ATR", (S.s > 0.0458) & (S.arah == -1)), ("SHORT ATR tinggi semua gerak", (S.atr_pct >= 3.868) & (S.arah == -1)),
              ("SHORT ATR tinggi gerak sedang", (S.atr_pct >= 3.868) & (S.arah == -1) & (S.s > 0.0315) & (S.s <= 0.0458))):
    o = []
    for per, pm in (("21-23", S.t < "2024"), ("24-26", S.t >= "2024")):
        z = S.loc[m & pm, "baru"].values
        o.append(f"{per} n {len(z)} PF {pf(z):.2f}")
    print(nm, " | ".join(o))
print("== per arah per gerak (sesi terakhir)")
S["lv"] = pd.cut(S.s, [0, 0.0315, 0.0458, 9], labels=["rendah", "sedang", "tinggi"])
for a, an in ((1, "LONG"), (-1, "SHORT")):
    for nm in ("rendah", "sedang", "tinggi"):
        o = []
        for per, pm in (("21-23", S.t < "2024"), ("24-26", S.t >= "2024"), ("21-22", S.t < "2023"), ("23-24", (S.t >= "2023") & (S.t < "2025")), ("25-26", S.t >= "2025")):
            z = S.loc[(S.arah == a) & (S.lv == nm) & pm, "baru"].values
            o.append(f"{per} n {len(z):4d} WR {np.mean(z>0)*100:4.1f} PF {pf(z):.2f}")
        print(f"{an:5s} {nm:7s} | " + " | ".join(o))
print("== lot")
for nm, f in (("penuh", lambda g: np.ones(len(g))), ("tinggi semua 0.5", lambda g: np.where(g.lv == "tinggi", 0.5, 1.0)),
              ("tinggi SHORT 0.5", lambda g: np.where((g.lv == "tinggi") & (g.arah == -1), 0.5, 1.0))):
    o = []
    for per, pm in (("21-23", S.t < "2024"), ("24-26", S.t >= "2024"), ("25-26", S.t >= "2025"), ("semua", S.t.notna())):
        g = S[pm]; x = g.baru.values * f(g)
        o.append(f"{per} total {x.sum():+6.0f} DD {dd(x):4.0f} t/DD {x.sum()/dd(x):5.1f}")
    print(f"{nm:18s} | " + " | ".join(o))

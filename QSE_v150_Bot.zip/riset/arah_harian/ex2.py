import numpy as np, pandas as pd
from wf import *
F = muat(23)
c = F.harga
F["a_r7"] = ((c / c.shift(7) - 1) <= -0.0921).astype(int)
F["a_e20"] = ((c / c.ewm(span=20, adjust=False).mean() - 1) >= 0.0994).astype(int)
F["a_rsi"] = (F.rsi_d >= 70.96).astype(int)
F["a_cp"] = (F.cp24 <= 0.1851).astype(int)
F["pasar24"] = F[["eth24", "alt24", "r1h"]].mean(axis=1)
F.to_pickle("fitur_23b.pkl")
semua = [x for x in F.columns if x not in SKIP]
TH = range(2020, 2025)
up = (F.y > 0)
m = (F.index >= "2020") & (F.index < "2025")
naive = np.where(F.lama_naik == 1, 1, 0)
print(f"naif aturan lama (naik kalau aturan, selain itu turun): {((naive == up)[m]).mean()*100:.1f}%")
for it, lr in ((100, 0.02), (300, 0.02)):
    nilai(jalan(F, semua, model_gb(it, lr), tahun=TH), f"GB semua it={it} lr={lr}", detail=False)
for amb in (0.02, 0.03):
    for mk in (8, 15):
        for C in (0.01, 0.05):
            nilai(jalan(F, semua, model_pilih(C, amb, mk), tahun=TH), f"LR pilih amb={amb} maks={mk} C={C}", detail=False)

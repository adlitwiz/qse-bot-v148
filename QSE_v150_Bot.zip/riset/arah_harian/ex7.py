import numpy as np, pandas as pd
from wf import *
F = pd.read_pickle("fitur_23b.pkl")
base = ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24"]
out, coefs = [], {}
for th in range(2019, 2027):
    a = pd.Timestamp(f"{th}-01-01", tz="UTC"); b = pd.Timestamp(f"{th+1}-01-01", tz="UTC")
    tr = F[(F.index < a) & F.y.notna()]; te = F[(F.index >= a) & (F.index < b) & F.y.notna()]
    p, cf = model_lr(0.01)(tr[base], (tr.y > 0).astype(int), te[base])
    coefs[th] = {k: round(v, 3) for k, v in cf.items()}
    out.append(pd.DataFrame({"p": p, "y": te.y.values, "ya": te.ya.values, "base": (tr.y > 0).mean()}, index=te.index))
R = pd.concat(out)
R.to_pickle("arah_oos_23.pkl")
print(pd.DataFrame(coefs).T.to_string())
nilai(R[R.index >= "2020"], "base 2020-2026")
nilai(R, "base 2019-2026")
R["b"] = pd.cut(R.p, [0, 0.46, 0.48, 0.5, 0.52, 0.54, 0.56, 1])
g = R.groupby("b", observed=True)
print(pd.DataFrame({"n": g.size(), "naik%": g.apply(lambda x: (x.y > 0).mean() * 100).round(1),
                    "alt naik%": g.apply(lambda x: (x.ya > 0).mean() * 100).round(1),
                    "rata BTC%": g.apply(lambda x: x.y.mean() * 100).round(3)}).to_string())
R["arah"] = np.where(R.p >= 0.5, 1, -1)
R["benar"] = np.sign(R.y) == R.arah
R["benar_alt"] = np.sign(R.ya) == R.arah
print("benar BTC per arah:", R.groupby("arah").benar.mean().round(3).to_dict(), "n", R.arah.value_counts().to_dict())
print("benar alt per arah:", R.groupby("arah").benar_alt.mean().round(3).to_dict())
kuat = (R.p - 0.5).abs()
for lo, hi, nm in ((0, 0.01, "tipis"), (0.01, 0.03, "sedang"), (0.03, 1, "kuat")):
    m = (kuat >= lo) & (kuat < hi)
    print(nm, int(m.sum()), f"{m.mean()*100:.0f}% hari", "benar BTC", round(R.benar[m].mean() * 100, 1), "alt", round(R.benar_alt[m].mean() * 100, 1),
          "| per periode:", [round(R.benar[m & pr].mean() * 100, 1) for pr in (R.index < "2022", (R.index >= "2022") & (R.index < "2024"), R.index >= "2024")])
# ikut arah: hasil rata-rata harian long/short BTC
r = R.arah * R.y
print("ikut arah BTC 24 jam: rata/hari %.3f%%, total %.0f%%" % (r.mean() * 100, r.sum() * 100), "| alt", round((R.arah * R.ya).mean() * 100, 3))

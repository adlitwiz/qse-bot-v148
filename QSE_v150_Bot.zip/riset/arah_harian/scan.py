"""Cari kondisi satu dan dua fitur (ambang persentil) yang konsisten condong TURUN atau NAIK di 3 periode."""
import numpy as np, pandas as pd, itertools
F = pd.read_pickle("fitur_23b.pkl").replace([np.inf, -np.inf], np.nan)
F = F[F.y.notna()]
SKIP = {"y", "y12", "ya", "yab", "yrng", "yup", "ydn", "harga", "n_alt", "lama_naik", "dw"}
fit = [c for c in F.columns if c not in SKIP and F[c].nunique() > 2]
up = (F.y > 0).values
per = [np.asarray(F.index < "2021"), np.asarray((F.index >= "2021") & (F.index < "2024")), np.asarray(F.index >= "2024")]
hasil = []
for c in fit:
    x = F[c]
    for q in (0.1, 0.2, 0.8, 0.9):
        # ambang dari data sebelum 2021 saja (supaya tidak melihat masa depan); fitur baru: dari 2021-2022
        ref = x[F.index < "2021"].dropna()
        if len(ref) < 300:
            ref = x[(F.index >= "2021") & (F.index < "2023")].dropna()
        th = ref.quantile(q)
        m = (x <= th) if q < 0.5 else (x >= th)
        st = []
        for p in per:
            k = (m.values & p)
            st.append((k.sum(), up[k].mean() if k.sum() else np.nan, up[p].mean()))
        if min(s[0] for s in st) < 40:
            continue
        d = [s[1] - s[2] for s in st]
        if all(v <= -0.04 for v in d) or all(v >= 0.04 for v in d):
            hasil.append((c, ("<=" if q < 0.5 else ">="), round(th, 5), q, [f"{s[1]*100:.0f}% (n{s[0]}, dasar {s[2]*100:.0f})" for s in st], np.mean(d)))
hasil.sort(key=lambda z: z[-1])
for h in hasil:
    print(f"{'TURUN' if h[-1] < 0 else 'NAIK '} {h[0]:12s} {h[1]} {h[2]:>10} (q{h[3]}) | " + " | ".join(h[4]))

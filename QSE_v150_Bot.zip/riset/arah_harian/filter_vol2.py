import numpy as np, pandas as pd
src = open("wr_kelas.py").read().split("pf = lambda")[0]
exec(src)
RR = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/ah/rentang_oos_semua.pkl")
s = (D.t + pd.Timedelta(hours=4)).values
idx = RR.index.values
k = np.searchsorted(idx, s, side="right") - 1          # sesi terakhir yang sudah lewat
D["s"] = np.where(k >= 0, RR.s.values[np.clip(k, 0, None)], np.nan)
D["s_age"] = (s - idx[np.clip(k, 0, None)]) / np.timedelta64(1, "h")
S = D[(D.skor2 >= 3) & D.s.notna() & (D.s_age <= 7)].copy()
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
lv = [0.0315, 0.0458]
S["lv"] = pd.cut(S.s, [0, lv[0], lv[1], 9], labels=["rendah", "sedang", "tinggi"])
S["pekan"] = pd.to_datetime(S.t + pd.Timedelta(hours=4 + 7)).dt.dayofweek >= 5
S["kelas"] = np.where(S.skor2 >= 8, "N10", np.where(S.skor2 >= 5, "N9", "N8"))
def baris(nm, g, v="baru"):
    o = []
    for per, pm in (("21-23", g.t < "2024"), ("24-26", g.t >= "2024")):
        x = g.loc[pm, v].values
        o.append(f"{per} n {len(x):5d} WR {np.mean(x > 0)*100:4.1f} PF {pf(x):.2f} rata {x.mean():+.3f}" if len(x) else f"{per} n 0")
    print(f"{nm:34s} | " + " | ".join(o))
print("== sesi terakhir (maks 7 jam)")
for nm, g in S.groupby("lv", observed=True): baris(f"gerak {nm}", g)
print("== per kelas")
for kl in ("N8", "N9", "N10"):
    for nm, g in S[S.kelas == kl].groupby("lv", observed=True): baris(f"{kl} gerak {nm}", g)
print("== hari kerja / akhir pekan")
for pk in (False, True):
    for nm, g in S[S.pekan == pk].groupby("lv", observed=True): baris(f"{'pekan' if pk else 'kerja'} gerak {nm}", g)
print("== per jalur")
for j in sorted(S.jalur.unique()):
    for nm, g in S[S.jalur == j].groupby("lv", observed=True): baris(f"{j} {nm}", g)
print("== ukuran lot")
S = S.sort_values("t")
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
for nm, w in (("lot penuh semua", {"rendah": 1, "sedang": 1, "tinggi": 1}), ("tinggi lot 0.5", {"rendah": 1, "sedang": 1, "tinggi": 0.5}),
              ("tinggi 0.5, sedang 0.75", {"rendah": 1, "sedang": 0.75, "tinggi": 0.5}), ("tinggi dilewati", {"rendah": 1, "sedang": 1, "tinggi": 0})):
    o = []
    for per, pm in (("21-23", S.t < "2024"), ("24-26", S.t >= "2024"), ("semua", S.t.notna())):
        g = S[pm]
        x = g.baru.values * g.lv.map(w).astype(float).values
        o.append(f"{per} total {x.sum():+6.0f}R DD {dd(x):4.0f} t/DD {x.sum() / dd(x):5.1f}")
    print(f"{nm:26s} | " + " | ".join(o))

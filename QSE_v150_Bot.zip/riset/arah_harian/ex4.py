import numpy as np, pandas as pd
from wf import *
F = pd.read_pickle("fitur_23b.pkl")
TH = range(2020, 2027)
semua = [x for x in F.columns if x not in SKIP and x != "pasar24"] + ["pasar24"]
base = ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24"]
for tg in ("ya", "y12"):
    print("TARGET", tg, "base naik", round((F[tg] > 0).mean() * 100, 1))
    for nm, fs in (("aturan+pekan+balik", base), ("pakar luas", base + ["cbp7", "ethbtc7", "eth24", "alt24", "adv24", "altbtc_e20", "r4j", "fng", "e200", "rsi_d", "cp24"])):
        nilai(jalan(F, fs, model_lr(0.01), target=tg, tahun=TH), f"{nm} C=0.01", detail=True)
    nilai(jalan(F, semua, model_lr(0.003), target=tg, tahun=TH), "LR semua C=0.003", detail=True)

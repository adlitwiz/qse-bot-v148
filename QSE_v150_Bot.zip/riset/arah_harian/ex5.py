import numpy as np, pandas as pd
from wf import *
F = pd.read_pickle("fitur_23b.pkl")
F["kamis"] = (F.dw == 3).astype(int)
F["sabtu"] = (F.dw == 5).astype(int)
F["minggu"] = (F.dw == 6).astype(int)
F["volz"] = np.log(F.rv24 / F.rv30)
F["balik_x_vol"] = F.pasar24 * (F.volz > 0)
F["fz_x"] = F.f24 * (F.r7h < 0)
TH = range(2020, 2027)
semua = [x for x in F.columns if x not in SKIP]
base = ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24"]
cb = base + ["cbp7", "ethbtc7"]
R1 = jalan(F, base, model_lr(0.01), tahun=TH)
R2 = jalan(F, semua, model_lr(0.003), tahun=TH)
R3 = jalan(F, cb, model_lr(0.01), tahun=TH)
nilai(R1, "base")
nilai(R2, "semua 0.003")
E = R1.copy(); E["p"] = (R1.p + R2.p) / 2
nilai(E, "ensemble base+semua")
E = R1.copy(); E["p"] = (R3.p + R2.p) / 2
nilai(E, "ensemble cb+semua")
for nm, fs in (("base+kamis", base + ["kamis"]), ("base+sabtu/minggu", ["a_r7", "a_e20", "a_rsi", "a_cp", "sabtu", "minggu", "pasar24"]),
               ("base+balik_x_vol", base + ["balik_x_vol", "volz"]), ("base+fz_x", base + ["fz_x", "f24"]),
               ("cb+kamis", cb + ["kamis"])):
    nilai(jalan(F, fs, model_lr(0.01), tahun=TH), nm)
print("TARGET yab (alt lawan BTC)", round((F.yab > 0).mean() * 100, 1))
nilai(jalan(F, semua, model_lr(0.003), target="yab", tahun=TH), "yab semua 0.003")
nilai(jalan(F, ["altbtc1", "altbtc7", "altbtc_e20", "ethbtc1", "ethbtc7", "ethbtc30", "br50", "alt7", "r7h"], model_lr(0.01), target="yab", tahun=TH), "yab relatif")

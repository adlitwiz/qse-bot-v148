import numpy as np, pandas as pd, sys
src = open("wr_kelas.py").read().split("pf = lambda")[0]
exec(src)
P = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/ah/arah_oos_23.pkl")
s = D.t + pd.Timedelta(hours=4)                      # waktu sinyal dikirim
anc = (s - pd.Timedelta(hours=23)).dt.floor("D") + pd.Timedelta(hours=23)
D["p"] = P.p.reindex(anc).values
D["lama"] = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/ah/fitur_23b.pkl").lama_naik.reindex(anc).values
S = D[(D.skor2 >= 3) & D.p.notna()].copy()
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
S["searah"] = np.where(S.arah == 1, S.p - 0.5, 0.5 - S.p)        # positif = sinyal searah tebakan
def baris(nm, m, v="baru"):
    o = []
    for per, pm in (("21-23", S.t < "2024"), ("24-26", S.t >= "2024")):
        x = S.loc[m & pm, v].values
        o.append(f"{per} n {len(x):5d} WR {np.mean(x > 0)*100:4.1f} PF {pf(x):.2f} rata {x.mean():+.3f}")
    print(f"{nm:44s} | " + " | ".join(o))
print("mode seimbang, exit baru (20% 0.5R + BE)")
baris("semua", S.p.notna())
for lo, hi in ((-1, -0.03), (-0.03, -0.01), (-0.01, 0.01), (0.01, 0.03), (0.03, 1)):
    baris(f"searah tebakan {lo:+.2f}..{hi:+.2f}", (S.searah > lo) & (S.searah <= hi))
for a, nm in ((1, "LONG"), (-1, "SHORT")):
    print(nm)
    baris(f"  {nm} semua", S.arah == a)
    baris(f"  {nm} lawan tebakan kuat (>0.03)", (S.arah == a) & (S.searah < -0.03))
    baris(f"  {nm} lawan tebakan (>0.01)", (S.arah == a) & (S.searah < -0.01))
    baris(f"  {nm} searah tebakan kuat", (S.arah == a) & (S.searah > 0.03))
    baris(f"  {nm} di hari aturan lama naik", (S.arah == a) & (S.lama == 1))
    baris(f"  {nm} hari aturan lama naik, bukan p", (S.arah == a) & (S.lama == 1) & (S.searah >= -0.03))

import numpy as np, pandas as pd
from wf import *
F = pd.read_pickle("fitur_23b.pkl")
for d in range(7):
    F[f"dw{d}"] = (F.dw == d).astype(int)
F["kamis"] = F.dw3
TH = range(2020, 2027)
sets = {
 "aturan": ["a_r7", "a_e20", "a_rsi", "a_cp"],
 "aturan+pekan": ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan"],
 "aturan+hari": ["a_r7", "a_e20", "a_rsi", "a_cp"] + [f"dw{d}" for d in range(7)],
 "aturan+pekan+balik": ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24"],
 "aturan+pekan+balik+cb": ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24", "cbp7", "ethbtc7"],
 "pakar luas": ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "kamis", "pasar24", "cbp7", "ethbtc7", "eth24", "alt24", "adv24", "altbtc_e20", "r4j", "fng", "e200", "rsi_d", "cp24"],
}
for nm, fs in sets.items():
    for C in (0.01, 0.1):
        R = jalan(F, fs, model_lr(C), tahun=TH)
        nilai(R, f"{nm} C={C}", detail=(C == 0.1))

import numpy as np, pandas as pd
from wf import *
F = pd.read_pickle("fitur_23b.pkl")
TH = range(2020, 2027)
base = ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24"]
sets = {
 "M1 base+alt4j+rsi1j+cp30": base + ["alt4j", "rsi_1j", "cp30h"],
 "M2 M1+cbp7": base + ["alt4j", "rsi_1j", "cp30h", "cbp7"],
 "M3 M2+tk7h": base + ["alt4j", "rsi_1j", "cp30h", "cbp7", "tk7h"],
 "M4 M3+f24+fng": base + ["alt4j", "rsi_1j", "cp30h", "cbp7", "tk7h", "f24", "fng"],
 "M5 M2+ethbtc7+adv24": base + ["alt4j", "rsi_1j", "cp30h", "cbp7", "ethbtc7", "adv24"],
}
RS = {}
for nm, fs in sets.items():
    for C in (0.01, 0.05):
        R = jalan(F, fs, model_lr(C), tahun=TH)
        RS[(nm, C)] = R
        nilai(R, f"{nm} C={C}", detail=(C == 0.01))
semua = [x for x in F.columns if x not in SKIP]
R2 = jalan(F, semua, model_lr(0.003), tahun=TH)
for k in [("M2 M1+cbp7", 0.01), ("M3 M2+tk7h", 0.01)]:
    E = RS[k].copy(); E["p"] = (RS[k].p + R2.p) / 2
    nilai(E, f"ensemble {k[0]} + semua")

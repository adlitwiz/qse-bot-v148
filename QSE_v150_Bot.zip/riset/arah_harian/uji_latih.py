"""Cek qse_latih (latih ulang otomatis tanpa sklearn) menghasilkan model yang sama dengan latih_final.py (sklearn).
Jalankan dari folder bot: QSE_STATE_DIR=/tmp/kosong python3 riset/arah_harian/uji_latih.py"""
import sys, os, json
import numpy as np
sys.path.insert(0, os.path.abspath("."))
import qse_latih as LT
A, nl = LT.data_latih()
baru, n = LT.latih(A)
lama = json.load(open("arah_model.json"))
for H in ("23", "5", "11", "17"):
    a, b = baru["sesi"][H], lama["sesi"][H]
    dw = float(np.max(np.abs(np.array(a["arah"]["w"]) - np.array(b["arah"]["w"]))))
    print(f"sesi {H}: selisih koefisien maks {dw:.1e} | uji maju baru {a['uji']['akurasi']}% KUAT {a['uji']['tingkat']['kuat'][1]}% | "
          f"riset {b['uji']['akurasi']}% KUAT {b['uji']['tingkat']['kuat'][1]}% | rentang isi 80% {a['rentang']['uji']['isi90']} lawan {b['rentang']['uji']['isi90']}")
print("penjaga:", LT.periksa(baru, lama, n) or "lolos semua")

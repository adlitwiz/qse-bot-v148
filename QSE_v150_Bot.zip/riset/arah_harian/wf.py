"""Uji maju (walk-forward) model arah harian. Latih semua hari sebelum tahun uji, uji tahun itu, ulang per tahun."""
import sys, warnings
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score

warnings.filterwarnings("ignore")
SKIP = {"y", "y12", "ya", "yab", "yrng", "yup", "ydn", "harga", "n_alt", "lama_naik"}


def muat(H=23):
    F = pd.read_pickle(f"fitur_{H}.pkl").replace([np.inf, -np.inf], np.nan)
    return F


def siapkan(Xtr, Xte, klip=4.0):
    mu, sd = Xtr.mean(), Xtr.std().replace(0, 1).fillna(1)
    a = ((Xtr - mu) / sd).clip(-klip, klip).fillna(0)
    b = ((Xte - mu) / sd).clip(-klip, klip).fillna(0)
    return a, b


def model_lr(C=0.01):
    def fit_pred(Xtr, ytr, Xte):
        a, b = siapkan(Xtr, Xte)
        m = LogisticRegression(C=C, max_iter=2000)
        m.fit(a, ytr)
        return m.predict_proba(b)[:, 1], dict(zip(Xtr.columns, m.coef_[0]))
    return fit_pred


def model_gb(it=150, lr=0.03, depth=3, leaf=80, l2=5.0):
    def fit_pred(Xtr, ytr, Xte):
        m = HistGradientBoostingClassifier(max_iter=it, learning_rate=lr, max_depth=depth, min_samples_leaf=leaf,
                                           l2_regularization=l2, early_stopping=False, random_state=0)
        ok = [c for c in Xtr.columns if Xtr[c].notna().sum() >= 200 and Xtr[c].nunique() > 1]
        m.fit(Xtr[ok], ytr)
        return m.predict_proba(Xte[ok])[:, 1], None
    return fit_pred


def jalan(F, fitur, fit_pred, target="y", tahun=range(2020, 2027), mulai_latih="2017-09-01", jendela=None):
    """Return DataFrame prediksi out-of-sample (p, y) untuk semua tahun uji."""
    out = []
    for th in tahun:
        a, b = pd.Timestamp(f"{th}-01-01", tz="UTC"), pd.Timestamp(f"{th + 1}-01-01", tz="UTC")
        lo = pd.Timestamp(mulai_latih, tz="UTC") if jendela is None else a - pd.Timedelta(days=365 * jendela)
        tr = F[(F.index >= lo) & (F.index < a) & F[target].notna()]
        te = F[(F.index >= a) & (F.index < b) & F[target].notna()]
        if len(te) == 0:
            continue
        p, coef = fit_pred(tr[fitur], (tr[target] > 0).astype(int), te[fitur])
        out.append(pd.DataFrame({"p": p, "y": te[target].values, "base": (tr[target] > 0).mean()}, index=te.index))
    return pd.concat(out)


def nilai(R, label="", detail=True):
    up = (R.y > 0).astype(int)
    pred = (R.p > 0.5).astype(int)
    acc = (pred == up).mean()
    br = ((R.p - up) ** 2).mean()
    brb = ((R.base - up) ** 2).mean()
    auc = roc_auc_score(up, R.p)
    conf = (R.p - 0.5).abs()
    sel = []
    for q in (0.5, 0.25, 0.1):
        th = conf.quantile(1 - q)
        m = conf >= th
        sel.append(f"top{int(q * 100)}% {((pred[m] == up[m]).mean()) * 100:4.1f}")
    per = []
    for nm, m in (("20-21", R.index < "2022"), ("22-23", (R.index >= "2022") & (R.index < "2024")), ("24-26", R.index >= "2024")):
        per.append(f"{nm} {((pred[m] == up[m]).mean()) * 100:4.1f}")
    print(f"{label:38s} akurasi {acc * 100:4.1f}  AUC {auc:.3f}  BSS {(1 - br / brb) * 100:+5.2f}%  | " + "  ".join(sel)
          + "  | " + "  ".join(per), flush=True)
    if detail:
        yr = R.groupby(R.index.year).apply(lambda g: f"{(((g.p > 0.5) == (g.y > 0)).mean()) * 100:.0f}")
        print("    per tahun:", dict(yr))
    return acc, auc


def model_pilih(C=0.01, ambang=0.02, maks=15, dasar=None):
    """LR dengan pemilihan fitur di dalam data latih saja: IC peringkat searah di dua paruh latih, |IC| minimal ambang."""
    def fit_pred(Xtr, ytr, Xte):
        n = len(Xtr)
        h1, h2 = Xtr.iloc[: n // 2], Xtr.iloc[n // 2:]
        y1, y2 = ytr.iloc[: n // 2], ytr.iloc[n // 2:]
        skor = {}
        for c in Xtr.columns:
            a, b = h1[c], h2[c]
            if a.notna().sum() < 150 or b.notna().sum() < 150:
                if b.notna().sum() >= 300:          # fitur baru: pakai dua paruh dari bagian yang ada datanya
                    z = Xtr[c].dropna()
                    k = len(z) // 2
                    a, b = z.iloc[:k], z.iloc[k:]
                    ya_, yb_ = ytr.loc[a.index], ytr.loc[b.index]
                else:
                    continue
            else:
                ya_, yb_ = y1, y2
            ia = a.rank().corr(ya_.loc[a.index].rank()) if a.notna().sum() else 0
            ib = b.rank().corr(yb_.loc[b.index].rank()) if b.notna().sum() else 0
            if np.sign(ia) == np.sign(ib) and min(abs(ia), abs(ib)) >= ambang:
                skor[c] = min(abs(ia), abs(ib))
        pilih = sorted(skor, key=lambda c: -skor[c])[:maks]
        if dasar:
            pilih = list(dict.fromkeys(list(dasar) + pilih))
        if not pilih:
            return np.full(len(Xte), ytr.mean()), {}
        a, b = siapkan(Xtr[pilih], Xte[pilih])
        m = LogisticRegression(C=C, max_iter=2000)
        m.fit(a, ytr)
        return m.predict_proba(b)[:, 1], dict(zip(pilih, m.coef_[0]))
    return fit_pred

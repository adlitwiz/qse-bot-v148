"""OOS perkiraan rentang untuk 4 sesi, gabung jadi deret per jam sesi (dipakai uji filter sinyal)."""
import numpy as np, pandas as pd, json
from sklearn.linear_model import LinearRegression
import importlib.util, sys
spec = importlib.util.spec_from_file_location("lf", "latih_final.py")
out = []
for H in (23, 5, 11, 17):
    F = pd.read_pickle(f"fitur_{H}b.pkl").replace([np.inf, -np.inf], np.nan)
    X = pd.DataFrame({"l_rng24": np.log(F.rng24), "l_rng7": np.log(F.rng7), "l_rv30": np.log(F.rv30),
                      "pekan": F.akhir_pekan.astype(float), "senin": (F.dw == 0).astype(float), "l_vrel": F.vrel, "abs_r1": F.r1h.abs()}, index=F.index)
    ok = np.isfinite(X).all(axis=1) & F.yrng.notna() & (F.yrng > 0)
    X, G = X[ok], F[ok]
    ly = np.log(G.yrng)
    for th in range(2019, 2027):
        a, b = pd.Timestamp(f"{th}-01-01", tz="UTC"), pd.Timestamp(f"{th + 1}-01-01", tz="UTC")
        tr, te = X.index < a, (X.index >= a) & (X.index < b)
        lr = LinearRegression().fit(X[tr], ly[tr])
        out.append(pd.DataFrame({"s": np.exp(lr.predict(X[te])), "H": H, "pekan": X.pekan[te]}, index=X.index[te]))
R = pd.concat(out).sort_index()
R.to_pickle("rentang_oos_semua.pkl")
print(R.shape, R.index[0], R.index[-1])

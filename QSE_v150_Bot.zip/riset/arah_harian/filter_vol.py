import numpy as np, pandas as pd
src = open("wr_kelas.py").read().split("pf = lambda")[0]
exec(src)
RR = pd.read_pickle("/tmp/claude-0/-home-claude/d4357a16-3227-54a1-8dbb-77b0850574a6/scratchpad/ah/rentang_oos.pkl")
s = D.t + pd.Timedelta(hours=4)
anc = (s - pd.Timedelta(hours=23)).dt.floor("D") + pd.Timedelta(hours=23)
D["s"] = RR.s.reindex(anc).values
S = D[(D.skor2 >= 3) & D.s.notna()].copy()
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
lv = [0.0315, 0.0458]
S["lv"] = pd.cut(S.s, [0, lv[0], lv[1], 9], labels=["rendah", "sedang", "tinggi"])
for v in ("baru",):
    for nm, g in S.groupby("lv", observed=True):
        o = []
        for per, pm in (("21-23", g.t < "2024"), ("24-26", g.t >= "2024")):
            x = g.loc[pm, v].values
            o.append(f"{per} n {len(x):5d} WR {np.mean(x > 0)*100:4.1f} PF {pf(x):.2f} rata {x.mean():+.3f}")
        print(f"gerak {nm:7s} | " + " | ".join(o))
    for a, an in ((1, "LONG"), (-1, "SHORT")):
        for nm, g in S[S.arah == a].groupby("lv", observed=True):
            o = []
            for per, pm in (("21-23", g.t < "2024"), ("24-26", g.t >= "2024")):
                x = g.loc[pm, v].values
                o.append(f"{per} n {len(x):5d} WR {np.mean(x > 0)*100:4.1f} PF {pf(x):.2f}")
            print(f"  {an} gerak {nm:7s} | " + " | ".join(o))

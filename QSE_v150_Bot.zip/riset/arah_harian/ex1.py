import numpy as np, pandas as pd
from wf import *
F = muat(23)
semua = [c for c in F.columns if c not in SKIP]
harga = [c for c in semua if not any(c.startswith(p) for p in ("f_", "f24", "f7h", "f30h", "fz", "prem", "ftk", "lev", "oi", "ls", "tls", "dvol", "vrp", "stc", "lsa", "lsp"))]
print(len(semua), len(harga))
TH = range(2020, 2025)
up = (F.y > 0)
m = F.index >= "2020"
m &= F.index < "2025"
print(f"base naik 2020-2024: {up[m].mean()*100:.1f}%  aturan lama naik: {(up[m & (F.lama_naik==1)]).mean()*100:.1f}% (n {int((m & (F.lama_naik==1)).sum())}), lain {(up[m & (F.lama_naik==0)]).mean()*100:.1f}%")
for C in (0.002, 0.005, 0.01, 0.03, 0.1):
    nilai(jalan(F, semua, model_lr(C), tahun=TH), f"LR semua C={C}", detail=False)
for C in (0.005, 0.01, 0.03):
    nilai(jalan(F, harga, model_lr(C), tahun=TH), f"LR harga C={C}", detail=False)
for it, lr in ((100, 0.02), (200, 0.02), (300, 0.03)):
    nilai(jalan(F, semua, model_gb(it, lr), tahun=TH), f"GB semua it={it} lr={lr}", detail=False)
    nilai(jalan(F, harga, model_gb(it, lr), tahun=TH), f"GB harga it={it} lr={lr}", detail=False)

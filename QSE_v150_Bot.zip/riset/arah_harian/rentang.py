import numpy as np, pandas as pd
from sklearn.linear_model import LinearRegression
F = pd.read_pickle("fitur_23b.pkl").replace([np.inf, -np.inf], np.nan)
F = F[F.yrng.notna() & (F.yrng > 0)]
X = pd.DataFrame({"l_rng24": np.log(F.rng24), "l_rng7": np.log(F.rng7), "l_rv30": np.log(F.rv30),
                  "pekan": F.akhir_pekan, "senin": (F.dw == 0).astype(int), "l_vrel": F.vrel.fillna(0),
                  "abs_r1": F.r1h.abs()}, index=F.index)
y = np.log(F.yrng)
ok = np.isfinite(X).all(axis=1) & np.isfinite(y)
X, y, F = X[ok], y[ok], F[ok]
out = []
for th in range(2019, 2027):
    a = pd.Timestamp(f"{th}-01-01", tz="UTC"); b = pd.Timestamp(f"{th+1}-01-01", tz="UTC")
    tr = X.index < a; te = (X.index >= a) & (X.index < b)
    m = LinearRegression().fit(X[tr], y[tr])
    s_tr = np.exp(m.predict(X[tr])); s_te = np.exp(m.predict(X[te]))
    u_tr = F.yup[tr] / s_tr; d_tr = -F.ydn[tr] / s_tr
    q = {k: (u_tr.quantile(k), d_tr.quantile(k)) for k in (0.5, 0.8, 0.9)}
    o = pd.DataFrame({"s": s_te, "yrng": F.yrng[te], "yup": F.yup[te], "ydn": F.ydn[te], "naif": F.rng7[te]}, index=X.index[te])
    for k, (qu, qd) in q.items():
        o[f"u{int(k*100)}"] = qu * s_te; o[f"d{int(k*100)}"] = qd * s_te
    if th == 2026:
        print("koef", dict(zip(X.columns, m.coef_.round(3))), "intersep", round(m.intercept_, 3), "kuantil", {k: (round(v[0], 3), round(v[1], 3)) for k, v in q.items()})
    out.append(o)
R = pd.concat(out)
ly = np.log(R.yrng)
r2 = 1 - ((ly - np.log(R.s)) ** 2).sum() / ((ly - ly.mean()) ** 2).sum()
r2n = 1 - ((ly - np.log(R.naif)) ** 2).sum() / ((ly - ly.mean()) ** 2).sum()
print(f"R2 log rentang: model {r2:.3f}, naif rata 7 hari {r2n:.3f}")
print(f"rentang nyata median {R.yrng.median()*100:.2f}%, tebakan median {R.s.median()*100:.2f}%")
print("salah rata (MAPE) model %.1f%%, naif %.1f%%" % ((abs(R.s / R.yrng - 1)).median() * 100, (abs(R.naif / R.yrng - 1)).median() * 100))
for k in (50, 80, 90):
    cu = (R.yup <= R[f"u{k}"]).mean(); cd = (-R.ydn <= R[f"d{k}"]).mean()
    both = ((R.yup <= R[f"u{k}"]) & (-R.ydn <= R[f"d{k}"])).mean()
    print(f"kuantil {k}: naik maks di bawah batas {cu*100:.1f}%, turun maks di atas batas {cd*100:.1f}%, dua-duanya {both*100:.1f}%")
for nm, m in (("19-21", R.index < "2022"), ("22-23", (R.index >= "2022") & (R.index < "2024")), ("24-26", R.index >= "2024")):
    both = ((R.yup <= R.u90) & (-R.ydn <= R.d90))[m].mean()
    print(nm, f"band 90/90 isi {both*100:.1f}%", f"lebar rata {((R.u90 + R.d90)[m]).mean()*100:.2f}%")
# tebakan tingkat gerak: rendah/sedang/tinggi vs nyata
qq = R.s.quantile([1/3, 2/3]).values
lv = pd.cut(R.s, [0, qq[0], qq[1], 9], labels=["rendah", "sedang", "tinggi"])
print(R.groupby(lv, observed=True).yrng.agg(["median", lambda x: (x > 0.05).mean()]).rename(columns={"<lambda_0>": "gerak>5%"}))
R.to_pickle("rentang_oos.pkl")

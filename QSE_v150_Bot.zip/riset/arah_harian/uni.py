import sys, numpy as np, pandas as pd
H = int(sys.argv[1]) if len(sys.argv) > 1 else 23
tg = sys.argv[2] if len(sys.argv) > 2 else "y"
F = pd.read_pickle(f"fitur_{H}.pkl").replace([np.inf, -np.inf], np.nan)
F = F[F[tg].notna()]
per = [("17-20", F.index < "2021"), ("21-23", (F.index >= "2021") & (F.index < "2024")), ("24-26", F.index >= "2024")]
skip = {"y", "y12", "ya", "yab", "yrng", "yup", "ydn", "harga", "n_alt"}
rows = []
for c in F.columns:
    if c in skip:
        continue
    out = {"fitur": c}
    for nm, m in per:
        x, y = F.loc[m, c], F.loc[m, tg]
        ok = x.notna() & y.notna()
        if ok.sum() < 150:
            out[nm] = np.nan; out[nm + "_t"] = np.nan
            continue
        ic = x[ok].rank().corr(y[ok].rank())
        q = pd.qcut(x[ok].rank(method="first"), 3, labels=False)
        up = (y[ok] > 0).groupby(q).mean()
        out[nm] = round(ic, 3)
        out[nm + "_t"] = f"{up.iloc[0]*100:.0f}/{up.iloc[2]*100:.0f}"
    rows.append(out)
R = pd.DataFrame(rows).set_index("fitur")
ics = R[["17-20", "21-23", "24-26"]]
R["konsisten"] = (np.sign(ics).nunique(axis=1) == 1) & ics.notna().all(axis=1)
R["min_abs"] = ics.abs().min(axis=1)
pd.set_option("display.width", 200)
print(f"target {tg}, jam {H} UTC. base naik:", {nm: round((F.loc[m, tg] > 0).mean() * 100, 1) for nm, m in per})
print(R.sort_values("min_abs", ascending=False).to_string())

import numpy as np, pandas as pd
from wf import *
F = pd.read_pickle("fitur_23b.pkl")
F["l_rng24"] = np.log(F.rng24.clip(lower=1e-4))
base = ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "pasar24"]
TH = range(2019, 2027)
for nm, fs in (("base", base), ("base+vol", base + ["l_rng24", "disp24", "vrel"]), ("base+vol+cb", base + ["l_rng24", "disp24", "vrel", "cbp7"]),
               ("alt khusus", ["a_r7", "a_e20", "a_rsi", "a_cp", "akhir_pekan", "alt24", "alt7", "l_rng24", "disp24", "vrel", "cbp7", "br50"])):
    R = jalan(F, fs, model_lr(0.01), target="ya", tahun=TH)
    nilai(R, f"ALT {nm}")
    k = (R.p - 0.5).abs()
    pr = (R.p > 0.5)
    print("    benar per arah:", {"NAIK": round((R.y[pr] > 0).mean() * 100, 1), "TURUN": round((R.y[~pr] <= 0).mean() * 100, 1)},
          "kuat:", f"{(k >= 0.03).mean()*100:.0f}% hari benar {((pr == (R.y > 0))[k >= 0.03]).mean()*100:.1f}%")

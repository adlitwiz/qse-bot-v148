"""Dataset fitur harian untuk riset arah BTC dan altcoin. Titik keputusan T = jam H UTC tiap hari (H=23 -> 06:00 WIB).
Semua deret per jam diberi indeks waktu TUTUP candle, jadi nilai di T hanya memakai data yang sudah selesai di T.
python3 -I fitur.py <scratchpad> <H>"""
import os, sys, glob, json
import numpy as np, pandas as pd

SP = sys.argv[1]
H = int(sys.argv[2]) if len(sys.argv) > 2 else 23
DL, K5 = os.path.join(SP, "dl"), os.path.join(SP, "k5")
HR = pd.Timedelta(hours=1)
STABIL = {"USDCUSDT", "FDUSDUSDT", "TUSDUSDT", "BUSDUSDT", "DAIUSDT", "USDEUSDT"}


def klines(folder):
    out = []
    for f in sorted(glob.glob(os.path.join(folder, "*.csv"))):
        df = pd.read_csv(f, header=None, low_memory=False)
        df = df[pd.to_numeric(df[0], errors="coerce").notna()].astype(float)
        out.append(df)
    df = pd.concat(out)
    t = df[0].values
    t = np.where(t > 1e14, t / 1000, t)
    df.index = pd.to_datetime(t.astype("int64"), unit="ms", utc=True) + HR      # indeks = waktu tutup
    df = df[~df.index.duplicated(keep="last")].sort_index()
    df = df.rename(columns={1: "o", 2: "h", 3: "l", 4: "c", 7: "q", 10: "tb"})[["o", "h", "l", "c", "q", "tb"]]
    full = pd.date_range(df.index[0], df.index[-1], freq="1h")
    df = df.reindex(full)
    df["c"] = df["c"].ffill()
    for k in ("o", "h", "l"):
        df[k] = df[k].fillna(df["c"])
    df[["q", "tb"]] = df[["q", "tb"]].fillna(0)
    return df


def csv_jam(path):
    df = pd.read_csv(path, index_col=0, parse_dates=True)
    df.index = df.index + HR
    return df["close"].astype(float)


def rsi(x, n=14):
    d = x.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))


def ema(x, n):
    return x.ewm(span=n, adjust=False).mean()


# ------------------------------------------------------------------ BTC dan ETH spot Binance (dengan taker buy)
B = klines(os.path.join(DL, "spot1h_BTCUSDT"))
E = klines(os.path.join(DL, "spot1h_ETHUSDT"))
P = B["c"]
lp = np.log(P)
r1 = lp.diff()
T = P.index[(P.index.hour == H)]
T = T[T >= P.index[0] + pd.Timedelta(days=30)]
F = pd.DataFrame(index=T)
D = P.loc[T]                                  # close harian berjangkar di jam H
lD = np.log(D)
for k in (1, 4, 8, 12):
    F[f"r{k}j"] = (lp - lp.shift(k)).reindex(T)
for k in (1, 3, 7, 14, 30, 60, 90, 180, 365):
    F[f"r{k}h"] = lD - lD.shift(k)
for k in (20, 50, 100, 200):
    F[f"e{k}"] = lD - np.log(ema(D, k))
F["rsi_d"] = rsi(D)
P4 = P[(P.index.hour % 4) == (H % 4)]
F["rsi_4j"] = rsi(P4).reindex(T)
F["rsi_1j"] = rsi(P).reindex(T)
hh = {n: B["h"].rolling(n).max() for n in (24, 168, 720, 2160)}
ll = {n: B["l"].rolling(n).min() for n in (24, 168, 720, 2160)}
for n, nm in ((24, "24"), (168, "7h"), (720, "30h")):
    F[f"cp{nm}"] = ((P - ll[n]) / (hh[n] - ll[n]).replace(0, np.nan)).reindex(T)
F["rng24"] = np.log(hh[24] / ll[24]).reindex(T)
F["rng7"] = F["rng24"].shift(1).rolling(7).mean()
F["rr"] = F["rng24"] / F["rng7"]
F["rv24"] = (r1.rolling(24).std() * np.sqrt(24)).reindex(T)
F["rv7"] = (r1.rolling(168).std() * np.sqrt(24)).reindex(T)
F["rv30"] = (r1.rolling(720).std() * np.sqrt(24)).reindex(T)
F["rvr"] = F["rv7"] / F["rv30"]
q24 = B["q"].rolling(24).sum()
F["vrel"] = np.log(q24.reindex(T) / q24.reindex(T).shift(1).rolling(30).mean())
tb = B["tb"]
for n, nm in ((4, "4"), (24, "24"), (168, "7h")):
    F[f"tk{nm}"] = (tb.rolling(n).sum() / B["q"].rolling(n).sum().replace(0, np.nan) - 0.5).reindex(T)
F["tkd"] = F["tk24"] - F["tk7h"]
F["dd90"] = np.log(P / hh[2160]).reindex(T)
F["up90"] = np.log(P / ll[2160]).reindex(T)
up = (F["r1h"] > 0).astype(int) - (F["r1h"] < 0).astype(int)
st = np.zeros(len(up))
for i in range(1, len(up)):
    st[i] = st[i - 1] + up.iloc[i] if np.sign(st[i - 1]) == up.iloc[i] else up.iloc[i]
F["streak"] = st
wk = P[(P.index.dayofweek == 0) & (P.index.hour == 0)]
F["wo"] = lp.reindex(T).values - np.log(wk.reindex(T, method="ffill")).values
mo = P[(P.index.day == 1) & (P.index.hour == 0)]
F["mo"] = lp.reindex(T).values - np.log(mo.reindex(T, method="ffill")).values
tgt = T + pd.Timedelta(hours=7)                       # tanggal WIB
F["dw"] = tgt.dayofweek
F["akhir_pekan"] = F["dw"].isin([5, 6]).astype(int)
gap = (lp - lp.shift(50)).reindex(T)
F["gap_senin"] = np.where(F["dw"] == 0, gap, 0.0) if H == 23 else 0.0
# ETH
pe = np.log(E["c"])
F["eth24"] = (pe - pe.shift(24)).reindex(T)
rat = (pe - lp).dropna()
F["ethbtc1"] = (rat - rat.shift(24)).reindex(T)
F["ethbtc7"] = (rat - rat.shift(168)).reindex(T)
F["ethbtc30"] = (rat - rat.shift(720)).reindex(T)
rd = np.exp(rat.reindex(T))
F["ethbtc_e20"] = np.log(rd / ema(rd, 20))

# ------------------------------------------------------------------ altcoin (data17 Binance 2017-2020, data 2020-2026)
alt = {}
nama = sorted({os.path.basename(p).split("_")[0] for p in glob.glob(os.path.join(K5, "data", "*_60.csv"))} |
              {os.path.basename(p).split("_")[0] for p in glob.glob(os.path.join(K5, "data17", "*_60.csv"))})
for s in nama:
    if s in ("BTCUSDT",) or s in STABIL:
        continue
    parts = []
    p17 = os.path.join(K5, "data17", f"{s}_60.csv")
    p20 = os.path.join(K5, "data", f"{s}_60.csv")
    if os.path.exists(p17):
        parts.append(csv_jam(p17))
    if os.path.exists(p20):
        x = csv_jam(p20)
        if parts:
            x = x[x.index > parts[0].index[-1]]
        parts.append(x)
    c = pd.concat(parts)
    c = c[~c.index.duplicated(keep="last")]
    c = c[c > 0]
    alt[s] = c
A = pd.DataFrame({s: c.reindex(T) for s, c in alt.items()})       # close harian berjangkar
lA = np.log(A)
ra1 = (lA - lA.shift(1)).clip(-0.5, 0.5)
ra7 = (lA - lA.shift(7)).clip(-1.0, 1.0)
F["n_alt"] = A.notna().sum(axis=1)
F["alt24"] = ra1.mean(axis=1)
F["alt7"] = ra7.mean(axis=1)
F["adv24"] = (ra1 > 0).sum(axis=1) / ra1.notna().sum(axis=1).replace(0, np.nan)
F["disp24"] = ra1.std(axis=1)
for k in (20, 50, 200):
    ok = A.notna().rolling(k).sum() >= k
    above = (A > A.ewm(span=k, adjust=False).mean()) & ok
    F[f"br{k}"] = above.sum(axis=1) / ok.sum(axis=1).replace(0, np.nan)
rel = (F["alt24"].fillna(0) - F["r1h"].fillna(0)).cumsum()
F["altbtc1"] = F["alt24"] - F["r1h"]
F["altbtc7"] = rel - rel.shift(7)
F["altbtc_e20"] = rel - ema(rel, 20)
# alt 4 jam terakhir (momentum menjelang titik keputusan): pakai data jam
AJ = pd.DataFrame({s: c for s, c in alt.items()}).reindex(P.index)
lAJ = np.log(AJ)
F["alt4j"] = (lAJ - lAJ.shift(4)).clip(-0.5, 0.5).mean(axis=1).reindex(T)

# ------------------------------------------------------------------ funding Bybit (2020+), basis, OI dan rasio Binance
fu = pd.read_csv(os.path.join(K5, "data", "BTCUSDT_FUND.csv"))
fu.index = pd.to_datetime(fu.ts, unit="ms", utc=True)
fr = fu["rate"].astype(float).sort_index()
fr = fr[~fr.index.duplicated()]
fH = fr.reindex(P.index, method="ffill", tolerance=pd.Timedelta(hours=9))          # nilai funding terakhir per jam
F["f_last"] = fH.reindex(T)
fs = fr.copy()
for n, nm in ((1, "24"), (7, "7h"), (30, "30h")):
    m = fs.rolling(f"{n}D").mean()
    F[f"f{nm}"] = m.reindex(P.index, method="ffill", tolerance=pd.Timedelta(hours=9)).reindex(T)
F["fz"] = F["f24"] - F["f30h"]
pr = klines(os.path.join(DL, "prem1h"))["c"]
pr = pr[pr.index >= pd.Timestamp("2020-01-01", tz="UTC")]
F["prem_last"] = pr.reindex(T)
F["prem24"] = pr.rolling(24).mean().reindex(T)
F["prem7"] = pr.rolling(168).mean().reindex(T)
FU = klines(os.path.join(DL, "fut1h"))
F["ftk24"] = (FU["tb"].rolling(24).sum() / FU["q"].rolling(24).sum() - 0.5).reindex(T)
F["ftk4"] = (FU["tb"].rolling(4).sum() / FU["q"].rolling(4).sum() - 0.5).reindex(T)
fq = FU["q"].rolling(24).sum().reindex(T)
sq = B["q"].rolling(24).sum().reindex(T)
lev = np.log(fq / sq)
F["lev"] = lev - lev.shift(1).rolling(30).mean()
ms = []
for f in sorted(glob.glob(os.path.join(DL, "metrics", "*.csv"))):
    try:
        ms.append(pd.read_csv(f))
    except Exception:
        pass
M = pd.concat(ms)
M.index = pd.to_datetime(M.create_time, utc=True)
M = M[~M.index.duplicated(keep="last")].sort_index()
M = M[["sum_open_interest", "count_toptrader_long_short_ratio", "sum_toptrader_long_short_ratio",
       "count_long_short_ratio", "sum_taker_long_short_vol_ratio"]].astype(float)
M = M[(M > 0).all(axis=1)]
MH = M.resample("1h", label="right", closed="right").last()
MT = MH.reindex(P.index, method="ffill", tolerance=pd.Timedelta(hours=2))
oi = np.log(MT["sum_open_interest"])
F["oi24"] = (oi - oi.shift(24)).reindex(T)
F["oi7"] = (oi - oi.shift(168)).reindex(T)
F["oi4"] = (oi - oi.shift(4)).reindex(T)
F["oi_div"] = F["oi24"] * -np.sign(F["r1h"])            # OI naik saat harga turun -> positif
for col, nm in (("count_toptrader_long_short_ratio", "lsa_top"), ("sum_toptrader_long_short_ratio", "lsp_top"),
                ("count_long_short_ratio", "ls_glob")):
    x = np.log(MT[col])
    F[nm] = x.reindex(T)
    F[nm + "_d24"] = (x - x.shift(24)).reindex(T)
    F[nm + "_z"] = ((x - x.rolling(720, min_periods=200).mean()) / x.rolling(720, min_periods=200).std()).reindex(T)
tl = np.log(M["sum_taker_long_short_vol_ratio"]).resample("1h", label="right", closed="right").mean()
tl = tl.reindex(P.index)
F["tls24"] = tl.rolling(24, min_periods=12).mean().reindex(T)
F["tls4"] = tl.rolling(4, min_periods=2).mean().reindex(T)

# ------------------------------------------------------------------ sentimen dan data luar
fng = json.load(open(os.path.join(DL, "fng.json")))["data"]
fg = pd.Series({pd.Timestamp(int(x["timestamp"]), unit="s", tz="UTC"): float(x["value"]) for x in fng}).sort_index()
fgT = fg.reindex(T.floor("D"))
F["fng"] = fgT.values
F["fng_d7"] = F["fng"] - F["fng"].shift(7)
cb = []
for f in glob.glob(os.path.join(DL, "coinbase1h", "*.json")):
    cb += json.load(open(f))
cbs = pd.Series({pd.Timestamp(int(r[0]), unit="s", tz="UTC") + HR: float(r[4]) for r in cb}).sort_index()
cbs = cbs[~cbs.index.duplicated()].reindex(P.index)
cbp = np.log(cbs / P)
F["cbp"] = cbp.reindex(T)
F["cbp24"] = cbp.rolling(24, min_periods=12).mean().reindex(T)
F["cbp7"] = cbp.rolling(168, min_periods=80).mean().reindex(T)
F["cbp_d"] = F["cbp24"] - F["cbp7"]
dv = json.load(open(os.path.join(DL, "dvol.json")))
dvs = pd.Series({pd.Timestamp(int(r[0]), unit="ms", tz="UTC") + HR: float(r[4]) for r in dv}).sort_index()
dvs = dvs[~dvs.index.duplicated()].reindex(P.index, method="ffill", tolerance=pd.Timedelta(hours=2))
F["dvol"] = dvs.reindex(T)
F["dvol_d24"] = (np.log(dvs) - np.log(dvs.shift(24))).reindex(T)
F["vrp"] = F["dvol"] / 100 - F["rv30"] * np.sqrt(365)
sc = json.load(open(os.path.join(DL, "stable.json")))
scs = pd.Series({pd.Timestamp(int(x["date"]), unit="s", tz="UTC"): float(x["totalCirculatingUSD"].get("peggedUSD", np.nan))
                 for x in sc}).sort_index()
scs = scs[scs > 1e9]
scl = np.log(scs)
sc7 = (scl - scl.shift(7)).shift(1)                   # pakai nilai hari sebelumnya (aman)
sc30 = (scl - scl.shift(30)).shift(1)
F["stc7"] = sc7.reindex(T.floor("D")).values
F["stc30"] = sc30.reindex(T.floor("D")).values

# ------------------------------------------------------------------ aturan lama (ATURAN_NAIK) untuk pembanding
c = D
F["lama_naik"] = ((c / c.shift(7) - 1 <= -0.0921) | (c / ema(c, 20) - 1 >= 0.0994) | (F["rsi_d"] >= 70.96) |
                  (F["cp24"] <= 0.1851)).astype(int)

# ------------------------------------------------------------------ target 24 jam dan 12 jam ke depan
F["y"] = lD.shift(-1) - lD
F["y12"] = (lp.shift(-12) - lp).reindex(T)
F["ya"] = (lA.shift(-1) - lA).clip(-0.5, 0.5).mean(axis=1)
F["yab"] = F["ya"] - F["y"]
F["yrng"] = np.log(hh[24].shift(-24) / ll[24].shift(-24)).reindex(T)        # rentang 24 jam ke depan
F["yup"] = np.log(hh[24].shift(-24) / P).reindex(T)                          # naik maksimal 24 jam ke depan
F["ydn"] = np.log(ll[24].shift(-24) / P).reindex(T)
F["harga"] = D
F = F[F.index >= pd.Timestamp("2017-09-15", tz="UTC")]
F.to_pickle(os.path.join(SP, "ah", f"fitur_{H}.pkl"))
print(F.shape, F.index[0], F.index[-1])
print(F.notna().mean().round(2).to_string())

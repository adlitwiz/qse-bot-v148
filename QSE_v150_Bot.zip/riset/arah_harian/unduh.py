"""Unduh data riset arah harian ke folder dl (data mentah, tidak dieksekusi)."""
import os, sys, io, zipfile, json, time, datetime as dt
import urllib.request
from concurrent.futures import ThreadPoolExecutor

DL = sys.argv[1]
os.makedirs(DL, exist_ok=True)
BV = "https://data.binance.vision/data"


def get(url, tries=4):
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 qse-riset"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            time.sleep(1 + k)
        except Exception:
            time.sleep(1 + k)
    return None


def bulan(a, b):
    y, m = a
    while (y, m) <= b:
        yield f"{y}-{m:02d}"
        m += 1
        if m == 13:
            y, m = y + 1, 1


def hari(a, b):
    d = dt.date(*a)
    while d <= dt.date(*b):
        yield d.isoformat()
        d += dt.timedelta(days=1)


def zip_csv(raw):
    z = zipfile.ZipFile(io.BytesIO(raw))
    return z.read(z.namelist()[0]).decode()


def ambil(job):
    url, out = job
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return 1
    raw = get(url)
    if raw is None:
        return 0
    try:
        txt = zip_csv(raw) if url.endswith(".zip") else raw.decode()
    except Exception:
        return 0
    with open(out + ".tmp", "w") as f:
        f.write(txt)
    os.replace(out + ".tmp", out)
    return 1


jobs = []
for sym in ("BTCUSDT", "ETHUSDT"):
    d = os.path.join(DL, f"spot1h_{sym}")
    os.makedirs(d, exist_ok=True)
    for b in bulan((2017, 8), (2026, 9)):
        jobs.append((f"{BV}/spot/monthly/klines/{sym}/1h/{sym}-1h-{b}.zip", os.path.join(d, f"{b}.csv")))
    for h in hari((2026, 10, 1), (2026, 10, 26)):
        jobs.append((f"{BV}/spot/daily/klines/{sym}/1h/{sym}-1h-{h}.zip", os.path.join(d, f"{h}.csv")))
sym = "BTCUSDT"
for nm, path, a in (("fut1h", "klines/BTCUSDT/1h/BTCUSDT-1h", (2020, 1)), ("prem1h", "premiumIndexKlines/BTCUSDT/1h/BTCUSDT-1h", (2020, 1)),
                    ("fund", "fundingRate/BTCUSDT/BTCUSDT-fundingRate", (2019, 9))):
    d = os.path.join(DL, nm)
    os.makedirs(d, exist_ok=True)
    for b in bulan(a, (2026, 9)):
        jobs.append((f"{BV}/futures/um/monthly/{path}-{b}.zip", os.path.join(d, f"{b}.csv")))
    if nm != "fund":
        dd = "klines" if nm == "fut1h" else "premiumIndexKlines"
        for h in hari((2026, 10, 1), (2026, 10, 26)):
            jobs.append((f"{BV}/futures/um/daily/{dd}/BTCUSDT/1h/BTCUSDT-1h-{h}.zip", os.path.join(d, f"{h}.csv")))
d = os.path.join(DL, "metrics")
os.makedirs(d, exist_ok=True)
for h in hari((2020, 9, 1), (2026, 10, 26)):
    jobs.append((f"{BV}/futures/um/daily/metrics/BTCUSDT/BTCUSDT-metrics-{h}.zip", os.path.join(d, f"{h}.csv")))

t0 = time.time()
with ThreadPoolExecutor(24) as ex:
    hasil = list(ex.map(ambil, jobs))
print("binance", sum(hasil), "/", len(jobs), round(time.time() - t0), "s", flush=True)

# Fear and Greed
raw = get("https://api.alternative.me/fng/?limit=0&format=json")
if raw:
    open(os.path.join(DL, "fng.json"), "wb").write(raw)
    print("fng ok", flush=True)

# Coinbase BTC-USD 1 jam, 300 candle per permintaan
cb = os.path.join(DL, "coinbase1h")
os.makedirs(cb, exist_ok=True)
t = int(dt.datetime(2017, 8, 1, tzinfo=dt.timezone.utc).timestamp())
akhir = int(dt.datetime(2026, 10, 27, tzinfo=dt.timezone.utc).timestamp())
cjobs = []
while t < akhir:
    t2 = min(t + 300 * 3600, akhir)
    s1 = dt.datetime.fromtimestamp(t, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    s2 = dt.datetime.fromtimestamp(t2, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    cjobs.append((f"https://api.exchange.coinbase.com/products/BTC-USD/candles?granularity=3600&start={s1}&end={s2}",
                  os.path.join(cb, f"{t}.json")))
    t = t2


def ambil_cb(job):
    url, out = job
    if os.path.exists(out) and os.path.getsize(out) > 2:
        return 1
    for k in range(5):
        raw = get(url)
        if raw and raw[:1] == b"[":
            open(out, "wb").write(raw)
            return 1
        time.sleep(1.5 + k)
    return 0


with ThreadPoolExecutor(4) as ex:
    hasil = list(ex.map(ambil_cb, cjobs))
print("coinbase", sum(hasil), "/", len(cjobs), round(time.time() - t0), "s", flush=True)

# DVOL Deribit 1 jam sejak 2021
dv = []
t = int(dt.datetime(2021, 3, 1, tzinfo=dt.timezone.utc).timestamp()) * 1000
while t < akhir * 1000:
    t2 = t + 1000 * 3600 * 1000
    raw = get(f"https://www.deribit.com/api/v2/public/get_volatility_index_data?currency=BTC&start_timestamp={t}&end_timestamp={t2}&resolution=3600")
    if raw:
        try:
            dv += json.loads(raw)["result"]["data"]
        except Exception:
            pass
    t = t2
json.dump(dv, open(os.path.join(DL, "dvol.json"), "w"))
print("dvol", len(dv), round(time.time() - t0), "s", flush=True)

raw = get("https://stablecoins.llama.fi/stablecoincharts/all")
if raw:
    open(os.path.join(DL, "stable.json"), "wb").write(raw)
    print("stable ok", flush=True)
print("SELESAI", round(time.time() - t0), "s", flush=True)

"""Bedah trade SL penuh dan uji cara keluar pengurang SL penuh (populasi sinyal live, aturan 36 jam + TP 20% di +0.5R).
Varian: kunci (setelah sempat untung +X R, SL naik ke Y R), ketat (di jam H belum aman, SL ke Y R atau tutup), potong separuh."""
import os, sys, time
import numpy as np, pandas as pd
import pf_waktu3 as P

TPR, TRL, SLA = P.TPR, P.TRL, P.SLA


def sim(H, L, C, e, d, risk, atr, jalur, n, kunci=None, ketat=None, separuh=None, jam_stop=36):
    """kunci=(pemicu_R, sl_R): sekali harga sempat +pemicu_R (belum aman), SL dipindah ke sl_R.
    ketat=(jam, sl_R): di jam itu kalau belum aman, SL dipindah ke sl_R. Kalau harga sudah di bawah sl_R, tutup market.
    separuh=lv_R: tutup 50% saat harga menyentuh lv_R (negatif). Return (R, jam_keluar, jam_aman, mfe_R)."""
    sl = e - d * risk
    best = e
    sisa, real = 1.0, 0.0
    lv = e + d * 0.5 * risk
    aman = -1
    tp = e + d * TPR[jalur] * risk if jalur in TPR else None
    tr0 = TRL.get(jalur)
    sudah_kunci = sudah_separuh = False
    mfe = 0.0
    for j in range(n):
        hi, lo = H[j], L[j]
        # potong separuh dulu (harga turun lewat lv sebelum SL)
        if separuh is not None and not sudah_separuh and aman < 0:
            lvp = e + d * separuh * risk
            if (lo <= lvp) if d == 1 else (hi >= lvp):
                real += 0.5 * sisa * separuh
                sisa *= 0.5
                sudah_separuh = True
        if (lo <= sl) if d == 1 else (hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman, mfe
        mfe = max(mfe, ((hi - e) if d == 1 else (e - lo)) / risk)
        if aman < 0 and ((hi >= lv) if d == 1 else (lo <= lv)):
            real += 0.2 * sisa * 0.5           # 20% dari sisa ditutup di +0.5R (sama dengan _tutup_bagian di bot)
            sisa = sisa * 0.8
            sl = max(sl, e) if d == 1 else min(sl, e)
            aman = j + 1
        if tp is not None and ((hi >= tp) if d == 1 else (lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman, mfe
        best = max(best, hi) if d == 1 else min(best, lo)
        if tr0 is not None and j % 4 == 3:
            sl = max(sl, best - tr0 * atr) if d == 1 else min(sl, best + tr0 * atr)
        if kunci is not None and aman < 0 and not sudah_kunci and mfe >= kunci[0]:
            sl_baru = e + d * kunci[1] * risk
            sl = max(sl, sl_baru) if d == 1 else min(sl, sl_baru)
            sudah_kunci = True
        if ketat is not None and aman < 0 and j + 1 == ketat[0]:
            rnow = (C[j] - e) * d / risk
            if rnow <= ketat[1]:
                return real + sisa * rnow, j + 1, aman, mfe
            sl_baru = e + d * ketat[1] * risk
            sl = max(sl, sl_baru) if d == 1 else min(sl, sl_baru)
        if jam_stop and j + 1 == jam_stop and aman < 0:
            return real + sisa * (C[j] - e) * d / risk, j + 1, aman, mfe
    return real + sisa * (C[n - 1] - e) * d / risk, n, aman, mfe


VAR = [("dasar", {}),
       ("kunci +0.3R SL -0.5R", dict(kunci=(0.3, -0.5))),
       ("kunci +0.3R SL -0.3R", dict(kunci=(0.3, -0.3))),
       ("kunci +0.25R SL -0.5R", dict(kunci=(0.25, -0.5))),
       ("kunci +0.4R SL -0.5R", dict(kunci=(0.4, -0.5))),
       ("kunci +0.4R SL 0", dict(kunci=(0.4, 0.0))),
       ("ketat jam 12 SL -0.5R", dict(ketat=(12, -0.5))),
       ("ketat jam 24 SL -0.5R", dict(ketat=(24, -0.5))),
       ("ketat jam 24 SL -0.3R", dict(ketat=(24, -0.3))),
       ("separuh di -0.5R", dict(separuh=-0.5)),
       ("separuh di -0.7R", dict(separuh=-0.7)),
       ("kunci +0.3R -0.5R + ketat 24 -0.5R", dict(kunci=(0.3, -0.5), ketat=(24, -0.5)))]


def jalankan():
    S = P.R[P.live]
    rows = []
    t0 = time.time()
    for s, Z in S.groupby("sym"):
        h = pd.read_csv(f"../data/{s}_60.csv", index_col=0, parse_dates=True)
        ix = h.index
        O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
        for r in Z.itertuples():
            k0 = ix.searchsorted(r.masuk)
            if k0 >= len(ix) or ix[k0] != r.masuk:
                continue
            e = O[k0]
            risk = e * r.slpct / 100
            d = int(r.arah)
            atr = risk / SLA.get(r.jalur, 2.0)
            cost = 0.15 / r.slpct
            n = min(180 if r.jalur in TPR else 240, len(ix) - k0)
            out = dict(idx=r.Index)
            for nm, kw in VAR:
                RR, x, a, mfe = sim(H[k0:k0 + n], L[k0:k0 + n], C[k0:k0 + n], e, d, risk, atr, r.jalur, n, **kw)
                out[nm] = RR - cost
                out["x" + nm] = x
                out["a" + nm] = a
                if nm == "dasar":
                    out["mfe"] = mfe
            rows.append(out)
    X = pd.DataFrame(rows).set_index("idx").sort_index()
    X.to_pickle("pf_slpenuh.pkl")
    print("sim", len(X), round(time.time() - t0), "s", flush=True)
    return X


if __name__ == "__main__":
    X = pd.read_pickle("pf_slpenuh.pkl") if os.path.exists("pf_slpenuh.pkl") and "ulang" not in sys.argv else jalankan()
    R = P.R[P.live].join(X)
    # cek dasar sama dengan t5j36
    print("cek dasar vs t5j36: beda maks", float(np.abs(R["dasar"] - R["t5j36"]).max()))
    sp = R["dasar"] < -0.9
    print(f"SL penuh {sp.mean() * 100:.1f}% | MFE sebelum SL penuh: kuantil {R.loc[sp, 'mfe'].quantile([.25, .5, .75, .9]).round(2).tolist()} | "
          f">=0.25R {np.mean(R.loc[sp, 'mfe'] >= 0.25) * 100:.0f}% >=0.3R {np.mean(R.loc[sp, 'mfe'] >= 0.3) * 100:.0f}% "
          f">=0.4R {np.mean(R.loc[sp, 'mfe'] >= 0.4) * 100:.0f}% | jam ke SL median {R.loc[sp, 'xdasar'].median():.0f}")
    for per, pm in (("21-23", R.masuk < "2024"), ("24-26", R.masuk >= "2024"), ("semua", R.masuk.notna())):
        print(f"== per trade {per}")
        for nm, _ in VAR:
            x = R.loc[pm, nm].values
            print(f"   {nm:36s} WR {np.mean(x > 0) * 100:4.1f} PF {P.pf(x):.2f} rata {x.mean():+.3f} SL penuh {np.mean(x < -0.9) * 100:4.1f}% "
                  f"rugi rata {x[x <= 0].mean():+.2f}", flush=True)

"""Uji celah pengurang rugi beruntun dan SL penuh (populasi sinyal live, satu orang, aturan 36 jam + aman 2)."""
import numpy as np
import pf_beruntun as B

live = B.live
KD = B.KD
VAR = [
    ("sekarang", {}),
    ("maks 1 entry per candle", dict(maks_candle=1)),
    ("maks 2 entry per candle", dict(maks_candle=2)),
    ("maks 3 entry per candle", dict(maks_candle=3)),
    ("maks 2 searah berisiko", dict(maks_searah=2)),
    ("maks 3 searah berisiko", dict(maks_searah=3)),
    ("maks 4 searah berisiko", dict(maks_searah=4)),
    ("maks 2/candle + 3 searah", dict(maks_candle=2, maks_searah=3)),
    ("maks 2/candle + 4 searah", dict(maks_candle=2, maks_searah=4)),
    ("jeda 3 SL penuh, lanjut saat robot aman", dict(jeda=dict(k=3, jenis="penuh", lanjut="aman"))),
    ("jeda 2 SL penuh, lanjut saat robot aman", dict(jeda=dict(k=2, jenis="penuh", lanjut="aman"))),
    ("jeda 4 kalah, lanjut saat robot aman", dict(jeda=dict(k=4, jenis="kalah", lanjut="aman"))),
    ("jeda 3 kalah, lanjut saat robot aman", dict(jeda=dict(k=3, jenis="kalah", lanjut="aman"))),
    ("jeda 3 SL penuh, lanjut 24 jam", dict(jeda=dict(k=3, jenis="penuh", lanjut="jam", jam=24))),
    ("2/candle + jeda 3 SL penuh aman", dict(maks_candle=2, jeda=dict(k=3, jenis="penuh", lanjut="aman"))),
    ("2/candle + 3 searah + jeda 3 penuh aman", dict(maks_candle=2, maks_searah=3, jeda=dict(k=3, jenis="penuh", lanjut="aman"))),
]
if __name__ == "__main__":
    for nm, kw in VAR:
        a = B.porto2(KD, 5, 2, live, **kw)
        print(B.metrik(KD, a, nm), flush=True)

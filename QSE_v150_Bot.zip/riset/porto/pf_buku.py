import numpy as np, pandas as pd
D = pd.read_pickle("pf_orang_D.pkl").reset_index(drop=True)
LEMAH = {"smc_choch", "msb_hpz", "GZH"}
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
def buku(hanya_seimbang, per_jalur, glob):
    kirim = np.zeros(len(D), bool); buka = []; baru_n = {}
    for i, r in enumerate(D.itertuples()):
        if hanya_seimbang and r.skor2 < 3: continue
        buka = [b for b in buka if b[0] > r.masuk]
        if any(b[1] == r.sym for b in buka): continue
        if per_jalur and sum(1 for b in buka if b[3] == r.jalur) >= per_jalur: continue
        kk = (r.jalur, r.masuk)
        if baru_n.get(kk, 0) >= 5: continue
        n = sum(1 for b in buka if b[2] == r.arah)
        if glob and (n >= glob or (r.jalur in LEMAH and n >= 8)): continue
        buka.append((r.td, r.sym, r.arah, r.jalur)); kirim[i] = True; baru_n[kk] = baru_n.get(kk, 0) + 1
    return kirim
def orang(kirim, cap):
    ambil = np.zeros(len(D), bool); buka = []
    for i, r in enumerate(D.itertuples()):
        if not kirim[i] or r.skor2 < 3: continue
        buka = [b for b in buka if b[0] > r.masuk]
        if cap and len(buka) >= cap: continue
        if any(b[1] == r.sym for b in buka): continue
        buka.append((r.tb, r.sym)); ambil[i] = True
    return ambil
def rem_aktif(kirim, thr=32, n=8):
    B = D[kirim].sort_values("td")
    bt = pd.DatetimeIndex(B.td)
    br = B.Rd.values * np.where(B.jalur.values == "GZH", 0.5, 1.0)
    eq = np.cumsum(br); ddv = np.maximum.accumulate(eq) - eq
    rug = np.zeros(len(br), int); c = 0
    for i, v in enumerate(br):
        c = c + 1 if v < 0 else 0; rug[i] = c
    S = D[kirim & (D.skor2.values >= 3)]
    k = bt.searchsorted(S.masuk, side="right") - 1
    return float(np.mean(np.where(k >= 0, (ddv[np.clip(k, 0, None)] > thr) | (rug[np.clip(k, 0, None)] >= n), False)))
hari = D.masuk.dt.floor("D").nunique()
for nm, hs, pj, gl in (("A sekarang: buku semua, 8/jalur, 16 searah", False, 8, 16), ("B buku semua, 8/jalur, tanpa 16", False, 8, 0),
                        ("C buku seimbang, 8/jalur, 16 searah", True, 8, 16), ("D buku seimbang, 8/jalur, tanpa 16", True, 8, 0),
                        ("E buku seimbang, 12/jalur, tanpa 16", True, 12, 0), ("F buku seimbang tanpa batas", True, 0, 0)):
    k = buku(hs, pj, gl)
    ks = k & (D.skor2.values >= 3)
    a = orang(k, 5)
    o = []
    for per, pm in (("21-23", D.masuk < "2024"), ("24-26", D.masuk >= "2024"), ("semua", D.masuk.notna())):
        x = D.loc[a & pm, "Rb"].values
        o.append(f"{per} n {len(x):4d} WR {np.mean(x > 0)*100:4.1f} PF {pf(x):.2f} total {x.sum():+4.0f} DD {dd(x):3.0f}")
    print(f"{nm:44s} | kirim {ks.sum() / hari:4.2f}/hari rem aktif {rem_aktif(k)*100:4.1f}% | orang maks 5 {a.sum() / hari:4.2f}/hari | " + " | ".join(o), flush=True)

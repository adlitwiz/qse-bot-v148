import numpy as np, pandas as pd
exec(open("pf_buku.py").read().split("hari = D.masuk")[0])
k = buku(False, 8, 0)
# rem per jalur: buku robot jalur itu (R jalur), DD > 16R atau rugi 6 beruntun (Ichimoku sama 16R/6)
B = D[k].copy()
aktif_j = {}
for j, g in B.groupby("jalur"):
    g = g.sort_values("td"); r = g.Rd.values
    eq = np.cumsum(r); ddv = np.maximum.accumulate(eq) - eq
    rug = np.zeros(len(r), int); c = 0
    for i, v in enumerate(r):
        c = c + 1 if v < 0 else 0; rug[i] = c
    aktif_j[j] = (pd.DatetimeIndex(g.td), ddv, rug)
out = []; buka = []
for i, r in enumerate(D.itertuples()):
    if not k[i] or r.skor2 < 3: continue
    buka = [b for b in buka if b[0] > r.masuk]
    if len(buka) >= 5 or any(b[1] == r.sym for b in buka): continue
    bt, ddv, rug = aktif_j[r.jalur]
    q = bt.searchsorted(r.masuk, side="right") - 1
    lot = 0.5 if (q >= 0 and (ddv[q] > 16 or rug[q] >= 6)) else 1.0
    buka.append((r.tb, r.sym)); out.append((i, lot))
idx = np.array([x[0] for x in out]); lot = np.array([x[1] for x in out])
for nm, L in (("tanpa rem", np.ones(len(lot))), ("rem per jalur 16R/6", lot)):
    o = []
    for per, pm in (("21-23", D.masuk.values[idx] < np.datetime64("2024-01-01")), ("24-26", D.masuk.values[idx] >= np.datetime64("2024-01-01")), ("semua", np.ones(len(idx), bool))):
        x = D.Rb.values[idx][pm] * L[pm]
        o.append(f"{per} total {x.sum():+5.0f} DD {dd(x):3.0f} t/DD {x.sum()/max(dd(x),1e-9):4.1f}")
    print(f"B {nm:20s} lot1/2 {np.mean(L < 1)*100:4.1f}% | " + " | ".join(o))

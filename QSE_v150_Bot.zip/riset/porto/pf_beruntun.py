"""Riset rugi beruntun dan SL penuh untuk satu orang (aturan sekarang: TP 20% di +0.5R lalu SL ke entry, batas 36 jam,
5 slot berisiko + 2 aman). Populasi sinyal seperti bot live (pf_waktu3). Urutan rugi dihitung menurut waktu tutup."""
import numpy as np, pandas as pd
import pf_waktu3 as P

R, live = P.R, P.live
KD = "t5j36"
H = 3600 * 10**9
masuk_h = (R.masuk.values.astype("datetime64[ns]").astype(np.int64) // H).astype(np.int64)


def arr(kd):
    x = R["x" + kd].values.astype(np.int64)
    a = R["a" + kd].values.astype(np.int64)
    keluar = masuk_h + x
    aman = np.where(a >= 0, masuk_h + np.maximum(a, 0), keluar)
    return keluar, aman, R[kd].values


def porto2(kd=KD, cap=5, runner=2, pilih=None, maks_candle=None, maks_searah=None, jeda=None, kecuali=None):
    """jeda: dict(k=3, jenis='kalah'|'penuh', lanjut='aman'|'jam', jam=24): setelah k rugi beruntun (urut waktu tutup),
    berhenti entry baru sampai ada sinyal robot (calon, diambil atau tidak) yang masuk sesudah jeda dan sudah aman
    (kena TP 20%), atau sampai `jam` lewat."""
    keluar, aman, Rv = arr(kd)
    a_raw = R["a" + kd].values.astype(np.int64)
    aman_ok = a_raw >= 0
    aman_t = masuk_h + np.maximum(a_raw, 0)
    sym, arah = R.sym.values, R.arah.values
    n = len(R)
    ambil = np.zeros(n, bool)
    buka = []
    tutup_antri = []            # (keluar, R) trade diambil yang belum dihitung beruntunnya
    beruntun = 0
    jeda_dari = None
    calon_jeda = []             # index sinyal calon sesudah jeda mulai
    for i in range(n):
        if pilih is not None and not pilih[i]:
            continue
        t = masuk_h[i]
        # catat trade yang sudah tutup sebelum t, urut waktu tutup
        if tutup_antri:
            tutup_antri.sort()
            sisa = []
            for k_, r_ in tutup_antri:
                if k_ <= t:
                    if jeda is not None:
                        rugi = (r_ < -0.9) if jeda["jenis"] == "penuh" else (r_ <= 0)
                        beruntun = beruntun + 1 if rugi else 0
                        if jeda_dari is None and beruntun >= jeda["k"]:
                            jeda_dari = k_
                            calon_jeda = []
                else:
                    sisa.append((k_, r_))
            tutup_antri = sisa
        if jeda_dari is not None:
            if t >= jeda_dari:
                calon_jeda.append(i)
            lanjut = False
            if jeda["lanjut"] == "jam":
                lanjut = t >= jeda_dari + jeda["jam"]
            else:
                lanjut = any(aman_ok[j] and aman_t[j] <= t for j in calon_jeda if j != i)
                if jeda.get("jam") and t >= jeda_dari + jeda["jam"]:
                    lanjut = True
            if lanjut:
                jeda_dari, beruntun = None, 0
            else:
                continue
        buka = [b for b in buka if keluar[b] > t]
        if any(sym[b] == sym[i] for b in buka):
            continue
        berisiko = [b for b in buka if aman[b] > t]
        if len(berisiko) >= cap or len(buka) >= cap + runner:
            continue
        if maks_candle and sum(1 for b in buka if masuk_h[b] == t) >= maks_candle:
            continue
        if maks_searah and sum(1 for b in berisiko if arah[b] == arah[i]) >= maks_searah:
            continue
        buka.append(i)
        ambil[i] = True
        tutup_antri.append((keluar[i], Rv[i]))
    return ambil


def metrik(kd, ambil, label, tahun=False):
    keluar, aman, Rv = arr(kd)
    idx = np.nonzero(ambil)[0]
    urut = idx[np.argsort(keluar[idx], kind="stable")]
    x = Rv[urut]
    def runs(mask):
        m = c = 0
        for v in mask:
            c = c + 1 if v else 0
            m = max(m, c)
        return m
    kalah = runs(x <= 0)
    penuh = runs(x < -0.9)
    eq = np.cumsum(x)
    dd = float((np.maximum.accumulate(eq) - eq).max())
    # SL penuh per 7 hari terburuk
    kt = keluar[urut]
    w = 0
    j = 0
    for i_ in range(len(kt)):
        while kt[i_] - kt[j] > 168:
            j += 1
        w = max(w, int(np.sum(x[j:i_ + 1] < -0.9)))
    hari = (R.masuk.max() - R.masuk.min()).days
    o = []
    for per, lo, hi in (("21-23", None, "2024"), ("24-26", "2024", None)):
        pm = np.ones(len(R), bool)
        if lo:
            pm &= (R.masuk >= lo).values
        if hi:
            pm &= (R.masuk < hi).values
        y = Rv[ambil & pm]
        o.append(f"{per} PF {P.pf(y):.2f} {y.sum():+4.0f}R")
    s = (f"{label:44s} | {ambil.sum() / hari:4.2f}/hari WR {np.mean(x > 0) * 100:4.1f} PF {P.pf(x):.2f} {x.sum():+4.0f}R DD {dd:3.0f} | "
         f"kalah beruntun {kalah:2d} SL penuh beruntun {penuh:2d} SL penuh {np.mean(x < -0.9) * 100:4.1f}% maks SL penuh/7hari {w:2d} | "
         + " | ".join(o))
    if tahun:
        th = R.masuk.dt.year.values
        s += "\n" + " " * 46 + " ".join(f"{y}: {Rv[ambil & (th == y)].sum():+4.0f}R" for y in sorted(set(th)))
    return s


if __name__ == "__main__":
    base = porto2()
    print(metrik(KD, base, "sekarang (36j + aman 2)", tahun=True))
    # struktur rugi beruntun: berapa banyak dari runtun terpanjang yang masuk di candle sama / searah
    keluar, aman, Rv = arr(KD)
    idx = np.nonzero(base)[0]
    urut = idx[np.argsort(keluar[idx], kind="stable")]
    x = Rv[urut]
    best, cur, s0 = 0, 0, 0
    for k, v in enumerate(x):
        if v <= 0:
            cur += 1
            if cur > best:
                best, s0 = cur, k - cur + 1
        else:
            cur = 0
    run = urut[s0:s0 + best]
    Z = R.iloc[run][["sym", "jalur", "arah", "masuk", KD, "slpct"]].copy()
    Z["keluar_jam"] = (R["x" + KD].values[run])
    print("\nruntun kalah terpanjang:")
    print(Z.to_string())
    print("\nentry per candle di runtun:", Z.masuk.value_counts().values.tolist(), "| arah:", Z.arah.value_counts().to_dict())

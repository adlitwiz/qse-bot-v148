"""Grid aturan ketat (jam J belum aman: rugi lebih dari L tutup, kalau belum SL naik ke L) dan gabungan dengan jeda,
di simulasi satu orang (5 berisiko + 2 aman, batas 36 jam), populasi sinyal live. Urutan rugi menurut waktu tutup."""
import os, sys, time
import numpy as np, pandas as pd
import pf_waktu3 as P
import pf_slpenuh as S
import pf_beruntun as B

GRID = [(j, l) for j in (6, 8, 10, 12, 16, 20) for l in (-0.4, -0.5, -0.6)]


def jalankan():
    Z0 = P.R[P.live]
    rows = []
    t0 = time.time()
    for s, Z in Z0.groupby("sym"):
        h = pd.read_csv(f"../data/{s}_60.csv", index_col=0, parse_dates=True)
        ix = h.index
        O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
        for r in Z.itertuples():
            k0 = ix.searchsorted(r.masuk)
            if k0 >= len(ix) or ix[k0] != r.masuk:
                continue
            e = O[k0]
            risk = e * r.slpct / 100
            d = int(r.arah)
            atr = risk / S.SLA.get(r.jalur, 2.0)
            cost = 0.15 / r.slpct
            n = min(180 if r.jalur in S.TPR else 240, len(ix) - k0)
            out = dict(idx=r.Index)
            for j, l in GRID:
                nm = f"k{j}_{-l:.1f}"
                RR, x, a, _ = S.sim(H[k0:k0 + n], L[k0:k0 + n], C[k0:k0 + n], e, d, risk, atr, r.jalur, n, ketat=(j, l))
                out[nm] = RR - cost
                out["x" + nm] = x
                out["a" + nm] = a
            rows.append(out)
    X = pd.DataFrame(rows).set_index("idx").sort_index()
    X.to_pickle("pf_slpenuh2.pkl")
    print("sim", len(X), round(time.time() - t0), "s", flush=True)
    return X


if __name__ == "__main__":
    X = pd.read_pickle("pf_slpenuh2.pkl") if os.path.exists("pf_slpenuh2.pkl") and "ulang" not in sys.argv else jalankan()
    X1 = pd.read_pickle("pf_slpenuh.pkl")
    for X_ in (X, X1):
        for c in X_.columns:
            if c == "mfe":
                continue
            v = X_[c].reindex(B.R.index)
            if c.startswith("x"):
                B.R[c] = v.fillna(1).astype(np.int64)
            elif c.startswith("a"):
                B.R[c] = v.fillna(-1).astype(np.int64)
            else:
                B.R[c] = v.fillna(0.0).astype(float)
    live = P.live
    L = B.R[live]
    print("== per trade (populasi live)")
    for j, l in GRID:
        nm = f"k{j}_{-l:.1f}"
        o = []
        for per, pm in (("21-23", L.masuk < "2024"), ("24-26", L.masuk >= "2024")):
            x = L.loc[pm, nm].values
            o.append(f"{per} PF {P.pf(x):.2f} SLp {np.mean(x < -0.9) * 100:4.1f}%")
        x = L[nm].values
        print(f"   ketat jam {j:2d} L {l:+.1f} | WR {np.mean(x > 0) * 100:4.1f} PF {P.pf(x):.2f} rata {x.mean():+.3f} SL penuh {np.mean(x < -0.9) * 100:4.1f}% | "
              + " | ".join(o), flush=True)
    print()
    print("== satu orang")
    J3 = dict(k=3, jenis="kalah", lanjut="aman")
    J4 = dict(k=4, jenis="kalah", lanjut="aman")
    for kd in ["t5j36", "k8_0.5", "k10_0.5", "k12_0.5", "k12_0.4", "k12_0.6", "k16_0.5", "separuh di -0.7R", "separuh di -0.5R"]:
        for jn, jd in (("", None), (" + jeda 3 kalah", J3), (" + jeda 4 kalah", J4)):
            a = B.porto2(kd, 5, 2, live, jeda=jd)
            print(B.metrik(kd, a, kd + jn), flush=True)

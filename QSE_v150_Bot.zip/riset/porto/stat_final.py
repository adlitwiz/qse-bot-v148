import numpy as np, pandas as pd
import pf_jeda as J
B, P = J.B, J.P
live = P.live
a_lama = P.porto(B.R, "t5", 5, None, live)
print(B.metrik("t5", a_lama, "cara lama (sebelum hari ini)"))
a_b = B.porto2("k8_0.5", 5, 2, live, jeda=dict(k=3, jenis="kalah", lanjut="jam", jam=24))
print(B.metrik("k8_0.5", a_b, "aturan lengkap baru"))
L = B.R[live]
kd = "k8_0.5"
print("per jalur (jam 8 + 36 jam): aman<=36j, median jam ke aman, median lama trade aman")
for j, W in L.groupby("jalur"):
    a = W["a" + kd].values; x = W["x" + kd].values; ok = a >= 0
    print(f'"{j}": ({np.mean(ok & (a <= 36)) * 100:.0f}, {np.median(a[ok]):.0f}, {np.median(x[ok]):.0f}),  n {len(W)}')
a = L["a" + kd].values; x = L["x" + kd].values; ok = a >= 0
print(f"SEMUA aman<=36j {np.mean(ok & (a <= 36)) * 100:.0f}% median jam ke aman {np.median(a[ok]):.0f} lama aman {np.median(x[ok]):.0f}")
xx = L[kd].values
print(f"per trade: WR {np.mean(xx > 0) * 100:.1f} PF {P.pf(xx):.2f} SL penuh {np.mean(xx < -0.9) * 100:.1f}%")
# di jam 8: berapa persen ditutup, berapa SL dinaikkan
x8 = L["x" + kd].values; a8 = L["a" + kd].values
tutup = (x8 == 8) & (a8 < 0)
naik = (x8 > 8) & ~((a8 >= 0) & (a8 <= 8))
print(f"jam 8: ditutup {tutup.mean() * 100:.1f}% sinyal, SL dinaikkan {naik.mean() * 100:.1f}%, sudah aman sebelum jam 8 {np.mean((a8 >= 0) & (a8 <= 8)) * 100:.1f}%")

"""Angka final aturan anti rugi beruntun: jam 8 belum kena TP 20% -> rugi > 0.5R tutup, kalau belum SL ke -0.5R,
plus jeda entry 24 jam setelah 3 rugi beruntun (per orang). Dibanding aturan sekarang (36 jam + aman 2)."""
import numpy as np, pandas as pd
import pf_jeda as J
B, P = J.B, J.P
live = P.live
for nm, kd, jd in (("sekarang (36j + aman 2)", "t5j36", None),
                   ("jam 8 SL -0.5R", "k8_0.5", None),
                   ("jam 8 SL -0.5R + jeda 3 kalah 24j", "k8_0.5", dict(k=3, jenis="kalah", lanjut="jam", jam=24)),
                   ("jam 8 SL -0.5R + jeda 4 kalah 24j", "k8_0.5", dict(k=4, jenis="kalah", lanjut="jam", jam=24))):
    a = B.porto2(kd, 5, 2, live, jeda=jd)
    print(B.metrik(kd, a, nm, tahun=True), flush=True)
    keluar, aman, Rv = B.arr(kd)
    x = Rv[a]
    jam = (keluar - B.masuk_h)[a]
    print(" " * 46 + f"rugi rata {x[x <= 0].mean():+.2f}R | menang rata {x[x > 0].mean():+.2f}R | selesai<=48j {np.mean(jam <= 48) * 100:.0f}% | n {a.sum()}")
L = B.R[live]
x = L["k8_0.5"].values
print(f"per trade sinyal live jam 8: WR {np.mean(x > 0) * 100:.1f} PF {P.pf(x):.2f} SL penuh {np.mean(x < -0.9) * 100:.1f}% rata {x.mean():+.3f}")
x = L["t5j36"].values
print(f"per trade sinyal live 36j  : WR {np.mean(x > 0) * 100:.1f} PF {P.pf(x):.2f} SL penuh {np.mean(x < -0.9) * 100:.1f}% rata {x.mean():+.3f}")
# ditutup di jam 8 (rugi > 0.5R) dan dipindah SL
a8 = L["ak8_0.5"].values; x8 = L["xk8_0.5"].values
tutup8 = (x8 == 8) & (a8 < 0)
print(f"ditutup di jam 8: {tutup8.mean() * 100:.1f}% sinyal, R rata {L.loc[tutup8, 'k8_0.5'].mean():+.2f} | kalau ditahan (36j): rata {L.loc[tutup8, 't5j36'].mean():+.2f}, "
      f"kena SL penuh {np.mean(L.loc[tutup8, 't5j36'] < -0.9) * 100:.0f}%")

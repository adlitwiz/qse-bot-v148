import numpy as np, pandas as pd
D = pd.read_pickle("pf_orang_D.pkl").reset_index(drop=True)
pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
def orang(kirim, cap, rem=None):
    """rem: None, ('robot', thr, n) atau ('diri', thr, n). Return array (idx, lot)."""
    out = []; buka = []; selesai = []          # selesai: (waktu tutup, R*lot)
    # rem robot: dari buku robot (semua sinyal terkirim robot), R jalur
    if rem and rem[0] == "robot":
        B = D[kirim].sort_values("td"); bt = pd.DatetimeIndex(B.td).tz_convert("UTC") if pd.DatetimeIndex(B.td).tz is not None else pd.DatetimeIndex(B.td).tz_localize("UTC"); br = (B.Rd.values * np.where(B.jalur.values == "GZH", 0.5, 1.0))
        beq = np.cumsum(br); bdd = np.maximum.accumulate(beq) - beq
        brug = np.zeros(len(br), int); c = 0
        for i, v in enumerate(br):
            c = c + 1 if v < 0 else 0; brug[i] = c
    for i, r in enumerate(D.itertuples()):
        if not kirim[i] or r.skor2 < 3: continue
        buka = [b for b in buka if b[0] > r.masuk]
        if cap and len(buka) >= cap: continue
        if any(b[1] == r.sym for b in buka): continue
        lot = 1.0
        if rem:
            if rem[0] == "robot":
                k = bt.searchsorted(r.masuk, side="right") - 1
                if k >= 0 and (bdd[k] > rem[1] or brug[k] >= rem[2]): lot = 0.5
            else:
                cl = sorted([s for s in selesai if s[0] <= r.masuk])
                if cl:
                    rr = np.array([s[1] for s in cl]); eq = np.cumsum(rr)
                    c = 0
                    for v in rr[::-1]:
                        if v < 0: c += 1
                        else: break
                    if (eq.max() - eq[-1]) > rem[1] or c >= rem[2]: lot = 0.5
        buka.append((r.tb, r.sym)); selesai.append((r.tb, r.Rb * lot)); out.append((i, lot))
    return out
for nm, rem in (("tanpa rem", None), ("rem robot 32R/8", ("robot", 32, 8)), ("rem diri 6R/5", ("diri", 6, 5)), ("rem diri 8R/6", ("diri", 8, 6)), ("rem diri 10R/8", ("diri", 10, 8))):
    for cap_nm, kirim in (("tanpa batas robot", D.k0.values), ("batas robot 16", D.k16.values)):
        a = orang(kirim, 5, rem)
        idx = np.array([x[0] for x in a]); lot = np.array([x[1] for x in a])
        o = []
        for per, pm in (("21-23", D.masuk.values[idx] < np.datetime64("2024-01-01")), ("24-26", D.masuk.values[idx] >= np.datetime64("2024-01-01")), ("semua", np.ones(len(idx), bool))):
            x = D.Rb.values[idx][pm] * lot[pm]
            o.append(f"{per} total {x.sum():+5.0f} DD {dd(x):3.0f} t/DD {x.sum()/max(dd(x),1e-9):4.1f}")
        print(f"{nm:16s} {cap_nm:18s} lot1/2 {np.mean(lot < 1)*100:4.1f}% | " + " | ".join(o), flush=True)

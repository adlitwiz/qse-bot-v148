"""Gabungan celah perputaran modal (27 Okt 2026). Satu orang, sinyal mode seimbang (skor 3+) urut prioritas, candle 1 jam
2021-2026. Celah yang diuji:
  1. batas waktu: posisi yang belum kena TP sebagian (+tps R) setelah J jam ditutup market
  2. slot aman: posisi yang SL-nya sudah di entry tidak makan slot berisiko, maks N posisi aman sekaligus
  3. filter SL: lewati sinyal dengan jarak SL > X% dari entry (kecuali GZH)
  4. level TP sebagian 0.4R / 0.5R / 0.6R (aman lebih cepat)"""
import os, sys, time
import numpy as np, pandas as pd

TPR = {"snr_vol": 3.0, "smc_choch": 3.0, "mcginley": 4.0, "orderblock": 4.0}
TRL = {"ichimoku": 4.0, "ema_short": 4.0, "msb_hpz": 4.0, "rsi_vol": 3.0, "GZH": 3.0}
SLA = {"ichimoku": 1.5, "ema_short": 1.5, "mcginley": 1.5}

# (kode, tps_r, jam_stop untuk posisi belum aman)
VAR = [("t5", 0.5, None), ("t5j24", 0.5, 24), ("t5j30", 0.5, 30), ("t5j36", 0.5, 36), ("t5j42", 0.5, 42), ("t5j48", 0.5, 48),
       ("t4", 0.4, None), ("t4j36", 0.4, 36), ("t4j48", 0.4, 48), ("t6", 0.6, None), ("t6j36", 0.6, 36), ("t6j48", 0.6, 48)]


def sim(H, L, C, e, d, risk, atr, jalur, n, tps_r, jam_stop):
    sl = e - d * risk
    best = e
    sisa, real = 1.0, 0.0
    lv = e + d * tps_r * risk
    aman = -1
    tp = e + d * TPR[jalur] * risk if jalur in TPR else None
    tr0 = TRL.get(jalur)
    for j in range(n):
        hi, lo = H[j], L[j]
        if (lo <= sl) if d == 1 else (hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if aman < 0 and ((hi >= lv) if d == 1 else (lo <= lv)):
            real += 0.2 * tps_r
            sisa = 0.8
            sl = max(sl, e) if d == 1 else min(sl, e)
            aman = j + 1
        if tp is not None and ((hi >= tp) if d == 1 else (lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        best = max(best, hi) if d == 1 else min(best, lo)
        if tr0 is not None and j % 4 == 3:
            sl = max(sl, best - tr0 * atr) if d == 1 else min(sl, best + tr0 * atr)
        if jam_stop and j + 1 == jam_stop and aman < 0:
            return real + sisa * (C[j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[n - 1] - e) * d / risk, n, aman


def jalankan():
    D = pd.read_pickle("pf_orang_D.pkl")
    S = D[D.k0 & (D.skor2 >= 3)].copy()
    t0 = time.time()
    rows = []
    for s, Z in S.groupby("sym"):
        h = pd.read_csv(f"../data/{s}_60.csv", index_col=0, parse_dates=True)
        ix = h.index
        O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
        for r in Z.itertuples():
            k0 = ix.searchsorted(r.masuk)
            if k0 >= len(ix) or ix[k0] != r.masuk:
                continue
            e = O[k0]
            risk = e * r.slpct / 100
            d = int(r.arah)
            atr = risk / SLA.get(r.jalur, 2.0)
            cost = 0.15 / r.slpct
            maks = 180 if r.jalur in TPR else 240
            n = min(maks, len(ix) - k0)
            out = dict(idx=r.Index, sym=s, jalur=r.jalur, masuk=r.masuk, arah=d, slpct=r.slpct, skor2=r.skor2)
            for kd, tr, js in VAR:
                R, x, a = sim(H[k0:k0 + n], L[k0:k0 + n], C[k0:k0 + n], e, d, risk, atr, r.jalur, n, tr, js)
                out[kd] = R - cost
                out["x" + kd] = x
                out["a" + kd] = a
            rows.append(out)
    R = pd.DataFrame(rows).set_index("idx").sort_index()
    R.to_pickle("pf_waktu2_R.pkl")
    print("sim", len(R), round(time.time() - t0), "s", flush=True)
    return R


pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)


def dd(x):
    eq = np.cumsum(x)
    return float((np.maximum.accumulate(eq) - eq).max())


def porto(R, kd, cap=5, runner=None, pilih=None):
    masuk = R.masuk.values
    keluar = masuk + (R["x" + kd].values * 3600e9).astype("timedelta64[ns]")
    a = R["a" + kd].values
    aman = np.where(a >= 0, masuk + (np.maximum(a, 0) * 3600e9).astype("timedelta64[ns]"), keluar)
    sym = R.sym.values
    ambil = np.zeros(len(R), bool)
    buka = []
    for i in range(len(R)):
        if pilih is not None and not pilih[i]:
            continue
        t = masuk[i]
        buka = [b for b in buka if keluar[b] > t]
        if any(sym[b] == sym[i] for b in buka):
            continue
        if runner is None:
            if len(buka) >= cap:
                continue
        else:
            if sum(1 for b in buka if aman[b] > t) >= cap or len(buka) >= cap + runner:
                continue
        buka.append(i)
        ambil[i] = True
    return ambil


def ringkas(R, kd, ambil, label, tahun=False):
    x = R.loc[ambil, kd].values
    jam = R.loc[ambil, "x" + kd].values
    hari = (R.masuk.max() - R.masuk.min()).days
    o = []
    for per, pm in (("21-23", R.masuk < "2024"), ("24-26", R.masuk >= "2024")):
        y = R.loc[ambil & pm.values, kd].values
        o.append(f"{per} PF {pf(y):.2f} {y.sum():+4.0f}R DD {dd(y):2.0f}")
    s = (f"{label:40s} | {ambil.sum() / hari:4.2f}/hari WR {np.mean(x > 0) * 100:4.1f} PF {pf(x):.2f} {x.sum():+4.0f}R DD {dd(x):2.0f} "
         f"rugi penuh {np.mean(x < -0.9) * 100:4.1f}% | <=24j {np.mean(jam <= 24) * 100:3.0f}% <=48j {np.mean(jam <= 48) * 100:3.0f}% "
         f"med {np.median(jam):3.0f}j | " + " | ".join(o))
    if tahun:
        th = R.masuk.dt.year.values
        s += "\n" + " " * 42 + " ".join(f"{y}: {R.loc[ambil & (th == y), kd].sum():+4.0f}R" for y in sorted(set(th)))
    return s


if __name__ == "__main__":
    R = pd.read_pickle("pf_waktu2_R.pkl") if os.path.exists("pf_waktu2_R.pkl") and "ulang" not in sys.argv else jalankan()
    gzh = (R.jalur == "GZH").values
    F = {"semua": None}
    for thr in (8, 9, 10, 12):
        F[f"SL<={thr}%"] = (R.slpct.values <= thr) | gzh
    print("== batas waktu dan filter, slot lepas saat keluar (cara sekarang) ==")
    for fn, pl in F.items():
        for kd in ("t5", "t5j36", "t5j48"):
            print(ringkas(R, kd, porto(R, kd, 5, None, pl), f"{kd} {fn}"), flush=True)
    print()
    print("== slot aman lepas, runner maks N ==")
    for fn in ("semua", "SL<=9%"):
        pl = F[fn]
        for kd in ("t5", "t5j24", "t5j30", "t5j36", "t5j42", "t5j48", "t4", "t4j36", "t4j48", "t6", "t6j36", "t6j48"):
            for rn in (2,):
                print(ringkas(R, kd, porto(R, kd, 5, rn, pl), f"{kd} {fn} runner {rn}"), flush=True)
    print()
    print("== kandidat final, per tahun ==")
    for kd, fn, rn in (("t5", "semua", None), ("t5j36", "SL<=9%", 2), ("t5j48", "SL<=9%", 2), ("t5j36", "SL<=8%", 2),
                       ("t5j36", "SL<=10%", 2), ("t5j36", "SL<=9%", 1), ("t5j36", "SL<=9%", 3), ("t5j48", "SL<=9%", 3)):
        print(ringkas(R, kd, porto(R, kd, 5, rn, F[fn]), f"{kd} {fn} runner {rn}", tahun=True), flush=True)

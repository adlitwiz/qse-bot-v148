"""Simulasi batas posisi per orang (ambil sinyal mode seimbang urut prioritas, maks N posisi terbuka) dengan dan tanpa
batas buku robot (16 searah, jalur lemah < 8, satu koin satu jalur). Cara keluar orang: TP sebagian 20% +0.5R lalu SL ke entry."""
import os, time
import numpy as np, pandas as pd
import wr_exit as W
TPR, TRL = W.TPR, W.TRL

def sim2(O, H, L, C, ix, k0, end, e, d, risk, atr, jalur, parts, be):
    sl = e - d * risk; best = e; sisa, real = 1.0, 0.0
    tp = e + d * TPR[jalur] * risk if jalur in TPR else None
    tr0 = TRL.get(jalur); lv = list(parts)
    for j in range(k0, end):
        hi, lo = H[j], L[j]
        if (lo <= sl) if d == 1 else (hi >= sl):
            return real + sisa * (sl - e) * d / risk, ix[j]
        while lv and ((hi >= e + d * lv[0][0] * risk) if d == 1 else (lo <= e + d * lv[0][0] * risk)):
            r, p = lv.pop(0); p = min(p, sisa); real += p * r; sisa -= p
            if be: sl = max(sl, e) if d == 1 else min(sl, e)
        if sisa <= 1e-9: return real, ix[j]
        if tp is not None and ((hi >= tp) if d == 1 else (lo <= tp)):
            return real + sisa * (tp - e) * d / risk, ix[j]
        best = max(best, hi) if d == 1 else min(best, lo)
        if tr0 is not None and (j - k0) % 4 == 3:
            sl = max(sl, best - tr0 * atr) if d == 1 else min(sl, best + tr0 * atr)
    return real + sisa * (C[end - 1] - e) * d / risk, ix[end - 1]

if not os.path.exists("pf_orang_data.pkl"):
    t0 = time.time(); rows = []
    for s, Z in W.X.groupby("sym"):
        p = f"../data/{s}_60.csv"
        if not os.path.exists(p): continue
        h = pd.read_csv(p, index_col=0, parse_dates=True); ix = h.index
        O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
        for r in Z.itertuples():
            k0 = ix.searchsorted(r.t + pd.Timedelta(hours=4))
            if k0 >= len(ix) or ix[k0] != r.t + pd.Timedelta(hours=4): continue
            e = O[k0]; risk = e / r.er; d = int(r.arah); atr = risk / W.SLA.get(r.jalur, 2.0); cost = 0.0015 * e / risk
            maks = 180 if r.jalur in TPR else 240; end = min(k0 + maks, len(ix))
            if end - k0 < maks: continue
            Rd, td = sim2(O, H, L, C, ix, k0, end, e, d, risk, atr, r.jalur, [], False)
            Rb, tb = sim2(O, H, L, C, ix, k0, end, e, d, risk, atr, r.jalur, [(0.5, 0.2)], True)
            rows.append(dict(t=r.t, jalur=r.jalur, sym=s, Rd=Rd - cost, td=td, Rb=Rb - cost, tb=tb, slpct=risk / e * 100))
    Y = pd.DataFrame(rows); Y.to_pickle("pf_orang_data.pkl"); print("sim", len(Y), round(time.time() - t0), "s", flush=True)
Y = pd.read_pickle("pf_orang_data.pkl")
exec(open("wr_kelas.py").read().split("pf = lambda")[0].replace('D = pd.read_pickle("wr_data.pkl")', 'D = pd.read_pickle("wr_data.pkl")[["jalur","sym","t","arah","n","fix","plus","pull"]]'))
D = D.merge(Y, on=["jalur", "sym", "t"]).copy()
PFJ = {"tt": 1.47, "orderblock": 1.45, "ema_short": 1.42, "rsi_vol": 1.34, "snr_vol": 1.33, "ichimoku": 1.29, "msb_hpz": 1.27, "smc_choch": 1.25, "mcginley": 1.24, "GZH": 1.24}
D["masuk"] = D.t + pd.Timedelta(hours=4)
D["pfj"] = D.jalur.map(PFJ).fillna(1.2)
D = D.sort_values(["masuk", "skor2", "pfj"], ascending=[True, False, False]).reset_index(drop=True)
LEMAH = {"smc_choch", "msb_hpz", "GZH"}

def buku_robot(cap=16):
    """Sinyal yang dikirim robot (semua skor masuk buku robot, batas izin). Return mask terkirim."""
    kirim = np.zeros(len(D), bool); buka = []          # (keluar, sym, arah)
    for i, r in enumerate(D.itertuples()):
        buka = [b for b in buka if b[0] > r.masuk]
        if any(b[1] == r.sym for b in buka): continue
        n = sum(1 for b in buka if b[2] == r.arah)
        if cap and n >= cap: continue
        if cap and r.jalur in LEMAH and n >= 8: continue
        buka.append((r.td, r.sym, r.arah)); kirim[i] = True
    return kirim

def orang(kirim, cap):
    ambil = np.zeros(len(D), bool); buka = []
    for i, r in enumerate(D.itertuples()):
        if not kirim[i] or r.skor2 < 3: continue
        buka = [b for b in buka if b[0] > r.masuk]
        if cap and len(buka) >= cap: continue
        if any(b[1] == r.sym for b in buka): continue
        buka.append((r.tb, r.sym)); ambil[i] = True
    return ambil

pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)
def dd(x):
    eq = np.cumsum(x); return float((np.maximum.accumulate(eq) - eq).max())
def streak(x):
    m = c = 0
    for v in x:
        c = c + 1 if v <= 0 else 0; m = max(m, c)
    return m
hari = D.masuk.dt.floor("D").nunique()
k16, k0 = buku_robot(16), buku_robot(0)
print("sinyal mode seimbang terkirim: dengan batas robot 16 %d, tanpa batas robot %d" % ((k16 & (D.skor2 >= 3)).sum(), (k0 & (D.skor2 >= 3)).sum()))
for nm, kirim in (("batas robot 16 (sekarang)", k16), ("tanpa batas robot", k0)):
    for cap in (3, 5, 8, 0):
        a = orang(kirim, cap)
        o = []
        for per, pm in (("21-23", D.masuk < "2024"), ("24-26", D.masuk >= "2024"), ("semua", D.masuk.notna())):
            x = D.loc[a & pm, "Rb"].values
            o.append(f"{per} n {len(x):5d} WR {np.mean(x > 0)*100:4.1f} PF {pf(x):.2f} total {x.sum():+5.0f} DD {dd(x):3.0f}")
        x = D.loc[a, "Rb"].values
        print(f"{nm:26s} maks {cap if cap else 'tak terbatas':>12} | {a.sum() / hari:4.2f}/hari beruntun {streak(x):3d} | " + " | ".join(o), flush=True)
D.assign(k16=k16, k0=k0).to_pickle("pf_orang_D.pkl")

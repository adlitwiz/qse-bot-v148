"""Ketahanan aturan jeda: jumlah rugi beruntun pemicu (2-5) dan cara lanjut (sinyal robot kena TP 20%, atau 12/24/48 jam),
digabung dengan aturan ketat jam 8/10/12 (SL -0.5R). Satu orang, populasi sinyal live."""
import numpy as np, pandas as pd
import pf_waktu3 as P
import pf_beruntun as B

X = pd.concat([pd.read_pickle("pf_slpenuh2.pkl"), pd.read_pickle("pf_slpenuh.pkl").drop(columns=["mfe"])], axis=1)
X = X.loc[:, ~X.columns.duplicated()]
tambah = {}
for c in X.columns:
    v = X[c].reindex(B.R.index)
    tambah[c] = v.fillna(1).astype(np.int64) if c.startswith("x") else (v.fillna(-1).astype(np.int64) if c.startswith("a") else v.fillna(0.0))
baru = pd.DataFrame(tambah, index=B.R.index)
for c in baru.columns:
    if c in B.R.columns:
        del B.R[c]
B.R = pd.concat([B.R, baru], axis=1)          # fungsi di pf_beruntun membaca R modul saat dipanggil
live = P.live


def ringkas(kd, jd):
    a = B.porto2(kd, 5, 2, live, jeda=jd)
    keluar, aman, Rv = B.arr(kd)
    x = Rv[a]
    o = []
    for per, pm in (("21-23", (B.R.masuk < "2024").values), ("24-26", (B.R.masuk >= "2024").values)):
        y = Rv[a & pm]
        o.append(f"{P.pf(y):.2f}/{y.sum():+.0f}")
    s = B.metrik(kd, a, "x")
    kal = int(s.split("kalah beruntun")[1].split()[0])
    pen = int(s.split("SL penuh beruntun")[1].split()[0])
    dd = int(float(s.split("DD")[1].split("|")[0]))
    return f"{x.sum():+4.0f}R PF {P.pf(x):.2f} DD {dd:2d} kalah {kal:2d} SLp {pen:2d} [{' '.join(o)}]"


if __name__ == "__main__":
    for kd in ("t5j36", "k8_0.5", "k10_0.5", "k12_0.5"):
        print(f"== {kd}  tanpa jeda: {ringkas(kd, None)}", flush=True)
        for lanjut in ("aman", 12, 24, 48):
            row = []
            for k in (2, 3, 4, 5):
                jd = dict(k=k, jenis="kalah", lanjut="aman") if lanjut == "aman" else dict(k=k, jenis="kalah", lanjut="jam", jam=lanjut)
                row.append(f"k{k}: {ringkas(kd, jd)}")
            print(f"   lanjut {str(lanjut):5s} | " + "\n                 | ".join(row), flush=True)

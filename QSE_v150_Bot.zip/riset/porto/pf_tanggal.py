"""Uji pola tanggal dalam bulan (WIB) di sinyal robot live 2021-2026, aturan keluar final (jam ke-8, 36 jam, TP 20%).
Per tanggal, per kelompok (1-5, 6-25, 26-31), dan uji acak: berapa tanggal 'konsisten jelek' muncul kalau label tanggal diacak."""
import numpy as np, pandas as pd
import pf_jeda as J
B, P = J.B, J.P
R = B.R[P.live].copy()
KD = "k8_0.5"
wib = R.masuk + pd.Timedelta(hours=7)
R["tgl"] = wib.dt.day.values
R["per"] = np.where(R.masuk < "2024", "21-23", "24-26")
pf = P.pf
x_all = R[KD].values
print(f"semua: n {len(R)} PF {pf(x_all):.2f} rata {x_all.mean():+.3f}")
for per in ("21-23", "24-26"):
    y = R.loc[R.per == per, KD].values
    print(f"  {per}: n {len(y)} PF {pf(y):.2f} rata {y.mean():+.3f}")
print("\n== per tanggal (PF 21-23 | 24-26, rata R, n)")
tab = {}
for t in range(1, 32):
    o = []
    for per in ("21-23", "24-26"):
        y = R.loc[(R.tgl == t) & (R.per == per), KD].values
        o.append((pf(y), y.mean() if len(y) else 0, len(y)))
    tab[t] = o
    tanda = ""
    if o[0][1] < 0 and o[1][1] < 0:
        tanda = "  <- rugi di dua periode"
    elif o[0][1] > 0.3 and o[1][1] > 0.3:
        tanda = "  <- bagus di dua periode"
    print(f"  tgl {t:2d}: PF {o[0][0]:.2f} | {o[1][0]:.2f}   rata {o[0][1]:+.3f} | {o[1][1]:+.3f}   n {o[0][2]:3d} | {o[1][2]:3d}{tanda}")


def hitung_jelek(df):
    n = 0
    for t in range(1, 32):
        a = df.loc[(df.tgl == t) & (df.per == "21-23"), KD].values
        b = df.loc[(df.tgl == t) & (df.per == "24-26"), KD].values
        if len(a) and len(b) and a.mean() < 0 and b.mean() < 0:
            n += 1
    return n


obs = hitung_jelek(R)
rng = np.random.default_rng(7)
acak = []
for _ in range(300):
    Z = R[["per", KD]].copy()
    Z["tgl"] = R.groupby("per")["tgl"].transform(lambda s: rng.permutation(s.values)).values
    acak.append(hitung_jelek(Z))
acak = np.array(acak)
print(f"\ntanggal rugi di dua periode: {obs} | kalau tanggal diacak: rata {acak.mean():.1f}, 95% di bawah {np.percentile(acak, 95):.0f}, "
      f"peluang >= {obs}: {np.mean(acak >= obs) * 100:.0f}%")
print("\n== per kelompok")
for nm, lo, hi in (("tgl 1-5", 1, 5), ("tgl 6-25", 6, 25), ("tgl 26-31", 26, 31), ("tgl 1-10", 1, 10), ("tgl 11-20", 11, 20), ("tgl 21-31", 21, 31)):
    o = []
    for per in ("21-23", "24-26"):
        y = R.loc[(R.tgl >= lo) & (R.tgl <= hi) & (R.per == per), KD].values
        o.append(f"{per} PF {pf(y):.2f} rata {y.mean():+.3f} WR {np.mean(y > 0) * 100:.0f}% n {len(y)}")
    print(f"  {nm:10s} " + " | ".join(o))

import numpy as np, pandas as pd
import pf_waktu3 as P
R, live, porto, ringkas = P.R, P.live, P.porto, P.ringkas
kd = "t5j36"
A0 = porto(R, "t5", 5, None, live)
A1 = porto(R, kd, 5, 2, live)
Z0, Z1 = R[A0], R[A1]
x0 = Z0["xt5"].values
a1 = Z1["a" + kd].values; x1 = Z1["x" + kd].values
s1 = np.where(a1 >= 0, np.minimum(a1, x1), x1)
print(f"slot terkunci sekarang: rata {x0.mean():.0f}j median {np.median(x0):.0f}j p90 {np.percentile(x0,90):.0f}j | baru: rata {s1.mean():.0f}j median {np.median(s1):.0f}j p90 {np.percentile(s1,90):.0f}j maks {s1.max():.0f}j")
ts = (x1 == 36) & (a1 < 0)
print(f"ditutup waktu 36j: {ts.mean()*100:.1f}% trade, R rata {Z1.loc[ts, kd].mean():+.3f}, positif {np.mean(Z1.loc[ts, kd] > 0)*100:.0f}% | kalau ditahan: rata {Z1.loc[ts, 't5'].mean():+.3f}, kena SL penuh {np.mean(Z1.loc[ts, 't5'] < -0.9)*100:.0f}%, WR {np.mean(Z1.loc[ts, 't5'] > 0)*100:.0f}%")
L = R[live]
a = L["at5"].values; x = L["xt5"].values
belum = ~((a >= 0) & (a <= 36)) & (x > 36)
print(f"sinyal live belum aman di 36j dan masih jalan: {belum.mean()*100:.1f}% | kalau ditahan rata {L.loc[belum, 't5'].mean():+.3f} SL penuh {np.mean(L.loc[belum, 't5'] < -0.9)*100:.0f}% | ditutup 36j rata {L.loc[belum, 't5j36'].mean():+.3f}")
for per, pm in (("21-23", L.masuk < "2024"), ("24-26", L.masuk >= "2024")):
    m = belum & pm.values
    print(f"   {per}: ditahan {L.loc[m, 't5'].mean():+.3f} | ditutup {L.loc[m, 't5j36'].mean():+.3f} | n {m.sum()}")
print()
print("per jalur (populasi live, aturan baru): aman <=36j, median jam ke aman, median lama trade yang sudah aman")
for j, W in L.groupby("jalur"):
    a = W["a" + kd].values; x = W["x" + kd].values
    ok = a >= 0
    print(f"{j:11s} n {len(W):4d} aman<=36j {np.mean(ok & (a <= 36))*100:3.0f}% | jam ke aman median {np.median(a[ok]):3.0f} | lama trade aman median {np.median(x[ok]):4.0f}j ({np.median(x[ok])/24:.1f} hari) p75 {np.percentile(x[ok],75)/24:.1f} hari")
a = L["a" + kd].values; x = L["x" + kd].values; ok = a >= 0
print(f"SEMUA       n {len(L):4d} aman<=36j {np.mean(ok & (a <= 36))*100:3.0f}% | jam ke aman median {np.median(a[ok]):3.0f} | lama trade aman median {np.median(x[ok]):4.0f}j p75 {np.percentile(x[ok],75)/24:.1f} hari")
print()
for nm, kd_, rn in (("sekarang", "t5", None), ("baru j36 r2", "t5j36", 2), ("baru j48 r2", "t5j48", 2)):
    print(ringkas(R, kd_, porto(R, kd_, 5, rn, live), nm, tahun=True))

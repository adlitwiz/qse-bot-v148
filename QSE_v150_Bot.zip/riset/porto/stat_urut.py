import numpy as np
import pf_jeda as J
B, P = J.B, J.P
live = P.live
def runs(m):
    b = c = 0
    for v in m:
        c = c + 1 if v else 0
        b = max(b, c)
    return b
for nm, kd, a in (("cara lama", "t5", P.porto(B.R, "t5", 5, None, live)),
                  ("36j + aman 2 (tadi siang)", "t5j36", B.porto2("t5j36", 5, 2, live)),
                  ("aturan lengkap baru", "k8_0.5", B.porto2("k8_0.5", 5, 2, live, jeda=dict(k=3, jenis="kalah", lanjut="jam", jam=24)))):
    keluar, aman, Rv = B.arr(kd)
    idx = np.nonzero(a)[0]
    for urut_nm, urut in (("urut entry", idx[np.argsort(B.masuk_h[idx], kind="stable")]), ("urut tutup", idx[np.argsort(keluar[idx], kind="stable")])):
        x = Rv[urut]
        print(f"{nm:28s} {urut_nm}: kalah beruntun {runs(x <= 0):2d}, SL penuh beruntun {runs(x < -0.9):2d}")
print("kerugian beruntun terbesar dalam R (urut tutup):")
for nm, kd, a in (("cara lama", "t5", P.porto(B.R, "t5", 5, None, live)),
                  ("36j + aman 2 (tadi siang)", "t5j36", B.porto2("t5j36", 5, 2, live)),
                  ("aturan lengkap baru", "k8_0.5", B.porto2("k8_0.5", 5, 2, live, jeda=dict(k=3, jenis="kalah", lanjut="jam", jam=24)))):
    keluar, aman, Rv = B.arr(kd)
    idx = np.nonzero(a)[0]
    x = Rv[idx[np.argsort(keluar[idx], kind="stable")]]
    terburuk = cur = 0.0
    for v in x:
        cur = cur + v if v <= 0 else 0.0
        terburuk = min(terburuk, cur)
    print(f"   {nm:28s} {terburuk:+.1f}R")

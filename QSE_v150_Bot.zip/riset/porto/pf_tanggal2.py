"""Uji ketat pola tanggal: (1) acak per hari kalender (sinyal satu hari tetap bersama, karena saling berkorelasi),
(2) uji maju: tanggal jelek dipilih dari satu periode, dicek di periode lain, (3) efek di simulasi satu orang."""
import numpy as np, pandas as pd
import pf_jeda as J
B, P = J.B, J.P
R = B.R[P.live].copy()
KD = "k8_0.5"
wib = R.masuk + pd.Timedelta(hours=7)
R["tgl"] = wib.dt.day.values
R["hari"] = wib.dt.floor("D").values
R["per"] = np.where(R.masuk < "2024", "A", "B")


def jelek_dua(df):
    m = df.groupby(["per", "tgl"])[KD].mean().unstack(0)
    return int(((m["A"] < 0) & (m["B"] < 0)).sum())


obs = jelek_dua(R)
hari = R[["hari", "per", "tgl"]].drop_duplicates("hari")
rng = np.random.default_rng(11)
acak = []
for _ in range(500):
    peta = {}
    for per, g in hari.groupby("per"):
        peta.update(dict(zip(g.hari.values, rng.permutation(g.tgl.values))))
    Z = R[["per", KD]].copy()
    Z["tgl"] = R.hari.map(peta).values
    acak.append(jelek_dua(Z))
acak = np.array(acak)
print(f"tanggal rugi di dua periode: {obs} | acak per hari kalender: rata {acak.mean():.1f}, peluang >= {obs}: {np.mean(acak >= obs) * 100:.1f}%")
# uji maju dua arah
for latih, uji in (("A", "B"), ("B", "A")):
    m = R[R.per == latih].groupby("tgl")[KD].mean()
    jelek = set(m[m < 0].index)
    U = R[R.per == uji]
    x_j = U[U.tgl.isin(jelek)][KD].values
    x_l = U[~U.tgl.isin(jelek)][KD].values
    print(f"tanggal jelek dari periode {latih} ({sorted(jelek)}): di periode {uji} PF {P.pf(x_j):.2f} rata {x_j.mean():+.3f} "
          f"lawan tanggal lain PF {P.pf(x_l):.2f} rata {x_l.mean():+.3f}")
# simulasi satu orang: lewati tanggal 9, 22, 23, 30
J4 = dict(k=3, jenis="kalah", lanjut="jam", jam=24)
tgl_all = (B.R.masuk + pd.Timedelta(hours=7)).dt.day.values
for nm, buang in (("aturan final", set()), ("lewati tgl 9 22 23 30", {9, 22, 23, 30}), ("lewati tgl 26-31", set(range(26, 32)))):
    pl = P.live & ~np.isin(tgl_all, list(buang))
    a = B.porto2(KD, 5, 2, pl, jeda=J4)
    print(B.metrik(KD, a, nm))

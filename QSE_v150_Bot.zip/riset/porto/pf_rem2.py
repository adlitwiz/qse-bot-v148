import numpy as np, pandas as pd
exec(open("pf_buku.py").read().split("hari = D.masuk")[0])
def orang_rem(kirim, cap, thr=None, n=None, sumber="robot"):
    B = D[kirim].sort_values("td"); bt = pd.DatetimeIndex(B.td)
    br = B.Rd.values * np.where(B.jalur.values == "GZH", 0.5, 1.0)
    eq = np.cumsum(br); ddv = np.maximum.accumulate(eq) - eq
    rug = np.zeros(len(br), int); c = 0
    for i, v in enumerate(br):
        c = c + 1 if v < 0 else 0; rug[i] = c
    out = []; buka = []
    for i, r in enumerate(D.itertuples()):
        if not kirim[i] or r.skor2 < 3: continue
        buka = [b for b in buka if b[0] > r.masuk]
        if cap and len(buka) >= cap: continue
        if any(b[1] == r.sym for b in buka): continue
        lot = 1.0
        if thr:
            k = bt.searchsorted(r.masuk, side="right") - 1
            if k >= 0 and (ddv[k] > thr or rug[k] >= n): lot = 0.5
        buka.append((r.tb, r.sym)); out.append((i, lot))
    return out
for nm, (hs, pj, gl) in (("A sekarang", (False, 8, 16)), ("B tanpa batas 16", (False, 8, 0))):
    k = buku(hs, pj, gl)
    for rnm, thr, n in (("tanpa rem", None, None), ("rem 32R/8", 32, 8), ("rem 64R/12", 64, 12)):
        a = orang_rem(k, 5, thr, n)
        idx = np.array([x[0] for x in a]); lot = np.array([x[1] for x in a])
        o = []
        for per, pm in (("21-23", D.masuk.values[idx] < np.datetime64("2024-01-01")), ("24-26", D.masuk.values[idx] >= np.datetime64("2024-01-01")), ("semua", np.ones(len(idx), bool))):
            x = D.Rb.values[idx][pm] * lot[pm]
            o.append(f"{per} total {x.sum():+5.0f} DD {dd(x):3.0f} t/DD {x.sum()/max(dd(x),1e-9):4.1f}")
        print(f"{nm:18s} {rnm:11s} lot1/2 {np.mean(lot < 1)*100:4.1f}% | " + " | ".join(o), flush=True)

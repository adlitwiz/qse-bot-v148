"""Ulang uji perputaran modal dengan populasi sinyal seperti bot live: SL maks 10% (semua jalur), SHORT setelah pump 30%
dalam 30 hari dibuang, mutu_buang, aturan Senin (hanya COMBO EMAS/FIX/2+ atau label BTC.D TURUN).
Butuh pf_waktu2_R.pkl (hasil pf_waktu2.py)."""
import os, sys
import numpy as np, pandas as pd
sys.path.insert(0, "/mnt/user-data/outputs/QSE_v148_Bot")
exec(open("pf_waktu2.py").read().split("if __name__")[0])

R = pd.read_pickle("pf_waktu2_R.pkl")
D = pd.read_pickle("pf_orang_D.pkl")
R = R.join(D[["t", "emas", "fix", "n", "skor", "vt", "pull"]])

if not os.path.exists("pf_waktu3_f.pkl"):
    import qse_strat as ST
    pump, buang = {}, {}
    for s, Z in R.groupby("sym"):
        h = pd.read_csv(f"../data/{s}_240.csv", index_col=0, parse_dates=True)
        ix = h.index
        for r in Z.itertuples():
            k = ix.searchsorted(r.t)
            if k >= len(ix) or ix[k] != r.t:
                pump[r.Index], buang[r.Index] = False, False
                continue
            df = h.iloc[max(0, k - 299):k + 1]
            arah = "LONG" if r.arah == 1 else "SHORT"
            pump[r.Index] = bool(ST.pump_tolak(df, arah))
            try:
                _, mp, mm = ST.mutu(df, arah)
                buang[r.Index] = bool(ST.mutu_buang(mp, mm))
            except Exception:
                buang[r.Index] = False
    F = pd.DataFrame({"pump": pd.Series(pump), "buang": pd.Series(buang)})
    F.to_pickle("pf_waktu3_f.pkl")
F = pd.read_pickle("pf_waktu3_f.pkl")
R = R.join(F)
wib = R.masuk.dt.tz_convert("Asia/Jakarta") - pd.Timedelta(hours=7)        # Senin 07:00 WIB s.d. Selasa 07:00 WIB
senin = (wib.dt.dayofweek == 0).values
dom = (R.skor2 > R.skor).values
senin_tolak = senin & ~(R.emas.values | R.fix.values | (R.n.values >= 2) | dom)
gzh = (R.jalur == "GZH").values
senin_tolak |= senin & gzh
live = (R.slpct.values <= 10) & ~R.pump.values & ~R.buang.values & ~senin_tolak
print(f"populasi: {len(R)} sinyal, lolos filter live {live.sum()} (SL>10% {np.sum(R.slpct.values > 10)}, pump {R.pump.sum()}, "
      f"mutu buang {R.buang.sum()}, Senin {senin_tolak.sum()})")
L9 = live & ((R.slpct.values <= 9) | gzh)
L8 = live & ((R.slpct.values <= 8) | gzh)

if __name__ == "__main__":
    x = R.loc[live, "t5"].values
    print(f"per trade live: WR {np.mean(x > 0) * 100:.1f} PF {pf(x):.2f} | SL 9-10%: ", end="")
    m = live & (R.slpct.values > 9) & ~gzh
    for per, pm in (("21-23", R.masuk < "2024"), ("24-26", R.masuk >= "2024")):
        y = R.loc[m & pm.values, "t5"].values
        print(f"{per} n {len(y)} PF {pf(y):.2f} rata {y.mean():+.3f} | ", end="")
    print()
    print("== populasi live ==")
    for kd, rn, pl, nm in (("t5", None, live, "sekarang"), ("t5j36", None, live, ""), ("t5j48", None, live, ""),
                           ("t5", 2, live, ""), ("t5j36", 2, live, ""), ("t5j42", 2, live, ""), ("t5j48", 2, live, ""),
                           ("t5j48", 1, live, ""), ("t5j48", 3, live, ""), ("t5j36", 2, L9, "SL<=9"), ("t5j48", 2, L9, "SL<=9"),
                           ("t5j48", 2, L8, "SL<=8"), ("t5j48", 3, L9, "SL<=9"), ("t5j48", 1, L9, "SL<=9")):
        print(ringkas(R, kd, porto(R, kd, 5, rn, pl), f"{kd} runner {rn} {nm}"), flush=True)
    print()
    for kd, rn, pl, nm in (("t5", None, live, "sekarang"), ("t5j48", 2, live, "baru"), ("t5j48", 2, L9, "baru SL<=9")):
        print(ringkas(R, kd, porto(R, kd, 5, rn, pl), f"{kd} runner {rn} {nm}", tahun=True), flush=True)

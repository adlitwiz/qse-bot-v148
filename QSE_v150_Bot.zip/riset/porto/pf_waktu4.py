"""Varian batas waktu yang menjaga WR: di jam J, posisi belum aman yang sedang untung >= ambang tidak ditutup, SL dipindah ke
entry (jadi aman, slot lepas). Yang di bawah ambang ditutup market. Juga: tutup separuh di jam J."""
import os, sys, time
import numpy as np, pandas as pd
import pf_waktu3 as P
TPR, TRL, SLA = P.TPR, P.TRL, P.SLA

def sim(H, L, C, e, d, risk, atr, jalur, n, jam_stop, ambang_be, separuh=False):
    sl = e - d * risk; best = e; sisa, real = 1.0, 0.0
    lv = e + d * 0.5 * risk; aman = -1
    tp = e + d * TPR[jalur] * risk if jalur in TPR else None
    tr0 = TRL.get(jalur)
    for j in range(n):
        hi, lo = H[j], L[j]
        if (lo <= sl) if d == 1 else (hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if aman < 0 and ((hi >= lv) if d == 1 else (lo <= lv)):
            real += 0.2 * 0.5; sisa = 0.8
            sl = max(sl, e) if d == 1 else min(sl, e); aman = j + 1
        if tp is not None and ((hi >= tp) if d == 1 else (lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        best = max(best, hi) if d == 1 else min(best, lo)
        if tr0 is not None and j % 4 == 3:
            sl = max(sl, best - tr0 * atr) if d == 1 else min(sl, best + tr0 * atr)
        if j + 1 == jam_stop and aman < 0:
            rnow = (C[j] - e) * d / risk
            if ambang_be is not None and rnow >= ambang_be:
                sl = max(sl, e) if d == 1 else min(sl, e); aman = j + 1
            else:
                return real + sisa * rnow, j + 1, aman
    return real + sisa * (C[n - 1] - e) * d / risk, n, aman

VAR = [("be0_36", 36, 0.0), ("be10_36", 36, 0.10), ("be25_36", 36, 0.25), ("be0_48", 48, 0.0), ("be25_48", 48, 0.25)]
if not os.path.exists("pf_waktu4_R.pkl"):
    D = pd.read_pickle("pf_orang_D.pkl"); S = D[D.k0 & (D.skor2 >= 3)]
    rows = []
    for s, Z in S.groupby("sym"):
        h = pd.read_csv(f"../data/{s}_60.csv", index_col=0, parse_dates=True); ix = h.index
        O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
        for r in Z.itertuples():
            k0 = ix.searchsorted(r.masuk)
            if k0 >= len(ix) or ix[k0] != r.masuk: continue
            e = O[k0]; risk = e * r.slpct / 100; d = int(r.arah); atr = risk / SLA.get(r.jalur, 2.0); cost = 0.15 / r.slpct
            n = min(180 if r.jalur in TPR else 240, len(ix) - k0)
            out = dict(idx=r.Index)
            for kd, js, amb in VAR:
                RR, x, a = sim(H[k0:k0 + n], L[k0:k0 + n], C[k0:k0 + n], e, d, risk, atr, r.jalur, n, js, amb)
                out[kd] = RR - cost; out["x" + kd] = x; out["a" + kd] = a
            rows.append(out)
    pd.DataFrame(rows).set_index("idx").sort_index().to_pickle("pf_waktu4_R.pkl")
R = P.R.join(pd.read_pickle("pf_waktu4_R.pkl"))
live = P.live
for kd, rn in (("t5", None), ("t5", 2), ("t5j36", 2), ("be0_36", 2), ("be10_36", 2), ("be25_36", 2), ("t5j48", 2), ("be0_48", 2), ("be25_48", 2)):
    print(P.ringkas(R, kd, P.porto(R, kd, 5, rn, live), f"{kd} runner {rn}"), flush=True)
for kd in ("t5j36", "be0_36", "be25_36"):
    print(P.ringkas(R, kd, P.porto(R, kd, 5, 2, live), f"{kd} runner 2", tahun=True), flush=True)

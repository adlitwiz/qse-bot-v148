"""Uji perputaran modal: batas waktu trade, slot bebas saat posisi aman (SL di entry), TP lebih dekat.
Sinyal mode seimbang (skor 3+) yang dikirim robot, satu orang maks 5 posisi berisiko, satu koin satu posisi.
Semua di candle 1 jam 2021-2026. Hasil per trade disimpan ke pf_waktu_R.pkl."""
import os, sys, time
import numpy as np, pandas as pd

TPR = {"snr_vol": 3.0, "smc_choch": 3.0, "mcginley": 4.0, "orderblock": 4.0}
TRL = {"ichimoku": 4.0, "ema_short": 4.0, "msb_hpz": 4.0, "rsi_vol": 3.0, "GZH": 3.0}
SLA = {"ichimoku": 1.5, "ema_short": 1.5, "mcginley": 1.5}

# (nama, jam_stop, ambang R untuk tutup posisi belum aman, jam_stop_runner, tp_penuh, trail_runner_atr)
#  jam_stop: di jam ini posisi yang belum kena TP sebagian ditutup bila R sekarang < ambang (inf = semua yang belum aman,
#  'semua' = tutup semua termasuk yang aman). jam_stop_runner: posisi aman ditutup paksa di jam ini.
VAR = [
    ("sekarang", None, None, None, None, None),
    ("tutup semua 24j", 24, "semua", None, None, None),
    ("tutup semua 48j", 48, "semua", None, None, None),
    ("tutup semua 72j", 72, "semua", None, None, None),
    ("belum aman 24j", 24, np.inf, None, None, None),
    ("belum aman 36j", 36, np.inf, None, None, None),
    ("belum aman 48j", 48, np.inf, None, None, None),
    ("belum aman 72j", 72, np.inf, None, None, None),
    ("belum aman rugi 48j", 48, 0.0, None, None, None),
    ("belum aman 48j + runner 96j", 48, np.inf, 96, None, None),
    ("belum aman 48j + runner 120j", 48, np.inf, 120, None, None),
    ("TP penuh 1.5R", None, None, None, 1.5, None),
    ("TP penuh 2R", None, None, None, 2.0, None),
    ("TP penuh 2R + belum aman 48j", 48, np.inf, None, 2.0, None),
    ("trail runner 2ATR", None, None, None, None, 2.0),
    ("trail runner 2ATR + belum aman 48j", 48, np.inf, None, None, 2.0),
]


def sim(H, L, C, e, d, risk, atr, jalur, n, jam_stop, ambang, jam_runner, tp_full, trail_run):
    """Return (R, jam_keluar, jam_aman atau -1). jam dihitung dari entry (akhir candle)."""
    sl = e - d * risk
    best = e
    sisa, real = 1.0, 0.0
    lv_r = e + d * 0.5 * risk
    aman = -1
    tp = e + d * tp_full * risk if tp_full else (e + d * TPR[jalur] * risk if jalur in TPR else None)
    tr0 = None if tp_full else TRL.get(jalur)
    for j in range(n):
        hi, lo = H[j], L[j]
        if (lo <= sl) if d == 1 else (hi >= sl):
            return real + sisa * (sl - e) * d / risk, j + 1, aman
        if aman < 0 and ((hi >= lv_r) if d == 1 else (lo <= lv_r)):
            real += 0.2 * 0.5
            sisa = 0.8
            sl = max(sl, e) if d == 1 else min(sl, e)
            aman = j + 1
        if tp is not None and ((hi >= tp) if d == 1 else (lo <= tp)):
            return real + sisa * (tp - e) * d / risk, j + 1, aman
        best = max(best, hi) if d == 1 else min(best, lo)
        if j % 4 == 3:
            if tr0 is not None:
                sl = max(sl, best - tr0 * atr) if d == 1 else min(sl, best + tr0 * atr)
            if trail_run and aman >= 0:
                sl = max(sl, best - trail_run * atr) if d == 1 else min(sl, best + trail_run * atr)
        if jam_stop and j + 1 == jam_stop:
            rnow = (C[j] - e) * d / risk
            if ambang == "semua" or (aman < 0 and rnow < ambang):
                return real + sisa * rnow, j + 1, aman
        if jam_runner and aman >= 0 and j + 1 >= jam_runner:
            return real + sisa * (C[j] - e) * d / risk, j + 1, aman
    return real + sisa * (C[n - 1] - e) * d / risk, n, aman


def jalankan():
    D = pd.read_pickle("pf_orang_D.pkl")
    S = D[D.k0 & (D.skor2 >= 3)].copy()
    t0 = time.time()
    rows = []
    for s, Z in S.groupby("sym"):
        h = pd.read_csv(f"../data/{s}_60.csv", index_col=0, parse_dates=True)
        ix = h.index
        O, H, L, C = (h[c].values for c in ("open", "high", "low", "close"))
        rng = (H - L)
        for r in Z.itertuples():
            k0 = ix.searchsorted(r.masuk)
            if k0 >= len(ix) or ix[k0] != r.masuk:
                continue
            e = O[k0]
            risk = e * r.slpct / 100
            d = int(r.arah)
            atr = risk / SLA.get(r.jalur, 2.0)
            cost = 0.15 / r.slpct
            maks = 180 if r.jalur in TPR else 240
            n = min(maks, len(ix) - k0)
            out = dict(idx=r.Index, sym=s, jalur=r.jalur, masuk=r.masuk, arah=d, slpct=r.slpct, skor2=r.skor2, pfj=r.pfj,
                       gerak24=rng[max(0, k0 - 24):k0].mean() / risk if k0 >= 24 else np.nan,
                       gerak72=rng[max(0, k0 - 72):k0].mean() / risk if k0 >= 72 else np.nan)
            for nm, js, amb, jr, tpf, trr in VAR:
                R, x, a = sim(H[k0:k0 + n], L[k0:k0 + n], C[k0:k0 + n], e, d, risk, atr, r.jalur, n, js, amb, jr, tpf, trr)
                out[nm] = R - cost
                out["x|" + nm] = x
                out["a|" + nm] = a
            rows.append(out)
    R = pd.DataFrame(rows).set_index("idx").sort_index()
    R.to_pickle("pf_waktu_R.pkl")
    print("sim", len(R), round(time.time() - t0), "s", flush=True)
    return R


pf = lambda x: x[x > 0].sum() / max(-x[x < 0].sum(), 1e-9)


def dd(x):
    eq = np.cumsum(x)
    return float((np.maximum.accumulate(eq) - eq).max())


def porto(R, nm, cap=5, runner=None, pilih=None):
    """Satu orang. cap = maks posisi berisiko (belum aman). runner = maks posisi aman tambahan (None = slot baru bebas
    saat keluar saja). pilih = mask sinyal yang boleh diambil. Return mask ambil."""
    masuk = R.masuk.values
    keluar = masuk + (R["x|" + nm].values * 3600e9).astype("timedelta64[ns]")
    a = R["a|" + nm].values
    aman = np.where(a >= 0, masuk + (np.maximum(a, 0) * 3600e9).astype("timedelta64[ns]"), keluar)
    sym = R.sym.values
    ambil = np.zeros(len(R), bool)
    buka = []
    for i in range(len(R)):
        if pilih is not None and not pilih[i]:
            continue
        t = masuk[i]
        buka = [b for b in buka if keluar[b] > t]
        if any(sym[b] == sym[i] for b in buka):
            continue
        if runner is None:
            if len(buka) >= cap:
                continue
        else:
            berisiko = sum(1 for b in buka if aman[b] > t)
            if berisiko >= cap or len(buka) >= cap + runner:
                continue
        buka.append(i)
        ambil[i] = True
    return ambil


def ringkas(R, nm, ambil, label):
    x = R.loc[ambil, nm].values
    jam = R.loc[ambil, "x|" + nm].values
    hari = R.masuk.dt.floor("D").nunique()
    o = []
    for per, pm in (("21-23", R.masuk < "2024"), ("24-26", R.masuk >= "2024")):
        y = R.loc[ambil & pm.values, nm].values
        o.append(f"{per} PF {pf(y):.2f} {y.sum():+5.0f}R")
    return (f"{label:44s} | {ambil.sum() / hari:4.2f}/hari WR {np.mean(x > 0) * 100:4.1f} PF {pf(x):.2f} total {x.sum():+5.0f}R "
            f"DD {dd(x):3.0f} | lama median {np.median(jam):4.0f}j, selesai<=48j {np.mean(jam <= 48) * 100:3.0f}% | " + " | ".join(o))


if __name__ == "__main__":
    R = pd.read_pickle("pf_waktu_R.pkl") if os.path.exists("pf_waktu_R.pkl") and "ulang" not in sys.argv else jalankan()
    print("== per trade (semua sinyal mode seimbang, tanpa batas slot) ==")
    for nm, *_ in VAR:
        x = R[nm].values
        jam = R["x|" + nm].values
        print(f"{nm:44s} | WR {np.mean(x > 0) * 100:4.1f} PF {pf(x):.2f} rata {x.mean():+.3f}R | lama median {np.median(jam):4.0f}j "
              f"selesai<=48j {np.mean(jam <= 48) * 100:3.0f}% | R per hari posisi {x.sum() / (jam.sum() / 24):+.3f}", flush=True)
    print()
    print("== satu orang, 5 posisi berisiko ==")
    for nm, *_ in VAR:
        print(ringkas(R, nm, porto(R, nm, 5, None), nm + " | slot lepas saat keluar"), flush=True)
    print()
    for nm in ("sekarang", "belum aman 48j", "belum aman 36j", "belum aman 72j", "belum aman 48j + runner 96j",
               "belum aman 48j + runner 120j", "trail runner 2ATR + belum aman 48j", "TP penuh 2R + belum aman 48j"):
        for rn in (1, 2, 3, 5):
            print(ringkas(R, nm, porto(R, nm, 5, rn), f"{nm} | aman lepas slot, runner maks {rn}"), flush=True)

"""QSE v149 - NEWS KE TRADE. Dipanggil listener tiap 15 menit.
Sumber: RSS media kripto (Cointelegraph, CoinDesk, Decrypt, Cryptonews), Google News, dan Reddit (sosmed).
Tiap berita: dicocokkan ke koin Bybit, dinilai dampaknya (positif/negatif, kuat/lemah), diterjemahkan ke bahasa Indonesia,
lalu disambungkan ke hasil engine QSE koin itu. Saran entry hanya keluar kalau arah berita dan engine searah.
Berita makro (Fed, ETF, regulasi, perang) dipetakan ke BTC. Tiap judul dikirim sekali."""
import html
import json
import os
import re
import time
import datetime as dt
import requests
import telegram_notify as TG
from config import STATE_DIR

FILE = os.path.join(STATE_DIR, "news.json")
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) qse-bot/1.0"}
WIB = dt.timezone(dt.timedelta(hours=7))
SUMBER = (
    ("Cointelegraph", "https://cointelegraph.com/rss"),
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/"),
    ("Decrypt", "https://decrypt.co/feed"),
    ("Cryptonews", "https://cryptonews.com/news/feed/"),
    ("Google News", "https://news.google.com/rss/search?q=crypto+OR+bitcoin+when:3h&hl=en-US&gl=US&ceid=US:en"),
    ("Reddit r/CryptoCurrency", "https://www.reddit.com/r/CryptoCurrency/hot/.rss?limit=25"),
    ("Reddit r/Bitcoin", "https://www.reddit.com/r/Bitcoin/hot/.rss?limit=15"),
)
NAMA = {
    "BTC": ("bitcoin", "btc"), "ETH": ("ethereum", "ether", "eth"), "SOL": ("solana", "sol"), "XRP": ("xrp", "ripple"),
    "BNB": ("bnb", "binance coin"), "DOGE": ("dogecoin", "doge"), "ADA": ("cardano", "ada"), "TRX": ("tron", "trx"),
    "AVAX": ("avalanche", "avax"), "LINK": ("chainlink",), "DOT": ("polkadot",), "TON": ("toncoin", "ton"),
    "SUI": ("sui",), "LTC": ("litecoin", "ltc"), "SHIB": ("shiba inu", "shib"), "PEPE": ("pepe",), "NEAR": ("near protocol",),
    "APT": ("aptos",), "ARB": ("arbitrum",), "OP": ("optimism",), "HBAR": ("hedera", "hbar"), "XLM": ("stellar", "xlm"),
    "UNI": ("uniswap",), "AAVE": ("aave",), "ENA": ("ethena",), "HYPE": ("hyperliquid",), "WLD": ("worldcoin",),
    "TIA": ("celestia",), "INJ": ("injective",), "FIL": ("filecoin",), "ICP": ("internet computer",), "ETC": ("ethereum classic",),
}
MAKRO = ("fed ", "fomc", "powell", "rate cut", "rate hike", "interest rate", "cpi", "inflation", "jobs report", "payroll",
         "etf", "sec ", "tariff", "war ", "sanction", "trump", "treasury", "recession", "liquidat", "stablecoin")
POS = {"approve": 2, "approval": 2, "etf inflow": 2, "inflows": 2, "partnership": 1, "launch": 1, "listing": 1, "lists": 1,
       "surge": 2, "soar": 2, "rally": 2, "jump": 1, "bullish": 2, "record high": 2, "all-time high": 2, "ath": 1,
       "rate cut": 2, "adopt": 1, "buys": 1, "accumulat": 1, "upgrade": 1, "wins": 1, "dismiss": 1, "breakout": 1,
       "gains": 1, "rebound": 1, "recover": 1, "reserve": 1, "eases": 1}
NEG = {"hack": 3, "exploit": 3, "lawsuit": 2, "sues": 2, "ban ": 2, "bans": 2, "delist": 3, "crash": 3, "plunge": 2,
       "dump": 2, "bearish": 2, "outflow": 2, "sell-off": 2, "selloff": 2, "liquidat": 2, "rate hike": 2, "fraud": 2,
       "drops": 1, "falls": 1, "slides": 1, "slump": 2, "warning": 1, "probe": 1, "investigat": 1, "halt": 2,
       "depeg": 3, "bankrupt": 3, "tariff": 1, "war ": 2, "sanction": 1, "unlock": 1, "fear": 1, "decline": 1}


DAMPAK = {  # backtest 2022-01 s/d 2026-10: reaksi BTC (persen) setelah berita jenis ini, data jam Binance
    'BANK_CRISIS': dict(n=3, b4=None, b24=-2.42, b72=-0.63, naik=0, dd=-4.05, up=0.26, alt24=0.59),
    'BANK_RESCUE': dict(n=1, b4=4.8, b24=13.22, b72=14.81, naik=100, dd=-0.81, up=15.17, alt24=-6.16),
    'CORPORATE_BUY': dict(n=3, b4=None, b24=-1.48, b72=0.85, naik=33, dd=-2.43, up=1.74, alt24=1.84),
    'CORPORATE_SELL': dict(n=1, b4=None, b24=-3.08, b72=-12.94, naik=0, dd=-4.06, up=0.57, alt24=1.76),
    'CPI_COOL': dict(n=24, b4=0.55, b24=0.79, b72=0.76, naik=58, dd=-1.81, up=2.66, alt24=1.39),
    'CPI_HOT': dict(n=19, b4=-0.92, b24=-0.75, b72=-1.94, naik=42, dd=-3.84, up=2.19, alt24=-0.01),
    'CPI_INLINE': dict(n=13, b4=1.42, b24=1.78, b72=3.29, naik=85, dd=-1.16, up=3.59, alt24=0.28),
    'ETF_POSITIVE': dict(n=8, b4=-1.36, b24=1.41, b72=-0.87, naik=50, dd=-2.2, up=3.51, alt24=1.24),
    'EXCHANGE_COLLAPSE': dict(n=9, b4=None, b24=-6.49, b72=-8.44, naik=0, dd=-8.58, up=1.03, alt24=-1.22),
    'FOMC_CUT': dict(n=6, b4=-0.65, b24=-0.54, b72=-0.05, naik=50, dd=-3.1, up=1.87, alt24=-0.88),
    'FOMC_HIKE': dict(n=12, b4=0.25, b24=0.16, b72=-0.38, naik=42, dd=-3.3, up=3.42, alt24=2.39),
    'FOMC_HOLD': dict(n=20, b4=-0.2, b24=-0.94, b72=-0.93, naik=45, dd=-2.92, up=1.93, alt24=0.27),
    'GOV_SELLING': dict(n=2, b4=None, b24=-3.62, b72=-6.31, naik=0, dd=-6.78, up=0.43, alt24=-0.72),
    'HACK': dict(n=17, b4=-0.03, b24=0.01, b72=-0.29, naik=29, dd=-1.75, up=1.83, alt24=-0.25),
    'HALVING': dict(n=1, b4=0.22, b24=1.76, b72=4.7, naik=100, dd=-1.14, up=2.51, alt24=4.12),
    'MACRO_SHOCK': dict(n=6, b4=0.32, b24=-0.57, b72=-1.59, naik=33, dd=-4.61, up=1.86, alt24=0.23),
    'POLITICS_PROCRYPTO': dict(n=6, b4=None, b24=3.36, b72=3.0, naik=67, dd=-1.46, up=5.26, alt24=2.13),
    'REG_NEGATIVE': dict(n=9, b4=None, b24=-1.21, b72=1.02, naik=33, dd=-3.36, up=1.69, alt24=-1.67),
    'REG_POSITIVE': dict(n=9, b4=None, b24=0.96, b72=-0.38, naik=67, dd=-1.7, up=2.84, alt24=2.38),
    'STABLECOIN_DEPEG': dict(n=3, b4=None, b24=-4.97, b72=0.09, naik=33, dd=-6.95, up=1.31, alt24=-2.71),
    'TARIFF_RELIEF': dict(n=6, b4=None, b24=1.97, b72=1.66, naik=67, dd=-2.98, up=3.65, alt24=0.8),
    'TARIFF_TRADEWAR': dict(n=5, b4=-5.04, b24=-3.03, b72=-3.85, naik=0, dd=-5.21, up=0.8, alt24=-3.54),
    'WAR': dict(n=10, b4=None, b24=-0.81, b72=-0.23, naik=40, dd=-3.79, up=1.54, alt24=-1.86),
    'WAR_DAMAI': dict(n=3, b4=None, b24=3.6, b72=4.16, naik=100, dd=-1.39, up=4.27, alt24=1.63),
}
LABEL = {"BANK_CRISIS": "krisis bank", "BANK_RESCUE": "penyelamatan bank", "CORPORATE_BUY": "perusahaan beli BTC",
         "CORPORATE_SELL": "perusahaan jual BTC", "CPI_COOL": "inflasi AS lebih rendah dari perkiraan",
         "CPI_HOT": "inflasi AS lebih tinggi dari perkiraan", "CPI_INLINE": "inflasi AS sesuai perkiraan",
         "ETF_POSITIVE": "kabar baik ETF", "EXCHANGE_COLLAPSE": "bursa atau lender kripto kolaps",
         "FOMC_CUT": "The Fed turunkan suku bunga", "FOMC_HIKE": "The Fed naikkan suku bunga", "FOMC_HOLD": "The Fed tahan suku bunga",
         "GOV_SELLING": "pemerintah atau Mt. Gox lepas BTC", "HACK": "peretasan besar", "HALVING": "halving",
         "MACRO_SHOCK": "guncangan makro", "POLITICS_PROCRYPTO": "kebijakan politik pro kripto",
         "REG_NEGATIVE": "regulasi atau gugatan negatif", "REG_POSITIVE": "regulasi positif",
         "STABLECOIN_DEPEG": "stablecoin lepas patokan", "TARIFF_RELIEF": "tarif dilonggarkan",
         "TARIFF_TRADEWAR": "tarif atau perang dagang", "WAR": "perang atau serangan militer", "WAR_DAMAI": "gencatan senjata atau damai"}
# kategori yang bisa jadi SARAN NEWS MANDIRI (walau engine berlawanan): minimal 5 kejadian, BTC 24 jam rata rata
# bergerak minimal 1.5%, dan arahnya konsisten (naik di 65% kejadian atau lebih, atau turun di 65% atau lebih).
# Backtest jalur ini (entry 1 jam setelah berita, LIMIT 0.25 ATR, SL di balik ayunan khas, TP 1R dan 2R, tahan 24 jam):
# 28 trade, WR 68%, PF 2.29, rata +0.37R. Ini in-sample, jadi tetap dicatat live dan berhenti sendiri kalau jelek.
BT_MANDIRI = "28 trade, WR 68%, PF 2.29, rata +0.37R (2022-2026)"
KUNCI = [  # urutan penting: yang lebih khusus dulu
    ("STABLECOIN_DEPEG", (("depeg", "de-peg", "loses peg", "lost its peg", "loses its peg"),)),
    ("EXCHANGE_COLLAPSE", (("halts withdrawals", "pauses withdrawals", "suspends withdrawals", "freezes withdrawals",
                            "files for bankruptcy", "chapter 11", "insolven", "collapse"),)),
    ("HACK", (("hack", "exploit", "drained", "stolen", "heist"),)),
    ("TARIFF_RELIEF", (("tariff", "trade war", "trade deal"), ("pause", "delay", "postpone", "truce", "deal", "exempt", "lift",
                                                             "strike down", "strikes down", "struck down", "drop", "roll back",
                                                             "rollback", "cut tariff", "cuts tariff", "reduce", "eases"))),
    ("TARIFF_TRADEWAR", (("tariff", "trade war"),)),
    ("FOMC_CUT", (("fed ", "fomc", "federal reserve", "powell", "warsh"), ("cuts rate", "rate cut", "cuts interest", "lowers rate",
                                                                         "cut rates", "cuts by"))),
    ("FOMC_HIKE", (("fed ", "fomc", "federal reserve", "powell", "warsh"), ("raises rate", "rate hike", "hikes rate", "raises interest",
                                                                          "hike rates", "hikes by"))),
    ("FOMC_HOLD", (("fed ", "fomc", "federal reserve", "powell", "warsh"), ("holds rate", "keeps rate", "leaves rate",
                                                                          "rates unchanged", "holds steady", "on hold"))),
    ("CPI_HOT", (("cpi", "inflation"), ("hotter", "higher than expected", "above expectation", "above forecast", "accelerat",
                                        "sticky", "rises more than"))),
    ("CPI_COOL", (("cpi", "inflation"), ("cooler", "lower than expected", "below expectation", "below forecast", "eases",
                                         "slows", "softer", "cools"))),
    ("CPI_INLINE", (("cpi",), ("in line", "as expected", "matches", "meets expectation"))),
    ("WAR_DAMAI", (("ceasefire", "peace deal", "peace agreement", "truce"),)),
    ("WAR", (("missile", "airstrike", "air strike", "invasion", "invades", "military strike", "strikes on", "declares war",
              "attack on", "launches strikes", "bomb"),)),
    ("ETF_POSITIVE", (("etf",), ("approv", "launch", "inflow", "filing", "files for", "record"))),
    ("REG_NEGATIVE", (("sues", "lawsuit", "charges", "crackdown", "bans ", "ban on", "sanction", "indict", "cloture fails",
                       "bill fails", "rejects"),)),
    ("REG_POSITIVE", (("clarity act", "genius act", "market structure", "dismiss", "drops case", "drops lawsuit",
                       "regulatory clarity", "approves", "signs", "passes"), ("crypto", "bitcoin", "stablecoin", "sec", "digital asset"))),
    ("POLITICS_PROCRYPTO", (("strategic bitcoin reserve", "crypto reserve", "bitcoin reserve", "pro-crypto", "crypto executive order"),)),
    ("GOV_SELLING", (("mt. gox", "mt gox", "government sells", "government moves", "seized bitcoin", "seized btc"),)),
    ("CORPORATE_SELL", (("sells bitcoin", "sold bitcoin", "sells btc", "sold btc"),)),
    ("CORPORATE_BUY", (("buys", "acquires", "purchases", "adds"), ("bitcoin", "btc"))),
    ("BANK_CRISIS", (("bank",), ("collapse", "fails", "failure", "seized", "bank run", "run on"))),
    ("MACRO_SHOCK", (("recession", "bank of japan", "boj ", "yen carry", "government shutdown", "stock market crash",
                      "global selloff", "global sell-off", "black monday"),)),
    ("HALVING", (("halving",),)),
]


def kategori(teks):
    """Jenis berita (kunci DAMPAK) dari judul dan ringkasan, atau None."""
    low = " " + teks.lower() + " "
    for k, grup in KUNCI:
        if all(any(w in low for w in g) for g in grup):
            return k
    return None


def arah_sejarah(k):
    """+1 kalau sejarah jenis berita ini condong naik, -1 condong turun, 0 campur."""
    d = DAMPAK.get(k)
    if not d or d["n"] < 5:
        return FACE.get(k, 0)
    if d["naik"] >= 60 and d["b24"] > 0:
        return 1
    if d["naik"] <= 40 and d["b24"] < 0:
        return -1
    return FACE.get(k, 0) if k in ("HACK", "REG_NEGATIVE", "REG_POSITIVE", "WAR") else 0


FACE = {"BANK_CRISIS": -1, "BANK_RESCUE": 1, "CORPORATE_BUY": 1, "CORPORATE_SELL": -1, "CPI_COOL": 1, "CPI_HOT": -1,
        "ETF_POSITIVE": 1, "EXCHANGE_COLLAPSE": -1, "FOMC_CUT": 1, "FOMC_HIKE": -1, "GOV_SELLING": -1, "HACK": -1,
        "HALVING": 1, "MACRO_SHOCK": -1, "POLITICS_PROCRYPTO": 1, "REG_NEGATIVE": -1, "REG_POSITIVE": 1,
        "STABLECOIN_DEPEG": -1, "TARIFF_RELIEF": 1, "TARIFF_TRADEWAR": -1, "WAR": -1, "WAR_DAMAI": 1}


def kuat_mandiri(k):
    d = DAMPAK.get(k)
    return bool(d) and d["n"] >= 5 and abs(d["b24"]) >= 1.5 and (d["naik"] >= 65 or d["naik"] <= 35)


def sejarah_teks(k):
    d = DAMPAK.get(k)
    if not d:
        return ""
    t = (f"📚 Sejarah 2022-2026, {LABEL.get(k, k)} ({d['n']} kejadian): BTC 24 jam rata rata {d['b24']:+.2f}%, "
         f"naik di {d['naik']}% kejadian, 3 hari {d['b72']:+.2f}%. Turun terdalam rata rata {d['dd']:.1f}% dan naik tertinggi "
         f"+{d['up']:.1f}% dalam 24 jam. Altcoin dibanding BTC {d['alt24']:+.2f}%.")
    if d["n"] < 5:
        t += " Sampel kecil, anggap petunjuk saja."
    elif arah_sejarah(k) == 0:
        t += " Arahnya campur, berita jenis ini lebih sering bikin harga bergoyang daripada searah."
    return t


def _load():
    try:
        with open(FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def _save(c):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(FILE + ".tmp", "w") as f:
        json.dump(c, f)
    os.replace(FILE + ".tmp", FILE)


def _bersih(s):
    s = re.sub(r"<!\[CDATA\[|\]\]>", "", s or "")
    return html.unescape(re.sub(r"<[^>]+>", " ", s)).replace("\xa0", " ").strip()


def _ambil(nama, url):
    try:
        x = requests.get(url, headers=UA, timeout=15).text
    except Exception as ex:
        print("[WARN] news", nama, ex)
        return []
    out = []
    for it in re.findall(r"<(?:item|entry)(?:\s[^>]*)?>(.*?)</(?:item|entry)>", x, re.S)[:25]:
        t = re.search(r"<title[^>]*>(.*?)</title>", it, re.S)
        if not t:
            continue
        ln = re.search(r"<link[^>]*?(?:href=\"([^\"]+)\"[^>]*/?>|>(.*?)</link>)", it, re.S)
        d = re.search(r"<(?:description|summary|content)[^>]*>(.*?)</(?:description|summary|content)>", it, re.S)
        pb = re.search(r"<(?:pubDate|published|updated|dc:date)[^>]*>(.*?)</(?:pubDate|published|updated|dc:date)>", it, re.S)
        out.append(dict(sumber=nama, judul=_bersih(t.group(1)),
                        link=(ln.group(1) or ln.group(2) or "").strip() if ln else "",
                        isi=_bersih(d.group(1))[:400] if d else "", pub=_waktu(pb.group(1)) if pb else None))
    return out


def _waktu(s):
    """Waktu terbit berita (epoch detik) dari format RSS atau Atom. Gagal = None."""
    s = _bersih(s)
    try:
        from email.utils import parsedate_to_datetime
        return parsedate_to_datetime(s).timestamp()
    except Exception:
        pass
    try:
        return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
    except Exception:
        return None


def terjemah(teks):
    """Terjemah ke bahasa Indonesia (Google Translate publik). Gagal = teks asli."""
    if not teks:
        return ""
    try:
        r = requests.get("https://translate.googleapis.com/translate_a/single", timeout=10,
                         params=dict(client="gtx", sl="auto", tl="id", dt="t", q=teks[:600])).json()
        return "".join(x[0] for x in r[0] if x and x[0]).strip() or teks
    except Exception:
        return teks


def _nilai(teks):
    low = " " + teks.lower() + " "
    p = sum(w for k, w in POS.items() if k in low)
    n = sum(w for k, w in NEG.items() if k in low)
    s = p - n
    if s == 0:
        return 0, ""
    kuat = "KUAT" if abs(s) >= 3 else "SEDANG" if abs(s) == 2 else "LEMAH"
    return (1 if s > 0 else -1), kuat


def _koin(teks, simbol):
    """Koin yang disebut di berita. Berita makro tanpa koin dipetakan ke BTC."""
    low = " " + re.sub(r"[^a-z0-9 ]", " ", teks.lower()) + " "
    hit = []
    for base, kata in NAMA.items():
        if any(f" {k} " in low for k in kata) and base + "USDT" in simbol:
            hit.append(base)
    for tok in set(re.findall(r"\$?\b([A-Z]{3,10})\b", teks)):
        if tok + "USDT" in simbol and tok not in hit and tok not in ("THE", "FOR", "AND", "NEW", "ETF", "SEC", "CEO", "USD"):
            hit.append(tok)
    if not hit and any(k in low for k in MAKRO):
        hit = ["BTC"]
    return hit[:2]


def _hasil(sym):
    try:
        with open(os.path.join(STATE_DIR, "screening_terbaru.json")) as f:
            for r in json.load(f):
                if r["symbol"] == sym and r.get("tf", "240") == "240":
                    return r
    except Exception:
        pass
    return None


def _harga(sym):
    try:
        from config import BYBIT_URL
        t = requests.get(BYBIT_URL + "/v5/market/tickers", params={"category": "linear", "symbol": sym},
                         timeout=10).json()["result"]["list"][0]
        return float(t["lastPrice"])
    except Exception:
        return None


def _atr1j(sym, pub, now):
    """ATR 1 jam dan gerak harga (persen) sejak berita terbit. Return (atr, gerak_pct, harga) atau None."""
    try:
        from config import BYBIT_URL
        rows = requests.get(BYBIT_URL + "/v5/market/kline", timeout=10, params={"category": "linear", "symbol": sym,
                            "interval": "60", "limit": 40}).json()["result"]["list"]
        k = sorted(([int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4])] for x in rows), key=lambda z: z[0])
    except Exception:
        return None
    if len(k) < 16:
        return None
    tr = [max(k[i][2] - k[i][3], abs(k[i][2] - k[i - 1][4]), abs(k[i][3] - k[i - 1][4])) for i in range(1, len(k))]
    atr = sum(tr[-15:-1]) / 14
    t0 = (pub or now - 7200) * 1000
    awal = next((x[1] for x in k if x[0] + 3600000 > t0), k[-2][1])
    return atr, (k[-1][4] / awal - 1) * 100, k[-1][4]


def _mandiri(sym, arah, kat, pub, now, eng):
    """SARAN NEWS MANDIRI: dipakai saat engine berlawanan atau belum punya saran, tapi sejarah jenis berita ini kuat."""
    import qse_catat as CT
    d = DAMPAK[kat]
    if CT.mati("news_mandiri"):
        return "⛔ Jalur news mandiri sedang dihentikan karena hasil live-nya jelek. Ikuti engine saja."
    if pub and now - pub > 3 * 3600:
        return (f"⏳ Berita sudah {(now - pub) / 3600:.0f} jam. Dampak jenis berita ini biasanya sudah berjalan, "
                f"jangan kejar dari berita ini.")
    m = _atr1j(sym, pub, now)
    if not m:
        return "👀 Data harga gagal diambil, jangan entry dari berita ini dulu."
    atr, gerak, px = m
    L = arah == "LONG"
    if (gerak if L else -gerak) >= 0.6 * abs(d["b24"]):
        return (f"⏳ Harga sudah bergerak {gerak:+.2f}% sejak berita, lebih dari 60% gerak khas jenis berita ini "
                f"({d['b24']:+.2f}%). Terlambat, jangan kejar.")
    import qse_saya as SY
    why = SY.cek_lintas(sym, arah)
    if why:
        return f"⏸️ Saran news ditahan: {why}."
    adv = (abs(d["dd"]) if L else d["up"]) / 100 * px
    dist = max(1.5 * atr, 1.2 * adv)
    e = px - 0.25 * atr if L else px + 0.25 * atr
    sl, t1, t2 = (e - dist, e + dist, e + 2 * dist) if L else (e + dist, e - dist, e - 2 * dist)
    t = (_hasil(sym) or {}).get("tick", 0.0001 if px < 100 else 0.1)
    batas = dt.datetime.fromtimestamp(now + 7200, WIB).strftime("%d/%m %H:%M WIB")
    CT.tambah("news_mandiri", sym, arah, e, sl, t1, t2, 2.0, LABEL.get(kat, kat))
    if not SY.TAMPIL_SEMUA and not SY.boleh_ikut("saran news", arah)[0]:
        return (f"🟡 Sejarah berita jenis ini condong {arah} untuk {sym}. Saran entry dari berita belum terbukti, "
                f"jadi tidak disarankan. Robot tetap mencatat hasilnya.")
    pc = lambda x: abs(x - e) / e * 100
    st = CT.statistik("news_mandiri")
    return (f"📰 <b>SARAN NEWS MANDIRI {arah} {sym}</b> (sejarah berita ini lebih kuat dari engine, engine condong {eng or '-'})\n"
            + SY.baris_kelas(arah, tambahan=["saran dari berita, harga bisa bergerak liar"], jalur="saran news") + "\n"
            + SY.blok_salin(e, sl, t1, t2, "LIMIT", t, sym=sym, arah=arah) + "\n"
            f"↳ Backtest jalur news mandiri: {BT_MANDIRI}."
            + (f" Live: {st['n']} trade, WR {st['wr']:.0f}%, PF {st['pf']:.2f}." if st["n"] else " Live: belum ada trade selesai.")
            + f"\n↳ Pakai setengah lot. Berlaku sampai {batas}, kalau belum terisi batalkan. SL sudah memberi ruang untuk "
            f"goyangan khas jenis berita ini.")


def _saran(sym, arah, now, kat=None, pub=None):
    """Sambungkan arah berita dengan engine. Kalau berlawanan, sejarah jenis berita yang menentukan. Return teks."""
    import qse_catat as CT
    r = _hasil(sym)
    akhir = dt.datetime.fromtimestamp((int(now // 14400) + 1) * 14400, WIB)
    batas = akhir.strftime("%d/%m %H:%M WIB")
    eng = ((r.get("pasar") or {}).get("arah") or r.get("bias")) if r else None
    if r:
        t = r["tick"]
        for x in r.get("saran") or []:
            if x["arah"] == arah and x["eksekusi"] and not x.get("sudah_masuk") and x["mutu"] in ("A", "B"):
                import qse_saya as SY
                why = SY.cek_lintas(sym, arah)
                if why:
                    return f"⏸️ Berita dan engine searah {arah}, tapi saran ditahan: {why}."
                CT.tambah("news_searah", sym, arah, x["entry"], x["sl"], x["tp1"], x["tp2"],
                          max(0.5, (akhir.timestamp() - now) / 3600), f"{x['pola']} + berita")
                if not SY.TAMPIL_SEMUA and not SY.boleh_ikut("saran news", arah)[0]:
                    return (f"🟡 Berita dan engine 4J {sym} searah {arah}. Saran entry dari berita belum terbukti, "
                            f"jadi tidak disarankan. Robot tetap mencatat hasilnya.")
                rr2 = abs(x["tp2"] - x["entry"]) / (abs(x["entry"] - x["sl"]) or 1e-12)
                return (f"✅ <b>SARAN ENTRY {arah} {sym}</b> (berita dan engine searah)\n"
                        + SY.baris_kelas(arah, skor=SY.skor_setup(r, x), wr=x.get("wr"), rr2=rr2, rapor=r.get("rapor"), jalur="saran news") + "\n"
                        + SY.blok_salin(x["entry"], x["sl"], x["tp1"], x["tp2"], x["order"], t, sym=sym, arah=arah) + "\n"
                        f"↳ pola {TG.e(x['pola'])} mutu {x['mutu']}, rapor robot {r['rapor']}. Berlaku sampai {batas}.")
    if kat and kuat_mandiri(kat) and sym == "BTCUSDT":
        return _mandiri(sym, arah, kat, pub, now, eng)
    if not r:
        return f"👀 {sym} belum ada di scan robot. Jangan entry dari berita saja."
    t = r["tick"]
    eng_txt = f"Engine QSE 4J {sym} condong {eng or 'belum jelas'}"
    if eng == arah:
        gp = (r.get("pasar") or {}).get("gp")
        zona = f" Zona tunggu {sym} {TG.fp(min(gp), t)} sampai {TG.fp(max(gp), t)}." if gp else ""
        return (f"🟡 {eng_txt}, searah berita ({arah}). Belum ada saran valid.{zona} Masuk hanya kalau harga sampai zona "
                f"dan ada candle konfirmasi {arah}, sebelum {batas}.")
    return f"⛔ {eng_txt}, berlawanan dengan berita ({arah}). Jangan entry dari berita ini."


def _cek_pasar(sym, arah):
    """Baris tambahan di bawah tiap berita: kondisi semua pasar (BTC 1J dan 4J, altcoin, berita lain),
    apakah arah berita searah BTC 1 jam, dan posisi kamu yang searah atau berlawanan dengan berita ini.
    Berita BTC atau ETH dianggap menyentuh semua altcoin, berita koin lain hanya menyentuh koin itu."""
    import qse_saya as SY
    rows = []          # baris konteks BTC 1 jam dan altcoin dihapus: tidak terbukti membantu keputusan
    try:
        luas = sym in ("BTCUSDT", "ETHUSDT")
        pos = [v for v in SY.lihat()["open"].values()
               if v.get("status") != "MENUNGGU" and (luas or v.get("sym") == sym)]
    except Exception:
        pos = []
    if pos:
        kena = "semua altcoin ikut terdorong" if luas else f"hanya {sym}"
        sama = sorted({f"{v['sym'].replace('USDT', '')} {v['arah']}" for v in pos if v["arah"] == arah})
        beda = sorted({f"{v['sym'].replace('USDT', '')} {v['arah']}" for v in pos if v["arah"] != arah})
        rows.append(f"📌 Posisi kamu ({kena}): "
                    + (f"berlawanan berita: {', '.join(beda)}. " if beda else "")
                    + (f"searah berita: {', '.join(sama)}. " if sama else "")
                    + ("Cek /status untuk jarak ke SL." if beda else ""))
    return "\n".join(rows)


def tes():
    """Perintah /berita: uji semua sumber, terjemahan, dan harga Bybit dari VPS. Tidak mengubah catatan berita."""
    rows, contoh = [], None
    for nama, url in SUMBER:
        b = _ambil(nama, url)
        rows.append(f"{'✅' if b else '❌'} {TG.e(nama)}: {len(b)} berita")
        if b and contoh is None:
            contoh = b[0]
    ok = sum(r.startswith("✅") for r in rows)
    out = "\n".join(rows) + f"\n\nSumber hidup: {ok} dari {len(SUMBER)}"
    if contoh:
        t = terjemah(contoh["judul"])
        out += (f"\n\nContoh: {TG.e(contoh['judul'][:150])}\n↳ terjemahan: {TG.e(t[:150])}"
                + ("" if t != contoh["judul"] else "\n↳ ❌ terjemahan gagal, teks asli dipakai"))
    hp = _harga("BTCUSDT")
    out += f"\n\nHarga BTC dari Bybit: {hp if hp else '❌ gagal'}"
    out += ("\n\nNews ke trade siap jalan. Berita baru dicek tiap 15 menit." if ok and hp
            else "\n\nAda yang gagal. Kirim foto pesan ini ke Claude.")
    return out


UMUR_MAKS = 3 * 3600      # berita lebih tua dari 3 jam tidak dikirim
JEDA_TOPIK = 6 * 3600     # topik sama (jenis berita + koin) paling sering sekali per 6 jam
GERAK_MIN = 1.0           # berita baru tanpa sejarah: harga harus sudah bergerak minimal 1% ...
GERAK_ATR = 1.5           # ... dan minimal 1.5 ATR 1 jam searah berita


def sejarah_singkat(k):
    d = DAMPAK.get(k)
    if not d:
        return ""
    alt = (" Alt biasanya kena lebih parah, hindari LONG alt." if d["alt24"] <= -1.5 else
           " Alt biasanya naik lebih kuat dari BTC." if d["alt24"] >= 1.5 else "")
    return (f"📚 Sejarah {d['n']} kejadian: BTC 24 jam {d['b24']:+.1f}%, naik di {d['naik']}% kejadian.{alt}")


def terbukti(kat):
    """Jenis berita yang dampaknya terbukti dari sejarah 2022-2026 (data jam Binance): arah konsisten (naik di 65%
    kejadian atau lebih, atau 35% atau kurang) dan gerak BTC 24 jam besar (minimal 1.5% bila 5-7 kejadian, minimal 1%
    bila 8 kejadian atau lebih). Contoh lolos: CPI sesuai perkiraan, bursa kolaps, regulasi negatif, perang dagang.
    Contoh tidak lolos: hack, CPI panas atau dingin, FOMC tahan, perang (arah campur atau gerak kecil)."""
    d = DAMPAK.get(kat)
    if not d or arah_sejarah(kat) == 0 or not (d["naik"] >= 65 or d["naik"] <= 35):
        return False
    return (d["n"] >= 5 and abs(d["b24"]) >= 1.5) or (d["n"] >= 8 and abs(d["b24"]) >= 1.0)


def _lolos(kat, kuat, arah, koin, pub, now):
    """Hanya berita yang jenisnya terbukti berdampak (20 Okt 2026). Jalur lama 'berita baru yang harga sudah bergerak'
    dihapus: beritanya datang setelah harga bergerak, jadi telat, dan gerak harga sudah dikabari PASAR BERGERAK SERENTAK."""
    if pub and now - pub > UMUR_MAKS:
        return None
    return "sejarah" if kat and terbukti(kat) else None


def _lolos_lama(kat, kuat, arah, koin, pub, now):
    """Saring berita. Return alasan lolos (teks) atau None.
    Lolos kalau (1) jenis berita ada di sejarah dan dampaknya besar, atau
    (2) berita baru tanpa sejarah, kata kuncinya kuat, dan harga sudah bergerak jelas searah berita."""
    if pub and now - pub > UMUR_MAKS:
        return None
    if kat:
        d = DAMPAK.get(kat, {})
        if arah_sejarah(kat) != 0 and (kuat_mandiri(kat) or (d.get("n", 0) >= 5 and abs(d.get("b24", 0)) >= 1.0)
                                       or abs(d.get("b24", 0)) >= 2.5):    # kejadian langka tapi besar
            return "sejarah"
    if kuat != "KUAT":
        return None
    m = _atr1j(koin[0] + "USDT", pub, now)
    if not m:
        return None
    atr, gerak, px = m
    g = gerak if arah > 0 else -gerak
    if g >= GERAK_MIN and g / 100 * px >= GERAK_ATR * atr:
        return f"harga sudah bergerak {gerak:+.1f}% sejak berita"
    return None


def cek(simbol, maks=2):
    """simbol = set simbol Bybit (mis. {'BTCUSDT', ...}). Return daftar pesan siap kirim.
    Hanya berita yang terbukti berdampak (sejarah kuat) atau baru keluar dan sudah menggerakkan harga."""
    c = _load()
    sudah = set(c.get("kirim", []))
    topik = c.get("topik", {})
    awal = not sudah
    now = time.time()
    out = []
    for nama, url in SUMBER:
        for b in _ambil(nama, url):
            kunci = re.sub(r"\W+", "", b["judul"].lower())[:90]
            if not kunci or kunci in sudah:
                continue
            sudah.add(kunci)
            if awal or len(out) >= maks:
                continue
            isi = "" if "google" in b["sumber"].lower() else b["isi"]   # ringkasan Google News isinya cuma link
            teks = b["judul"] + " " + isi[:200]
            kat = kategori(teks)
            arah, kuat = _nilai(teks)
            if kat:
                arah = arah_sejarah(kat) or arah
            if not arah:
                continue
            koin = _koin(teks, simbol) or (["BTC"] if kat and "BTCUSDT" in simbol else [])
            if not koin:
                continue
            tk = f"{kat or 'KW' + str(arah)}|{koin[0]}"
            if now - topik.get(tk, 0) < JEDA_TOPIK:
                continue
            alasan = _lolos(kat, kuat, arah, koin, b.get("pub"), now)
            if not alasan:
                continue
            # berita berlawanan atau searah dalam 3 jam terakhir untuk koin yang sama tidak dikirim terpisah:
            # berlawanan dianggap saling batal, searah cukup sekali
            riw = [x for x in c.get("terakhir", []) if now - x["t"] < 3 * 3600 and x.get("koin") and x["koin"][0] == koin[0]]
            if any(x["arah"] != ("LONG" if arah > 0 else "SHORT") for x in riw):
                c.setdefault("batal", []).append(dict(t=now, koin=koin[0], judul=b["judul"][:120]))
                continue
            if riw:
                continue
            topik[tk] = now
            arah_t = "LONG" if arah > 0 else "SHORT"
            c.setdefault("terakhir", []).append(dict(t=now, arah=arah_t, koin=koin[:2], kat=kat))
            c["terakhir"] = [x for x in c["terakhir"] if now - x["t"] < 86400][-50:]
            judul = TG.e(terjemah(b["judul"])[:160])
            if b["link"]:
                judul = f'<a href="{html.escape(b["link"], quote=True)}">{judul}</a>'
            umur = f", {(now - b['pub']) / 60:.0f} menit lalu" if b.get("pub") and now >= b["pub"] else ""
            rows = [f"🗞️ <b>{judul}</b>",
                    f"↳ {TG.e(b['sumber'])}{umur} | {'🟢 POSITIF' if arah > 0 else '🔴 NEGATIF'} untuk {', '.join(koin)}"
                    + (f" | {LABEL.get(kat, kat)}" if kat else "")
                    + ("" if alasan == "sejarah" else f" | {alasan}")]
            if alasan == "sejarah":
                rows.append(sejarah_singkat(kat))
            rows.append("🛠 Aksi: info saja, jangan entry dari berita. Sinyal teknik tetap acuan, posisi jalan tetap ikuti "
                        "SL dan TP (uji: keluar lebih awal menurunkan profit). Khusus CPI dan FOMC ikuti pesan SIAGA.")
            for base in koin[:1]:
                ck = _cek_pasar(base + "USDT", arah_t)
                if ck:
                    rows.append(ck)
            out.append("\n".join(rows))
    c["kirim"] = list(sudah)[-1500:]
    c["topik"] = {k: v for k, v in topik.items() if now - v < 86400}
    _save(c)
    return out


def kabar(mundur=1, maju=10):
    """Perintah /kabar: berita kripto 1 jam terakhir dan kalender berita besar USD 1 jam lalu sampai 10 jam ke depan,
    lengkap dengan arah (LONG, SHORT, atau campur) dan koin yang terkena."""
    import qse_berita as BR
    now = time.time()
    rows = ["<b>Kalender berita besar USD</b> (1 jam lalu sampai 10 jam ke depan)"]
    try:
        ev = [e for e in BR.kalender() if now - mundur * 3600 <= e["ts"] / 1000 <= now + maju * 3600]
    except Exception:
        ev = []
    for e in ev:
        sisa = (e["ts"] / 1000 - now) / 3600
        siaga = any(k in e["judul"].upper() for k in ("CPI", "FOMC", "FEDERAL FUNDS"))
        rows.append(f"{BR.dampak(e['judul'], 'USD')} {BR.jam_wib(e['ts'])} | {TG.e(e['judul'])} | "
                    + (f"{sisa:.1f} jam lagi" if sisa > 0 else "sudah rilis")
                    + (". Robot kirim SIAGA 1 jam sebelum" if siaga else ""))
    if not ev:
        rows.append("Tidak ada berita besar USD di rentang ini.")
    rows.append("Sinyal jalur tetap jalan saat berita (uji 2021-2026: sinyal dekat FOMC, ECB, BoJ, earnings tidak lebih jelek).")
    try:
        k7 = [e for e in BR.kalender_semua(7) if e["tanda"] != "⚪" and e["ts"] / 1000 > now + maju * 3600][:10]
        if k7:
            rows.append("\n<b>7 hari ke depan</b> (lengkap di pesan KALENDER BERITA tiap Senin 06:10 WIB)")
            rows += [f"{e['tanda']} {BR.jam_wib(e['ts'])} | {TG.e(e['teks'])}" for e in k7]
    except Exception as ex:
        print("[WARN] kalender 7 hari", ex)
    rows.append(f"\n<b>Berita kripto {mundur} jam terakhir</b>")
    try:
        import qse_saya as SY
        simbol = set(SY._peta_robot()) | {"BTCUSDT", "ETHUSDT"}
    except Exception:
        simbol = {"BTCUSDT", "ETHUSDT"}
    semua, lihat = [], set()
    for nama, url in SUMBER:
        for b in _ambil(nama, url):
            kunci = b["judul"].lower()[:80]
            if b["pub"] and b["pub"] >= now - mundur * 3600 and kunci not in lihat:
                lihat.add(kunci)
                semua.append(b)
    semua.sort(key=lambda b: -b["pub"])
    for b in semua[:8]:
        teks = b["judul"] + " " + b["isi"]
        kat = kategori(teks)
        a = arah_sejarah(kat) if kat else 0
        if a == 0:
            a = _nilai(teks)[0]
        koin = _koin(teks, simbol)
        arah = "LONG" if a > 0 else "SHORT" if a < 0 else "campur"
        jam = time.strftime("%H:%M", time.gmtime(b["pub"] + 7 * 3600))
        rows.append(f"{jam} WIB | {TG.e(terjemah(b['judul'])[:160])}\n↳ arah {arah}"
                    + (f" | koin {', '.join(koin)}" if koin else "")
                    + (f" | jenis {LABEL.get(kat, kat)}" if kat else ""))
    if not semua:
        rows.append("Tidak ada berita kripto baru di 1 jam terakhir.")
    rows.append("\nArah dari sejarah jenis berita (kalau ada) atau dari kata kunci judul. Berita yang benar-benar "
                "berdampak tetap dikirim otomatis lewat NEWS PENTING.")
    return "\n".join(rows)


STOP = set("the a an and or of to in on for with as at by from is are was be this that its it after over into amid new says "
           "said will could may than more how why what who crypto cryptocurrency price prices market markets news today "
           "bitcoin btc ethereum eth".split())


def _kata(judul):
    return {w for w in re.findall(r"[a-z0-9]{3,}", judul.lower()) if w not in STOP}


VIRAL_MIN = 7.0          # skor minimal kiriman otomatis: dua sumber atau lebih, atau Reddit, atau jenis berita berdampak


def _kunci_viral(b):
    return re.sub(r"\W+", "", b["judul"].lower())[:60]


def viral(jam=24, maks=6, sudah=None, skor_min=0.0, kunci_out=None):
    """Perintah /viral: berita kripto paling ramai dan paling berdampak dalam `jam` jam terakhir.
    Ramai = dibahas banyak sumber (judul mirip digabung) dan masuk Reddit hot. Dampak = jenis berita yang
    punya sejarah gerak BTC besar, atau kata kunci kuat. Arah dan koin yang terkena ikut ditulis."""
    import qse_saya as SY
    now = time.time()
    try:
        simbol = set(SY._peta_robot()) | {"BTCUSDT", "ETHUSDT"}
    except Exception:
        simbol = {"BTCUSDT", "ETHUSDT"}
    semua = []
    for nama, url in SUMBER:
        for b in _ambil(nama, url):
            if b["pub"] and b["pub"] >= now - jam * 3600:
                semua.append(dict(b, kata=_kata(b["judul"])))
    if not semua:
        return None if sudah is not None else "Belum ada berita kripto yang bisa diambil. Coba lagi beberapa menit lagi."
    klaster = []
    for b in sorted(semua, key=lambda b: b["pub"]):
        for k in klaster:
            u = b["kata"] | k["kata"]
            if u and len(b["kata"] & k["kata"]) / len(u) >= 0.3:
                k["isi"].append(b)
                k["kata"] |= b["kata"]
                break
        else:
            klaster.append(dict(kata=set(b["kata"]), isi=[b]))
    rows = []
    for k in klaster:
        isi = k["isi"]
        utama = next((b for b in isi if "reddit" not in b["sumber"].lower()), isi[0])
        teks = " ".join(b["judul"] + " " + b["isi"][:200] for b in isi)
        kat = kategori(teks)
        a, kuat = _nilai(teks)
        if kat and arah_sejarah(kat):
            a = arah_sejarah(kat)
        sumber = {b["sumber"] for b in isi}
        reddit = any("reddit" in s.lower() for s in sumber)
        d = DAMPAK.get(kat) if kat else None
        dampak = abs(d["b24"]) if d else (2.0 if kuat == "KUAT" else 1.0 if kuat == "SEDANG" else 0.0)
        umur = (now - max(b["pub"] for b in isi)) / 3600
        skor = 2.0 * len(sumber) + (2 if reddit else 0) + 1.5 * dampak + max(0.0, 3 - umur / 4)
        rows.append(dict(skor=skor, utama=utama, sumber=sumber, reddit=reddit, kat=kat, arah=a, kuat=kuat,
                         koin=_koin(teks, simbol), umur=umur, n=len(isi)))
    rows.sort(key=lambda z: -z["skor"])
    if sudah is not None:          # mode otomatis: buang yang sudah pernah dikirim atau skornya rendah, tidak ada sisa berarti tidak kirim
        rows = [z for z in rows if z["skor"] >= skor_min and _kunci_viral(z["utama"]) not in sudah]
        if not rows:
            return None
    if kunci_out is not None:
        kunci_out += [_kunci_viral(z["utama"]) for z in rows[:maks]]
    out = [f"🔥 <b>BERITA VIRAL DAN BERDAMPAK</b>  ·  {jam} jam terakhir",
           f"Dari {len(semua)} berita di {len({b['sumber'] for b in semua})} sumber, diurut dari yang paling ramai dan berdampak."]
    for i, z in enumerate(rows[:maks], 1):
        b = z["utama"]
        judul = TG.e(terjemah(b["judul"])[:170])
        if b["link"]:
            judul = f'<a href="{html.escape(b["link"], quote=True)}">{judul}</a>'
        arah = ("🟢 POSITIF" if z["arah"] > 0 else "🔴 NEGATIF" if z["arah"] < 0 else "⚪ NETRAL")
        kena = ", ".join(z["koin"]) if z["koin"] else "pasar umum"
        baris = [SY.GARIS, f"<b>{i}. {judul}</b>",
                 f"📰 {len(z['sumber'])} sumber" + (" · ramai di Reddit" if z["reddit"] else "")
                 + (f" · {z['umur'] * 60:.0f} menit lalu" if z["umur"] < 1 else f" · {z['umur']:.0f} jam lalu"),
                 f"🎯 {arah} untuk {kena}" + (f" · jenis {LABEL.get(z['kat'], z['kat'])}" if z["kat"] else "")]
        sj = sejarah_singkat(z["kat"]) if z["kat"] else ""
        if sj:
            baris.append(sj)
        elif z["kuat"]:
            baris.append(f"📚 Belum ada sejarah jenis berita ini, kekuatan kata kunci {z['kuat'].lower()}")
        out.append("\n".join(baris))
    out.append(SY.GARIS + "\nDikirim otomatis 13:00 dan 20:00 WIB. Berita yang menggerakkan harga masuk NEWS PENTING, "
               "jadwal berita besar dikirim H-24 dan H-6 jam sebelum rilis.")
    return "\n".join(out)


_CACHE_KOIN = {}


def berita_koin(sym, maks=3, jam=72):
    """Berita terbaru tentang satu koin untuk /cek (Google News per koin plus RSS media kripto, disimpan 10 menit).
    Tiap judul diberi arah kata kunci dan, kalau jenisnya ada di sejarah, dampak historisnya. Info saja."""
    import urllib.parse
    base = sym.replace("USDT", "")
    now = time.time()
    c = _CACHE_KOIN.get(sym)
    if c and now - c[0] < 600:
        return c[1]
    kata = NAMA.get(base, (base.lower(),))[0]
    q = urllib.parse.quote(f"{kata} {'crypto' if base not in ('BTC', 'ETH') else ''} when:3d".strip())
    items = _ambil("Google News", f"https://news.google.com/rss/search?q={q}&hl=en-US&gl=US&ceid=US:en")
    for nama, url in SUMBER[:4]:
        items += [b for b in _ambil(nama, url) if _koin(b["judul"] + " " + b["isi"][:200], {sym}) == [base]]
    lihat, out = set(), []
    for b in sorted(items, key=lambda z: -(z.get("pub") or 0)):
        if b.get("pub") and now - b["pub"] > jam * 3600:
            continue
        k = re.sub(r"\W+", "", b["judul"].lower())[:60]
        if not k or k in lihat:
            continue
        lihat.add(k)
        teks = b["judul"] + " " + b["isi"][:200]
        kat = kategori(teks)
        arah, _ = _nilai(teks)
        if kat:
            arah = arah_sejarah(kat) or arah
        umur = f"{(now - b['pub']) / 3600:.0f} jam lalu" if b.get("pub") else ""
        ik = "🟢" if arah > 0 else "🔴" if arah < 0 else "⚪"
        baris = f"{ik} {TG.e(terjemah(b['judul'])[:150])} ({TG.e(b['sumber'])}{', ' + umur if umur else ''})"
        if kat and terbukti(kat):
            d = DAMPAK[kat]
            baris += f"\n   ↳ jenis {LABEL.get(kat, kat)}: sejarah BTC 24 jam {d['b24']:+.1f}%, naik di {d['naik']}% kejadian"
        out.append(baris)
        if len(out) >= maks:
            break
    _CACHE_KOIN[sym] = (now, out)
    return out

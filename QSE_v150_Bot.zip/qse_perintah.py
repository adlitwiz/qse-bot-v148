"""QSE v149 - semua perintah Telegram. Dipakai qse_listener.py (balasan detik) dan main.py (cadangan)."""
import fcntl
import json
import os
import re
import time
import qse_fixprofit as FX
import qse_saya as SY
import qse_alarm as AL
import telegram_notify as TG
from config import STATE_DIR

LOCK_BOT = os.path.join(STATE_DIR, ".lock")

def mulai_scan():
    """Jalankan scan sekarang di proses terpisah supaya listener tetap bisa membalas perintah lain."""
    import subprocess
    import sys
    tanda = os.path.join(STATE_DIR, ".scan_terakhir")
    try:
        if time.time() - os.path.getmtime(tanda) < 600:
            sisa = int(600 - (time.time() - os.path.getmtime(tanda))) // 60 + 1
            return f"Scan terakhir belum 10 menit. Coba lagi sekitar {sisa} menit lagi, atau cek /sinyal4j dan /sinyal1j."
    except OSError:
        pass
    open(tanda, "w").close()
    folder = os.path.dirname(os.path.abspath(__file__))
    subprocess.Popen([sys.executable, "main.py", "--scan"], cwd=folder, env=os.environ.copy(),
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return ("Scan dimulai. Robot menilai ulang koin rapor A/B di TF 4J dan TF 1J dengan harga terkini. "
            "Hasilnya terkirim dalam 1 sampai 3 menit.")


def mulai_laporan4j():
    """Paksa laporan 4 jam sekarang (laporan susulan) di proses terpisah."""
    import fcntl
    import subprocess
    import sys
    try:
        with open(os.path.join(STATE_DIR, ".main.lock"), "a") as f:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(f, fcntl.LOCK_UN)
    except OSError:
        return "Laporan 4 jam sedang dibuat. Hasilnya otomatis terkirim begitu selesai."
    tanda = os.path.join(STATE_DIR, ".laporan_terakhir")
    try:
        if time.time() - os.path.getmtime(tanda) < 900:
            return "Laporan 4 jam baru saja diminta. Tunggu hasilnya dulu, paling lama 20 menit."
    except OSError:
        pass
    open(tanda, "w").close()
    folder = os.path.dirname(os.path.abspath(__file__))
    log = open(os.path.join(STATE_DIR, "main.log"), "a")
    log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} /laporan4j =====\n")
    log.flush()
    subprocess.Popen([sys.executable, "-u", "main.py", "semua"], cwd=folder, env=os.environ.copy(),
                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    log.close()
    return ("Laporan 4 jam susulan dimulai. Robot memindai semua koin dengan harga sekarang. "
            "Hasilnya terkirim dalam 10 sampai 20 menit dan otomatis disematkan.")


BANTUAN_SEMUA = ("❓ <b>QSE v149 | SEMUA PERINTAH</b>\n\n"
           "<b>Catat entry</b>\n"
           "/entry long market AUSDT = entry MARKET di harga sekarang\n"
           "/entry long market AUSDT sl 0.99 tp1 1.05 tp2 1.08 = TP dan SL sendiri. Tanpa itu robot pakai sinyal terakhir koin ini\n"
           "/entry long limit AUSDT 1.022 = order LIMIT yang menunggu terisi\n"
           "/entry long limit AUSDT 1.022 terisi 02:00 = lupa catat, sudah terisi jam 02:00 WIB\n"
           "Tambahan opsional: sl 0.99 tp1 1.05 tp2 1.08 lev 10\n\n"
           "<b>Kelola posisi</b>\n"
           "/tp AUSDT 30% = ambil profit 30% posisi di harga sekarang (bisa 50% atau 100%). Urutan bebas, contoh /tp 25% 1000BONK 0.002959. "
           "Ambil profit sebagian dicatat sebagai TP sebagian, lalu robot menyuruh SL ke entry\n"
           "/sl AUSDT 50% = cut loss 50% posisi di harga sekarang\n"
           "/sl AUSDT short 100% = tutup hanya posisi SHORT (kalau ada LONG dan SHORT di koin yang sama)\n"
           "/serok AUSDT long 0.95 = tambah posisi di harga lebih baik, lot dibatasi supaya rugi total di SL maks 1.5R\n"
           "/hapus AUSDT short = hapus trade terbuka yang salah entry, kalau tidak ada hapus catatan selesai terakhir\n"
           "/tp AUSDT 50% 1.050 = sama, tapi di harga yang kamu tulis\n"
           "/modify AUSDT sl 0.99 tp1 1.05 tp2 1.08 = geser SL atau TP (sama dengan /ubah)\n"
           "/modify AUSDT sl entry = geser SL ke titik impas\n"
           "Entry kedua di koin dan arah yang sama otomatis digabung jadi satu posisi, sama seperti di Bybit\n"
           "/tutup AUSDT = tutup semua sisa posisi di harga sekarang\n"
           "/batal AUSDT = batalkan order yang belum terisi\n\n"
           "<b>Batas posisi dan risiko</b> (otomatis, tanpa pengaturan)\n"
           "Dikunci ke hasil uji v149: maks 4 posisi berisiko per orang ditambah 2 posisi yang sudah aman (sudah TPawal), rugi kalau semua SL kena maks 5R. "
           "Jam ke-12 belum kena TP 20% dan harga melawan: SL naik ke -0.5R (searah: SL tetap). 30 jam belum kena: tutup. 3 rugi beruntun: jeda "
           "entry 24 jam (dihitung dari catatan kamu sendiri). Model arah BTC dilatih ulang sendiri tiap Senin 05:30 WIB\n"
           "/modal = lihat slot, risiko SL, dan sisa waktu tiap posisi kamu\n"
           "/modal 155 1 5 = isi modal dolar, risiko persen per trade, leverage. Kartu sinyal lalu menampilkan posisi dan margin dalam dolar\n"
           "/slok AUSDT = SL di Bybit sudah dipindah ke entry setelah TP 20% kena, pengingat berhenti\n"
           "/mingguan = laporan 7 hari: hasil robot dan trade kamu lawan uji, plus selisih harga isi lawan sinyal. Otomatis tiap Senin 06:20 WIB\n\n"
           "<b>Alarm harga</b>\n"
           "/alert BTC 60000 = kabari saat harga menyentuh 60000, bisa ditambah catatan\n"
           "/alert = daftar alarm aktif\n"
           "/alert hapus BTC atau /alert hapus semua = hapus alarm\n"
           "/tunggu SOL atas 150 4j = kabari saat candle 4J TUTUP di atas 150 (bawah juga bisa, TF 15m, 1j, 4j, 1d)\n"
           "/tunggu = daftar, /tunggu hapus SOL = hapus. Sentuhan GZH otomatis dipantau sampai candle 4J tutup\n\n"
           "<b>Sinyal</b>\n"
           "/sinyal4j atau /scan = sinyal jalur terbukti yang masih bisa diikuti di harga sekarang\n"
           "/laporan4j = buat ulang laporan 4 jam sekarang (laporan susulan), hasil dalam 10 sampai 20 menit\n"
           "/berita = uji news ke trade: sumber berita, terjemahan, harga Bybit\n"
           "/jalur = hasil live saran momentum, news searah, dan news mandiri\n"
           "/altseason = cek rezim altcoin vs BTC dan peluangnya di sejarah\n"
           "/ichimoku = posisi jalur Ichimoku tren 4J, SL trailing terbaru, dan hasilnya\n"
           "/ob = jalur Order Block + Volume 4J: posisi, hasil, dan hasil uji 6 tahun\n"
           "/pelengkap = kantong Sinyal Pelengkap sektor 4J (lot 0.5x, maks 2 posisi): posisi dan hasil\n"
           "/strategi = jalur EMA Cross, RSI 50, McGinley, SnR, MSB, SMC, GZH: posisi, hasil, uji 6 tahun\n"
           "/arah SOL = tren 15m sampai 1W, tanggal yang sama tahun lalu, pola kembar, dan riwayat pola robot di koin ini\n\n"
           "<b>Info</b>\n"
           "Otomatis tanpa perintah: pengingat berita besar H-24 dan H-6 jam, NEWS PENTING, viral 13:00 dan 20:00 WIB. Perintah /kabar dan /viral hanya kalau mau cek sendiri\n"
           "/cek AUSDT = analisa lengkap koin: kesimpulan, saran robot, teknikal, siklus, skill, fundamental, derivatif, kalender\n"
           "/evaluasi = jalur, pola, koin, hari, dan jam terbaik dari trade kamu, plus lot disarankan\n"
           "/uji = hasil uji mundur 6 bulan saran cadangan, fib, dan siklus\n"
           "/kalibrasi ETHFI = angka bot untuk dicocokkan dengan DASBOR TradingView\n"
           "/tespin = cek apakah bot sudah bisa menyematkan pesan\n"
           "/status = trade kamu: teknik, nilai, isi Bybit, sampai kapan, total untung rugi, WR\n"
           "/bantuan = daftar perintah ini\n\n"
           "<b>Arti tanda BUKTI di tiap sinyal</b>\nSinyal yang tampil lengkap = yang bisa diikuti. Sisanya tetap dicatat robot dan naik sendiri kalau terbukti di live.\n"
           "✅ TERBUKTI = untung di backtest 5 tahun (Ichimoku, Order Block + Volume). Ikuti semua, lot penuh\n"
           "✅ TERBUKTI LIVE = jalur sudah 30 trade live dengan PF 1.2 ke atas. Lot penuh\n"
           "🧪 SEDANG DIUJI = kelompok yang untung di uji (4J SHORT kelompok terbaik). Setengah lot\n"
           "⚠️ BELUM TERBUKTI = sudah diuji tapi hasilnya impas atau rugi. Satu baris di TIDAK DISARANKAN, lewati\n"
           "❔ BELUM DIUJI atau JARANG = belum ada angka uji. Satu baris di TIDAK DISARANKAN, lewati\n"
           "⚠️ MELEMAH DI LIVE = terbukti, tapi live 40 trade lebih PF di bawah 1. Setengah lot\n"
           "⚠️ Waspada di kartu = BTC 1 jam melawan atau berita dekat, lot sudah dipotong setengah")


BANTUAN = ("❓ <b>QSE v149 | BANTUAN</b>\n\n"
           "Robot berjalan otomatis: scan 4 jam dan per jam, sinyal semua jalur, pemantauan posisi tiap menit, "
           "peringatan dini, gabung posisi, berita, dan arah pasar tiap pagi jam 07:05 WIB. "
           "Aturan jaga modal juga otomatis: jam ke-12 SL naik ke -0.5R kalau harga melawan, batas 30 jam, jeda 24 jam setelah 3 rugi beruntun, "
           "dan model arah BTC dilatih ulang sendiri tiap Senin. Kalender berita 7 hari (FOMC, CPI, bank sentral, earnings, "
           "token unlock) dikirim tiap Senin 06:10 WIB, dan LONG baru ditahan 7 hari sebelum token unlock 1% atau lebih. "
           "Perintah di bawah hanya untuk hal yang perlu kamu putuskan sendiri.\n\n"
           "<b>Catat dan kelola trade</b>\n"
           "/entry long market SOL = catat entry (tambah sl tp1 tp2 kalau mau level sendiri)\n"           "/entry lalu tempel blok sinyal (Entry, SL, TP1, TP2) = langsung tercatat, koin dicari otomatis\n"
           "/modify SOL sl 140 tp1 160 = geser SL atau TP\n"
           "/tp SOL 50% atau /sl SOL 100% = ambil profit atau cut loss sebagian\n"
           "/tutup SOL = tutup semua sisa posisi\n"
           "/hapus SOL long = hapus catatan yang salah\n\n"
           "<b>Lihat</b>\n"
           "/status = posisi: teknik, nilai, angka siap isi di Bybit (SL TP terbaru), sampai kapan, total untung rugi, WR\n"
           "/tidur = cara aman meninggalkan posisi semalam, SL dan Trailing Stop tiap posisi\n"
           "/cek SOL = analisa lengkap satu koin\n"
           "/arah SOL = tren 15m sampai 1W dan pola sejarah koin\n"
           "Otomatis tanpa perintah: pengingat berita besar H-24 dan H-6 jam, NEWS PENTING, viral 13:00 dan 20:00 WIB\n"
           "/kabar dan /viral hanya kalau mau cek sendiri (/viral 6 = 6 jam terakhir)\n\n"
           "<b>Alarm</b>\n"
           "/tunggu SOL atas 150 4j = kabari saat candle 4J TUTUP di atas 150 (bawah juga bisa, TF 15m, 1j, 4j, 1d)\n"
           "/alert SOL 150 = kabari saat harga menyentuh 150\n\n"
           "<b>Arti tanda BUKTI di tiap sinyal</b>\nSinyal yang tampil lengkap = yang bisa diikuti. Sisanya tetap dicatat robot dan naik sendiri kalau terbukti di live.\n"
           "✅ TERBUKTI = untung di backtest 5 tahun (Ichimoku, Order Block + Volume). Ikuti semua, lot penuh\n"
           "✅ TERBUKTI LIVE = jalur sudah 30 trade live dengan PF 1.2 ke atas. Lot penuh\n"
           "🧪 SEDANG DIUJI = kelompok yang untung di uji (4J SHORT kelompok terbaik). Setengah lot\n"
           "⚠️ BELUM TERBUKTI = sudah diuji tapi hasilnya impas atau rugi. Satu baris di TIDAK DISARANKAN, lewati\n"
           "❔ BELUM DIUJI atau JARANG = belum ada angka uji. Satu baris di TIDAK DISARANKAN, lewati\n"
           "⚠️ MELEMAH DI LIVE = terbukti, tapi live 40 trade lebih PF di bawah 1. Setengah lot\n"
           "⚠️ Waspada di kartu = BTC 1 jam melawan atau berita dekat, lot sudah dipotong setengah\n\n"
           "<b>Lainnya</b>\n"
           "/modal = lihat slot, risiko SL, dan sisa waktu posisi kamu. /modal 155 1 5 = isi modal, risiko, leverage (dolar)\n"
           "/slok AUSDT = SL di Bybit sudah di entry setelah TP 20% kena\n"
           "/mingguan = laporan 7 hari: robot dan trade kamu lawan hasil uji. Otomatis tiap Senin 06:20 WIB\n"
           "/bantuan semua = daftar semua perintah\n"
           "/menu = munculkan lagi tombol menu di bawah kolom ketik")


def _sym(a):
    return a if a.endswith("USDT") else a + "USDT"


def _bot_bebas():
    lk = open(LOCK_BOT, "a")
    try:
        fcntl.flock(lk, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return lk
    except OSError:
        lk.close()
        return None


def _batal_sinyal(sym, dari_main):
    """Hapus sinyal robot koin ini dari catatan. Return teks keterangan."""
    if dari_main:
        led = FX.load()
        n = FX.batal_manual(led, sym)
        FX.save(led)
        return n, False
    lk = _bot_bebas()
    try:
        led = FX.load()
        ada = sum(1 for v in led["open"].values() if v["sym"] == sym)
        if not ada:
            return 0, False
        if lk:
            FX.batal_manual(led, sym)
            FX.save(led)
            return ada, False
        FX.antrian_tambah(sym)
        return ada, True
    finally:
        if lk:
            lk.close()


def balas(cmd, args, dari_main=False):
    if cmd == "/entry":
        return SY.entry(args)
    if cmd in ("/cek", "/cekdetail"):
        if not args:
            return "Format: /cek SOL atau /cek SOL long 185.4"
        sym = _sym(args[0])
        arah = next((("LONG" if a in ("LONG", "BUY") else "SHORT") for a in args[1:]
                     if a in ("LONG", "SHORT", "BUY", "SELL")), None)
        harga = next((SY._angka(a) for a in args[1:] if SY._angka(a) is not None), None)
        if cmd == "/cekdetail":
            return SY.konsultasi(sym, arah, harga)
        return SY.cek_jalur(sym, arah, harga)
    if cmd in ("/tutup", "/tp", "/sl") and args and args[0] in ("ALL", "SEMUA", "ALLUSDT", "SEMUAUSDT"):
        return SY.tutup_semua({"/tp": "ambil profit", "/sl": "cut loss"}.get(cmd, "TUTUP"))
    if cmd in ("/tpall", "/tpsemua"):
        return SY.tutup_semua("ambil profit")
    if cmd in ("/slall", "/slsemua"):
        return SY.tutup_semua("cut loss")
    if cmd == "/tutup":
        return SY.tutup(args)
    if cmd == "/mode":
        import qse_strat as ST
        if args:
            m = ST.set_mode(args[0])
            if not m:
                return "Pilihan: /mode semua, /mode profit, atau /mode raja"
        m = ST.mode_sinyal()
        return (f"Mode sinyal sekarang: <b>{m.upper()}</b> (skor label minimal {ST.MODE_MIN[m]})\n\n"
                "• /mode semua: semua sinyal jalur terbukti. Uji 2021-2026 PF 1.24 dan 1.28, sekitar 15 sinyal per hari sebelum batas posisi\n"
                "• /mode profit: skor label 5 ke atas. PF 1.65 dan 1.77, WR 44-45%, sekitar 2 sinyal per hari, drawdown 4 kali lebih kecil\n"
                "• /mode raja: skor label 8 ke atas. PF 2.25 dan 2.22, WR 48%, sekitar 1 sinyal per 2-3 hari\n\n"
                "Tidak ada mode yang pasti untung. Mode profit tetap kena SL sekitar 55% trade, untungnya dari trade menang yang lebih besar.")
    if cmd == "/pindah":
        return SY.pindah(args)
    if cmd == "/tp":
        return SY.tutup(args, "ambil profit")
    if cmd == "/sl":
        return SY.tutup(args, "cut loss")
    if cmd == "/tespin":
        ids = TG.send(["📌 <b>QSE v149 | TES PIN</b>\nKalau pesan ini tersemat, izin pin bot sudah benar."]) or []
        if not ids:
            return "Pesan tes gagal terkirim."
        err = TG.pin(ids[0])
        return ("✅ Pin berhasil. Sinyal 4 jam berikutnya akan otomatis disematkan dan pin lama dilepas."
                if not err else f"❌ Pin gagal. Kata Telegram: {TG.e(str(err))}\nBuka info grup, Administrator, pilih bot, "
                f"lalu aktifkan izin Sematkan pesan (Pin messages).")
    if cmd == "/kalibrasi":
        return SY.kalibrasi_teks(args[0]) if args else "Format: /kalibrasi ETHFI"
    if cmd == "/serok":
        return SY.serok(args)
    if cmd == "/hapus":
        return SY.hapus(args)
    if cmd in ("/ubah", "/modify", "/modif", "/edit"):
        return SY.ubah_level(args)
    if cmd in ("/alert", "/alarm"):
        return AL.perintah(args)
    if cmd in ("/tunggu", "/close"):
        return AL.tunggu(args)
    if cmd in ("/sinyal4j", "/sinyal4", "/sinyal", "/scan"):
        return SY.sinyal_jalur()
    if cmd in ("/sinyal1j", "/sinyal1"):
        return ("Saran 1J dimatikan. Uji 111 koin data 1 jam 2020-2026: 9 jalur terbukti versi 1J PF 1.00 sampai 1.11, "
                "tidak ada yang untung setelah biaya. Pakai /sinyal4j.")
    if cmd in ("/laporan4j", "/laporan", "/susul"):
        return mulai_laporan4j()
    if cmd in ("/jalur", "/rekapjalur"):
        import qse_catat as CT
        return CT.teks()
    if cmd in ("/mingguan", "/pekan"):
        import qse_mingguan as MG
        return MG.teks()
    if cmd in ("/arah", "/tren"):
        import qse_arah as AR
        return AR.teks(args)
    if cmd in ("/strategi", "/strat", "/ema", "/rsi", "/mcginley", "/mcg", "/snr", "/msb", "/smc"):
        import qse_strat as ST
        return ST.teks()
    if cmd in ("/ob", "/orderblock"):
        import qse_ob as OB
        return OB.teks()
    if cmd in ("/lab", "/papan"):
        import qse_lab as LB
        return LB.status_teks()
    if cmd in ("/pelengkap", "/sektor"):
        import qse_sektor as SKT
        return SKT.teks()
    if cmd in ("/ichimoku", "/ichi"):
        import qse_ichimoku as IC
        return IC.teks()
    if cmd in ("/altseason", "/alt"):
        import qse_altseason as AS
        return AS.teks() or "Data altcoin gagal diambil, coba lagi nanti."
    if cmd in ("/ujimomentum", "/ujimom"):
        return ("Momentum 15/30 menit dimatikan. Uji 40 koin paling likuid data 15 menit 2021-2026: aturan robot PF 0.58 (15 menit) "
                "dan 0.67 (30 menit). Variasi terbaik PF 1.06, tetap tidak lolos.")
        import qse_momentum as MO
        try:
            with open(os.path.join(STATE_DIR, "screening_terbaru.json")) as f:
                lama = json.load(f)
        except Exception:
            return "Belum ada hasil scan 4 jam. Coba lagi setelah laporan 4 jam keluar."
        sym = [r["symbol"] for r in lama if r.get("tf", "240") == "240" and r["rapor"] in ("A", "B")]
        if args:
            sym = [a.upper() if a.upper().endswith("USDT") else a.upper() + "USDT" for a in args]
        return MO.uji(sym) if sym else "Belum ada koin rapor A/B untuk diuji."
    if cmd in ("/kabar", "/info"):
        import qse_news as NW
        return NW.kabar()
    if cmd in ("/viral", "/trending", "/hits", "/hot"):
        import qse_news as NW
        try:
            jam = int(args[0]) if args else 24
        except ValueError:
            jam = 24
        return NW.viral(max(1, min(72, jam)))
    if cmd in ("/berita", "/news"):
        import qse_news as NW
        return NW.tes()
    if cmd == "/modal":
        import qse_modal as MD
        return MD.perintah(args)
    if cmd in ("/slok", "/slsudah"):
        return SY.slok(args)
    if cmd == "/evaluasi":
        return SY.evaluasi()
    if cmd == "/uji":
        import qse_uji as QU
        return QU.ringkas()
    if cmd == "/batal":
        if not args:
            return "Format: /batal AUSDT"
        rows = []
        for a in args:
            sym = _sym(a)
            n_sig, antri = _batal_sinyal(sym, dari_main)
            n_saya, jalan = SY.batal(sym)
            bag = []
            if n_sig:
                bag.append(f"{n_sig} saran robot dihapus dari daftar pantau" + (" (tercatat permanen setelah scan selesai)" if antri else ""))
            if n_saya:
                bag.append(f"{n_saya} order kamu yang belum terisi dibatalkan")
            if jalan:
                bag.append(f"{jalan} posisi kamu masih jalan, pakai /tutup {a} HARGA untuk keluar")
            rows.append(f"➡️ {sym}: " + ("; ".join(bag) if bag else "tidak ada order terbuka"))
        return "\n".join(rows)
    if cmd in ("/tidur", "/sl_terbaru", "/slterbaru"):
        teks, _ = SY.kartu_sl(tidur=cmd == "/tidur")
        return teks or ("😴 <b>QSE v149 | SIAP TIDUR</b>\nTidak ada posisi jalan. Tidak ada yang perlu diatur. Sinyal jam 23:00 dan "
                        "03:00 WIB masih bisa kamu ikuti pagi di laporan 07:05, selama harga masih dekat entry robot.")
    if cmd == "/status":
        try:
            with open(os.path.join(STATE_DIR, "state.json")) as f:
                s4 = json.load(f).get("scan4")
        except Exception:
            s4 = None
        akhir = time.strftime("%d/%m %H:%M", time.gmtime(s4 / 1000 + 7 * 3600)) if s4 else "-"
        return ("📊 <b>QSE v149 | STATUS</b>" + (f"  ·  👤 {SY.nama_pengguna(SY.uid_aktif())}" if SY.uid_aktif() else "")
                + "\n" + f"Scan 4 jam terakhir: candle tutup {akhir} WIB\n\n" + SY.status_saya()
                + ("" if SY._peng().get("pemilik") else "\n\nℹ️ Ketik /milikku supaya catatan trade lama jadi milik kamu. "
                   "Trade orang lain di grup tercatat terpisah."))
    if cmd in ("/bantuan", "/help", "/start"):
        return BANTUAN_SEMUA if args and args[0] in ("SEMUA", "ALL", "LENGKAP") else BANTUAN
    return ""


def proses(cmds, dari_main=False):
    """Jalankan daftar (perintah, argumen), kirim balasan ke Telegram. Return jumlah dibalas."""
    n = 0
    for item in cmds:
        cmd, args = item[0], item[1]
        uid, nama = (item[2], item[3]) if len(item) >= 4 else (None, "")
        args = [x for x in (re.sub(r"[^A-Z0-9.,:/%]", "", a.upper()) for a in args) if x]
        try:
            if uid is not None:
                SY.pakai(uid, nama)       # catatan trade milik pengirim perintah
            if cmd in ("/milikku", "/punyaku"):
                isi = SY.milikku(uid, nama) if uid is not None else "Kirim dari grup supaya pengirimnya dikenali."
            else:
                isi = balas(cmd, args, dari_main)
        except Exception as ex:
            isi = f"Perintah gagal: {TG.e(str(ex)[:200])}"
        finally:
            SY.pakai(None)
        if isi:
            ikon = {"/entry": "📝", "/cek": "🧐", "/cekdetail": "🧐", "/tutup": "✋", "/tp": "💰", "/sl": "🛑", "/ubah": "✏️", "/modify": "✏️", "/modif": "✏️", "/edit": "✏️", "/hapus": "🗑️", "/serok": "➕", "/kalibrasi": "🧪", "/tespin": "📌", "/batal": "❌", "/alert": "🔔", "/alarm": "🔔", "/tunggu": "⏳", "/close": "⏳", "/evaluasi": "📚",
                    "/uji": "🧪", "/mingguan": "📅", "/pekan": "📅", "/modal": "💼", "/scan": "🔎", "/laporan4j": "📊", "/laporan": "📊", "/susul": "📊", "/berita": "📰", "/kabar": "📰", "/viral": "🔥", "/trending": "🔥", "/hits": "🔥", "/hot": "🔥", "/info": "📰", "/ujimomentum": "⚡", "/jalur": "📒", "/rekapjalur": "📒", "/altseason": "🌈", "/ichimoku": "📈", "/pelengkap": "🧩", "/lab": "🧪", "/papan": "🧪", "/menu": "🤖", "/sektor": "🧩", "/ob": "⭐", "/strategi": "📈", "/strat": "📈", "/ema": "📈", "/rsi": "📈", "/orderblock": "⭐", "/smc": "⭐", "/arah": "🧭", "/tren": "🧭", "/ichi": "📈", "/alt": "🌈", "/ujimom": "⚡", "/news": "📰", "/sinyal4j": "📡", "/sinyal4": "📡",
                    "/sinyal": "📡", "/sinyal1j": "📡", "/sinyal1": "📡",
                    "/bantuan": "❓", "/milikku": "👤", "/pindah": "🔀", "/mode": "🎚️", "/tpall": "💰", "/tpsemua": "💰", "/slall": "🛑", "/slsemua": "🛑", "/punyaku": "👤", "/help": "❓", "/start": "❓"}
            isi = isi if "QSE v149 |" in isi.split("\n")[0] else f"{ikon.get(cmd, '🤖')} <b>QSE v149 | {cmd.upper()[1:]}</b>\n\n{isi}"
            TG.send(isi.split("\n\n"))
            n += 1
    return n
